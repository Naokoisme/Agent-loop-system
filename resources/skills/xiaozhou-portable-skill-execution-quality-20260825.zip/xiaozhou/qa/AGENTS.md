# 小周 QA 能力边界

本目录是 `$xiaozhou` 内置、可迁移的 QA 能力包。普通测试任务不要把本文件当作流程说明反复加载；唯一生产入口是 [`workflow-v2/SKILL.md`](workflow-v2/SKILL.md)。

## 便携边界

- 只通过相对路径使用本目录内的主控、知识、参考、模板、检索、导出和门禁能力；不搜索、不要求、不调用外部 `qatest_-skill`。
- 新环境安装、能力更新或制作便携包时，才读取本文件并运行：`python scripts/bootstrap.py --install`、`python scripts/quick_validate.py --json`、`python scripts/smoke_test.py --json`、`python scripts/verify_portable_package.py --json`。
- 便携包只包含可复用能力；客户 PRD、项目工作区、生成用例、报告、密钥、缓存、备份、虚拟环境和 Git 历史不得打包。
- 共享能力更新后仍须保持全部运行路径相对本目录；远程同步只在用户明确要求时执行。

## 数据边界

- 新项目通过 `--workspace-root <外部项目根目录>` 写入 Skill 外部工作区，不把机器绝对路径写入 Skill。
- 缺少执行画像的历史 `workflow-v2/projects/` 项目按严格兼容路径读取；迁移前先清单和哈希，未经用户授权不移动、不删除。
- 普通生产任务只写当前项目目录及其 `workunits/`；`knowledge/`、`references/`、`scripts/`、模板和 manifest 保持只读。
- 只有用户明确要求改善 QA 能力时，才允许修改共享能力，并执行完整回归和便携校验。

## 唯一入口

- PRD、蓝湖、需求或已有 Excel 到可交付测试用例：读 [`workflow-v2/SKILL.md`](workflow-v2/SKILL.md)。
- 单独输出测试计划、测试方案、测试策略或测试点：由主控路由到 [`test-planning/SKILL.md`](test-planning/SKILL.md)。
- 详细规则只按入口路由读取 1 至 3 份命中参考；禁止预加载整个 `knowledge/`、`references/` 或四份入口文档。

## 禁止事项

- 用例质量优先,数量其次；禁止用条数配额代替覆盖，禁止为凑数重复拆分或为压数合并独立风险。
- 参数必须来自 PRD 或真实产品，正式测试点写成 `验证设置<参数名>为<具体值>`；缺值写 `待产品确认:<具体问题>`，禁止编造。
- 禁止绕过 `执行画像.json`、核心 S1-S36、按平台画像启用的 S37、措辞/归类/顺序/功能边界人员执行质量门禁、最终 Excel 实物验收或当前文件哈希绑定。
- 禁止把普通任务自动升级为完整追溯、先导、四 Reviewer 或正式准出；只有路由命中能力包或用户明确要求时升级。
- 子代理或工作单只能交回局部产物和自检结果，不能宣布整体交付完成。
- 外部发送边界只按 [`../references/qa-testcase-delivery.md`](../references/qa-testcase-delivery.md) 执行，本入口不重复定义。
