# Xiaozhou Portable QA Usage

## Purpose

This file explains how Codex, Claude Code, Cursor, ChatGPT, Gemini, Kimi, DeepSeek, or another AI agent should use this bundled QA capability.

This bundled QA package is not a lightweight generic prompt pack. It is the portable project-level test-case production line inside `$xiaozhou`, with workflow orchestration, local knowledge retrieval, Excel delivery, structure gates, coverage traceability, and reinforcement loops.

It must run from its own directory tree and must not depend on an external repository path, drive letter, or Git checkout.

## Mandatory Entry

For PRD, Lanhu, requirement, test-case, full workflow, or delivery tasks, read first:

```text
AGENTS.md
workflow-v2/SKILL.md
test-planning/SKILL.md
```

Then follow `workflow-v2/SKILL.md` as the main production line.

For a new production project, run the contract-declared pilot modules first with `python workflow-v2/scripts/casegen.py --project <project> --pilot`. Review `pilot_cases/`, lock `pilot_acceptance`, and only then run the same command without `--pilot` to create formal `cases/`.

## Main Routing

```text
PRD / Lanhu / requirement -> test cases:
  Use workflow-v2/SKILL.md.

Vague requirement / "how to test":
  Use references/beachburg-qa-strategy.md, then return to workflow-v2 or test-planning.

Release decision:
  Use references/beachburg-release-gate.md and map evidence to gates A/B/C.

Escaped defect / missed case / review rejection:
  Use references/beachburg-defect-retrospective.md.

Code, script, gate, export, traceability, or automation fix:
  Use references/tdd-real-verification.md and report real commands and outputs.
```

## Non-Negotiable Existing Capabilities

Do not skip or weaken:

- `workflow-v2` main flow.
- Lanhu / PRD parsing.
- Product-shape identification.
- Local knowledge retrieval.
- Fixed case hierarchy.
- Excel standard 15-column delivery.
- S1-S37 gates, including concrete semantics, preconditions, manual feasibility, ownership, conflict disposition, scenario completeness, hierarchy continuity, Android/iOS main-flow coverage, and concise regression wording.
- Coverage traceability.
- Reinforcement loop.
- Earbud charging case, watch, APP-IoT and other business templates.
- Pre-generation acceptance contract and pilot-module gate.
- Structured preconditions/steps/expected without conjunction-based semantic guessing.
- Auditable decision-table/orthogonal dataset rows and pending-evidence coverage tiers.
- Unified machine audit envelope with separate blocking and risk counts.

## Reading Rule

Read only what the current task needs.

Do not load the entire `knowledge/`, `references/`, or `projects/` tree at once. Use the routers and search scripts described in `test-planning/SKILL.md`.

## Verification Rule

Do not invent test results.

When commands are run, report actual commands and actual output summaries. When commands are not run, state why and what risk remains.

## Environment Setup

Install the bundled dependencies from the QA root:

```powershell
python -m pip install -r requirements.txt
python scripts/quick_validate.py --json
python scripts/verify_portable_package.py --json
python scripts/smoke_test.py --json
```

`openpyxl` is required for testcase Excel generation and gates. OCR dependencies are included for Lanhu/screenshot PRD extraction.
