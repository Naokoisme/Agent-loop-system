# 测试工作流 v2（workflow-v2）

> Gitee 团队 QA 仓库的端到端主控目录。当前生产规则以 `SKILL.md` 为准；本文件只保留目录与追溯器的快速说明，不能覆盖 S1-S35、双轴覆盖和最终 Excel 实物验收要求。

## 这是什么

把「提需求 → 蓝湖拆解 → PRD → PRD 审查 → 识别产品形态 → 生成前蓝图 → 第一版用例（知识库+框架）→ 用例审查 → PRD追溯 → 场景完整度 → 最终 Excel 实物验收 → 产物就绪」做成一条显式、有门禁、可编排的流水线。

覆盖追溯器只负责 PRD 显式条款映射；全功能准出还必须通过 Gate C S1-S35、场景覆盖矩阵和最终 Excel 语义/物理验收。覆盖率 100% 不是免检金牌，这次已经交过学费。

## 目录结构

```
workflow-v2/
├── README.md                      本文件
├── scripts/
│   ├── tc_excel.py                通用测试用例 Excel 读写器（标准 15 列、主表+分页、样式、合并）
│   ├── lineage.py                 schema v3 构建血缘（source→cases→Excel/稳定索引→追溯底稿→准出）
│   └── traceability/              覆盖追溯器
│       ├── trace_extract.py       步骤1 抽取：PRD+用例 → 工作底稿
│       ├── trace_assemble.py      步骤3 汇总：结果 → 覆盖矩阵 xlsx
│       ├── trace_gate.py          门禁：算覆盖率、出缺口、PASS/FAIL
│       └── trace_insert.py        闭环回插：补充用例按锚点插回主表
├── references/
│   └── 覆盖追溯判定规范.md         步骤2「逐条判定覆盖」的 AI 判定契约（I/O 规范）
├── knowledge/
│   └── 功能模块/                   从原知识库搬入的可复用模块模板（质量好的部分打底）
└── projects/
    └── <项目名>/
        ├── trace.config.json      项目配置（原本硬编码的全部参数）
        ├── 用例设计蓝图.json       生成前归属、排序、矩阵和人工前置合同
        ├── 冲突矩阵索引.json       affected owner / 复用 / N/A / 待确认
        ├── 场景覆盖矩阵.json       PRD之外的全功能场景完整度轴
        ├── 工作底稿/              extract 产物
        ├── 结果/                  AI 判定产物（按判定规范）
        └── 补充用例/              gate 产出的缺口 + AI 补的新用例
```

## 覆盖追溯三步（设计内核）

| 步骤 | 谁做 | 输入 → 输出 |
|---|---|---|
| 1 抽取 | 脚本 `trace_extract.py` | PRD 章节 + 用例 xlsx → `工作底稿/<模块>.json` |
| 2 判定 | **AI**（按 `references/覆盖追溯判定规范.md`） | 工作底稿 → `结果/<模块>.json`（testable/status/matched_ids/note） |
| 3 汇总+门禁 | 脚本 `trace_assemble.py` / `trace_gate.py` | 结果 → 覆盖矩阵 xlsx + 缺口清单 + PASS/FAIL |

**抽取/汇总是机械的（脚本）；逐条判定覆盖是智能内核（AI）。** 判定结果必须与需求同序、引用真实用例编号；缺模块、0条可测需求、未接受的部分覆盖或无效 matched_ids 都会由门禁拒绝。

## 怎么用（以一个项目为例）

```powershell
cd workflow-v2
# 1. 抽取
python scripts/traceability/trace_extract.py --config projects/<项目>/trace.config.json
# 2. AI 按 references/覆盖追溯判定规范.md 逐模块判定，产出 结果/<模块>.json
# 3. 汇总矩阵
python scripts/traceability/trace_assemble.py --config projects/<项目>/trace.config.json
# 4. 门禁（不达阈值出缺口、退出码非0）
python scripts/traceability/trace_gate.py --config projects/<项目>/trace.config.json
# 5.（缺口补完后）回插主表
python scripts/traceability/trace_insert.py --config projects/<项目>/trace.config.json --base <原用例xlsx> --out <补强后xlsx>
# 6. 结构、语义、归属、人工可执行性与场景完整度门禁
python scripts/check_structure.py --config projects/<项目>/trace.config.json
# 7. 单一最终准出（含反馈扫描与分层抽样）
python scripts/release_acceptance.py --config projects/<项目>/trace.config.json
```

schema v3 项目会由 `lineage.py` 逐阶段记录并校验 SHA-256 与父构建 ID。源 spec、正式 cases、Excel、稳定索引或追溯底稿任一被单独修改后，最终准出会阻断，并要求从对应阶段重新构建；不得只改下游文件后沿用旧 PASS。

生成和导出共用项目级构建锁，并在全部门禁通过后先暂存、回读再提交。`用例稳定索引.json` schema v2 的 `items` 只保存当前用例，删除记录进入 `retired_items` 墓碑，`high_water` 保存各锁定前缀历史最大序号；新稳定身份只能从该尾号连续追加，恢复旧身份必须取回原编号。静默改号一律阻断；只有显式 `--renumber --migration-file` 才会输出按 `stable_id / old_case_ids[] / new_case_id` 绑定的结构化迁移记录。

判定表法/正交试验法的每一行必须把因素落实到人工正文。schema v3（或 `quality_gates.functional_manual_contract.required=true`）使用以下不可关闭的证据结构：

```json
{
  "method": "正交试验法",
  "dataset_id": "PRIORITY_OA_001",
  "factors": ["事件A=消息", "事件B=闹钟", "顺序=A后B"],
  "factor_evidence": [
    {"factor": "事件A=消息", "field": "step", "fragments": ["发送消息"]},
    {"factor": "事件B=闹钟", "field": "step", "fragments": ["设备闹钟到点"]},
    {"factor": "顺序=A后B", "field": "step", "fragments": ["发送消息", "设备闹钟到点"]}
  ]
}
```

`field` 仅允许 `pre/step/exp`，结构化的 `preconditions/steps/expected` 会映射到这三个逻辑字段。每个 factor 必须且只能有一条 evidence；片段必须至少含两个有效字母、数字或汉字，在指定正文中精确存在并保持声明顺序。缺失、额外、重复、非法字段、正文不存在或逆序都会在写入稳定 ID 和 `cases/` 前阻断。schema v1 且未显式启用人工功能合同的遗留项目保持兼容。

分层抽样默认要求最近变更、高风险/P0、待确认、交叉/冲突和每功能点均有候选。若项目确实不存在某一层，必须在 `trace.config.json -> release_acceptance.strata_not_applicable` 为该层写具体原因；空理由或已有候选却声明不适用会阻断准出。

## 边界（重要）

- 普通项目生产只读共享规则、知识库和模板；所有项目产物写在 `projects/<项目>/` 内。
- 只有用户明确要求改善团队 QA 能力时，才修改共享脚本、规则、知识和模板。
- 固定流程终点是最终 Excel 验收完成、产物就绪并返回路径；外部发送需要当前用户明确指定渠道和收件人。
