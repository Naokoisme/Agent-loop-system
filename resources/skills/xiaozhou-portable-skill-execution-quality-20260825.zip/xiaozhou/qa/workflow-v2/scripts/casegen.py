# -*- coding: utf-8 -*-
"""用例生成流水线(仓库级通用)。代码在此,数据在 projects/<项目>/ 内。

一条命令把项目的紧凑 spec 展开为标准 15 列用例,并按显式蓝图补界面操作/交叉、归一功能点并分组:
  python scripts/casegen.py --project <项目名>
  python scripts/casegen.py --project <项目名> --pilot  # 仅先导模块,输出 pilot_cases/

读取(都在 projects/<项目>/ 下,缺省即跳过对应步骤):
  specs/*.json     紧凑用例 spec(必需)         —— 见下"spec 格式"
  ui_pages.json    界面操作页面清单(可选)      —— {module:[{page,fp?,pre?,ov?}]}
  cross.json       交叉场景配置(可选)          —— 只接受显式 items;每格声明受影响模块与处置
  fpmap.json       功能点归一映射(可选)        —— {GLOBAL:{},MODULES:{module:{}}}
输出:cases/*.json(标准15列;功能点按首次出现稳定分组,同功能点连续)

之后照常:scripts/export_cases.py --project <项目> --order ... --renumber --migration-file 用例编号迁移.json
        → trace_extract → judge_build → trace_gate(门禁B) → check_structure(门禁C)

spec 格式(每模块一个 specs/<模块>.json):
  {"module":"血氧","prefix":"SPO2","default_pre":"...","default_compat":"N/A",
   "cases":[{"_stable_id":"CASE::<uuid>","fp":功能点,"ti":测试项,"tp":测试点,"step":步骤,"exp":预期,
             "pri":优先级,"pre":前置,"compat":兼容性,"note":备注,"fw":固件,"hw":型号,"way":方式}]}
  缩写:fp/ti/tp/step/exp 必填核心;其余有默认值。

新格式可用 ``preconditions/steps/expected`` 非空字符串数组替代 ``pre/step/exp``，
由生成器确定性输出同编号逐行文本。新旧字段不得在同一用例混用；生成器不会按“且、并、
同时、然后”等连接词猜测拆句。判定表法/正交试验法数据行另带
``method/dataset_id/factors``，输出为下划线元数据且不改变标准15列。

规则仍待确认时可带 ``risk``（或兼容别名 ``_risk``）；该元数据会沿稳定索引进入追溯门禁，不能被15列表格丢失。

首次运行会为普通 spec 用例和 ui_pages 页面写回一次性 UUID 稳定 ID；之后改标题、插入或重排均复用原 ID。
冲突矩阵用例以显式 matrix_key 作为稳定身份；matrix_key 必须非空且全项目唯一。
"""
from __future__ import annotations
import argparse, copy, json, re, tempfile
from pathlib import Path

from generation_contract import (
    GenerationContractError,
    PreparedSpec,
    load_and_validate_generation_inputs,
)
from execution_profile import load_profile, required_blueprint_keys
from project_paths import resolve_project
from build_lock import project_build_lock
from lineage import LINEAGE_REL, LineageError, record_casegen, verify_stable_index_history
from quality_semantics import check_functional_manual_contract, check_step_expected_contract
from stable_ids import (
    StableIdentityError,
    build_identity_maps,
    case_stable_identity,
    commit_staged_files,
    ensure_case_stable_id,
    ensure_page_stable_id,
)

ROOT = Path(__file__).resolve().parents[1]          # workflow-v2/
COLS = ["用例编号", "功能模块", "功能点", "测试项", "测试点/检查项", "前置条件", "操作步骤",
        "预期结果", "优先级", "兼容性", "是否自动化", "固件版本", "硬件型号", "测试方式", "备注"]

# 界面操作:标准手势集 + 默认可判定预期(ov 可逐手势覆盖)
GESTURES = ["上滑", "下滑", "左滑", "右滑", "单击侧键", "双击侧键", "长按侧键3s", "长按侧键10s"]
GKW = {"上滑": "上滑", "下滑": "下滑", "左滑": "左滑", "右滑": "右滑",
       "单击侧键": "单击", "双击侧键": "双击", "长按侧键3s": "3s", "长按侧键10s": "10s"}
GDEFAULT = {
    "上滑": "上滑无响应,页面保持当前", "下滑": "下滑无响应,页面保持当前",
    "左滑": "左滑无响应,页面保持当前", "右滑": "右滑返回上一级",
    "单击侧键": "单击侧键按按键定义返回上一级或主表盘", "双击侧键": "双击侧键无响应",
    "长按侧键3s": "长按侧键3s进入三合一页面", "长按侧键10s": "长按侧键10s设备硬重启",
}
def _pdir(name: str, workspace_root: str | Path | None = None) -> Path:
    return resolve_project(name, workspace_root=workspace_root)


def _load(p: Path):
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else None


def expand_specs(
    prepared_specs: list[PreparedSpec],
) -> tuple[dict[str, list[dict]], dict[Path, dict]]:
    out: dict[str, list[dict]] = {}
    changed_specs: dict[Path, dict] = {}
    for prepared_spec in prepared_specs:
        source = prepared_spec.path
        s = prepared_spec.data
        mod, prefix = prepared_spec.module, prepared_spec.prefix
        dpre, dcompat = s.get("default_pre", ""), s.get("default_compat", "Android/iOS")
        rows = []
        changed = False
        for i, prepared_case in enumerate(prepared_spec.cases, 1):
            c = prepared_case.source
            try:
                stable_id, case_changed = ensure_case_stable_id(c)
            except StableIdentityError as exc:
                raise SystemExit(f"{source.name} 第{i}条用例稳定ID异常: {exc}") from exc
            changed = changed or case_changed
            precondition = prepared_case.precondition_text if (
                "pre" in c or "preconditions" in c
            ) else dpre
            row = {
                "用例编号": "", "功能模块": mod, "功能点": c.get("fp", ""),
                "测试项": c.get("ti", ""), "测试点/检查项": c.get("tp", ""), "前置条件": precondition,
                "操作步骤": prepared_case.step_text, "预期结果": prepared_case.expected_text,
                "优先级": c.get("pri", "P2"),
                "兼容性": c.get("compat", dcompat), "是否自动化": c.get("auto", "否"),
                "固件版本": c.get("fw", ""), "硬件型号": c.get("hw", ""), "测试方式": c.get("way", "人工执行"),
                "备注": c.get("note", ""), "_stable_id": stable_id,
            }
            if prepared_case.method:
                row["_method"] = prepared_case.method
            if prepared_case.dataset_id:
                row["_dataset_id"] = prepared_case.dataset_id
            if prepared_case.factors:
                row["_factors"] = prepared_case.factors
            if prepared_case.method or prepared_case.dataset_id or prepared_case.factors:
                row["_design"] = {
                    "method": prepared_case.method,
                    "dataset_id": prepared_case.dataset_id,
                    "factors": list(prepared_case.factors),
                }
                if "factor_evidence" in c:
                    row["_design"]["factor_evidence"] = copy.deepcopy(c["factor_evidence"])
            if "preconditions" in c:
                row["_detail_contract"] = {
                    "schema_version": 1,
                    "source_kind": "structured",
                    "preconditions": copy.deepcopy(c["preconditions"]),
                    "steps": copy.deepcopy(c["steps"]),
                    "expected": copy.deepcopy(c["expected"]),
                }
            risk = c.get("risk") if "risk" in c else c.get("_risk")
            if risk not in (None, "", {}, []):
                row["_risk"] = copy.deepcopy(risk)
            rows.append(row)
        if changed:
            changed_specs[source] = s
        out[mod] = rows
    return out, changed_specs


def preflight_prepared_specs(prepared_specs: list[PreparedSpec]) -> None:
    """Validate the human-facing contract before stable IDs or cases are written."""
    rows: list[dict] = []
    for prepared_spec in prepared_specs:
        data = prepared_spec.data
        default_pre = data.get("default_pre", "")
        default_compat = data.get("default_compat", "Android/iOS")
        for index, prepared_case in enumerate(prepared_spec.cases, 1):
            source = prepared_case.source
            rows.append({
                "用例编号": f"{prepared_spec.prefix}_{index:03d}",
                "功能模块": prepared_spec.module,
                "功能点": source.get("fp", ""),
                "测试项": source.get("ti", ""),
                "测试点/检查项": source.get("tp", ""),
                "前置条件": prepared_case.precondition_text if (
                    "pre" in source or "preconditions" in source
                ) else default_pre,
                "操作步骤": prepared_case.step_text,
                "预期结果": prepared_case.expected_text,
                "优先级": source.get("pri", "P2"),
                "兼容性": source.get("compat", default_compat),
                "是否自动化": source.get("auto", "否"),
                "固件版本": source.get("fw", ""),
                "硬件型号": source.get("hw", ""),
                "测试方式": source.get("way", "人工执行"),
                "备注": source.get("note", ""),
            })
    violations = check_functional_manual_contract(rows)
    violations.extend(check_step_expected_contract(rows))
    if violations:
        preview = "\n".join(f"  {item}" for item in violations[:50])
        extra = len(violations) - 50
        suffix = f"\n  ... 其余 {extra} 处" if extra > 0 else ""
        raise SystemExit(
            "功能测试用例人工执行合同未通过，禁止生成cases：\n" + preview + suffix
        )


def inject_ui(cases: dict, ui_pages: dict) -> bool:
    changed = False
    for module, pages in ui_pages.items():
        if not isinstance(pages, list):
            raise SystemExit(f"ui_pages.json {module} 必须是页面数组")
        rows = cases.get(module)
        if rows is None:
            raise SystemExit(f"ui_pages.json 模块不存在于 specs: {module}")
        tps = [r["测试点/检查项"] for r in rows]
        for page_index, pg in enumerate(pages, 1):
            try:
                page_id, page_changed = ensure_page_stable_id(pg)
            except StableIdentityError as exc:
                raise SystemExit(f"ui_pages.json {module} 第{page_index}个页面稳定ID异常: {exc}") from exc
            changed = changed or page_changed
            page = pg["page"]
            fp = pg.get("fp", page)
            pre = pg.get("pre", f"1.已进入{page}")
            ov = pg.get("ov", {})
            for g in GESTURES:
                if any((page in t and GKW[g] in t) for t in tps):
                    continue
                tp = f"验证{page}{g}响应"
                rows.append({"用例编号": "", "功能模块": module, "功能点": fp, "测试项": "界面操作",
                             "测试点/检查项": tp, "前置条件": pre, "操作步骤": f"1.在{page}执行{g}",
                             "预期结果": f"1.{ov.get(g, GDEFAULT[g])}", "优先级": "P3", "兼容性": "N/A",
                             "是否自动化": "否", "固件版本": "", "硬件型号": "", "测试方式": "人工执行", "备注": "",
                             "_stable_id": f"{page_id}::INPUT::{g}"})
                tps.append(tp)
    return changed


def inject_cross(cases: dict, cross_cfg: dict, *, allowed_modules: set[str] | None = None):
    """Only materialize explicit generated cells from the design blueprint.

    Legacy ``{module:{state,mode}}`` input is rejected because it blindly creates
    four cross cases, guesses results, and assigns them to the wrong module.
    """
    items = cross_cfg.get("items") if isinstance(cross_cfg, dict) else None
    if not isinstance(items, list):
        raise SystemExit(
            "cross.json 旧版自动铺场景格式已停用；请提供 items，并为每格声明 "
            "affected_module/status/coverage_kind。规则不明确时用 pending_confirmation/rule_only/not_applicable。"
        )
    matrix_keys: set[str] = set()
    for item_index, item in enumerate(items, 1):
        key = str(item.get("matrix_key", "") or "").strip()
        if not key:
            raise SystemExit(f"冲突矩阵第{item_index}格缺 matrix_key，禁止用动作/状态或列表位置临时生成稳定身份")
        if key in matrix_keys:
            raise SystemExit(f"冲突矩阵 matrix_key 重复，禁止生成: {key}")
        matrix_keys.add(key)
        status = str(item.get("status", ""))
        kind = str(item.get("coverage_kind", ""))
        if status != "covered" or kind != "generated":
            continue
        module = str(item.get("affected_module", ""))
        if allowed_modules is not None and module not in allowed_modules:
            continue
        rows = cases.get(module)
        if rows is None:
            raise SystemExit(f"冲突矩阵 affected_module 不存在于 specs: {module}")
        required = ["action", "state", "test_point", "preconditions", "steps", "expected"]
        missing = [field for field in required if not item.get(field)]
        if missing:
            raise SystemExit(f"冲突矩阵 generated 格缺字段 {missing}: {item.get('matrix_key','')}")
        row = {
            "用例编号": "",
            "功能模块": module,
            "功能点": str(item.get("feature_point", "交叉场景")),
            "测试项": str(item.get("test_item", item["action"])),
            "测试点/检查项": str(item["test_point"]),
            "前置条件": str(item["preconditions"]),
            "操作步骤": str(item["steps"]),
            "预期结果": str(item["expected"]),
            "优先级": str(item.get("priority", "P1")),
            "兼容性": str(item.get("compatibility", "N/A")),
            "是否自动化": str(item.get("automation", "否")),
            "固件版本": str(item.get("firmware", "")),
            "硬件型号": str(item.get("hardware", "")),
            "测试方式": str(item.get("test_method", "人工执行")),
            "备注": str(item.get("note", "")),
            "_matrix_key": key,
        }
        risk = item.get("risk") if "risk" in item else item.get("_risk")
        if risk not in (None, "", {}, []):
            row["_risk"] = copy.deepcopy(risk)
        rows.append(row)


def validate_stable_identities(cases: dict) -> None:
    seen: dict[str, str] = {}
    for module, rows in cases.items():
        for index, row in enumerate(rows, 1):
            try:
                stable_value, _ = case_stable_identity(row)
            except StableIdentityError as exc:
                raise SystemExit(f"{module} 第{index}条用例稳定ID异常: {exc}") from exc
            if not stable_value:
                raise SystemExit(f"{module} 第{index}条用例缺稳定ID/matrix_key")
            location = f"{module} 第{index}条"
            if stable_value in seen:
                raise SystemExit(f"稳定ID重复，禁止生成: {stable_value} ({seen[stable_value]} / {location})")
            seen[stable_value] = location


def load_case_id_history(
    project_dir: Path,
    *,
    pilot_only: bool = False,
) -> tuple[dict[str, str], dict[str, str], dict[str, int]]:
    """Merge immutable index history with pilot/full pre-export case history."""
    index_path = project_dir / "用例稳定索引.json"
    stable_to_case: dict[str, str] = {}
    case_to_stable: dict[str, str] = {}
    history_high_water: dict[str, int] = {}

    def merge_maps(
        additions: tuple[dict[str, str], dict[str, str]],
        *,
        label: str,
        index_is_authoritative: bool = False,
    ) -> None:
        add_stable_to_case, _ = additions
        for stable_value, case_id in add_stable_to_case.items():
            existing_case = stable_to_case.get(stable_value)
            existing_stable = case_to_stable.get(case_id)
            if existing_case is not None and existing_case != case_id:
                if index_is_authoritative:
                    continue
                raise SystemExit(
                    f"稳定编号历史冲突，禁止生成: {label} stable_id {stable_value} "
                    f"映射 {case_id}，已有 {existing_case}"
                )
            if existing_stable is not None and existing_stable != stable_value:
                raise SystemExit(
                    f"稳定编号历史冲突，禁止生成: {label} case_id {case_id} "
                    f"映射 {stable_value}，已有 {existing_stable}"
                )
            stable_to_case[stable_value] = case_id
            case_to_stable[case_id] = stable_value

    if index_path.exists():
        try:
            payload = json.loads(index_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise SystemExit(f"用例稳定索引无法读取或不是合法JSON: {index_path} ({exc})") from exc
        if not isinstance(payload, dict) or not isinstance(payload.get("items"), list):
            raise SystemExit("用例稳定索引必须是包含 items 数组的对象")
        retired = payload.get("retired_items", [])
        if not isinstance(retired, list):
            raise SystemExit("用例稳定索引 retired_items 必须是数组")
        historical_records = payload["items"] + retired
        try:
            merge_maps(
                build_identity_maps(historical_records, label="用例稳定索引历史"),
                label="用例稳定索引历史",
            )
        except StableIdentityError as exc:
            raise SystemExit(f"稳定编号历史冲突，禁止生成: {exc}") from exc
        for record in historical_records:
            case_id = str(record.get("case_id", "") or "")
            match = re.fullmatch(r"(.+)_(\d+)", case_id)
            if match:
                history_high_water[match.group(1)] = max(
                    history_high_water.get(match.group(1), 0), int(match.group(2))
                )
        if payload.get("schema_version") == 2 and "high_water" not in payload:
            raise SystemExit("用例稳定索引 schema v2 必须包含 high_water 对象")
        declared_high_water = payload.get("high_water", {})
        if not isinstance(declared_high_water, dict):
            raise SystemExit("用例稳定索引 high_water 必须是对象")
        for prefix, value in declared_high_water.items():
            if not isinstance(value, int) or isinstance(value, bool) or value < 0:
                raise SystemExit(f"用例稳定索引 high_water.{prefix} 必须是非负整数")
            prefix_value = str(prefix)
            if value < history_high_water.get(prefix_value, 0):
                raise SystemExit(
                    f"用例稳定索引 high_water.{prefix_value}={value} 小于历史最大编号 "
                    f"{history_high_water[prefix_value]}"
                )
            history_high_water[prefix_value] = value

    # Before the next export, either branch may contain identities absent from
    # the last index. Merge both so pilot/full runs cannot renumber each other.
    for fallback_name in ("cases", "pilot_cases"):
        fallback_dir = project_dir / fallback_name
        records: list[dict] = []
        for path in sorted(fallback_dir.glob("*.json")):
            try:
                payload = json.loads(path.read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError) as exc:
                raise SystemExit(f"历史cases无法读取或不是合法JSON: {path} ({exc})") from exc
            rows = payload.get("cases") if isinstance(payload, dict) else None
            if not isinstance(rows, list):
                raise SystemExit(f"历史cases缺合法 cases 数组: {path}")
            records.extend(rows)
        if not records:
            continue
        label = f"{fallback_name}历史用例"
        try:
            additions = build_identity_maps(records, label=label)
        except StableIdentityError as exc:
            raise SystemExit(f"稳定编号历史冲突，禁止生成: {exc}") from exc
        merge_maps(additions, label=label, index_is_authoritative=index_path.exists())
    return stable_to_case, case_to_stable, history_high_water


def assign_stable_case_ids(
    cases: dict[str, list[dict]],
    prefix_by_module: dict[str, str],
    stable_to_case: dict[str, str],
    case_to_stable: dict[str, str],
    history_high_water: dict[str, int],
) -> None:
    """Reuse historical IDs and append unseen identities after each prefix maximum."""
    assigned_case_ids: set[str] = set()
    reserved_case_ids = set(case_to_stable)
    for module, rows in cases.items():
        prefix = str(prefix_by_module.get(module, "") or "").strip()
        if not prefix:
            raise SystemExit(f"模块 {module} 缺编号前缀，无法稳定分配用例编号")
        pattern = re.compile(rf"^{re.escape(prefix)}_(\d+)$")
        history_numbers = [
            int(match.group(1))
            for case_id in reserved_case_ids
            if (match := pattern.fullmatch(case_id)) is not None
        ]
        next_number = max(max(history_numbers, default=0), history_high_water.get(prefix, 0)) + 1
        for index, row in enumerate(rows, 1):
            try:
                stable_value, _ = case_stable_identity(row)
            except StableIdentityError as exc:
                raise SystemExit(f"{module} 第{index}条用例稳定ID异常: {exc}") from exc
            historical_id = stable_to_case.get(stable_value)
            if historical_id:
                if pattern.fullmatch(historical_id) is None:
                    raise SystemExit(
                        f"稳定ID {stable_value} 的历史编号 {historical_id} 不属于模块前缀 {prefix}；"
                        "禁止静默换号，请走显式 --renumber + --migration-file 迁移"
                    )
                case_id = historical_id
            else:
                case_id = f"{prefix}_{next_number:03d}"
                while case_id in reserved_case_ids or case_id in assigned_case_ids:
                    next_number += 1
                    case_id = f"{prefix}_{next_number:03d}"
                next_number += 1
                reserved_case_ids.add(case_id)
                stable_to_case[stable_value] = case_id
                case_to_stable[case_id] = stable_value
            if case_id in assigned_case_ids:
                raise SystemExit(f"当前生成集合用例编号重复，禁止写入: {case_id}")
            assigned_case_ids.add(case_id)
            row["用例编号"] = case_id


def normalize_group(cases: dict, fpmap: dict | None):
    g = (fpmap or {}).get("GLOBAL", {})
    mm_all = (fpmap or {}).get("MODULES", {})
    for module, rows in cases.items():
        mm = mm_all.get(module, {})
        for r in rows:
            fp = r["功能点"]
            fp = g.get(fp, fp)
            fp = mm.get(fp, fp)
            r["功能点"] = fp
        order = []
        for r in rows:
            if r["功能点"] not in order:
                order.append(r["功能点"])
        rows.sort(key=lambda r: order.index(r["功能点"]))


def _run(args, pdir: Path):
    if not (pdir / "specs").exists():
        raise SystemExit(f"缺 specs 目录: {pdir/'specs'}")
    blueprint = _load(pdir / "用例设计蓝图.json")
    if not isinstance(blueprint, dict):
        raise SystemExit(f"缺生成前用例设计蓝图: {pdir/'用例设计蓝图.json'}")
    try:
        profile = load_profile(pdir)
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        raise SystemExit(f"执行画像无法读取，禁止生成: {exc}") from exc
    required_blueprint = required_blueprint_keys(profile)
    missing_blueprint = [key for key in required_blueprint if key not in blueprint]
    if missing_blueprint:
        raise SystemExit(f"用例设计蓝图字段缺失: {missing_blueprint}")

    # 必须在稳定ID、ui_pages 或 cases 输出发生任何写入前完成合同与spec全量只读校验。
    try:
        prepared_specs = load_and_validate_generation_inputs(pdir, pilot_only=args.pilot)
    except GenerationContractError as exc:
        raise SystemExit(str(exc)) from exc
    preflight_prepared_specs(prepared_specs)
    try:
        verify_stable_index_history(pdir)
    except (LineageError, OSError, json.JSONDecodeError) as exc:
        raise SystemExit(f"稳定索引历史校验失败，禁止生成: {exc}") from exc
    stable_to_case, case_to_stable, history_high_water = load_case_id_history(
        pdir, pilot_only=args.pilot
    )

    if not args.pilot:
        expected_modules = {spec.module for spec in prepared_specs}
        cases_dir = pdir / "cases"
        stale_modules = {path.stem for path in cases_dir.glob("*.json")} - expected_modules
        if stale_modules:
            raise SystemExit(
                f"cases目录存在非当前模块旧文件，禁止混入新构建: {sorted(stale_modules)}；"
                "请先人工确认并移出这些文件后重跑"
            )

    cases, changed_specs = expand_specs(prepared_specs)
    selected_modules = set(cases)
    ui_path = pdir / "ui_pages.json"
    ui = _load(ui_path)
    if ui:
        selected_ui = {
            module: pages for module, pages in ui.items()
            if not args.pilot or module in selected_modules
        }
        ui_changed = inject_ui(cases, selected_ui)
    else:
        ui_changed = False
    cross = _load(pdir / "cross.json")
    if cross:
        inject_cross(cases, cross, allowed_modules=selected_modules if args.pilot else None)
    fpmap = _load(pdir / "fpmap.json")
    normalize_group(cases, fpmap)
    validate_stable_identities(cases)
    assign_stable_case_ids(
        cases,
        {spec.module: spec.prefix for spec in prepared_specs},
        stable_to_case,
        case_to_stable,
        history_high_water,
    )
    rows = [row for module_rows in cases.values() for row in module_rows]
    contract_violations = check_functional_manual_contract(rows)
    contract_violations.extend(check_step_expected_contract(rows))
    if contract_violations:
        preview = "\n".join(f"  {item}" for item in contract_violations[:50])
        extra = len(contract_violations) - 50
        suffix = f"\n  ... 其余 {extra} 处" if extra > 0 else ""
        raise SystemExit(
            "功能测试用例人工执行合同未通过，禁止生成cases：\n" + preview + suffix
        )
    cdir = pdir / ("pilot_cases" if args.pilot else "cases")
    total = sum(len(module_rows) for module_rows in cases.values())

    # Gate failures above leave all project inputs and final cases untouched.
    # Stage and read back every changed artifact before committing any of them.
    with tempfile.TemporaryDirectory(prefix=".qa-casegen-stage-", dir=pdir) as stage_value:
        stage = Path(stage_value)
        staged_replacements: list[tuple[Path, Path]] = []
        for source, payload in sorted(changed_specs.items(), key=lambda item: str(item[0])):
            staged = stage / f"spec-{len(staged_replacements):04d}.json"
            staged.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            json.loads(staged.read_text(encoding="utf-8"))
            staged_replacements.append((source, staged))
        if ui_changed:
            staged_ui = stage / "ui-pages.json"
            staged_ui.write_text(json.dumps(ui, ensure_ascii=False, indent=2), encoding="utf-8")
            json.loads(staged_ui.read_text(encoding="utf-8"))
            staged_replacements.append((ui_path, staged_ui))

        staged_case_rows: list[dict] = []
        staged_cases: list[tuple[Path, Path]] = []
        for module_index, (mod, module_rows) in enumerate(cases.items()):
            staged = stage / f"cases-{module_index:04d}.json"
            staged.write_text(
                json.dumps({"module": mod, "cases": module_rows}, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            staged_payload = json.loads(staged.read_text(encoding="utf-8"))
            if staged_payload.get("module") != mod or not isinstance(staged_payload.get("cases"), list):
                raise SystemExit(f"暂存cases回读失败，禁止提交: {mod}")
            if len(staged_payload["cases"]) != len(module_rows):
                raise SystemExit(f"暂存cases数量不一致，禁止提交: {mod}")
            staged_case_rows.extend(staged_payload["cases"])
            staged_cases.append((cdir / f"{mod}.json", staged))
        try:
            build_identity_maps(staged_case_rows, label="暂存cases")
        except StableIdentityError as exc:
            raise SystemExit(f"暂存cases稳定身份冲突，禁止提交: {exc}") from exc

        commit_pairs = [
            (staged, target) for target, staged in staged_replacements + staged_cases
        ]
        try:
            commit_staged_files(
                commit_pairs,
                protected_paths=[pdir / LINEAGE_REL] if not args.pilot else [],
                post_commit=(lambda: record_casegen(pdir)) if not args.pilot else None,
            )
        except (OSError, RuntimeError, StableIdentityError, LineageError) as exc:
            raise SystemExit(f"casegen批量提交失败，已回滚全部产物: {exc}") from exc

    for mod, module_rows in cases.items():
        print(f"  {mod:14s} {len(module_rows):3d} 条")
    print(f"合计 {total} 条 -> {cdir}")
    print("下一步: export_cases.py → trace_extract → judge_build → trace_gate(B) → check_structure(C)；仅显式迁移时使用 --renumber + --migration-file")


def main():
    ap = argparse.ArgumentParser(description="用例生成流水线(spec→cases + 界面操作/交叉 + 归一分组)")
    ap.add_argument("--project", required=True)
    ap.add_argument("--workspace-root", help="项目工作区根目录；--project 为名称时生效")
    ap.add_argument(
        "--pilot", action="store_true",
        help="只生成合同pilot_modules；允许先导验收尚未通过，且写入pilot_cases而不覆盖正式cases",
    )
    args = ap.parse_args()
    pdir = _pdir(args.project, args.workspace_root)
    try:
        with project_build_lock(pdir):
            _run(args, pdir)
    except RuntimeError as exc:
        raise SystemExit(str(exc)) from exc


if __name__ == "__main__":
    main()
