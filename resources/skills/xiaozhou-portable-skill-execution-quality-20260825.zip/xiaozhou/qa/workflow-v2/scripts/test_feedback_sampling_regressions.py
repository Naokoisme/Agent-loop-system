# -*- coding: utf-8 -*-
"""Regression tests for feedback-wide scanning and stratified acceptance sampling."""
from __future__ import annotations

import copy
import hashlib
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parent
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import tc_excel  # noqa: E402


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def row(case_id: str, module: str, feature: str, *, priority: str = "P1", note: str = "") -> dict:
    return {
        "用例编号": case_id,
        "功能模块": module,
        "功能点": feature,
        "测试项": "功能测试",
        "测试点/检查项": f"验证{feature}行为",
        "前置条件": "1.设备已进入目标状态",
        "操作步骤": "1.执行目标操作",
        "预期结果": "1.页面显示目标结果",
        "优先级": priority,
        "兼容性": "N/A",
        "是否自动化": "否",
        "固件版本": "待测版本",
        "硬件型号": "待测型号",
        "测试方式": "人工执行",
        "备注": note,
    }


def run(script: str, *args: str) -> subprocess.CompletedProcess[str]:
    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    return subprocess.run(
        [sys.executable, str(SCRIPTS / script), *args],
        cwd=str(SCRIPTS.parent),
        env=env,
        text=True,
        capture_output=True,
        encoding="utf-8",
        errors="replace",
    )


def marker(proc: subprocess.CompletedProcess[str], value: str) -> bool:
    return value in proc.stdout + proc.stderr


def main() -> None:
    errors: list[str] = []
    results: list[dict] = []

    def check(name: str, passed: bool, detail: object = "") -> None:
        results.append({"name": name, "passed": passed, "detail": detail})
        if not passed:
            errors.append(f"{name}: {detail}")

    with tempfile.TemporaryDirectory(prefix="qa-feedback-sampling-") as temp_dir:
        temp = Path(temp_dir)
        cases = temp / "cases.xlsx"
        rows = [
            row("CASE_001", "设置", "亮度页面"),
            row("CASE_002", "设置", "亮度页面", note="待产品确认:自动亮度文案"),
            row("CASE_003", "通话", "来电页面"),
            row("CASE_004", "SOS", "紧急呼叫", priority="P0"),
            row("CASE_005", "天气", "天气首页"),
        ]
        tc_excel.write_workbook(rows, cases, ["设置", "通话", "SOS", "天气"])
        current_hash = sha256(cases)
        changed = temp / "changed.json"
        changed.write_text(json.dumps({"changed_case_ids": ["CASE_001"]}), encoding="utf-8")
        conflict = temp / "conflict.json"
        conflict.write_text(json.dumps({"items": [{
            "matrix_key": "通话|SOS",
            "case_id": "CASE_003",
            "target_case_id": "CASE_004",
        }]}, ensure_ascii=False), encoding="utf-8")
        ledger = temp / "feedback.json"

        config = {
            "project": "regression",
            "cases_xlsx": "cases.xlsx",
            "release_acceptance": {
                "feedback_patterns_required": True,
                "feedback_patterns_file": "feedback.json",
                "changed_case_ids_file": "changed.json",
                "conflict_index_file": "conflict.json",
                "required_strata": [
                    "changed_case_ids", "pending_confirmation", "conflict_cases",
                    "high_risk", "feature_points",
                ],
                "sample_seed": "fixed-regression-seed",
            },
        }
        config_path = temp / "trace.config.json"
        config_path.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")

        missing = run("feedback_pattern_gate.py", "--config", str(config_path))
        check(
            "feedback_required_ledger_missing_fails",
            missing.returncode != 0 and marker(missing, "FEEDBACK_LEDGER_MISSING"),
            missing.stdout + missing.stderr,
        )

        good_pattern = {
            "pattern_id": "FB-001",
            "reported_case_ids": ["CASE_001"],
            "scope": "all_project",
            "scan_status": "passed",
            "scanned_case_count": len(rows),
            "matched_case_ids": ["CASE_001", "CASE_002"],
            "resolved_case_ids": ["CASE_001", "CASE_002"],
            "evidence": "已按相同测试项表达扫描全部5条并完成修复复核",
            "input_xlsx_sha256": current_hash,
        }

        bad_scope = copy.deepcopy(good_pattern)
        bad_scope["scope"] = "reported_module"
        ledger.write_text(json.dumps({"patterns": [bad_scope]}, ensure_ascii=False), encoding="utf-8")
        scope_proc = run("feedback_pattern_gate.py", "--config", str(config_path))
        check(
            "feedback_non_project_scope_fails",
            scope_proc.returncode != 0 and marker(scope_proc, "FEEDBACK_SCOPE_NOT_ALL_PROJECT"),
            scope_proc.stdout + scope_proc.stderr,
        )

        stale = copy.deepcopy(good_pattern)
        stale["input_xlsx_sha256"] = "0" * 64
        ledger.write_text(json.dumps({"patterns": [stale]}, ensure_ascii=False), encoding="utf-8")
        stale_proc = run("feedback_pattern_gate.py", "--config", str(config_path))
        check(
            "feedback_stale_input_hash_fails",
            stale_proc.returncode != 0 and marker(stale_proc, "FEEDBACK_INPUT_HASH_STALE"),
            stale_proc.stdout + stale_proc.stderr,
        )

        unresolved = copy.deepcopy(good_pattern)
        unresolved["resolved_case_ids"] = ["CASE_001"]
        ledger.write_text(json.dumps({"patterns": [unresolved]}, ensure_ascii=False), encoding="utf-8")
        unresolved_proc = run("feedback_pattern_gate.py", "--config", str(config_path))
        check(
            "feedback_not_all_matches_resolved_fails",
            unresolved_proc.returncode != 0 and marker(unresolved_proc, "FEEDBACK_NOT_FULLY_RESOLVED"),
            unresolved_proc.stdout + unresolved_proc.stderr,
        )

        ledger.write_text(json.dumps({"patterns": [good_pattern]}, ensure_ascii=False), encoding="utf-8")
        good_proc = run("feedback_pattern_gate.py", "--config", str(config_path))
        check(
            "feedback_complete_project_scan_passes",
            good_proc.returncode == 0 and marker(good_proc, '"status": "PASS"'),
            good_proc.stdout + good_proc.stderr,
        )

        sample_one = temp / "sample-one.json"
        sample_two = temp / "sample-two.json"
        sample_proc = run(
            "stratified_acceptance_sample.py", "--config", str(config_path), "--out", str(sample_one)
        )
        sample_payload = json.loads(sample_one.read_text(encoding="utf-8"))
        sample_ids = {item["case_id"] for item in sample_payload.get("sample", [])}
        counts = sample_payload.get("metrics", {}).get("coverage_counts", {})
        layers_ok = (
            sample_proc.returncode == 0
            and {"CASE_001", "CASE_002", "CASE_003", "CASE_004", "CASE_005"} <= sample_ids
            and counts.get("changed_case_ids", {}).get("selected_count") == 1
            and counts.get("pending_confirmation", {}).get("selected_count") == 1
            and counts.get("conflict_cases", {}).get("selected_count") == 2
            and counts.get("high_risk", {}).get("selected_count") == 1
            and counts.get("feature_points", {}).get("selected_count") == 4
        )
        check("sampling_every_required_stratum_is_hit", layers_ok, sample_payload)

        sample_proc_two = run(
            "stratified_acceptance_sample.py", "--config", str(config_path), "--out", str(sample_two)
        )
        sample_payload_two = json.loads(sample_two.read_text(encoding="utf-8"))
        deterministic = (
            sample_proc_two.returncode == 0
            and sample_payload.get("sample") == sample_payload_two.get("sample")
        )
        check("sampling_fixed_seed_is_deterministic", deterministic, sample_payload_two.get("sample"))

        missing_strata_config = copy.deepcopy(config)
        missing_strata_config["release_acceptance"].pop("required_strata")
        missing_strata_path = temp / "missing-strata.config.json"
        missing_strata_path.write_text(json.dumps(missing_strata_config, ensure_ascii=False), encoding="utf-8")
        missing_strata_out = temp / "missing-strata.json"
        missing_strata_proc = run(
            "stratified_acceptance_sample.py", "--config", str(missing_strata_path), "--out", str(missing_strata_out)
        )
        check(
            "sampling_required_strata_missing_fails",
            missing_strata_proc.returncode != 0 and marker(missing_strata_proc, "REQUIRED_STRATA_MISSING"),
            missing_strata_proc.stdout + missing_strata_proc.stderr,
        )

        changed.write_text(json.dumps({"changed_case_ids": ["GHOST_999"]}), encoding="utf-8")
        invalid_out = temp / "invalid-reference.json"
        invalid_proc = run(
            "stratified_acceptance_sample.py", "--config", str(config_path), "--out", str(invalid_out)
        )
        check(
            "sampling_invalid_reference_fails",
            invalid_proc.returncode != 0 and marker(invalid_proc, "REFERENCED_CASE_ID_MISSING"),
            invalid_proc.stdout + invalid_proc.stderr,
        )

        def write_sampling_variant(
            name: str,
            *,
            variant_rows: list[dict] | None = None,
            changed_ids: list[str] | None = None,
            conflict_items: list[dict] | None = None,
            not_applicable: dict | None = None,
        ) -> subprocess.CompletedProcess[str]:
            variant_dir = temp / name
            variant_dir.mkdir()
            tc_excel.write_workbook(variant_rows if variant_rows is not None else rows, variant_dir / "cases.xlsx")
            (variant_dir / "changed.json").write_text(
                json.dumps({"changed_case_ids": ["CASE_001"] if changed_ids is None else changed_ids}),
                encoding="utf-8",
            )
            (variant_dir / "conflict.json").write_text(
                json.dumps({"items": [{"case_id": "CASE_003", "target_case_id": "CASE_004"}]
                            if conflict_items is None else conflict_items}, ensure_ascii=False),
                encoding="utf-8",
            )
            variant_config = copy.deepcopy(config)
            variant_config["release_acceptance"]["changed_case_ids_file"] = "changed.json"
            variant_config["release_acceptance"]["conflict_index_file"] = "conflict.json"
            if not_applicable is not None:
                variant_config["release_acceptance"]["strata_not_applicable"] = not_applicable
            variant_path = variant_dir / "trace.config.json"
            variant_path.write_text(json.dumps(variant_config, ensure_ascii=False), encoding="utf-8")
            return run(
                "stratified_acceptance_sample.py", "--config", str(variant_path),
                "--out", str(variant_dir / "sample.json"),
            )

        empty_changed = write_sampling_variant("empty-changed", changed_ids=[])
        check(
            "sampling_empty_changed_stratum_fails",
            empty_changed.returncode != 0 and marker(empty_changed, "REQUIRED_STRATUM_EMPTY")
            and marker(empty_changed, "changed_case_ids"),
            empty_changed.stdout + empty_changed.stderr,
        )

        no_pending_rows = [dict(item, **{"备注": ""}) for item in rows]
        empty_pending = write_sampling_variant("empty-pending", variant_rows=no_pending_rows)
        check(
            "sampling_empty_pending_stratum_fails",
            empty_pending.returncode != 0 and marker(empty_pending, "REQUIRED_STRATUM_EMPTY")
            and marker(empty_pending, "pending_confirmation"),
            empty_pending.stdout + empty_pending.stderr,
        )

        empty_conflict = write_sampling_variant("empty-conflict", conflict_items=[])
        check(
            "sampling_empty_conflict_stratum_fails",
            empty_conflict.returncode != 0 and marker(empty_conflict, "REQUIRED_STRATUM_EMPTY")
            and marker(empty_conflict, "conflict_cases"),
            empty_conflict.stdout + empty_conflict.stderr,
        )

        no_high_risk_rows = [dict(item, **{"优先级": "P1", "备注": str(item.get("备注", "")).replace("高风险", "")}) for item in rows]
        empty_high_risk = write_sampling_variant("empty-high-risk", variant_rows=no_high_risk_rows)
        check(
            "sampling_empty_high_risk_stratum_fails",
            empty_high_risk.returncode != 0 and marker(empty_high_risk, "REQUIRED_STRATUM_EMPTY")
            and marker(empty_high_risk, "high_risk"),
            empty_high_risk.stdout + empty_high_risk.stderr,
        )

        no_feature_rows = [dict(item, **{"功能模块": "", "功能点": ""}) for item in rows]
        empty_feature = write_sampling_variant("empty-feature", variant_rows=no_feature_rows)
        check(
            "sampling_empty_feature_point_stratum_fails",
            empty_feature.returncode != 0 and marker(empty_feature, "REQUIRED_STRATUM_EMPTY")
            and marker(empty_feature, "feature_points"),
            empty_feature.stdout + empty_feature.stderr,
        )

        pending_na = write_sampling_variant(
            "pending-not-applicable",
            variant_rows=no_pending_rows,
            not_applicable={"pending": "当前项目需求已全部确认，最终Excel不存在待确认用例"},
        )
        check(
            "sampling_explicit_not_applicable_allows_empty_stratum",
            pending_na.returncode == 0 and marker(pending_na, '"status": "PASS"'),
            pending_na.stdout + pending_na.stderr,
        )

        empty_reason = write_sampling_variant(
            "pending-empty-reason", variant_rows=no_pending_rows, not_applicable={"pending": "N/A"}
        )
        check(
            "sampling_not_applicable_requires_concrete_reason",
            empty_reason.returncode != 0 and marker(empty_reason, "STRATA_NOT_APPLICABLE_REASON_MISSING"),
            empty_reason.stdout + empty_reason.stderr,
        )

        contradictory_na = write_sampling_variant(
            "pending-contradictory-na", not_applicable={"pending": "当前项目没有待确认用例"}
        )
        check(
            "sampling_not_applicable_cannot_hide_existing_candidates",
            contradictory_na.returncode != 0
            and marker(contradictory_na, "STRATUM_NOT_APPLICABLE_CONTRADICTS_CANDIDATES"),
            contradictory_na.stdout + contradictory_na.stderr,
        )

    output = {"success": not errors, "results": results, "errors": errors}
    print(json.dumps(output, ensure_ascii=False, indent=2))
    raise SystemExit(0 if not errors else 1)


if __name__ == "__main__":
    main()
