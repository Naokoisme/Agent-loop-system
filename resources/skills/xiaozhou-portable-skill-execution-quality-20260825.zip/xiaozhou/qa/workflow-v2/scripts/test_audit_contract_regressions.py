# -*- coding: utf-8 -*-
"""Focused regression coverage for the canonical workflow audit contract."""
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path


SCRIPTS = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPTS))

import audit_contract as audit  # noqa: E402


def record(results: list[dict], errors: list[str], name: str, passed: bool, details: object = None) -> None:
    item = {"name": name, "passed": bool(passed)}
    if details is not None:
        item["details"] = details
    results.append(item)
    if not passed:
        errors.append(f"{name}: {details}")


def run_cli(payload: object, *extra: str) -> subprocess.CompletedProcess[str]:
    with tempfile.TemporaryDirectory(prefix="audit-contract-") as temp_dir:
        path = Path(temp_dir) / "input.json"
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        return subprocess.run(
            [sys.executable, str(SCRIPTS / "audit_contract.py"), "--input", str(path), *extra],
            cwd=SCRIPTS.parent,
            text=True,
            capture_output=True,
            encoding="utf-8",
            errors="replace",
        )


def main() -> None:
    results: list[dict] = []
    errors: list[str] = []

    clean = audit.build_report("regression.clean", metrics={"checked": 3})
    record(
        results,
        errors,
        "clean_report_is_pass",
        clean["status"] == "PASS"
        and clean["blocking_count"] == clean["risk_count"] == clean["warning_count"] == 0
        and audit.exit_code(clean) == 0,
        clean,
    )

    risk = audit.make_issue("risk", "threshold is pending", code="PENDING_THRESHOLD")
    warning = audit.make_issue("warning", "legacy note retained", code="LEGACY_NOTE")
    risky = audit.build_report("regression.risks", issues=[risk, warning])
    record(
        results,
        errors,
        "risks_do_not_fail_process",
        risky["status"] == "PASS_WITH_RISKS"
        and risky["risk_count"] == 1
        and risky["warning_count"] == 1
        and audit.exit_code(risky) == 0,
        risky,
    )

    failed = audit.build_report(
        "regression.fail",
        issues=[audit.make_issue("blocking", "gate failed", code="GATE_FAIL", kind="failure")],
    )
    record(
        results,
        errors,
        "failure_exit_code_is_one",
        failed["status"] == "FAIL" and audit.exit_code(failed) == 1,
        failed,
    )

    blocked = audit.build_report(
        "regression.blocked",
        issues=[audit.make_issue("blocking", "required input missing", code="INPUT_MISSING", kind="blocked")],
    )
    record(
        results,
        errors,
        "blocked_exit_code_is_two",
        blocked["status"] == "BLOCKED" and audit.exit_code(blocked) == 2,
        blocked,
    )

    contradictory = dict(risky)
    contradictory["risk_count"] = 0
    validation = audit.validate_report(contradictory)
    record(
        results,
        errors,
        "counts_are_derived_not_trusted",
        audit.exit_code(contradictory) == 2 and any("risk_count must be derived" in item for item in validation),
        validation,
    )

    status_drift = dict(clean)
    status_drift["status"] = "FAIL"
    validation = audit.validate_report(status_drift)
    record(
        results,
        errors,
        "status_is_derived_not_trusted",
        audit.exit_code(status_drift) == 2 and any("status must be derived" in item for item in validation),
        validation,
    )

    legacy_failure = audit.normalize_report(
        {"status": "FAIL", "failures": ["Excel physical validation failed"], "case_count": 957},
        tool="legacy.final_review",
    )
    record(
        results,
        errors,
        "legacy_failure_shape_is_readable",
        legacy_failure["status"] == "FAIL"
        and legacy_failure["blocking_count"] == 1
        and audit.exit_code(legacy_failure) == 1,
        legacy_failure,
    )

    legacy_success = audit.normalize_report(
        {"success": True, "errors": [], "checks": 12}, tool="legacy.portable"
    )
    record(
        results,
        errors,
        "legacy_success_shape_is_readable",
        legacy_success["status"] == "PASS" and audit.exit_code(legacy_success) == 0,
        legacy_success,
    )

    cli_risk = run_cli({"status": "PASS_WITH_RISKS", "risks": ["one pending product rule"]}, "--tool", "legacy.cli")
    cli_risk_payload = json.loads(cli_risk.stdout) if cli_risk.stdout.strip() else {}
    record(
        results,
        errors,
        "cli_risk_returns_zero",
        cli_risk.returncode == 0 and cli_risk_payload.get("status") == "PASS_WITH_RISKS",
        {"returncode": cli_risk.returncode, "stdout": cli_risk.stdout, "stderr": cli_risk.stderr},
    )

    cli_schema = run_cli(contradictory, "--strict")
    cli_schema_payload = json.loads(cli_schema.stdout) if cli_schema.stdout.strip() else {}
    record(
        results,
        errors,
        "cli_schema_error_returns_two",
        cli_schema.returncode == 2
        and cli_schema_payload.get("status") == "BLOCKED"
        and cli_schema_payload.get("blocking_count") == 1,
        {"returncode": cli_schema.returncode, "stdout": cli_schema.stdout, "stderr": cli_schema.stderr},
    )

    output = audit.build_report(
        "test_audit_contract_regressions",
        issues=[audit.make_issue("blocking", error, code="REGRESSION_FAIL", kind="failure") for error in errors],
        metrics={"tests": len(results), "passed": sum(1 for item in results if item["passed"])},
        extensions={"results": results},
    )
    print(json.dumps(output, ensure_ascii=False, indent=2))
    raise SystemExit(audit.exit_code(output))


if __name__ == "__main__":
    main()
