# -*- coding: utf-8 -*-
"""Regression tests for QA failure modes that must not recur."""
from __future__ import annotations

import importlib.util
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

from openpyxl import load_workbook

SCRIPTS = Path(__file__).resolve().parent
QA_ROOT = SCRIPTS.parents[1]
for path in (SCRIPTS, SCRIPTS / "traceability"):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if not spec or not spec.loader:
        raise RuntimeError(f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


quality = load_module("qa_quality_semantics_regression", SCRIPTS / "quality_semantics.py")
trace_gate = load_module("qa_trace_gate_regression", SCRIPTS / "traceability" / "trace_gate.py")
structure = load_module("qa_structure_regression", SCRIPTS / "check_structure.py")
remap = load_module("qa_remap_regression", SCRIPTS / "remap_judgments.py")
tc_excel = load_module("qa_tc_excel_regression", SCRIPTS / "tc_excel.py")
gate_fix = load_module("qa_gate_fix_regression", SCRIPTS / "gate_fix_loop.py")


def base_row(**updates) -> dict:
    row = {
        "用例编号": "QA_001",
        "功能模块": "录音",
        "功能点": "本地录音",
        "测试项": "中断测试",
        "测试点/检查项": "验证连续插拔后录音文件仍可播放",
        "前置条件": "1.设备正在本地录音\n2.TF卡剩余空间大于10MB",
        "操作步骤": "1.连续插拔充电线20次\n2.停止录音\n3.打开新生成的OGG文件",
        "预期结果": "1.每轮插入和拔出均切换对应充电状态\n2.录音停止并保存OGG文件\n3.OGG文件可播放",
        "优先级": "P1",
        "兼容性": "N/A",
        "是否自动化": "否",
        "固件版本": "待测版本",
        "硬件型号": "待测型号",
        "测试方式": "人工执行",
        "备注": "",
    }
    row.update(updates)
    return row


def production_quality() -> dict:
    return {
        "production_semantics": {
            "require_nonempty_core_fields": True,
            "check_manual_feasibility": True,
            "check_dependency_module_boundaries": True,
            "parameter_values": {
                "enabled": True,
                "require_explicit_value": True,
                "require_value_in_steps_and_expected": True,
                "actual_value_labels": [],
            },
            "preconditions": {"require_nonempty": True, "fixture_ids": []},
        }
    }


def expect(name: str, violations: list[str], marker: str | None, errors: list[str], results: list[dict]) -> None:
    passed = not violations if marker is None else any(marker in value for value in violations)
    results.append({"name": name, "passed": passed, "violations": violations})
    if not passed:
        expected = "PASS" if marker is None else f"violation containing {marker}"
        errors.append(f"{name}: expected {expected}, got {violations}")


def scenario_items(modules: list[str], dimensions: list[str], case_id: str) -> list[dict]:
    return [
        {"module": module, "dimension": dimension, "status": "covered", "case_ids": [case_id]}
        for module in modules for dimension in dimensions
    ]


def run_gate(config: Path) -> tuple[int, str]:
    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    completed = subprocess.run(
        [sys.executable, str(SCRIPTS / "check_structure.py"), "--config", str(config)],
        cwd=str(SCRIPTS.parent),
        env=env,
        text=True,
        capture_output=True,
        encoding="utf-8",
        errors="replace",
    )
    return completed.returncode, (completed.stdout + completed.stderr).strip()


class TraceCfg:
    def __init__(self, base: Path, modules: list[str], raw: dict | None = None):
        self.base = base
        self.module_order = modules
        self.coverage_threshold = 0.95
        self.raw = raw or {}

    def out_dir(self, key: str) -> Path:
        path = self.base / {"result": "结果", "gaps": "补充用例"}.get(key, key)
        path.mkdir(parents=True, exist_ok=True)
        return path


def main() -> None:
    errors: list[str] = []
    results: list[dict] = []
    q = production_quality()

    # Auto-fix must preserve Chinese conjunction semantics. Only explicit
    # numbered/newline boundaries may be normalized.
    conjunction_case = {
        "操作步骤": "1.点击保存并同步",
        "预期结果": "1.APP保存配置且设备收到同步结果",
        "测试项": "同步测试",
        "测试点/检查项": "验证保存同步结果",
    }
    _, conjunction_steps = gate_fix.normalize_case(conjunction_case)
    conjunction_preserved = (
        conjunction_case["操作步骤"] == "1.点击保存并同步"
        and conjunction_case["预期结果"] == "1.APP保存配置且设备收到同步结果"
    )
    results.append({"name": "gate_fix_preserves_chinese_conjunctions", "passed": conjunction_preserved, "touched": conjunction_steps})
    if not conjunction_preserved:
        errors.append(f"gate_fix_preserves_chinese_conjunctions: {conjunction_case}")

    ambiguous_blocked = False
    try:
        gate_fix.normalize_case({
            "操作步骤": "点击保存并同步",
            "预期结果": "APP保存配置且设备收到同步结果",
            "测试项": "同步测试",
            "测试点/检查项": "验证保存同步结果",
        })
    except ValueError as exc:
        ambiguous_blocked = "禁止按中文连接词猜拆" in str(exc)
    results.append({"name": "gate_fix_blocks_ambiguous_unnumbered_prose", "passed": ambiguous_blocked})
    if not ambiguous_blocked:
        errors.append("gate_fix_blocks_ambiguous_unnumbered_prose: ambiguous prose was auto-rewritten")

    expect("good_concrete_manual_case", quality.check_production_semantics([base_row()], q), None, errors, results)
    concrete_parameter = base_row(**{
        "测试点/检查项": "验证设置亮屏时长为5秒",
        "操作步骤": "1.进入亮屏时长设置页\n2.选择5秒并保存",
        "预期结果": "1.显示亮屏时长可选值\n2.当前亮屏时长显示为5秒",
    })
    expect(
        "parameter_actual_value_is_concrete_and_consistent",
        quality.check_production_semantics([concrete_parameter], q),
        None,
        errors,
        results,
    )
    for name, test_point in (
        ("parameter_blocks_casual_setting", "验证随便设置亮屏时长"),
        ("parameter_blocks_arbitrary_setting", "验证任意设置亮屏时长"),
        ("parameter_blocks_lowest_gear", "验证设置亮屏时长为最低档"),
        ("parameter_blocks_middle_gear", "验证设置亮屏时长为中间档"),
        ("parameter_blocks_highest_gear", "验证设置亮屏时长为最高档"),
        ("parameter_blocks_threshold_before", "验证阈值前行为"),
        ("parameter_blocks_threshold_equal", "验证阈值点行为"),
        ("parameter_blocks_threshold_after", "验证阈值后行为"),
    ):
        expect(
            name,
            quality.check_production_semantics([base_row(**{"测试点/检查项": test_point})], q),
            "S29 参数值描述抽象",
            errors,
            results,
        )
    expect(
        "parameter_blocks_missing_actual_value",
        quality.check_production_semantics([
            base_row(**{"测试点/检查项": "验证设置亮屏时长"})
        ], q),
        "S29 参数实际值缺失",
        errors,
        results,
    )
    expect(
        "parameter_requires_value_in_steps",
        quality.check_production_semantics([
            base_row(**{
                "测试点/检查项": "验证设置亮屏时长为5秒",
                "操作步骤": "1.进入亮屏时长设置页\n2.选择15秒并保存",
                "预期结果": "1.显示亮屏时长可选值\n2.当前亮屏时长显示为5秒",
            })
        ], q),
        "S29 参数值未贯穿",
        errors,
        results,
    )
    expect(
        "parameter_requires_value_in_expected",
        quality.check_production_semantics([
            base_row(**{
                "测试点/检查项": "验证设置亮屏时长为5秒",
                "操作步骤": "1.进入亮屏时长设置页\n2.选择5秒并保存",
                "预期结果": "1.显示亮屏时长可选值\n2.设置保存成功",
            })
        ], q),
        "S29 参数值未贯穿",
        errors,
        results,
    )
    for name, test_point in (
        ("parameter_allows_default_named_value", "验证首次默认节奏为Moderate"),
        ("parameter_allows_any_music_control", "验证未连接蓝牙时点击任意音乐控件进入未连接页面"),
        ("parameter_allows_any_alarm_key", "验证提醒中点击任意按键关闭闹钟"),
        ("parameter_allows_any_page_navigation", "验证任意页面右滑返回上一级"),
        ("parameter_allows_chart_maximum", "验证图表最大值向上取整为8000"),
        ("parameter_allows_shuffle_mode", "验证随机播放模式生效"),
    ):
        expect(
            name,
            quality.check_production_semantics([base_row(**{"测试点/检查项": test_point})], q),
            None,
            errors,
            results,
        )
    expect(
        "parameter_allows_explicit_shuffle_value",
        quality.check_production_semantics([
            base_row(**{
                "测试点/检查项": "验证设置播放模式为随机播放",
                "操作步骤": "1.进入播放模式设置页\n2.选择随机播放并保存",
                "预期结果": "1.显示播放模式列表\n2.当前模式显示为随机播放",
            })
        ], q),
        None,
        errors,
        results,
    )
    expect(
        "parameter_allows_pending_product_value",
        quality.check_production_semantics([
            base_row(**{"测试点/检查项": "验证设置亮屏时长为待产品确认:支持的具体档位"})
        ], q),
        None,
        errors,
        results,
    )
    expect(
        "parameter_setting_page_noun_is_not_misclassified",
        quality.check_production_semantics([
            base_row(**{"测试点/检查项": "验证亮屏时长设置页面显示5个选项"})
        ], q),
        None,
        errors,
        results,
    )
    legacy_parameter_q = {
        "production_semantics": {
            "require_nonempty_core_fields": True,
            "preconditions": {"require_nonempty": True, "fixture_ids": []},
        }
    }
    expect(
        "legacy_project_without_parameter_gate_remains_compatible",
        quality.check_production_semantics([
            base_row(**{"测试点/检查项": "验证设置亮屏时长为最高档"})
        ], legacy_parameter_q),
        None,
        errors,
        results,
    )
    labeled_value_q = production_quality()
    labeled_value_q["production_semantics"]["parameter_values"]["actual_value_labels"] = ["最高档"]
    expect(
        "prd_declared_named_gear_can_be_whitelisted",
        quality.check_production_semantics([
            base_row(**{
                "测试点/检查项": "验证设置风速为最高档",
                "操作步骤": "1.进入风速设置页\n2.选择最高档并保存",
                "预期结果": "1.显示风速档位列表\n2.当前风速显示为最高档",
            })
        ], labeled_value_q),
        None,
        errors,
        results,
    )
    expect(
        "concrete_normal_receive_and_unaffected_playback_is_allowed",
        structure.check([
            base_row(**{
                "操作步骤": "1.在音乐播放中接收一条手机消息",
                "预期结果": "1.消息正常接收，不影响音乐播放",
            })
        ]),
        None,
        errors,
        results,
    )
    expect(
        "generic_normal_result_is_still_blocked",
        structure.check([
            base_row(**{"预期结果": "1.系统正常"})
        ]),
        "S4",
        errors,
        results,
    )
    expect(
        "vague_test_point",
        quality.check_production_semantics([base_row(**{"测试点/检查项": "验证录音中解绑后的处理"})], q),
        "S29",
        errors,
        results,
    )
    expect(
        "concrete_noun_with_processing_word",
        quality.check_production_semantics([
            base_row(**{"测试点/检查项": "验证图像处理完成后生成JPEG文件"})
        ], q),
        None,
        errors,
        results,
    )
    expect(
        "placeholder_detail",
        quality.check_production_semantics([base_row(**{"预期结果": "1.本步骤执行完成\n2.完成对应检查\n3.明确结果"})], q),
        "S29",
        errors,
        results,
    )
    expect(
        "empty_precondition",
        quality.check_production_semantics([base_row(**{"前置条件": ""})], q),
        "S30",
        errors,
        results,
    )
    expect(
        "placeholder_precondition",
        quality.check_production_semantics([base_row(**{"前置条件": "1.具备测试条件"})], q),
        "S30",
        errors,
        results,
    )
    expect(
        "manual_fixture_reference_is_blocked",
        quality.check_precondition_semantics([
            base_row(**{"前置条件": "1.引用公共前置:BASE_ENV\n2.设备处于待机状态"})
        ], {"production_semantics": {"preconditions": {"require_nonempty": True, "fixture_ids": ["BASE_ENV"]}}}),
        "S30 人工用例内部fixture泄漏",
        errors,
        results,
    )
    expect(
        "functional_case_canonical_manual_values_pass",
        quality.check_functional_manual_contract([base_row()]),
        None,
        errors,
        results,
    )
    for value in ("no", "false", "0"):
        expect(
            f"functional_case_noncanonical_auto_{value}_is_blocked",
            quality.check_functional_manual_contract([base_row(**{"是否自动化": value})]),
            "FMC1 功能用例非人工执行",
            errors,
            results,
        )
    for name, value in (("hand", "手工"), ("english", "manual")):
        expect(
            f"functional_case_noncanonical_way_{name}_is_blocked",
            quality.check_functional_manual_contract([base_row(**{"测试方式": value})]),
            "FMC1 功能用例执行方式不纯",
            errors,
            results,
        )
    expect(
        "functional_case_automation_flag_is_blocked",
        quality.check_functional_manual_contract([
            base_row(**{"是否自动化": "是", "测试方式": "人工执行"})
        ]),
        "FMC1 功能用例非人工执行",
        errors,
        results,
    )
    expect(
        "functional_contract_cannot_be_disabled_by_empty_quality_config",
        structure.check([base_row(**{"是否自动化": "是", "测试方式": "自动化脚本"})]),
        "FMC1 功能用例非人工执行",
        errors,
        results,
    )
    expect(
        "legacy_schema_can_skip_new_manual_only_contract",
        structure.check(
            [base_row(**{"测试方式": "手工+秒表"})],
            enforce_manual_contract=False,
        ),
        None,
        errors,
        results,
    )
    expect(
        "functional_case_automation_detail_is_blocked",
        quality.check_functional_manual_contract([
            base_row(**{"前置条件": "1.准备BLE协议注入工具", "测试方式": "人工执行"})
        ]),
        "FMC2 功能用例混入自动化实现细节",
        errors,
        results,
    )
    expect(
        "functional_case_automation_layer_word_is_blocked",
        quality.check_functional_manual_contract([
            base_row(**{"前置条件": "1.自动化操作环境已经准备", "测试方式": "人工执行"})
        ]),
        "FMC2 功能用例混入自动化实现细节",
        errors,
        results,
    )
    for name, phrase in (
        ("python_script_runtime", "1.Python脚本运行环境已经准备"),
        ("generic_script_runtime", "1.脚本运行环境已经准备"),
    ):
        expect(
            f"functional_case_{name}_is_blocked",
            quality.check_functional_manual_contract([base_row(**{"前置条件": phrase})]),
            "FMC2 功能用例混入自动化实现细节",
            errors,
            results,
        )
    expect(
        "functional_case_underscore_fixture_id_is_blocked",
        quality.check_functional_manual_contract([
            base_row(**{"前置条件": "1.引用FIXTURE_LOGIN准备设备"})
        ]),
        "FMC2 功能用例混入自动化实现细节",
        errors,
        results,
    )
    for field, phrase in (
        ("兼容性", "BASE_ENV"),
        ("固件版本", "FIXTURE_FIRMWARE"),
        ("硬件型号", "自动化脚本设备"),
    ):
        expect(
            f"functional_case_automation_detail_in_{field}_is_blocked",
            quality.check_functional_manual_contract([base_row(**{field: phrase})]),
            "FMC2 功能用例混入自动化实现细节",
            errors,
            results,
        )
    expect(
        "functional_case_fixtureless_business_word_is_allowed",
        quality.check_functional_manual_contract([base_row(**{"备注": "fixtureless人工连接流程"})]),
        None,
        errors,
        results,
    )
    expect(
        "functional_case_protocol_internal_assertion_is_blocked",
        quality.check_functional_manual_contract([
            base_row(**{"预期结果": "1.协议字段已上报且值正确\n2.录音停止并保存OGG文件\n3.OGG文件可播放", "测试方式": "人工执行"})
        ]),
        "FMC2 功能用例混入自动化实现细节",
        errors,
        results,
    )
    implementation_leaks = [
        ("internal_anchor_token", "前置条件", "1.APP_BOUND_ANCHOR 已登记"),
        ("human_facing_anchor_word", "操作步骤", "1.检查 App 已连接锚点"),
        ("internal_record_query", "操作步骤", "1.通过 APP_NAME_RECORD_QUERY 查询 App 内名称记录"),
        ("text_inspector", "操作步骤", "1.复制输入内容到 TEXT_INSPECTOR"),
        ("chinese_text_inspector", "操作步骤", "1.复制内容到项目批准文本检查器"),
        ("ui_layout_contract", "前置条件", "1.UI_HOME_NAME 已填写视口参数"),
        ("toast_observation_contract", "操作步骤", "1.观察至 TOAST_OBSERVATION_WINDOW 结束"),
        ("frame_by_frame_video", "操作步骤", "1.逐帧检查设备端连续录像"),
        ("immutable_evidence_id", "前置条件", "1.不可变证据编号已登记"),
        ("package_sha", "固件版本", "候选包 SHA-256 已登记"),
        ("communication_record", "操作步骤", "1.导出通信记录并比对"),
        ("network_record", "操作步骤", "1.采集网络记录"),
        ("server_side_setup", "前置条件", "1.服务端已准备测试账号"),
        ("server_internal_state", "预期结果", "1.服务器保存运动记录"),
        ("database_internal_state", "预期结果", "1.数据库新增一条记录"),
        ("firmware_flag", "前置条件", "1.固件标志位已设为1"),
        ("capability_flag", "前置条件", "1.能力标志已开启"),
        ("generic_log", "操作步骤", "1.查看运行日志"),
        ("device_local_state", "预期结果", "1.设备本地新增一条记录"),
        ("local_cache_state", "预期结果", "1.本地缓存已清除"),
        ("cached_data_state", "预期结果", "1.缓存数据保持不变"),
        ("app_local_record_precondition", "前置条件", "1.App 本地不存在该设备的自定义名称记录"),
        ("protocol_field", "预期结果", "1.协议字段值为01"),
        ("protocol_frame", "预期结果", "1.报文内容正确"),
        ("register_value", "预期结果", "1.寄存器值变为1"),
        ("downlink_instruction", "操作步骤", "1.下发指令启动测量"),
        ("received_instruction", "预期结果", "1.设备收到测量指令"),
        ("sent_instruction", "预期结果", "1.APP发送结束指令"),
        ("decision_row", "备注", "DECISION_ROW=R01"),
        ("orthogonal_row", "备注", "ORTHOGONAL_ROW=O01"),
        ("data_row_definition", "前置条件", "1.按数据行定义A准备环境"),
        ("dataset_id", "备注", "数据集ID: DATA_01"),
        ("construct_test_data", "前置条件", "1.构造边界测试数据"),
        ("import_test_data", "前置条件", "1.导入100条历史数据"),
        ("inject_test_data", "前置条件", "1.注入异常测试数据"),
        ("simulate_test_data", "前置条件", "1.模拟连续3天缺失数据"),
    ]
    for name, field, phrase in implementation_leaks:
        expect(
            f"functional_case_{name}_is_blocked",
            quality.check_functional_manual_contract([base_row(**{field: phrase})]),
            "FMC2 功能用例混入自动化实现细节",
            errors,
            results,
        )

    expect(
        "functional_case_visible_sports_log_is_allowed",
        quality.check_functional_manual_contract([base_row(**{
            "操作步骤": "1.打开运动日志页面",
            "预期结果": "1.页面显示本周运动日志列表",
        })]),
        None,
        errors,
        results,
    )

    observable_business_phrases = [
        ("visible_upload", {
            "操作步骤": "1.在记录详情页点击上传",
            "预期结果": "1.APP显示上传成功图标",
        }),
        ("visible_sync", {
            "操作步骤": "1.在设备页点击同步",
            "预期结果": "1.APP显示同步完成且进度为100%",
        }),
        ("visible_field", {
            "操作步骤": "1.打开个人资料页",
            "预期结果": "1.页面显示姓名字段和当前昵称",
        }),
    ]
    for name, updates in observable_business_phrases:
        expect(
            f"functional_case_{name}_is_allowed",
            quality.check_functional_manual_contract([base_row(**updates)]),
            None,
            errors,
            results,
        )

    expect(
        "functional_case_hidden_server_result_is_blocked",
        quality.check_functional_manual_contract([
            base_row(**{"预期结果": "1.服务端已写入运动记录\n2.录音停止并保存OGG文件\n3.OGG文件可播放", "测试方式": "人工执行"})
        ]),
        "FMC3 人工预期不可观察",
        errors,
        results,
    )
    expect(
        "functional_case_hidden_upload_to_server_result_is_blocked",
        quality.check_functional_manual_contract([
            base_row(**{"预期结果": "1.运动记录上传服务端成功\n2.录音停止并保存OGG文件\n3.OGG文件可播放"})
        ]),
        "FMC3 人工预期不可观察",
        errors,
        results,
    )
    expect(
        "functional_case_hidden_write_database_result_is_blocked",
        quality.check_functional_manual_contract([
            base_row(**{"预期结果": "1.运动记录写入数据库完成\n2.录音停止并保存OGG文件\n3.OGG文件可播放"})
        ]),
        "FMC3 人工预期不可观察",
        errors,
        results,
    )
    expect(
        "functional_case_hidden_device_storage_result_is_blocked",
        quality.check_functional_manual_contract([
            base_row(**{"预期结果": "1.设备本地数据已覆盖\n2.录音停止并保存OGG文件\n3.OGG文件可播放", "测试方式": "人工执行"})
        ]),
        "FMC3 人工预期不可观察",
        errors,
        results,
    )
    expect(
        "functional_case_toolchain_test_way_is_blocked",
        quality.check_functional_manual_contract([
            base_row(**{"测试方式": "APP实机+协议Mock+协议日志"})
        ]),
        "FMC1 功能用例执行方式不纯",
        errors,
        results,
    )
    with tempfile.TemporaryDirectory(prefix="_tc_excel_manual_contract_") as temp_dir:
        forbidden_xlsx = Path(temp_dir) / "forbidden.xlsx"
        low_level_blocked = False
        try:
            tc_excel.write_workbook([
                base_row(**{"是否自动化": "是", "测试方式": "自动化脚本"})
            ], forbidden_xlsx)
        except ValueError as exc:
            low_level_blocked = "功能测试用例人工执行合同未通过" in str(exc)
        low_level_blocked = low_level_blocked and not forbidden_xlsx.exists()
        results.append({"name": "tc_excel_low_level_write_blocks_automation_rows", "passed": low_level_blocked})
        if not low_level_blocked:
            errors.append("tc_excel_low_level_write_blocks_automation_rows: workbook was written or wrong error returned")
    with tempfile.TemporaryDirectory(prefix="_tc_excel_mirror_contract_") as temp_dir:
        temp = Path(temp_dir)
        mirror_rows = [
            base_row(**{
                "用例编号": "QA_001",
                "前置条件": "1.设备处于待机状态",
                "操作步骤": "1.打开APP",
                "预期结果": "1.APP显示首页",
            }),
            base_row(**{
                "用例编号": "QA_002",
                "测试点/检查项": "验证设备页显示已连接设备",
                "前置条件": "1.APP停留在首页",
                "操作步骤": "1.点击设备页",
                "预期结果": "1.设备页显示已连接设备",
            }),
        ]
        good_xlsx = temp / "mirror-good.xlsx"
        tc_excel.write_workbook(mirror_rows, good_xlsx, ["录音"])
        expect(
            "workbook_writer_output_is_exact_mirror_with_merged_cells",
            structure.check_workbook_mirror(good_xlsx, tc_excel.read_master_rows(good_xlsx)),
            None,
            errors,
            results,
        )

        missing_xlsx = temp / "mirror-missing.xlsx"
        shutil.copyfile(good_xlsx, missing_xlsx)
        workbook = load_workbook(missing_xlsx)
        workbook.remove(workbook["录音"])
        workbook.save(missing_xlsx)
        expect(
            "workbook_missing_module_sheet_is_blocked",
            structure.check_workbook_mirror(missing_xlsx, tc_excel.read_master_rows(missing_xlsx)),
            "FMC4 缺少子表",
            errors,
            results,
        )

        extra_xlsx = temp / "mirror-extra.xlsx"
        shutil.copyfile(good_xlsx, extra_xlsx)
        workbook = load_workbook(extra_xlsx)
        workbook.create_sheet("额外子表")
        workbook.save(extra_xlsx)
        expect(
            "workbook_extra_sheet_is_blocked",
            structure.check_workbook_mirror(extra_xlsx, tc_excel.read_master_rows(extra_xlsx)),
            "FMC4 多余或非法子表",
            errors,
            results,
        )

        row_count_xlsx = temp / "mirror-row-count.xlsx"
        shutil.copyfile(good_xlsx, row_count_xlsx)
        workbook = load_workbook(row_count_xlsx)
        workbook["录音"].delete_rows(3, 1)
        workbook.save(row_count_xlsx)
        expect(
            "workbook_module_row_count_difference_is_blocked",
            structure.check_workbook_mirror(row_count_xlsx, tc_excel.read_master_rows(row_count_xlsx)),
            "FMC4 子表行数不一致",
            errors,
            results,
        )

        tampered_xlsx = temp / "mirror-tampered.xlsx"
        shutil.copyfile(good_xlsx, tampered_xlsx)
        workbook = load_workbook(tampered_xlsx)
        sheet = workbook["录音"]
        headers = {str(sheet.cell(1, column).value): column for column in range(1, sheet.max_column + 1)}
        sheet.cell(2, headers["前置条件"]).value = "1.引用公共前置:BASE_ENV"
        workbook.save(tampered_xlsx)
        expect(
            "workbook_child_only_base_env_tamper_is_blocked",
            structure.check_workbook_mirror(tampered_xlsx, tc_excel.read_master_rows(tampered_xlsx)),
            "FMC4 子表字段不一致",
            errors,
            results,
        )
        completed = subprocess.run(
            [sys.executable, str(SCRIPTS / "check_structure.py"), "--xlsx", str(tampered_xlsx)],
            cwd=SCRIPTS.parent,
            text=True,
            capture_output=True,
            encoding="utf-8",
            errors="replace",
        )
        cli_output = completed.stdout + completed.stderr
        cli_blocked = completed.returncode != 0 and "FMC4 子表字段不一致" in cli_output
        results.append({
            "name": "gate_c_cli_blocks_child_only_base_env_tamper",
            "passed": cli_blocked,
            "returncode": completed.returncode,
        })
        if not cli_blocked:
            errors.append(f"gate_c_cli_blocks_child_only_base_env_tamper: {cli_output}")

        dirty_row_xlsx = temp / "mirror-blank-id-dirty-row.xlsx"
        shutil.copyfile(good_xlsx, dirty_row_xlsx)
        workbook = load_workbook(dirty_row_xlsx)
        sheet = workbook["录音"]
        headers = {str(sheet.cell(1, column).value): column for column in range(1, sheet.max_column + 1)}
        sheet.cell(sheet.max_row + 1, headers["备注"]).value = "人工补充内容"
        workbook.save(dirty_row_xlsx)
        expect(
            "workbook_child_blank_case_id_dirty_row_is_blocked",
            structure.check_workbook_mirror(dirty_row_xlsx, tc_excel.read_master_rows(dirty_row_xlsx)),
            "FMC4 子表空编号脏行",
            errors,
            results,
        )

        extra_column_xlsx = temp / "mirror-extra-column.xlsx"
        shutil.copyfile(good_xlsx, extra_column_xlsx)
        workbook = load_workbook(extra_column_xlsx)
        sheet = workbook["录音"]
        extra_column = sheet.max_column + 1
        sheet.cell(1, extra_column).value = "内部执行条件"
        sheet.cell(2, extra_column).value = "人工确认"
        workbook.save(extra_column_xlsx)
        expect(
            "workbook_child_nonstandard_extra_column_is_blocked",
            structure.check_workbook_mirror(extra_column_xlsx, tc_excel.read_master_rows(extra_column_xlsx)),
            "FMC4 非标准额外列",
            errors,
            results,
        )

        hidden_automation_xlsx = temp / "mirror-hidden-automation-cell.xlsx"
        shutil.copyfile(good_xlsx, hidden_automation_xlsx)
        workbook = load_workbook(hidden_automation_xlsx)
        sheet = workbook["录音"]
        extra_column = sheet.max_column + 1
        sheet.cell(1, extra_column).value = "内部执行条件"
        sheet.cell(2, extra_column).value = "Python脚本运行环境"
        workbook.save(hidden_automation_xlsx)
        hidden_violations = structure.check_workbook_mirror(
            hidden_automation_xlsx, tc_excel.read_master_rows(hidden_automation_xlsx)
        )
        expect(
            "workbook_child_any_cell_automation_leak_is_blocked",
            hidden_violations,
            "FMC4 子表自动化泄漏",
            errors,
            results,
        )
    expect(
        "step_expected_one_to_one_passes",
        quality.check_step_expected_contract([base_row()]),
        None,
        errors,
        results,
    )
    expect(
        "step_expected_missing_result_is_blocked",
        quality.check_step_expected_contract([
            base_row(**{"预期结果": "1.每轮插入和拔出均切换对应充电状态\n3.OGG文件可播放"})
        ]),
        "S8 步骤预期非一一对应",
        errors,
        results,
    )
    expect(
        "step_expected_duplicate_numbers_are_blocked",
        quality.check_step_expected_contract([
            base_row(**{
                "操作步骤": "1.插入充电线\n1.拔出充电线",
                "预期结果": "1.设备进入充电状态\n1.设备退出充电状态",
            })
        ]),
        "S8 步骤编号不连续",
        errors,
        results,
    )
    expect(
        "step_expected_gap_numbers_are_blocked",
        quality.check_step_expected_contract([
            base_row(**{
                "操作步骤": "1.插入充电线\n3.拔出充电线",
                "预期结果": "1.设备进入充电状态\n3.设备退出充电状态",
            })
        ]),
        "S8 步骤编号不连续",
        errors,
        results,
    )
    expect(
        "step_inline_second_number_on_same_physical_line_is_blocked",
        quality.check_step_expected_contract([
            base_row(**{
                "操作步骤": "1.打开APP 2.点击设备页",
                "预期结果": "1.APP显示首页\n2.设备页显示已连接设备",
            })
        ]),
        "S8 步骤未逐项编号",
        errors,
        results,
    )
    expect(
        "expected_inline_second_number_on_same_physical_line_is_blocked",
        quality.check_step_expected_contract([
            base_row(**{
                "操作步骤": "1.打开APP\n2.点击设备页",
                "预期结果": "1.APP显示首页 2.设备页显示已连接设备",
            })
        ]),
        "S8 预期未逐项编号",
        errors,
        results,
    )
    numeric_leading_bodies = (
        ("fifty_actions", "1.50次晃动设备", "1.50次晃动均被设备识别"),
        ("fifty_rounds", "1.50轮操作均已完成", "1.50轮结果均显示在页面"),
        ("hundred_steps", "1.完成100步行走", "1.100步计数显示在页面"),
        ("five_alarms", "1.打开闹钟列表", "1.5个闹钟按时间顺序显示"),
    )
    for name, steps, expected in numeric_leading_bodies:
        expect(
            f"numbered_{name}_body_start_is_not_an_inline_number",
            quality.check_step_expected_contract([
                base_row(**{"操作步骤": steps, "预期结果": expected})
            ]),
            None,
            errors,
            results,
        )
    expect(
        "atomic_numbered_manual_steps_pass",
        structure.check([base_row(**{
            "前置条件": "1.设备处于待机状态",
            "操作步骤": "1.打开APP\n2.点击设备页",
            "预期结果": "1.APP显示首页\n2.设备页显示已连接设备",
        })]),
        None,
        errors,
        results,
    )
    expect(
        "comma_separated_actions_are_blocked",
        structure.check([base_row(**{
            "前置条件": "1.设备处于待机状态",
            "操作步骤": "1.打开APP，点击设备页",
            "预期结果": "1.设备页显示已连接设备",
        })]),
        "S9 步骤非原子动作",
        errors,
        results,
    )
    for name, step in (
        ("long_press_drag", "1.长按运动项并拖动至第3位"),
        ("hold_move", "1.按住运动项移动到列表顶部"),
    ):
        expect(
            f"continuous_{name}_is_one_manual_gesture",
            structure.check([base_row(**{
                "前置条件": "1.运动编辑页显示多个运动项",
                "操作步骤": step,
                "预期结果": "1.运动项停留在目标位置",
            })]),
            None,
            errors,
            results,
        )
    expect(
        "continuous_drag_followed_by_click_is_still_blocked",
        structure.check([base_row(**{
            "前置条件": "1.运动编辑页显示多个运动项",
            "操作步骤": "1.长按运动项并拖动至第3位并点击保存",
            "预期结果": "1.运动项停留在目标位置",
        })]),
        "S9 步骤非原子动作",
        errors,
        results,
    )
    expect(
        "comma_separated_results_are_blocked",
        structure.check([base_row(**{
            "前置条件": "1.设备处于待机状态",
            "操作步骤": "1.打开APP",
            "预期结果": "1.APP显示首页，设备页显示已连接设备",
        })]),
        "S9 预期非原子结果",
        errors,
        results,
    )
    expect(
        "period_separated_actions_in_one_number_are_blocked",
        structure.check([base_row(**{
            "前置条件": "1.设备处于待机状态",
            "操作步骤": "1.打开APP。点击设备页",
            "预期结果": "1.设备页显示已连接设备",
        })]),
        "S9 步骤非原子动作",
        errors,
        results,
    )
    expect(
        "period_separated_results_in_one_number_are_blocked",
        structure.check([base_row(**{
            "前置条件": "1.设备处于待机状态",
            "操作步骤": "1.打开APP",
            "预期结果": "1.APP显示首页。设备页显示已连接设备",
        })]),
        "S9 预期非原子结果",
        errors,
        results,
    )
    expect(
        "legacy_schema_skips_new_comma_inference_only",
        structure.check([base_row(**{
            "前置条件": "1.设备处于待机状态",
            "操作步骤": "1.打开APP，点击设备页",
            "预期结果": "1.APP显示首页，设备页显示已连接设备",
        })], enforce_manual_contract=False),
        None,
        errors,
        results,
    )
    expect(
        "legacy_schema_still_blocks_explicit_multi_action_connectors",
        structure.check([base_row(**{
            "前置条件": "1.设备处于待机状态",
            "操作步骤": "1.打开APP并点击设备页",
            "预期结果": "1.设备页显示已连接设备",
        })], enforce_manual_contract=False),
        "S9 步骤非原子动作",
        errors,
        results,
    )
    expect(
        "leading_temporal_adverbs_do_not_invent_second_clause",
        structure.check([base_row(**{
            "前置条件": "1.设备处于待机状态",
            "操作步骤": "1.手机B随后发起配对请求",
            "预期结果": "1.设备随后按1分钟间隔采样",
        })], enforce_manual_contract=False),
        None,
        errors,
        results,
    )
    independent_surface_results = [
        ("device_and_app", "1.A036短振一次，APP显示强档位已选中"),
        ("app_and_device", "1.APP新增一张照片，A036短振一次"),
    ]
    for name, expected in independent_surface_results:
        expect(
            f"comma_independent_{name}_results_are_blocked",
            structure.check([base_row(**{
                "前置条件": "1.设备处于待机状态",
                "操作步骤": "1.执行对应人工操作",
                "预期结果": expected,
            })]),
            "S9 预期非原子结果",
            errors,
            results,
        )
    comma_supplement_cases = [
        ("repeat_count_suffix", "1.每次等待照片保存完成后再次晃动设备，累计20次", "1.APP新增一张照片"),
        ("purpose_suffix", "1.新增一个支持的运动，使列表达到3项", "1.编辑页显示3项运动"),
        ("condition_suffix", "1.查看手机与设备距离", "1.A036与手机相距8米，现场无遮挡"),
        ("duration_suffix", "1.等待查找反馈结束", "1.反馈持续约60秒后停止，期间没有叠加"),
        ("detail_suffix", "1.打开运动编辑页", "1.编辑页显示3项运动，新增项可见"),
        ("device_state_manifestation", "1.等待低电关机", "1.A036自行关机，灯光与振动停止"),
        ("app_flow_landing_detail", "1.结束运动互联", "1.APP结束本次互联，页面显示运动结果"),
        ("app_same_page_prompt_detail", "1.打开运动准备页", "1.APP停留在运动准备页，页面显示连接设备提示"),
    ]
    for name, steps, expected in comma_supplement_cases:
        expect(
            f"comma_{name}_is_not_misclassified",
            structure.check([base_row(**{
                "前置条件": "1.设备处于待机状态",
                "操作步骤": steps,
                "预期结果": expected,
            })]),
            None,
            errors,
            results,
        )
    expect(
        "empty_steps_and_expected_are_blocked",
        structure.check([base_row(**{"操作步骤": "", "预期结果": ""})]),
        "S8 步骤未逐项编号",
        errors,
        results,
    )
    expect(
        "precondition_state_inversion",
        quality.check_production_semantics([
            base_row(**{
                "前置条件": "1.设备正在录音\n2.TF卡剩余空间大于10MB",
                "操作步骤": "1.开始录音\n2.停止录音\n3.打开新生成的OGG文件",
            })
        ], q),
        "S30",
        errors,
        results,
    )
    expect(
        "manual_one_second_twenty_cycles",
        quality.check_production_semantics([base_row(**{"操作步骤": "1.在1秒内插拔充电线20次\n2.停止录音\n3.打开新生成的OGG文件"})], q),
        "S31",
        errors,
        results,
    )
    expect(
        "manual_twenty_per_second",
        quality.check_production_semantics([base_row(**{"操作步骤": "1.以每秒20次频率插拔充电线\n2.停止录音\n3.打开新生成的OGG文件"})], q),
        "S31",
        errors,
        results,
    )
    expect(
        "manual_twenty_actions_each_second_phrase",
        quality.check_production_semantics([base_row(**{"操作步骤": "1.以20次每秒频率插拔充电线\n2.停止录音\n3.打开新生成的OGG文件"})], q),
        "S31",
        errors,
        results,
    )
    expect(
        "manual_continuous_twenty_cycles",
        quality.check_production_semantics([base_row()], q),
        None,
        errors,
        results,
    )
    duplicate_rows = [base_row(), base_row(**{"功能点": "录音文件", "测试项": "文件检查"})]
    expect("duplicate_case_id", structure.check(duplicate_rows), "S22", errors, results)

    all_atomic_hits = structure.check([base_row(**{
        "操作步骤": "1.点击保存并同步\n2.选择录音且选择上传",
        "预期结果": "1.页面显示保存结果且显示同步结果\n2.页面显示录音状态且显示上传状态",
    })])
    s9_hits = [value for value in all_atomic_hits if value.startswith("[S9 ")]
    s9_all_reported = len(s9_hits) == 4
    results.append({"name": "s9_reports_every_non_atomic_line", "passed": s9_all_reported, "violations": s9_hits})
    if not s9_all_reported:
        errors.append(f"s9_reports_every_non_atomic_line: expected 4 S9 violations, got {s9_hits}")

    expect(
        "s25_empty_phrases_still_blocks_internal_fixture",
        structure.check_common_fixtures(
            [base_row(**{"前置条件": "1.引用公共前置:BASE_ENV\n2.设备处于待机状态"})],
            {"common_fixtures": {"fixture_ids": ["BASE_ENV"], "phrases": []}},
        ),
        "S25 人工用例内部fixture泄漏",
        errors,
        results,
    )

    ui_anchor = base_row(**{
        "用例编号": "SET_001", "功能模块": "设置", "功能点": "亮度页面",
        "测试项": "页面展示", "测试点/检查项": "验证进入亮度页面后显示亮度选项",
    })
    ui_operation = base_row(**{
        "用例编号": "SET_002", "功能模块": "设置", "功能点": "亮度页面",
        "测试项": "界面操作", "测试点/检查项": "验证亮度页面上滑切换选项",
    })
    strict_missing = {
        "ui_operation_order": {
            "enabled": True,
            "strict_coverage": True,
            "pages": [{
                "module": "设置", "page": "音量页", "feature_point": "音量页面",
                "anchor_keywords": ["进入音量页面"], "ui_keywords": ["上滑"],
            }],
        }
    }
    expect(
        "s28_strict_missing_page_config_fails",
        structure.check_ui_operation_order([ui_anchor, ui_operation], strict_missing),
        "S28 严格覆盖",
        errors,
        results,
    )
    strict_complete = {
        "ui_operation_order": {
            "enabled": True,
            "strict_coverage": True,
            "pages": [{
                "module": "设置", "page": "亮度页", "feature_point": "亮度页面",
                "anchor_keywords": ["进入亮度页面"], "ui_keywords": ["上滑"],
            }],
        }
    }
    expect(
        "s28_strict_complete_config_passes",
        structure.check_ui_operation_order([ui_anchor, ui_operation], strict_complete),
        None,
        errors,
        results,
    )
    strict_multiple = {
        "ui_operation_order": {
            "enabled": True,
            "strict_coverage": True,
            "pages": [
                {
                    "module": "设置", "page": "亮度页A", "feature_point": "亮度页面",
                    "anchor_keywords": ["进入亮度页面"], "ui_keywords": ["上滑"],
                },
                {
                    "module": "设置", "page": "亮度页B", "feature_point": "亮度页面",
                    "anchor_keywords": ["进入亮度页面"], "ui_keywords": ["亮度页面"],
                },
            ],
        }
    }
    expect(
        "s28_strict_multiple_page_matches_fail",
        structure.check_ui_operation_order([ui_anchor, ui_operation], strict_multiple),
        "S28 严格覆盖多重配置",
        errors,
        results,
    )
    expect(
        "s28_non_strict_empty_config_remains_compatible",
        structure.check_ui_operation_order(
            [ui_anchor, ui_operation],
            {"ui_operation_order": {"enabled": True, "pages": []}},
        ),
        None,
        errors,
        results,
    )

    ota_rows = [
        base_row(**{"用例编号": "OTA_001", "功能模块": "OTA升级", "功能点": "升级结果"}),
        base_row(**{"用例编号": "OTA_002", "功能模块": "OTA升级", "功能点": "升级入口"}),
    ]
    ota_gate = {"OTA升级": {"order": ["升级入口", "升级结果"], "required": True, "mode": "exact"}}
    expect("ota_real_flow_order", structure.check_feature_order(ota_rows, ota_gate), "S7", errors, results)
    expect(
        "bluetooth_dependency_owns_recording_interrupt",
        quality.check_production_semantics([
            base_row(**{
                "用例编号": "BLE_001",
                "功能模块": "蓝牙绑定连接",
                "功能点": "交叉场景",
                "测试点/检查项": "验证录音中解绑后OGG文件保存",
                "操作步骤": "1.录音中在APP执行解绑\n2.打开新生成的OGG文件\n3.刷新设备列表",
                "预期结果": "1.录音停止并保存OGG文件\n2.OGG文件可播放\n3.APP移除当前设备",
            })
        ], q),
        "S32",
        errors,
        results,
    )

    with tempfile.TemporaryDirectory(prefix="qa-quality-regression-") as temp_dir:
        temp = Path(temp_dir)
        workbook = temp / "cases.xlsx"
        workbook.touch()
        recording = base_row()

        bad_conflict = {
            "items": [{
                "action": "手动解绑设备",
                "state": "录音中",
                "matrix_key": "手动解绑设备|录音中",
                "status": "covered",
                "coverage_kind": "generated",
                "affected_module": "录音",
                "expected_owner": "蓝牙绑定连接",
                "case_id": "QA_001",
                "target_case_id": "QA_001",
                "reason": "",
            }]
        }
        (temp / "conflict.json").write_text(json.dumps(bad_conflict, ensure_ascii=False), encoding="utf-8")
        cq = {"conflict_matrix_policy": {"required": True, "index_file": "conflict.json"}}
        expect("conflict_wrong_owner", quality.check_conflict_matrix([recording], cq, workbook), "S33", errors, results)

        good_conflict = json.loads(json.dumps(bad_conflict, ensure_ascii=False))
        good_conflict["items"][0]["expected_owner"] = "录音"
        (temp / "conflict.json").write_text(json.dumps(good_conflict, ensure_ascii=False), encoding="utf-8")
        expect("conflict_affected_owner", quality.check_conflict_matrix([recording], cq, workbook), None, errors, results)

        duplicate_reuse = {"items": [
            dict(good_conflict["items"][0]),
            {
                **dict(good_conflict["items"][0]),
                "action": "关闭蓝牙",
                "matrix_key": "关闭蓝牙|录音中",
            },
        ]}
        (temp / "conflict.json").write_text(json.dumps(duplicate_reuse, ensure_ascii=False), encoding="utf-8")
        expect("conflict_one_case_cannot_fill_multiple_cells", quality.check_conflict_matrix([recording], cq, workbook), "S33", errors, results)

        dimensions = ["主流程与业务规则", "边界与限制"]
        sq = {"scenario_coverage": {"required": True, "file": "scenario.json", "expected_dimensions": dimensions}}
        (temp / "scenario.json").write_text(json.dumps({"items": [
            {"module": "录音", "dimension": "主流程与业务规则", "status": "covered", "case_ids": ["QA_001"]}
        ]}, ensure_ascii=False), encoding="utf-8")
        expect(
            "prd_traceability_is_not_scenario_completeness",
            quality.check_scenario_coverage([recording], sq, workbook, [{"name": "录音"}]),
            "S34",
            errors,
            results,
        )
        (temp / "scenario.json").write_text(json.dumps({
            "items": scenario_items(["录音"], dimensions, "QA_001")
        }, ensure_ascii=False), encoding="utf-8")
        expect(
            "complete_scenario_axis",
            quality.check_scenario_coverage([recording], sq, workbook, [{"name": "录音"}]),
            None,
            errors,
            results,
        )

        missing_cfg = TraceCfg(temp / "trace-missing", ["录音"])
        missing_cfg.out_dir("draft")
        per_module, totals, _, validation_errors = trace_gate.collect(missing_cfg)
        missing = [name for name, summary in per_module if summary is None]
        passed = not missing and totals["testable"] > 0
        results.append({"name": "trace_missing_result_must_fail", "passed": not passed, "missing": missing})
        if passed:
            errors.append("trace_missing_result_must_fail: empty/missing results were treated as PASS")

        partial_cfg = TraceCfg(temp / "trace-partial", ["录音"], {"coverage_policy": {"require_zero_partial": True}})
        draft_dir = partial_cfg.out_dir("draft")
        (draft_dir / "录音.json").write_text(json.dumps({
            "module": "录音",
            "requirements": [{"req_id": "REQ-1", "text": "录音规则"}],
            "cases": [{"id": "QA_001", "测试点": "验证录音规则"}],
        }, ensure_ascii=False), encoding="utf-8")
        result_dir = partial_cfg.out_dir("result")
        (result_dir / "录音.json").write_text(json.dumps({"items": [{
            "req_id": "REQ-1", "testable": True, "status": "部分覆盖", "matched_ids": ["QA_001"], "note": "规则未明确"
        }]}, ensure_ascii=False), encoding="utf-8")
        _, totals, gaps, validation_errors = trace_gate.collect(partial_cfg)
        unexpected_partial = [
            gap for module_gaps in gaps.values() for gap in module_gaps if gap.get("status") == "部分覆盖"
        ]
        passed = totals["testable"] > 0 and totals["un"] == 0 and not unexpected_partial
        results.append({"name": "trace_partial_without_acceptance_must_fail", "passed": not passed})
        if passed:
            errors.append("trace_partial_without_acceptance_must_fail: unaccepted partial coverage was treated as PASS")

        risk_cfg = TraceCfg(temp / "trace-risk-states", ["录音"])
        risk_draft = risk_cfg.out_dir("draft")
        (risk_draft / "录音.json").write_text(json.dumps({
            "module": "录音",
            "requirements": [
                {"req_id": "REQ-CONF", "text": "确定规则"},
                {"req_id": "REQ-MIX", "text": "混合证据规则"},
                {"req_id": "REQ-PEND", "text": "待确认规则"},
            ],
            "cases": [
                {"id": "QA_CONF", "测试点": "验证确定规则", "risk": {"state": "confirmed"}},
                {"id": "QA_PEND", "测试点": "验证待确认规则", "risk": {"state": "pending_confirmation"}},
            ],
        }, ensure_ascii=False), encoding="utf-8")
        risk_result = risk_cfg.out_dir("result")
        (risk_result / "录音.json").write_text(json.dumps({"module": "录音", "items": [
            {"req_id": "REQ-CONF", "testable": True, "status": "已覆盖", "matched_ids": ["QA_CONF"], "note": ""},
            {"req_id": "REQ-MIX", "testable": True, "status": "已覆盖", "matched_ids": ["QA_CONF", "QA_PEND"], "note": ""},
            {"req_id": "REQ-PEND", "testable": True, "status": "已覆盖", "matched_ids": ["QA_PEND"], "note": ""},
        ]}, ensure_ascii=False), encoding="utf-8")
        _, risk_totals, _, risk_errors = trace_gate.collect(risk_cfg)
        risk_states_ok = (
            not risk_errors
            and risk_totals["covered_confirmed"] == 1
            and risk_totals["covered_with_pending"] == 1
            and risk_totals["covered_pending_only"] == 1
        )
        results.append({"name": "trace_evidence_states_confirmed_mixed_pending_only", "passed": risk_states_ok, "totals": risk_totals, "errors": risk_errors})
        if not risk_states_ok:
            errors.append(f"trace_evidence_states_confirmed_mixed_pending_only: {risk_totals} {risk_errors}")

        legacy_item = {
            "req_id": "REQ-LEGACY", "testable": True, "status": "已覆盖",
            "matched_ids": ["QA_LEGACY"], "note": "",
        }
        trace_gate.derive_item_evidence(legacy_item, {
            "QA_LEGACY": {"id": "QA_LEGACY", "预期": "待产品确认:失败提示原文"}
        })
        legacy_pending_ok = legacy_item.get("coverage_state") == "covered_pending_only"
        results.append({"name": "trace_legacy_pending_marker_fallback", "passed": legacy_pending_ok, "item": legacy_item})
        if not legacy_pending_ok:
            errors.append(f"trace_legacy_pending_marker_fallback: {legacy_item}")

        report_ok, report_unexpected, report_errors = trace_gate.evaluate_pending_evidence_policy(
            risk_totals, {"pending_evidence_mode": "report_only"}
        )
        require_ok, require_unexpected, require_errors = trace_gate.evaluate_pending_evidence_policy(
            risk_totals,
            {"pending_evidence_mode": "require_acceptance", "accepted_pending_req_ids": ["REQ-MIX", "REQ-PEND"]},
        )
        require_rejects, _, _ = trace_gate.evaluate_pending_evidence_policy(
            risk_totals,
            {"pending_evidence_mode": "require_acceptance", "accepted_pending_req_ids": ["REQ-MIX"]},
        )
        block_ok, block_unexpected, block_errors = trace_gate.evaluate_pending_evidence_policy(
            risk_totals, {"pending_evidence_mode": "block"}
        )
        policy_ok = (
            report_ok and len(report_unexpected) == 2 and not report_errors
            and require_ok and not require_unexpected and not require_errors
            and not require_rejects
            and not block_ok and len(block_unexpected) == 2 and not block_errors
        )
        results.append({"name": "trace_pending_evidence_policy_modes", "passed": policy_ok})
        if not policy_ok:
            errors.append("trace_pending_evidence_policy_modes: policy evaluation mismatch")

        invalid_cfg = TraceCfg(temp / "trace-invalid-id", ["录音"])
        invalid_draft = invalid_cfg.out_dir("draft")
        (invalid_draft / "录音.json").write_text(json.dumps({
            "module": "录音",
            "requirements": [{"req_id": "REQ-1", "text": "录音规则"}],
            "cases": [{"id": "QA_001", "测试点": "验证录音规则"}],
        }, ensure_ascii=False), encoding="utf-8")
        invalid_result = invalid_cfg.out_dir("result")
        (invalid_result / "录音.json").write_text(json.dumps({"module": "录音", "items": [{
            "req_id": "REQ-1", "testable": True, "status": "已覆盖", "matched_ids": ["DOES_NOT_EXIST"], "note": ""
        }]}, ensure_ascii=False), encoding="utf-8")
        _, _, _, invalid_errors = trace_gate.collect(invalid_cfg)
        invalid_failed = any("matched_ids引用不存在" in error for error in invalid_errors)
        results.append({"name": "trace_invalid_matched_id_must_fail", "passed": invalid_failed, "errors": invalid_errors})
        if not invalid_failed:
            errors.append("trace_invalid_matched_id_must_fail: nonexistent case reference was accepted")

        malformed_cfg = TraceCfg(temp / "trace-malformed", ["录音"])
        malformed_draft = malformed_cfg.out_dir("draft")
        (malformed_draft / "录音.json").write_text(json.dumps({
            "module": "录音", "requirements": [{"req_id": "REQ-1", "text": "录音规则"}],
            "cases": [{"id": "QA_001", "测试点": "验证录音规则"}],
        }, ensure_ascii=False), encoding="utf-8")
        malformed_result = malformed_cfg.out_dir("result")
        (malformed_result / "录音.json").write_text(json.dumps({
            "module": "录音", "items": ["bad-item"]
        }, ensure_ascii=False), encoding="utf-8")
        malformed_crashed = False
        try:
            _, _, _, malformed_errors = trace_gate.collect(malformed_cfg)
        except Exception as exc:  # noqa: BLE001
            malformed_crashed = True
            malformed_errors = [str(exc)]
        malformed_failed_cleanly = (not malformed_crashed) and any("必须是对象" in error for error in malformed_errors)
        results.append({
            "name": "trace_malformed_item_fails_without_crash",
            "passed": malformed_failed_cleanly,
            "errors": malformed_errors,
        })
        if not malformed_failed_cleanly:
            errors.append(f"trace_malformed_item_fails_without_crash: {malformed_errors}")

        cross_cfg = TraceCfg(
            temp / "trace-cross-module",
            ["录音", "蓝牙绑定连接"],
            {"coverage_policy": {"allow_cross_module_matched_ids": True}},
        )
        cross_draft = cross_cfg.out_dir("draft")
        (cross_draft / "录音.json").write_text(json.dumps({
            "module": "录音", "requirements": [{"req_id": "REQ-REC", "text": "录音断连"}],
            "cases": [{"id": "REC_001", "测试点": "验证录音断连"}],
        }, ensure_ascii=False), encoding="utf-8")
        (cross_draft / "蓝牙绑定连接.json").write_text(json.dumps({
            "module": "蓝牙绑定连接", "requirements": [{"req_id": "REQ-BLE", "text": "蓝牙状态"}],
            "cases": [{"id": "BLE_001", "测试点": "验证蓝牙状态"}],
        }, ensure_ascii=False), encoding="utf-8")
        cross_result = cross_cfg.out_dir("result")
        (cross_result / "录音.json").write_text(json.dumps({
            "module": "录音", "items": [{
                "req_id": "REQ-REC", "testable": True, "status": "已覆盖",
                "matched_ids": ["BLE_001"], "note": "遗留跨模块映射"
            }]
        }, ensure_ascii=False), encoding="utf-8")
        (cross_result / "蓝牙绑定连接.json").write_text(json.dumps({
            "module": "蓝牙绑定连接", "items": [{
                "req_id": "REQ-BLE", "testable": True, "status": "已覆盖",
                "matched_ids": ["BLE_001"], "note": ""
            }]
        }, ensure_ascii=False), encoding="utf-8")
        _, _, _, cross_errors = trace_gate.collect(cross_cfg)
        cross_passed = not cross_errors
        results.append({"name": "trace_legacy_cross_module_id_is_verified", "passed": cross_passed, "errors": cross_errors})
        if not cross_passed:
            errors.append(f"trace_legacy_cross_module_id_is_verified: {cross_errors}")

        (cross_result / "录音.json").write_text(json.dumps({
            "module": "录音", "items": [{
                "req_id": "REQ-REC", "testable": True, "status": "已覆盖",
                "matched_ids": ["GHOST_999"], "note": "错误跨模块映射"
            }]
        }, ensure_ascii=False), encoding="utf-8")
        _, _, _, ghost_errors = trace_gate.collect(cross_cfg)
        ghost_failed = any("GHOST_999" in error for error in ghost_errors)
        results.append({"name": "trace_legacy_cross_module_unknown_id_must_fail", "passed": ghost_failed, "errors": ghost_errors})
        if not ghost_failed:
            errors.append("trace_legacy_cross_module_unknown_id_must_fail: unknown global case ID was accepted")

        old_cases = [{"id": "OLD_001", "测试点": "旧标题", "_stable_id": "CASE-A"}]
        new_cases = [{"id": "NEW_009", "测试点": "标题已经修改", "_stable_id": "CASE-A"}]
        old_map = remap.unique_map(old_cases, "id", "stable")
        new_map = remap.unique_map(new_cases, "stable", "id")
        stable_remap_ok = new_map.get(old_map.get("OLD_001", "")) == "NEW_009"
        results.append({"name": "title_change_uses_stable_id", "passed": stable_remap_ok})
        if not stable_remap_ok:
            errors.append("title_change_uses_stable_id: title edit broke stable remapping")

        duplicate_stable_failed = False
        try:
            remap.unique_map([
                {"id": "A", "_stable_id": "DUP"}, {"id": "B", "_stable_id": "DUP"}
            ], "stable", "id")
        except SystemExit:
            duplicate_stable_failed = True
        results.append({"name": "duplicate_stable_id_must_fail", "passed": duplicate_stable_failed})
        if not duplicate_stable_failed:
            errors.append("duplicate_stable_id_must_fail: duplicate stable IDs were accepted")

        missing_stable_failed = False
        try:
            remap.unique_map([{"id": "A", "测试点": "只有标题"}], "stable", "id")
        except SystemExit:
            missing_stable_failed = True
        results.append({"name": "missing_stable_id_must_fail", "passed": missing_stable_failed})
        if not missing_stable_failed:
            errors.append("missing_stable_id_must_fail: title-only fallback was accepted")

        integration = temp / "integration"
        integration.mkdir()
        good_xlsx = integration / "good.xlsx"
        bad_xlsx = integration / "bad.xlsx"
        good_row = base_row(**{
            "功能点": "本地录音",
            "测试项": "稳定性测试",
            "测试点/检查项": "验证连续插拔后录音文件仍可播放",
        })
        bad_row = base_row(**{
            "用例编号": "BLE_001",
            "功能模块": "蓝牙绑定连接",
            "功能点": "交叉场景",
            "测试点/检查项": "验证录音中解绑后的处理",
            "前置条件": "1.具备测试条件",
            "操作步骤": "1.在1秒内插拔充电线20次\n2.录音中执行解绑\n3.查看本步骤执行结果",
            "预期结果": "1.本步骤执行完成\n2.状态可判定\n3.明确结果",
        })
        tc_excel.write_workbook([good_row], good_xlsx, ["录音"])
        tc_excel.write_workbook([bad_row], bad_xlsx, ["蓝牙绑定连接"])
        blueprints = {
            "module_boundary": {}, "feature_order": {}, "page_state_anchors": {}, "input_matrix": {},
            "exception_matrix": [], "cross_matrix": [], "common_fixtures": {},
            "case_precondition_rules": [], "unsupported_features": [],
        }
        (integration / "用例设计蓝图.json").write_text(json.dumps(blueprints, ensure_ascii=False), encoding="utf-8")
        (integration / "good-scenario.json").write_text(json.dumps({"items": [
            {"module": "录音", "dimension": "人工体验", "status": "covered", "case_ids": ["QA_001"]}
        ]}, ensure_ascii=False), encoding="utf-8")
        common_quality = {
            "excel_format": {
                "merge_hierarchy_cells": True,
                "require_precondition_numbering": True,
                "require_test_point_verify_prefix": True,
                "test_point_max_length": 35,
                "check_migration": False,
            },
            "blueprint": {"required": True, "files": ["用例设计蓝图.json"]},
            "production_semantics": {
                "require_nonempty_core_fields": True,
                "check_manual_feasibility": True,
                "check_dependency_module_boundaries": True,
                "preconditions": {"require_nonempty": True, "fixture_ids": ["BASE_ENV"]},
            },
        }
        good_config = {
            "project": "good", "prd_path": "unused.md", "cases_xlsx": "good.xlsx",
            "modules": [{"name": "录音", "prefix": "QA", "prd_sections": []}],
            "quality_gates": {
                **common_quality,
                "scenario_coverage": {"required": True, "file": "good-scenario.json", "expected_dimensions": ["人工体验"]},
            },
        }
        bad_config = {
            "project": "bad", "prd_path": "unused.md", "cases_xlsx": "bad.xlsx",
            "modules": [{"name": "蓝牙绑定连接", "prefix": "BLE", "prd_sections": []}],
            "quality_gates": common_quality,
        }
        good_config_path = integration / "good.config.json"
        bad_config_path = integration / "bad.config.json"
        good_config_path.write_text(json.dumps(good_config, ensure_ascii=False, indent=2), encoding="utf-8")
        bad_config_path.write_text(json.dumps(bad_config, ensure_ascii=False, indent=2), encoding="utf-8")
        good_code, good_output = run_gate(good_config_path)
        good_passed = good_code == 0
        results.append({"name": "gate_c_integrated_good_case", "passed": good_passed, "output": good_output})
        if not good_passed:
            errors.append(f"gate_c_integrated_good_case failed: {good_output}")
        bad_code, bad_output = run_gate(bad_config_path)
        bad_markers = all(marker in bad_output for marker in ("S29", "S30", "S31", "S32"))
        bad_passed = bad_code != 0 and bad_markers
        results.append({"name": "gate_c_integrated_bad_case", "passed": bad_passed, "output": bad_output})
        if not bad_passed:
            errors.append(f"gate_c_integrated_bad_case did not hit S29-S32: {bad_output}")

    output = {"success": not errors, "results": results, "errors": errors}
    print(json.dumps(output, ensure_ascii=False, indent=2))
    if errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
