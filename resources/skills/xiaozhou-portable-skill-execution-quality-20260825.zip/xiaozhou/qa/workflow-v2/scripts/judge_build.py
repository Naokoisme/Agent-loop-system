# -*- coding: utf-8 -*-
"""覆盖判定结果生成器(仓库级)。把紧凑判定展开成 结果/<模块>.json(符合 覆盖追溯判定规范)。

读 projects/<项目>/judgments/<模块>.json:
  {"module":"血氧","verdicts":{"REQ_xxx":[status,[matched_ids],note], ...}}
  status ∈ 已覆盖/部分覆盖/未覆盖/非可测项;非可测项 testable=false。
按 工作底稿/<模块>.json 的 requirements 顺序回填 text/source 输出 结果/<模块>.json。
用法: python scripts/judge_build.py --project <项目> [模块名 ...]
"""
from __future__ import annotations
import argparse, json, glob
from collections import Counter
from pathlib import Path

from traceability.trace_gate import derive_item_evidence
from lineage import record_results, result_binding, validate_judgment_binding
from traceability._common import load_config
from project_paths import resolve_project

ROOT = Path(__file__).resolve().parents[1]


def build(pdir: Path, mod: str, draft_dir: Path, result_dir: Path):
    draft_path = draft_dir / f"{mod}.json"
    draft = json.loads(draft_path.read_text(encoding="utf-8"))
    jd = json.loads((pdir / "judgments" / f"{mod}.json").read_text(encoding="utf-8"))
    validate_judgment_binding(pdir, draft_path, jd)
    verdicts = jd["verdicts"]
    cases_by_id = {
        str(case.get("id", "")): case for case in draft.get("cases", [])
        if isinstance(case, dict) and str(case.get("id", ""))
    }
    items, missing = [], []
    for r in draft["requirements"]:
        rid = r["req_id"]
        if rid not in verdicts:
            missing.append(rid); continue
        status, ids, note = verdicts[rid]
        item = {"req_id": rid, "text": r["text"], "source": r["source"],
                "testable": status != "非可测项", "status": status,
                "matched_ids": ids, "note": note}
        derive_item_evidence(item, cases_by_id)
        items.append(item)
    if missing:
        raise SystemExit(f"[{mod}] 缺判定: {missing}")
    result_dir.mkdir(parents=True, exist_ok=True)
    payload = {"module": mod, "items": items}
    binding = result_binding(pdir, draft_path)
    if binding:
        payload["_lineage"] = binding
    (result_dir / f"{mod}.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"  {mod:14s} {len(items):3d} 项 | {dict(Counter(i['status'] for i in items))}")


def main():
    ap = argparse.ArgumentParser(description="覆盖判定结果生成器")
    ap.add_argument("--project", required=True)
    ap.add_argument("--workspace-root", help="项目工作区根目录；--project 为名称时生效")
    ap.add_argument(
        "--finalize-existing", action="store_true",
        help="不重建判定，只校验并登记当前全部模块 result 哈希；供外部AI写结果后显式收口",
    )
    ap.add_argument("modules", nargs="*", help="指定模块名;缺省全部 judgments/*.json")
    args = ap.parse_args()
    pdir = resolve_project(args.project, workspace_root=args.workspace_root)
    cfg = load_config(pdir / "trace.config.json")
    draft_dir = cfg.out_dir("draft")
    result_dir = cfg.out_dir("result")
    mods = args.modules or [Path(p).stem for p in sorted(glob.glob(str(pdir / "judgments" / "*.json")))]
    if not args.finalize_existing:
        for m in mods:
            build(pdir, m, draft_dir, result_dir)
    result_paths = [result_dir / f"{mod['name']}.json" for mod in cfg.modules]
    if all(path.is_file() for path in result_paths):
        record_results(pdir, result_paths)
    elif args.finalize_existing:
        missing = [str(path) for path in result_paths if not path.is_file()]
        raise SystemExit(f"无法 finalize，缺模块结果: {missing}")


if __name__ == "__main__":
    main()
