# -*- coding: utf-8 -*-
"""Focused regressions for lightweight routing, external workspaces, and S36/S37."""
from __future__ import annotations

import copy
import json
import subprocess
import sys
import tempfile
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parent
WORKFLOW = SCRIPTS.parent
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import check_structure as structure  # noqa: E402
import execution_profile as profiles  # noqa: E402
import new_project  # noqa: E402
import release_acceptance as release  # noqa: E402
import work_unit_contract as work_units  # noqa: E402
from project_paths import resolve_project, validate_component  # noqa: E402


def assert_true(name: str, condition: bool, detail: object, errors: list[str], results: list[dict]) -> None:
    results.append({"name": name, "passed": bool(condition), "detail": detail})
    if not condition:
        errors.append(f"{name}: {detail}")


def run_new_project(*args: str) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, str(SCRIPTS / "new_project.py"), *args],
        cwd=WORKFLOW,
        text=True,
        capture_output=True,
        encoding="utf-8",
        errors="replace",
    )


def row(case_id: str, module: str, feature: str, item: str, platform: str = "") -> dict:
    return {
        "用例编号": case_id,
        "功能模块": module,
        "功能点": feature,
        "测试项": item,
        "测试点/检查项": f"验证{feature}{platform}主流程",
        "前置条件": f"1.已安装{platform}版本" if platform else "1.已进入功能入口",
        "操作步骤": "1.执行主流程操作",
        "预期结果": "1.页面显示主流程结果",
        "兼容性": platform or "N/A",
        "备注": "",
    }


def main() -> None:
    errors: list[str] = []
    results: list[dict] = []

    core = profiles.build_profile(
        requested_mode="auto",
        work_units=["AI问答", "AI翻译"],
        platform_scope=["Android", "iOS"],
    )
    assert_true(
        "auto_multi_function_routes_core_with_peer_and_platform",
        core["base_path"] == "core"
        and core["parallel_generation"] is True
        and {"peer_review", "platform_coverage"}.issubset(core["capability_packs"]),
        core,
        errors,
        results,
    )
    strict = profiles.build_profile(requested_mode="auto", risk_flags=["ota"])
    assert_true(
        "high_risk_only_upgrades_to_strict",
        strict["base_path"] == "strict" and profiles.STRICT_PACKS.issubset(strict["capability_packs"]),
        strict,
        errors,
        results,
    )
    tampered = copy.deepcopy(core)
    tampered["delivery_target"] = "STRICT_GO"
    tampered["release_target"] = "GO"
    assert_true(
        "profile_tampering_is_rejected",
        any("delivery_target" in value for value in profiles.validate_profile(tampered))
        and any("release_target" in value for value in profiles.validate_profile(tampered)),
        profiles.validate_profile(tampered),
        errors,
        results,
    )
    removed_peer = copy.deepcopy(core)
    removed_peer["capability_packs"].remove("peer_review")
    removed_peer["not_enabled"]["peer_review"] = "手工删除"
    removed_platform = copy.deepcopy(core)
    removed_platform["capability_packs"].remove("platform_coverage")
    removed_platform["not_enabled"]["platform_coverage"] = "手工删除"
    fake_legacy = copy.deepcopy(core)
    fake_legacy["legacy_fallback"] = True
    assert_true(
        "derived_peer_platform_and_legacy_flags_cannot_be_downgraded",
        any("peer_review" in value for value in profiles.validate_profile(removed_peer))
        and any("platform_coverage" in value for value in profiles.validate_profile(removed_platform))
        and any("legacy_fallback" in value for value in profiles.validate_profile(fake_legacy)),
        {
            "peer": profiles.validate_profile(removed_peer),
            "platform": profiles.validate_profile(removed_platform),
            "legacy": profiles.validate_profile(fake_legacy),
        },
        errors,
        results,
    )
    legacy = profiles.build_profile(requested_mode="strict")
    legacy.update({"requested_mode": "legacy", "legacy_fallback": True, "not_enabled": {}})
    assert_true(
        "legacy_missing_new_routing_fields_remains_compatible",
        release.execution_profile_routing_errors({}, legacy) == [],
        release.execution_profile_routing_errors({}, legacy),
        errors,
        results,
    )
    assert_true(
        "legacy_explicit_wrong_routing_field_is_rejected",
        any(
            "pilot_required" in value
            for value in release.execution_profile_routing_errors({"pilot_required": False}, legacy)
        ),
        release.execution_profile_routing_errors({"pilot_required": False}, legacy),
        errors,
        results,
    )
    core_release = {
        "delivery_target": "READY_FOR_REVIEW",
        "full_traceability_required": False,
        "pilot_required": False,
        "formal_release_required": False,
    }
    assert_true(
        "new_core_requires_complete_matching_routing_fields",
        release.execution_profile_routing_errors(core_release, core) == []
        and len(release.execution_profile_routing_errors({}, core)) == 4,
        release.execution_profile_routing_errors({}, core),
        errors,
        results,
    )

    for value in ("..", "../escape", "nested/name", "nested\\name", "C:/escape"):
        blocked = False
        try:
            validate_component(value)
        except ValueError:
            blocked = True
        assert_true(f"unsafe_component_blocked_{value}", blocked, value, errors, results)

    with tempfile.TemporaryDirectory(prefix="qa-lightweight-routing-") as tmp:
        base = Path(tmp)
        workspace = base / "workspace"
        workspace.mkdir()
        escaped = False
        try:
            resolve_project("..\\escape", workspace_root=workspace)
        except ValueError:
            escaped = True
        assert_true("workspace_traversal_is_blocked", escaped, str(workspace), errors, results)

        conflict = False
        try:
            resolve_project(base / "absolute", workspace_root=workspace)
        except ValueError:
            conflict = True
        assert_true("absolute_project_and_workspace_conflict", conflict, str(base), errors, results)

        proc = run_new_project(
            "--name", "AI功能集", "--workspace-root", str(workspace),
            "--execution-mode", "auto", "--work-unit", "AI问答", "--work-unit", "AI翻译",
            "--platform", "Android", "--platform", "iOS",
        )
        project = workspace / "AI功能集"
        profile = json.loads((project / "执行画像.json").read_text(encoding="utf-8")) if proc.returncode == 0 else {}
        config = json.loads((project / "trace.config.json").read_text(encoding="utf-8")) if proc.returncode == 0 else {}
        assert_true(
            "external_workspace_core_scaffold",
            proc.returncode == 0
            and profile.get("base_path") == "core"
            and config.get("workspace", {}).get("external") is True
            and config.get("release_acceptance", {}).get("delivery_target") == "READY_FOR_REVIEW"
            and not (project / "生成验收合同.json").exists()
            and (project / "工作底稿" / "同行评审.json").is_file()
            and all(
                (project / "workunits" / name / work_units.CONTRACT_FILENAME).is_file()
                for name in ("AI问答", "AI翻译")
            )
            and config.get("workspace", {}).get("work_unit_contracts_required") is True,
            proc.stdout + proc.stderr,
            errors,
            results,
        )
        profile_path = project / profiles.PROFILE_FILENAME
        no_pointer = copy.deepcopy(config)
        no_pointer.pop("execution_profile", None)
        assert_true(
            "new_profile_pointer_is_mandatory_and_profile_is_still_hashed",
            bool(release.execution_profile_pointer_errors(project / "trace.config.json", no_pointer, profile))
            and profile_path.resolve() in release.input_files(project / "trace.config.json", no_pointer),
            release.execution_profile_pointer_errors(project / "trace.config.json", no_pointer, profile),
            errors,
            results,
        )

        (project / "prd.md").write_text("# AI功能PRD\n", encoding="utf-8")
        config["prd_path"] = "prd.md"
        (project / "trace.config.json").write_text(
            json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8",
        )
        frozen = work_units.freeze_project_contracts(project, profile)
        for unit, reviewer in (("AI问答", "AI翻译"), ("AI翻译", "AI问答")):
            unit_dir = project / "workunits" / unit
            case_path = unit_dir / "cases.json"
            self_path = unit_dir / "自检.json"
            peer_path = unit_dir / "同行评审.json"
            case_path.write_text(
                json.dumps({"cases": [{"用例编号": f"{unit}_001"}]}, ensure_ascii=False),
                encoding="utf-8",
            )
            self_path.write_text(json.dumps({"status": "PASS"}), encoding="utf-8")
            peer_path.write_text(json.dumps({"status": "PASS"}), encoding="utf-8")
            contract_path = unit_dir / work_units.CONTRACT_FILENAME
            contract = json.loads(contract_path.read_text(encoding="utf-8"))
            case_hash = work_units.sha256(case_path)
            contract["handoff"].update({
                "status": "REVIEWED",
                "case_count": 1,
                "current_sha256": case_hash,
                "submitted_by": f"agent-{unit}",
                "submitted_at": "2026-08-19T00:00:00+00:00",
            })
            contract["handoff"]["self_check"].update({
                "status": "PASS", "current_sha256": work_units.sha256(self_path),
            })
            contract["handoff"]["peer_review"].update({
                "status": "PASS",
                "reviewer_work_unit": reviewer,
                "current_sha256": work_units.sha256(peer_path),
            })
            contract["main_acceptance"].update({
                "status": "PASS",
                "accepted_case_sha256": case_hash,
                "accepted_by": "main-agent",
                "accepted_at": "2026-08-19T00:10:00+00:00",
            })
            contract_path.write_text(
                json.dumps(contract, ensure_ascii=False, indent=2), encoding="utf-8",
            )
        contract_errors, contract_metrics = work_units.validate_project_contracts(
            project, profile, require_frozen=True, require_complete=True,
        )
        assert_true(
            "parallel_work_unit_contracts_freeze_handoff_review_and_accept",
            not contract_errors
            and contract_metrics.get("work_unit_contracts_validated") == 2
            and len(frozen.get("snapshot_id", "")) == 64,
            {"errors": contract_errors, "metrics": contract_metrics},
            errors,
            results,
        )
        escape_contract_path = project / "workunits" / "AI问答" / work_units.CONTRACT_FILENAME
        escape_contract = json.loads(escape_contract_path.read_text(encoding="utf-8"))
        escape_contract["handoff"]["case_file"] = "workunits/AI翻译/cases.json"
        escape_errors = work_units.validate_contract(
            project,
            escape_contract_path,
            escape_contract,
            expected_work_unit="AI问答",
            expected_project="AI功能集",
        )
        assert_true(
            "work_unit_cross_directory_write_is_rejected",
            any("越出当前工作单目录" in value for value in escape_errors),
            escape_errors,
            errors,
            results,
        )
        (project / "prd.md").write_text("# AI功能PRD\n变更\n", encoding="utf-8")
        stale_errors, _ = work_units.validate_project_contracts(
            project, profile, require_frozen=True, require_complete=True,
        )
        assert_true(
            "work_unit_shared_input_change_invalidates_snapshot",
            any("共享输入已变化" in value for value in stale_errors),
            stale_errors,
            errors,
            results,
        )

        strict_proc = run_new_project(
            "--name", "严格项目", "--workspace-root", str(workspace), "--execution-mode", "strict",
        )
        strict_project = workspace / "严格项目"
        strict_config = json.loads((strict_project / "trace.config.json").read_text(encoding="utf-8")) \
            if strict_proc.returncode == 0 else {}
        assert_true(
            "strict_scaffold_keeps_full_contract",
            strict_proc.returncode == 0
            and strict_config.get("release_acceptance", {}).get("delivery_target") == "STRICT_GO"
            and (strict_project / "生成验收合同.json").is_file()
            and (strict_project / "工作底稿" / "多轮测试用例评审.json").is_file()
            and (
                strict_project / "workunits" / "严格项目" / work_units.CONTRACT_FILENAME
            ).is_file(),
            strict_proc.stdout + strict_proc.stderr,
            errors,
            results,
        )

        single_core_proc = run_new_project(
            "--name", "单功能核心项目", "--workspace-root", str(workspace),
            "--execution-mode", "core",
        )
        single_core_project = workspace / "单功能核心项目"
        assert_true(
            "single_core_does_not_require_peer_review_artifact",
            single_core_proc.returncode == 0
            and not (single_core_project / "工作底稿" / "同行评审.json").exists(),
            single_core_proc.stdout + single_core_proc.stderr,
            errors,
            results,
        )

        legacy = workspace / "遗留项目"
        legacy.mkdir()
        (legacy / "trace.config.json").write_text("{}", encoding="utf-8")
        legacy_proc = run_new_project("--name", "遗留项目", "--workspace-root", str(workspace))
        assert_true(
            "legacy_project_is_not_silently_profiled",
            legacy_proc.returncode != 0
            and not (legacy / "执行画像.json").exists()
            and "历史项目" in legacy_proc.stdout + legacy_proc.stderr,
            legacy_proc.stdout + legacy_proc.stderr,
            errors,
            results,
        )

    split_rows = [
        row("A_001", "AI问答", "回答", "页面内容"),
        row("A_002", "AI问答", "回答", "异常测试"),
        row("A_003", "AI问答", "回答", "页面内容"),
    ]
    assert_true(
        "s36_detects_split_three_level_group",
        any("S36 三级分组不连续" in value for value in structure.check_hierarchy_contiguous_blocks(split_rows)),
        structure.check_hierarchy_contiguous_blocks(split_rows),
        errors,
        results,
    )
    legal_exception = [{
        "module": "AI问答", "feature_point": "回答", "test_item": "页面内容",
        "reason": "两个生命周期阶段均需就近展示", "max_blocks": 2,
    }]
    assert_true(
        "s36_exact_active_exception_passes",
        not structure.check_hierarchy_contiguous_blocks(split_rows, legal_exception),
        structure.check_hierarchy_contiguous_blocks(split_rows, legal_exception),
        errors,
        results,
    )
    stale = [{
        "module": "AI问答", "feature_point": "回答", "test_item": "不存在",
        "reason": "历史例外", "max_blocks": 2,
    }]
    assert_true(
        "s36_stale_exception_fails",
        any("S36 连续区块例外失效" in value for value in structure.check_hierarchy_contiguous_blocks(split_rows, stale)),
        structure.check_hierarchy_contiguous_blocks(split_rows, stale),
        errors,
        results,
    )
    unknown = [{
        "module": "AI问答", "feature_point": "回答", "test_item": "页面内容",
        "reason": "业务原因", "max_blocks": 2, "enabled": False,
    }]
    assert_true(
        "s36_unknown_exception_field_fails",
        any("未知字段" in value for value in structure.check_hierarchy_contiguous_blocks(split_rows, unknown)),
        structure.check_hierarchy_contiguous_blocks(split_rows, unknown),
        errors,
        results,
    )

    platform_rows = [
        row("P_001", "AI问答", "提问与回答", "主流程", "Android"),
        row("P_002", "AI问答", "提问与回答", "主流程", "iOS"),
    ]
    platform_cfg = {
        "required": True,
        "platforms": ["Android", "iOS"],
        "main_flow_feature_points": [{"module": "AI问答", "feature_point": "提问与回答"}],
        "fields": ["兼容性", "测试点/检查项", "前置条件", "操作步骤", "预期结果", "备注"],
    }
    assert_true(
        "s37_android_ios_main_flow_passes",
        not structure.check_platform_coverage(platform_rows, platform_cfg),
        structure.check_platform_coverage(platform_rows, platform_cfg),
        errors,
        results,
    )
    assert_true(
        "s37_missing_ios_main_flow_fails",
        any("S37 平台主流程漏覆盖" in value for value in structure.check_platform_coverage(platform_rows[:1], platform_cfg)),
        structure.check_platform_coverage(platform_rows[:1], platform_cfg),
        errors,
        results,
    )

    print(json.dumps({"success": not errors, "results": results, "errors": errors}, ensure_ascii=False, indent=2))
    if errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
