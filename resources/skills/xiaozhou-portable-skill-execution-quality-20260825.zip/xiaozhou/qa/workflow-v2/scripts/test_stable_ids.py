# -*- coding: utf-8 -*-
"""Focused regression for durable testcase identities and legacy bootstrap."""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch


SCRIPTS = Path(__file__).resolve().parent
WORKFLOW = SCRIPTS.parent
PROJECTS = WORKFLOW / "projects"
sys.path.insert(0, str(SCRIPTS))

import stable_ids as stable_ids_module  # noqa: E402
from stable_ids import (  # noqa: E402
    StableIdentityError,
    case_stable_identity,
    commit_staged_files,
    ensure_case_stable_id,
)
from check_structure import check_migration  # noqa: E402
from test_generation_contract_regressions import (  # noqa: E402
    combination_case,
    structured_case,
    valid_contract,
    write_project,
)


def run(
    args: list[str],
    *,
    env: dict[str, str] | None = None,
) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        [sys.executable, *args],
        cwd=WORKFLOW,
        text=True,
        capture_output=True,
        encoding="utf-8",
        errors="replace",
        env=env,
    )


def file_snapshot(paths: list[Path]) -> dict[Path, bytes | None]:
    return {path: path.read_bytes() if path.is_file() else None for path in paths}


def restore_snapshot(snapshot: dict[Path, bytes | None]) -> None:
    for path, content in snapshot.items():
        if content is None:
            path.unlink(missing_ok=True)
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(content)


def snapshot_matches(snapshot: dict[Path, bytes | None]) -> bool:
    return all(
        (path.read_bytes() if path.is_file() else None) == content
        for path, content in snapshot.items()
    )


def blueprint() -> dict:
    return {
        "module_boundary": {}, "feature_order": {}, "page_state_anchors": {}, "input_matrix": {},
        "exception_matrix": [], "cross_matrix": [], "common_fixtures": {},
        "case_precondition_rules": [], "unsupported_features": [],
    }


def spec_case(title: str) -> dict:
    return {
        "fp": "录音入口", "ti": "入口检查", "tp": title,
        "pre": "1.设备处于待机且TF卡剩余空间大于10MB",
        "step": "1.短按录音键", "exp": "1.设备开始录音并生成临时录音文件",
    }


def main() -> None:
    errors: list[str] = []
    results: list[dict] = []

    case: dict = {}
    first, changed = ensure_case_stable_id(case)
    second, changed_again = ensure_case_stable_id(case)
    ok = changed and not changed_again and first == second and first.startswith("CASE::")
    results.append({"name": "uuid_is_persisted_and_reused", "passed": ok})
    if not ok:
        errors.append("normal case UUID was not stable across repeated reads")

    matrix_value, matrix_key = case_stable_identity({"_matrix_key": "解绑|录音中"})
    ok = matrix_value == "MATRIX::解绑|录音中" and matrix_key == "解绑|录音中"
    results.append({"name": "matrix_key_is_canonical_identity", "passed": ok})
    if not ok:
        errors.append("matrix_key did not become the canonical matrix identity")

    alias_conflict = False
    try:
        case_stable_identity({"stable_id": "CASE::A", "_stable_id": "CASE::B"})
    except StableIdentityError:
        alias_conflict = True
    results.append({"name": "conflicting_aliases_must_fail", "passed": alias_conflict})
    if not alias_conflict:
        errors.append("conflicting stable ID aliases were accepted")

    retry_root = Path(tempfile.mkdtemp(prefix="stable_replace_retry_"))
    try:
        retry_target = retry_root / "cases.xlsx"
        retry_staged = retry_root / "staged.xlsx"
        retry_target.write_bytes(b"old")
        retry_staged.write_bytes(b"new")
        real_replace = stable_ids_module.os.replace
        forward_attempts = 0

        def flaky_forward_replace(source, target):
            nonlocal forward_attempts
            if ".qa-new-" in Path(source).name and Path(target) == retry_target and forward_attempts < 2:
                forward_attempts += 1
                raise PermissionError(13, "simulated transient forward lock")
            return real_replace(source, target)

        with patch.object(stable_ids_module.os, "replace", side_effect=flaky_forward_replace):
            commit_staged_files([(retry_staged, retry_target)])
        forward_retry_ok = forward_attempts == 2 and retry_target.read_bytes() == b"new"

        retry_target.write_bytes(b"old")
        retry_staged.write_bytes(b"new")
        rollback_attempts = 0

        def flaky_rollback_replace(source, target):
            nonlocal rollback_attempts
            if ".qa-old-" in Path(source).name and Path(target) == retry_target and rollback_attempts < 2:
                rollback_attempts += 1
                raise PermissionError(13, "simulated transient rollback lock")
            return real_replace(source, target)

        def fail_post_commit():
            raise RuntimeError("forced post-commit failure")

        forced_failure_seen = False
        with patch.object(stable_ids_module.os, "replace", side_effect=flaky_rollback_replace):
            try:
                commit_staged_files(
                    [(retry_staged, retry_target)],
                    post_commit=fail_post_commit,
                )
            except RuntimeError as exc:
                forced_failure_seen = "forced post-commit failure" in str(exc)
        rollback_retry_ok = (
            forced_failure_seen
            and rollback_attempts == 2
            and retry_target.read_bytes() == b"old"
        )
        retry_ok = forward_retry_ok and rollback_retry_ok
        results.append({"name": "transient_replace_lock_is_retried_for_commit_and_rollback", "passed": retry_ok})
        if not retry_ok:
            errors.append(
                "transient replace retry failed: "
                f"forward={forward_retry_ok} rollback={rollback_retry_ok}"
            )
    finally:
        shutil.rmtree(retry_root, ignore_errors=True)

    PROJECTS.mkdir(parents=True, exist_ok=True)
    pilot_project = Path(tempfile.mkdtemp(prefix="_stable_id_pilot_full_", dir=PROJECTS))
    pilot_name = pilot_project.name
    try:
        pilot_contract = valid_contract()
        pilot_contract["schema_version"] = 1
        write_project(
            pilot_project,
            [combination_case()],
            require_contract=True,
            contract=pilot_contract,
        )
        pilot_first = run([str(SCRIPTS / "casegen.py"), "--project", pilot_name, "--pilot"])
        record_spec = pilot_project / "specs" / "记录.json"
        first_payload = json.loads(record_spec.read_text(encoding="utf-8"))
        first_payload["cases"].insert(0, structured_case("CASE::FULL-NEW"))
        record_spec.write_text(
            json.dumps(first_payload, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        full_after_pilot = run([str(SCRIPTS / "casegen.py"), "--project", pilot_name])
        full_rows = json.loads(
            (pilot_project / "cases" / "记录.json").read_text(encoding="utf-8")
        )["cases"] if full_after_pilot.returncode == 0 else []
        full_ids = {row.get("_stable_id"): row.get("用例编号") for row in full_rows}
        pilot_to_full_ok = (
            pilot_first.returncode == 0
            and full_after_pilot.returncode == 0
            and full_ids.get("CASE::COMBO-001") == "SAVE_001"
            and full_ids.get("CASE::FULL-NEW") == "SAVE_002"
            and not (pilot_project / "用例稳定索引.json").exists()
        )
        results.append({"name": "pilot_to_full_without_index_preserves_and_appends_ids", "passed": pilot_to_full_ok})
        if not pilot_to_full_ok:
            errors.append(
                f"pilot->full history was not merged without index: "
                f"{pilot_first.stdout} {full_after_pilot.stdout} {full_ids}"
            )

        second_payload = json.loads(record_spec.read_text(encoding="utf-8"))
        second_payload["cases"].insert(0, structured_case("CASE::PILOT-NEW"))
        record_spec.write_text(
            json.dumps(second_payload, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        pilot_after_full = run([str(SCRIPTS / "casegen.py"), "--project", pilot_name, "--pilot"])
        pilot_rows = json.loads(
            (pilot_project / "pilot_cases" / "记录.json").read_text(encoding="utf-8")
        )["cases"] if pilot_after_full.returncode == 0 else []
        pilot_ids = {row.get("_stable_id"): row.get("用例编号") for row in pilot_rows}
        full_to_pilot_ok = (
            pilot_after_full.returncode == 0
            and pilot_ids.get("CASE::COMBO-001") == "SAVE_001"
            and pilot_ids.get("CASE::FULL-NEW") == "SAVE_002"
            and pilot_ids.get("CASE::PILOT-NEW") == "SAVE_003"
            and not (pilot_project / "用例稳定索引.json").exists()
        )
        results.append({"name": "full_to_pilot_without_index_preserves_and_appends_ids", "passed": full_to_pilot_ok})
        if not full_to_pilot_ok:
            errors.append(
                f"full->pilot history was not merged without index: "
                f"{pilot_after_full.stdout} {pilot_after_full.stderr} {pilot_ids}"
            )
    finally:
        if pilot_project.exists():
            shutil.rmtree(pilot_project)

    high_water_project = Path(tempfile.mkdtemp(prefix="_stable_id_high_water_", dir=PROJECTS))
    high_water_name = high_water_project.name
    try:
        (high_water_project / "specs").mkdir(parents=True)
        high_water_spec = high_water_project / "specs" / "录音.json"
        first_high_water_case = spec_case("验证历史高水位已有用例")
        first_high_water_case["_stable_id"] = "CASE::HIGH-WATER-OLD"
        second_high_water_case = spec_case("验证历史高水位后新增用例")
        second_high_water_case["_stable_id"] = "CASE::HIGH-WATER-NEW"
        high_water_spec.write_text(json.dumps({
            "module": "录音", "prefix": "REC",
            "cases": [first_high_water_case, second_high_water_case],
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        (high_water_project / "用例设计蓝图.json").write_text(
            json.dumps(blueprint(), ensure_ascii=False, indent=2), encoding="utf-8"
        )
        (high_water_project / "用例稳定索引.json").write_text(json.dumps({
            "schema_version": 2,
            "items": [{
                "stable_id": "CASE::HIGH-WATER-OLD", "case_id": "REC_001", "matrix_key": "",
            }],
            "retired_items": [],
            "high_water": {"REC": 9},
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        high_water_run = run([str(SCRIPTS / "casegen.py"), "--project", high_water_name])
        high_water_rows = json.loads(
            (high_water_project / "cases" / "录音.json").read_text(encoding="utf-8")
        )["cases"] if high_water_run.returncode == 0 else []
        high_water_ids = {row.get("_stable_id"): row.get("用例编号") for row in high_water_rows}
        high_water_ok = (
            high_water_run.returncode == 0
            and high_water_ids.get("CASE::HIGH-WATER-OLD") == "REC_001"
            and high_water_ids.get("CASE::HIGH-WATER-NEW") == "REC_010"
        )
        results.append({"name": "casegen_appends_after_declared_index_high_water", "passed": high_water_ok})
        if not high_water_ok:
            errors.append(f"casegen ignored stable-index high_water: {high_water_run.stdout} {high_water_ids}")

        high_water_index = high_water_project / "用例稳定索引.json"
        high_water_cases = high_water_project / "cases" / "录音.json"
        high_water_artifacts = [high_water_spec, high_water_index, high_water_cases]
        high_water_baseline = file_snapshot(high_water_artifacts)
        high_water_payload = json.loads(high_water_index.read_text(encoding="utf-8"))
        v2_gate_ok = True
        v2_gate_details: list[str] = []
        for variant, value in (("missing", None), ("not_object", [])):
            candidate = json.loads(json.dumps(high_water_payload, ensure_ascii=False))
            if value is None:
                candidate.pop("high_water", None)
            else:
                candidate["high_water"] = value
            high_water_index.write_text(
                json.dumps(candidate, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            before = file_snapshot(high_water_artifacts)
            blocked = run([str(SCRIPTS / "casegen.py"), "--project", high_water_name])
            if (
                blocked.returncode == 0
                or "high_water" not in blocked.stdout + blocked.stderr
                or not snapshot_matches(before)
            ):
                v2_gate_ok = False
                v2_gate_details.append(
                    f"{variant}: rc={blocked.returncode} out={blocked.stdout} err={blocked.stderr}"
                )
            restore_snapshot(high_water_baseline)

        v1_payload = json.loads(json.dumps(high_water_payload, ensure_ascii=False))
        v1_payload["schema_version"] = 1
        v1_payload.pop("high_water", None)
        high_water_index.write_text(
            json.dumps(v1_payload, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        v1_compatible = run([str(SCRIPTS / "casegen.py"), "--project", high_water_name])
        high_water_schema_ok = v2_gate_ok and v1_compatible.returncode == 0
        results.append({
            "name": "schema_v2_index_requires_high_water_object_and_v1_remains_compatible",
            "passed": high_water_schema_ok,
        })
        if not high_water_schema_ok:
            errors.append(
                "stable-index high_water schema gate failed: "
                + " | ".join(v2_gate_details)
                + f" | v1={v1_compatible.stdout} {v1_compatible.stderr}"
            )
        restore_snapshot(high_water_baseline)
    finally:
        if high_water_project.exists():
            shutil.rmtree(high_water_project)

    generated_project = Path(tempfile.mkdtemp(prefix="_stable_id_casegen_", dir=PROJECTS))
    generated_name = generated_project.name
    try:
        specs = generated_project / "specs"
        specs.mkdir(parents=True)
        spec_path = specs / "录音.json"
        spec_path.write_text(json.dumps({
            "module": "录音", "prefix": "REC", "cases": [spec_case("验证按键启动录音")],
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        ui_path = generated_project / "ui_pages.json"
        ui_path.write_text(json.dumps({
            "录音": [{"page": "录音首页", "fp": "录音入口"}],
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        (generated_project / "用例设计蓝图.json").write_text(
            json.dumps(blueprint(), ensure_ascii=False, indent=2), encoding="utf-8"
        )
        first_run = run([str(SCRIPTS / "casegen.py"), "--project", generated_name])
        first_spec = json.loads(spec_path.read_text(encoding="utf-8"))
        first_ui = json.loads(ui_path.read_text(encoding="utf-8"))
        first_id = str(first_spec["cases"][0].get("_stable_id", ""))
        page_id = str(first_ui["录音"][0].get("_stable_id", ""))
        generated_rows = json.loads(
            (generated_project / "cases" / "录音.json").read_text(encoding="utf-8")
        )["cases"]
        first_case_id = next(
            str(row.get("用例编号", "")) for row in generated_rows
            if row.get("_stable_id") == first_id
        )
        historical_max = max(
            int(str(row["用例编号"]).rsplit("_", 1)[1]) for row in generated_rows
        )
        ui_ids = {str(row.get("_stable_id", "")) for row in generated_rows if row.get("测试项") == "界面操作"}
        expected_ui = {
            f"{page_id}::INPUT::{gesture}" for gesture in
            ("上滑", "下滑", "左滑", "右滑", "单击侧键", "双击侧键", "长按侧键3s", "长按侧键10s")
        }
        casegen_ok = first_run.returncode == 0 and first_id.startswith("CASE::") and page_id.startswith("PAGE::")
        results.append({"name": "casegen_persists_spec_and_page_ids", "passed": casegen_ok})
        if not casegen_ok:
            errors.append(f"casegen did not persist normal/page stable IDs: {first_run.stdout} {first_run.stderr}")
        ui_ok = len(ui_ids) == 8 and ui_ids == expected_ui
        results.append({"name": "ui_input_ids_are_unique_and_durable", "passed": ui_ok})
        if not ui_ok:
            errors.append(f"UI input stable IDs were incomplete or duplicated: {sorted(ui_ids)}")

        first_export = run([
            str(SCRIPTS / "export_cases.py"), "--project", generated_name,
        ])
        stable_index_path = generated_project / "用例稳定索引.json"
        first_export_ok = first_export.returncode == 0 and stable_index_path.exists()
        results.append({"name": "first_export_persists_stable_id_case_id_history", "passed": first_export_ok})
        if not first_export_ok:
            errors.append(f"first stable index export failed: {first_export.stdout} {first_export.stderr}")

        changed_spec = first_spec
        changed_spec["cases"][0]["tp"] = "验证标题修改后按键仍可启动录音"
        changed_spec["cases"].insert(0, spec_case("验证新增录音入口说明"))
        spec_path.write_text(json.dumps(changed_spec, ensure_ascii=False, indent=2), encoding="utf-8")
        second_run = run([str(SCRIPTS / "casegen.py"), "--project", generated_name])
        second_spec = json.loads(spec_path.read_text(encoding="utf-8"))
        second_rows = json.loads(
            (generated_project / "cases" / "录音.json").read_text(encoding="utf-8")
        )["cases"] if second_run.returncode == 0 else []
        old_row = next((row for row in second_rows if row.get("_stable_id") == first_id), {})
        new_stable_id = str(second_spec["cases"][0].get("_stable_id", ""))
        new_row = next((row for row in second_rows if row.get("_stable_id") == new_stable_id), {})
        edit_ok = (
            second_run.returncode == 0
            and second_spec["cases"][1].get("_stable_id") == first_id
            and str(second_spec["cases"][0].get("_stable_id", "")).startswith("CASE::")
        )
        results.append({"name": "title_edit_and_insertion_preserve_existing_id", "passed": edit_ok})
        if not edit_ok:
            errors.append("casegen changed an existing stable ID after title edit/insertion")
        case_id_reuse_ok = (
            second_run.returncode == 0
            and old_row.get("用例编号") == first_case_id
            and new_row.get("用例编号") == f"REC_{historical_max + 1:03d}"
        )
        results.append({"name": "spec_insert_reuses_old_case_id_and_appends_new_id", "passed": case_id_reuse_ok})
        if not case_id_reuse_ok:
            errors.append(
                f"casegen renumbered existing stable identity or inserted into history: "
                f"old={old_row} new={new_row} historical_max={historical_max}"
            )

        second_export = run([str(SCRIPTS / "export_cases.py"), "--project", generated_name])
        removed_spec_case = second_spec["cases"].pop(0)
        spec_path.write_text(
            json.dumps(second_spec, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        after_delete = run([str(SCRIPTS / "casegen.py"), "--project", generated_name])
        delete_export = run([str(SCRIPTS / "export_cases.py"), "--project", generated_name])
        deleted_index = json.loads(stable_index_path.read_text(encoding="utf-8"))
        retired_by_stable = {
            item.get("stable_id"): item.get("case_id")
            for item in deleted_index.get("retired_items", [])
        }
        tombstone_ok = (
            second_export.returncode == 0
            and after_delete.returncode == 0
            and delete_export.returncode == 0
            and retired_by_stable.get(new_stable_id) == f"REC_{historical_max + 1:03d}"
            and deleted_index.get("high_water", {}).get("REC") == historical_max + 1
            and all(
                item.get("stable_id") != new_stable_id
                for item in deleted_index.get("items", [])
            )
        )
        results.append({"name": "deleted_identity_becomes_tombstone_with_high_water", "passed": tombstone_ok})
        if not tombstone_ok:
            errors.append(f"deleted stable identity was not retained as tombstone: {deleted_index}")

        after_delete_spec = json.loads(spec_path.read_text(encoding="utf-8"))
        after_delete_spec["cases"].insert(0, spec_case("验证删除后新增用例编号尾追加"))
        spec_path.write_text(
            json.dumps(after_delete_spec, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        after_new = run([str(SCRIPTS / "casegen.py"), "--project", generated_name])
        with_new_spec = json.loads(spec_path.read_text(encoding="utf-8"))
        fresh_stable_id = str(with_new_spec["cases"][0].get("_stable_id", ""))
        with_new_rows = json.loads(
            (generated_project / "cases" / "录音.json").read_text(encoding="utf-8")
        )["cases"] if after_new.returncode == 0 else []
        fresh_row = next(
            (row for row in with_new_rows if row.get("_stable_id") == fresh_stable_id), {}
        )
        append_after_tombstone_ok = (
            after_new.returncode == 0
            and fresh_stable_id.startswith("CASE::")
            and fresh_row.get("用例编号") == f"REC_{historical_max + 2:03d}"
        )
        results.append({"name": "new_identity_never_reuses_tombstoned_case_id", "passed": append_after_tombstone_ok})
        if not append_after_tombstone_ok:
            errors.append(f"new identity reused or skipped tombstone history: {fresh_row}")
        new_export = run([str(SCRIPTS / "export_cases.py"), "--project", generated_name])

        restore_spec = json.loads(spec_path.read_text(encoding="utf-8"))
        restore_spec["cases"].append(removed_spec_case)
        spec_path.write_text(
            json.dumps(restore_spec, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        restored = run([str(SCRIPTS / "casegen.py"), "--project", generated_name])
        restored_rows = json.loads(
            (generated_project / "cases" / "录音.json").read_text(encoding="utf-8")
        )["cases"] if restored.returncode == 0 else []
        restored_map = {row.get("_stable_id"): row.get("用例编号") for row in restored_rows}
        restore_ok = (
            new_export.returncode == 0
            and restored.returncode == 0
            and restored_map.get(new_stable_id) == f"REC_{historical_max + 1:03d}"
            and restored_map.get(fresh_stable_id) == f"REC_{historical_max + 2:03d}"
        )
        results.append({"name": "restored_identity_recovers_original_tombstoned_id", "passed": restore_ok})
        if not restore_ok:
            errors.append(f"restored stable identity did not recover original ID: {restored_map}")
        restore_export = run([str(SCRIPTS / "export_cases.py"), "--project", generated_name])
        if restore_export.returncode != 0:
            errors.append(f"restored stable history could not be exported: {restore_export.stdout} {restore_export.stderr}")

        (generated_project / "cross.json").write_text(json.dumps({"items": [
            {"matrix_key": "解绑|录音中", "status": "not_applicable", "coverage_kind": "not_applicable"},
            {"matrix_key": "解绑|录音中", "status": "rule_only", "coverage_kind": "rule_only"},
        ]}, ensure_ascii=False, indent=2), encoding="utf-8")
        duplicate_matrix = run([str(SCRIPTS / "casegen.py"), "--project", generated_name])
        duplicate_matrix_failed = duplicate_matrix.returncode != 0 and "matrix_key 重复" in (
            duplicate_matrix.stdout + duplicate_matrix.stderr
        )
        results.append({"name": "duplicate_matrix_key_must_fail", "passed": duplicate_matrix_failed})
        if not duplicate_matrix_failed:
            errors.append("casegen accepted duplicate matrix_key values")

        (generated_project / "cross.json").unlink()
        stable_payload = json.loads(stable_index_path.read_text(encoding="utf-8"))
        stable_payload["items"].append(dict(stable_payload["items"][0]))
        stable_index_path.write_text(
            json.dumps(stable_payload, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        cases_before_conflict = (generated_project / "cases" / "录音.json").read_bytes()
        index_conflict = run([str(SCRIPTS / "casegen.py"), "--project", generated_name])
        index_conflict_ok = (
            index_conflict.returncode != 0
            and "稳定编号历史冲突" in index_conflict.stdout + index_conflict.stderr
            and (generated_project / "cases" / "录音.json").read_bytes() == cases_before_conflict
        )
        results.append({"name": "duplicate_stable_index_blocks_casegen_before_cases_write", "passed": index_conflict_ok})
        if not index_conflict_ok:
            errors.append(f"casegen accepted or wrote through duplicate stable index: {index_conflict.stdout} {index_conflict.stderr}")
    finally:
        if generated_project.exists():
            shutil.rmtree(generated_project)

    strict_project = Path(tempfile.mkdtemp(prefix="_stable_id_lineage_txn_", dir=PROJECTS))
    strict_name = strict_project.name
    try:
        strict_contract = valid_contract()
        write_project(
            strict_project,
            [combination_case()],
            require_contract=True,
            contract=strict_contract,
        )
        strict_casegen = run([str(SCRIPTS / "casegen.py"), "--project", strict_name])
        strict_export = run([str(SCRIPTS / "export_cases.py"), "--project", strict_name])
        strict_index = strict_project / "用例稳定索引.json"
        strict_lineage = strict_project / "工作底稿" / "build_lineage.json"
        strict_xlsx = strict_project / f"{strict_name}_全功能测试用例.xlsx"
        strict_specs = sorted((strict_project / "specs").glob("*.json"))
        strict_cases = sorted((strict_project / "cases").glob("*.json"))
        strict_artifacts = [*strict_specs, *strict_cases, strict_index, strict_lineage, strict_xlsx]
        strict_baseline = file_snapshot(strict_artifacts)

        strict_index.unlink(missing_ok=True)
        without_index_before = file_snapshot([*strict_specs, *strict_cases, strict_lineage, strict_xlsx])
        missing_index_run = run([str(SCRIPTS / "casegen.py"), "--project", strict_name])
        missing_index_ok = (
            strict_casegen.returncode == 0
            and strict_export.returncode == 0
            and missing_index_run.returncode != 0
            and "稳定索引" in missing_index_run.stdout + missing_index_run.stderr
            and not strict_index.exists()
            and snapshot_matches(without_index_before)
        )
        results.append({"name": "schema_v3_export_lineage_blocks_deleted_stable_index", "passed": missing_index_ok})
        if not missing_index_ok:
            errors.append(f"schema v3 casegen accepted deleted stable index: {missing_index_run.stdout} {missing_index_run.stderr}")
        restore_snapshot(strict_baseline)

        tampered_index_payload = json.loads(strict_index.read_text(encoding="utf-8"))
        tampered_index_payload.setdefault("high_water", {})["SAVE"] = (
            int(tampered_index_payload.get("high_water", {}).get("SAVE", 0)) + 1
        )
        strict_index.write_text(
            json.dumps(tampered_index_payload, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        tampered_before = file_snapshot(strict_artifacts)
        tampered_index_run = run([str(SCRIPTS / "casegen.py"), "--project", strict_name])
        tampered_index_ok = (
            tampered_index_run.returncode != 0
            and "稳定索引" in tampered_index_run.stdout + tampered_index_run.stderr
            and snapshot_matches(tampered_before)
        )
        results.append({"name": "schema_v3_export_lineage_blocks_tampered_stable_index", "passed": tampered_index_ok})
        if not tampered_index_ok:
            errors.append(f"schema v3 casegen accepted tampered stable index: {tampered_index_run.stdout} {tampered_index_run.stderr}")
        restore_snapshot(strict_baseline)

        lineage_contract_ok = True
        lineage_contract_details: list[str] = []
        lineage_baseline_payload = json.loads(strict_lineage.read_text(encoding="utf-8"))
        lineage_variants = (
            ("wrong_path", {**lineage_baseline_payload, "stable_index_path": "other.json"}, "必须为"),
            (
                "missing_path",
                {key: value for key, value in lineage_baseline_payload.items() if key != "stable_index_path"},
                "路径/哈希不完整",
            ),
            (
                "missing_hash",
                {key: value for key, value in lineage_baseline_payload.items() if key != "stable_index_hash"},
                "路径/哈希不完整",
            ),
        )
        for variant, payload, expected_error in lineage_variants:
            strict_lineage.write_text(
                json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            before = file_snapshot(strict_artifacts)
            blocked = run([str(SCRIPTS / "casegen.py"), "--project", strict_name])
            if (
                blocked.returncode == 0
                or expected_error not in blocked.stdout + blocked.stderr
                or not snapshot_matches(before)
            ):
                lineage_contract_ok = False
                lineage_contract_details.append(
                    f"{variant}: rc={blocked.returncode} out={blocked.stdout} err={blocked.stderr}"
                )
            restore_snapshot(strict_baseline)
        results.append({
            "name": "schema_v3_lineage_requires_canonical_stable_index_path_and_complete_hash_pair",
            "passed": lineage_contract_ok,
        })
        if not lineage_contract_ok:
            errors.append("stable-index lineage contract gap: " + " | ".join(lineage_contract_details))

        inert_spec_path = strict_project / "specs" / "记录.json"
        inert_spec_payload = json.loads(inert_spec_path.read_text(encoding="utf-8"))
        inert_spec_payload["cases"].append(spec_case("验证生产环境普通变量不影响正常生成"))
        inert_spec_path.write_text(
            json.dumps(inert_spec_payload, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        inert_env = {
            **os.environ,
            "QA_TEST_FAIL_REPLACE_AT": "1",
            "QA_TEST_FAIL_REPLACE_MODE": "before",
            "QA_TEST_FAIL_LINEAGE_WRITE_AT": "1",
            "QA_TEST_FAIL_LINEAGE_WRITE_MODE": "before",
        }
        inert_env.pop("QA_TEST_ENABLE_FAULT_INJECTION", None)
        inert_run = run(
            [str(SCRIPTS / "casegen.py"), "--project", strict_name], env=inert_env
        )
        inert_ok = inert_run.returncode == 0
        results.append({
            "name": "fault_injection_variables_are_inert_without_test_enable_switch",
            "passed": inert_ok,
        })
        if not inert_ok:
            errors.append(
                f"fault injection bypassed test-only switch: {inert_run.stdout} {inert_run.stderr}"
            )
        restore_snapshot(strict_baseline)

        record_spec_path = strict_project / "specs" / "记录.json"
        transaction_spec = json.loads(record_spec_path.read_text(encoding="utf-8"))
        transaction_spec["cases"].append(spec_case("验证批量提交失败必须回滚"))
        record_spec_path.write_text(
            json.dumps(transaction_spec, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        casegen_txn_paths = [*strict_specs, *strict_cases, strict_index, strict_lineage, strict_xlsx]
        casegen_txn_before = file_snapshot(casegen_txn_paths)
        replace_failures_ok = True
        replace_failure_details: list[str] = []
        for fail_mode in ("before", "after"):
            for replace_at in range(1, 5):
                failed = run(
                    [str(SCRIPTS / "casegen.py"), "--project", strict_name],
                    env={
                        **os.environ,
                        "QA_TEST_ENABLE_FAULT_INJECTION": "1",
                        "QA_TEST_FAIL_REPLACE_AT": str(replace_at),
                        "QA_TEST_FAIL_REPLACE_MODE": fail_mode,
                    },
                )
                fault_marker = f"QA_TEST_FAIL_REPLACE_AT={replace_at} mode={fail_mode}"
                if (
                    failed.returncode == 0
                    or fault_marker not in failed.stdout + failed.stderr
                    or not snapshot_matches(casegen_txn_before)
                ):
                    replace_failures_ok = False
                    replace_failure_details.append(
                        f"mode={fail_mode} replace_at={replace_at} rc={failed.returncode} "
                        f"out={failed.stdout} err={failed.stderr}"
                    )
                restore_snapshot(casegen_txn_before)
        results.append({
            "name": "casegen_each_replace_failure_rolls_back_all_artifacts",
            "passed": replace_failures_ok,
        })
        if not replace_failures_ok:
            errors.append("casegen transaction split artifacts: " + " | ".join(replace_failure_details))

        lineage_rollback_ok = True
        lineage_failure_details: list[str] = []
        for fail_mode in ("before", "after"):
            lineage_failed = run(
                [str(SCRIPTS / "casegen.py"), "--project", strict_name],
                env={
                    **os.environ,
                    "QA_TEST_ENABLE_FAULT_INJECTION": "1",
                    "QA_TEST_FAIL_LINEAGE_WRITE_AT": "1",
                    "QA_TEST_FAIL_LINEAGE_WRITE_MODE": fail_mode,
                },
            )
            marker = f"QA_TEST_FAIL_LINEAGE_WRITE_AT=1 mode={fail_mode}"
            if (
                lineage_failed.returncode == 0
                or marker not in lineage_failed.stdout + lineage_failed.stderr
                or not snapshot_matches(casegen_txn_before)
            ):
                lineage_rollback_ok = False
                lineage_failure_details.append(
                    f"mode={fail_mode} out={lineage_failed.stdout} err={lineage_failed.stderr}"
                )
            restore_snapshot(casegen_txn_before)
        results.append({
            "name": "casegen_lineage_write_failure_rolls_back_all_artifacts",
            "passed": lineage_rollback_ok,
        })
        if not lineage_rollback_ok:
            errors.append("casegen lineage failure left mixed artifacts: " + " | ".join(lineage_failure_details))
        restore_snapshot(strict_baseline)

        export_txn_paths = [*strict_cases, strict_index, strict_lineage, strict_xlsx]
        export_txn_before = file_snapshot(export_txn_paths)
        export_replace_ok = True
        export_failure_details: list[str] = []
        for fail_mode in ("before", "after"):
            for replace_at in range(1, 3):
                failed = run(
                    [str(SCRIPTS / "export_cases.py"), "--project", strict_name],
                    env={
                        **os.environ,
                        "QA_TEST_ENABLE_FAULT_INJECTION": "1",
                        "QA_TEST_FAIL_REPLACE_AT": str(replace_at),
                        "QA_TEST_FAIL_REPLACE_MODE": fail_mode,
                    },
                )
                fault_marker = f"QA_TEST_FAIL_REPLACE_AT={replace_at} mode={fail_mode}"
                if (
                    failed.returncode == 0
                    or fault_marker not in failed.stdout + failed.stderr
                    or not snapshot_matches(export_txn_before)
                ):
                    export_replace_ok = False
                    export_failure_details.append(
                        f"mode={fail_mode} replace_at={replace_at} rc={failed.returncode} "
                        f"out={failed.stdout} err={failed.stderr}"
                    )
                restore_snapshot(export_txn_before)
        results.append({
            "name": "export_each_replace_failure_rolls_back_excel_index_and_lineage",
            "passed": export_replace_ok,
        })
        if not export_replace_ok:
            errors.append("export transaction split artifacts: " + " | ".join(export_failure_details))

        export_lineage_rollback_ok = True
        export_lineage_details: list[str] = []
        for fail_mode in ("before", "after"):
            export_lineage_failed = run(
                [str(SCRIPTS / "export_cases.py"), "--project", strict_name],
                env={
                    **os.environ,
                    "QA_TEST_ENABLE_FAULT_INJECTION": "1",
                    "QA_TEST_FAIL_LINEAGE_WRITE_AT": "1",
                    "QA_TEST_FAIL_LINEAGE_WRITE_MODE": fail_mode,
                },
            )
            marker = f"QA_TEST_FAIL_LINEAGE_WRITE_AT=1 mode={fail_mode}"
            if (
                export_lineage_failed.returncode == 0
                or marker not in export_lineage_failed.stdout + export_lineage_failed.stderr
                or not snapshot_matches(export_txn_before)
            ):
                export_lineage_rollback_ok = False
                export_lineage_details.append(
                    f"mode={fail_mode} out={export_lineage_failed.stdout} "
                    f"err={export_lineage_failed.stderr}"
                )
            restore_snapshot(export_txn_before)
        results.append({
            "name": "export_lineage_write_failure_rolls_back_excel_and_index",
            "passed": export_lineage_rollback_ok,
        })
        if not export_lineage_rollback_ok:
            errors.append(
                "export lineage failure left mixed artifacts: " + " | ".join(export_lineage_details)
            )
        restore_snapshot(strict_baseline)

        persisted_spec = json.loads(record_spec_path.read_text(encoding="utf-8"))
        persisted_spec["cases"].append(structured_case("CASE::RENUMBER-SECOND"))
        record_spec_path.write_text(
            json.dumps(persisted_spec, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        persisted_casegen = run([str(SCRIPTS / "casegen.py"), "--project", strict_name])
        persisted_export = run([str(SCRIPTS / "export_cases.py"), "--project", strict_name])
        reordered_spec = json.loads(record_spec_path.read_text(encoding="utf-8"))
        reordered_spec["cases"] = list(reversed(reordered_spec["cases"]))
        record_spec_path.write_text(
            json.dumps(reordered_spec, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        reordered_casegen = run([str(SCRIPTS / "casegen.py"), "--project", strict_name])
        persisted_paths = [*strict_specs, *strict_cases, strict_index, strict_lineage, strict_xlsx]
        persisted_before = file_snapshot(persisted_paths)
        strict_index.unlink(missing_ok=True)
        anchor_missing_before = file_snapshot([*strict_specs, *strict_cases, strict_lineage, strict_xlsx])
        anchor_missing_run = run([str(SCRIPTS / "casegen.py"), "--project", strict_name])
        anchor_persists_ok = (
            persisted_casegen.returncode == 0
            and persisted_export.returncode == 0
            and reordered_casegen.returncode == 0
            and anchor_missing_run.returncode != 0
            and "稳定索引" in anchor_missing_run.stdout + anchor_missing_run.stderr
            and snapshot_matches(anchor_missing_before)
        )
        results.append({
            "name": "stable_index_lineage_anchor_survives_successful_casegen",
            "passed": anchor_persists_ok,
        })
        if not anchor_persists_ok:
            errors.append(
                f"successful casegen dropped stable-index history anchor: "
                f"{anchor_missing_run.stdout} {anchor_missing_run.stderr}"
            )
        restore_snapshot(persisted_before)

        full_migration = strict_project / "renumber-transaction.json"
        full_migration.unlink(missing_ok=True)
        full_txn_paths = [*strict_specs, *strict_cases, strict_index, strict_lineage, strict_xlsx, full_migration]
        full_txn_before = file_snapshot(full_txn_paths)
        full_replace_ok = True
        full_replace_details: list[str] = []
        for fail_mode in ("before", "after"):
            for replace_at in range(1, 5):
                failed = run(
                    [
                        str(SCRIPTS / "export_cases.py"), "--project", strict_name,
                        "--renumber", "--migration-file", str(full_migration),
                    ],
                    env={
                        **os.environ,
                        "QA_TEST_ENABLE_FAULT_INJECTION": "1",
                        "QA_TEST_FAIL_REPLACE_AT": str(replace_at),
                        "QA_TEST_FAIL_REPLACE_MODE": fail_mode,
                    },
                )
                marker = f"QA_TEST_FAIL_REPLACE_AT={replace_at} mode={fail_mode}"
                if (
                    failed.returncode == 0
                    or marker not in failed.stdout + failed.stderr
                    or not snapshot_matches(full_txn_before)
                    or full_migration.exists()
                ):
                    full_replace_ok = False
                    full_replace_details.append(
                        f"mode={fail_mode} replace_at={replace_at} rc={failed.returncode} "
                        f"out={failed.stdout} err={failed.stderr}"
                    )
                restore_snapshot(full_txn_before)
        results.append({
            "name": "renumber_each_replace_failure_rolls_back_cases_migration_excel_index_lineage",
            "passed": full_replace_ok,
        })
        if not full_replace_ok:
            errors.append("full renumber transaction split artifacts: " + " | ".join(full_replace_details))

        full_lineage_ok = True
        full_lineage_details: list[str] = []
        for fail_mode in ("before", "after"):
            for write_at in (1, 2):
                failed = run(
                    [
                        str(SCRIPTS / "export_cases.py"), "--project", strict_name,
                        "--renumber", "--migration-file", str(full_migration),
                    ],
                    env={
                        **os.environ,
                        "QA_TEST_ENABLE_FAULT_INJECTION": "1",
                        "QA_TEST_FAIL_LINEAGE_WRITE_AT": str(write_at),
                        "QA_TEST_FAIL_LINEAGE_WRITE_MODE": fail_mode,
                    },
                )
                marker = f"QA_TEST_FAIL_LINEAGE_WRITE_AT={write_at} mode={fail_mode}"
                if (
                    failed.returncode == 0
                    or marker not in failed.stdout + failed.stderr
                    or not snapshot_matches(full_txn_before)
                    or full_migration.exists()
                ):
                    full_lineage_ok = False
                    full_lineage_details.append(
                        f"mode={fail_mode} write_at={write_at} rc={failed.returncode} "
                        f"out={failed.stdout} err={failed.stderr}"
                    )
                restore_snapshot(full_txn_before)
        results.append({
            "name": "renumber_each_lineage_write_failure_rolls_back_entire_transaction",
            "passed": full_lineage_ok,
        })
        if not full_lineage_ok:
            errors.append("full lineage transaction split artifacts: " + " | ".join(full_lineage_details))
        restore_snapshot(strict_baseline)
    finally:
        if strict_project.exists():
            shutil.rmtree(strict_project)

    retired_migration_project = Path(tempfile.mkdtemp(prefix="_stable_id_retired_migration_", dir=PROJECTS))
    retired_migration_name = retired_migration_project.name
    try:
        (retired_migration_project / "specs").mkdir(parents=True)
        (retired_migration_project / "specs" / "录音.json").write_text(
            json.dumps({"module": "录音", "prefix": "REC", "cases": []}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        retired_cases_dir = retired_migration_project / "cases"
        retired_cases_dir.mkdir(parents=True)
        retired_source = retired_cases_dir / "录音.json"
        base_manual_row = {
            "用例编号": "REC_001", "功能模块": "录音", "功能点": "录音入口", "测试项": "入口检查",
            "测试点/检查项": "验证录音入口", "前置条件": "1.设备处于待机状态",
            "操作步骤": "1.短按录音键", "预期结果": "1.设备进入录音页面",
            "优先级": "P1", "兼容性": "N/A", "是否自动化": "否", "固件版本": "待测版本",
            "硬件型号": "待测型号", "测试方式": "人工执行", "备注": "", "_stable_id": "CASE::ACTIVE-ONE",
        }
        second_manual_row = dict(base_manual_row)
        second_manual_row.update({
            "用例编号": "REC_002", "测试点/检查项": "验证新增稳定身份不得占退休编号",
            "_stable_id": "CASE::ACTIVE-NEW",
        })
        retired_source.write_text(json.dumps({
            "module": "录音", "cases": [base_manual_row, second_manual_row],
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        retired_index = retired_migration_project / "用例稳定索引.json"
        retired_index.write_text(json.dumps({
            "schema_version": 2,
            "items": [{"stable_id": "CASE::ACTIVE-ONE", "case_id": "REC_001", "matrix_key": ""}],
            "retired_items": [{"stable_id": "CASE::RETIRED", "case_id": "REC_002", "matrix_key": ""}],
            "high_water": {"REC": 2},
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        retired_out = retired_migration_project / "retired-conflict.xlsx"
        retired_migration = retired_migration_project / "retired-conflict.json"
        retired_before = file_snapshot([retired_source, retired_index, retired_out, retired_migration])
        retired_run = run([
            str(SCRIPTS / "export_cases.py"), "--project", retired_migration_name,
            "--out", str(retired_out), "--renumber", "--migration-file", str(retired_migration),
        ])
        retired_conflict_ok = (
            retired_run.returncode != 0
            and "旧编号歧义" in retired_run.stdout + retired_run.stderr
            and snapshot_matches(retired_before)
        )
        results.append({
            "name": "migration_item_cannot_claim_retired_case_id_with_zero_writes",
            "passed": retired_conflict_ok,
        })
        if not retired_conflict_ok:
            errors.append(f"export allowed migration item to claim retired ID: {retired_run.stdout} {retired_run.stderr}")
        restore_snapshot(retired_before)

        retired_migration.write_text(json.dumps({
            "schema_version": 2,
            "items": [{
                "stable_id": "CASE::ACTIVE-NEW", "old_case_ids": ["REC_002"], "new_case_id": "REC_003",
            }],
            "retired_items": [{"stable_id": "CASE::RETIRED", "case_id": "REC_002"}],
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        s22_retired_violations = check_migration(
            retired_out,
            [{"用例编号": "REC_003"}],
            {"migration_file": retired_migration.name},
        )
        s22_retired_ok = any("旧编号歧义" in item for item in s22_retired_violations)
        results.append({
            "name": "s22_blocks_old_case_id_shared_with_retired_item",
            "passed": s22_retired_ok,
        })
        if not s22_retired_ok:
            errors.append(f"S22 missed retired old-ID ambiguity: {s22_retired_violations}")

        duplicate_within_item = retired_migration_project / "duplicate-within-item.json"
        duplicate_within_item.write_text(json.dumps({
            "schema_version": 2,
            "items": [{
                "stable_id": "CASE::ACTIVE-NEW",
                "old_case_ids": ["REC_001", "REC_001"],
                "new_case_id": "REC_003",
            }],
            "retired_items": [],
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        duplicate_violations = check_migration(
            retired_out,
            [{"用例编号": "REC_003"}],
            {"migration_file": duplicate_within_item.name},
        )
        missing_retired = retired_migration_project / "missing-retired.json"
        missing_retired.write_text(json.dumps({
            "schema_version": 2,
            "items": [{
                "stable_id": "CASE::ACTIVE-NEW",
                "old_case_ids": [],
                "new_case_id": "REC_003",
            }],
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        missing_retired_violations = check_migration(
            retired_out,
            [{"用例编号": "REC_003"}],
            {"migration_file": missing_retired.name},
        )
        non_array_retired = retired_migration_project / "non-array-retired.json"
        non_array_retired.write_text(json.dumps({
            "schema_version": 2,
            "items": [{
                "stable_id": "CASE::ACTIVE-NEW",
                "old_case_ids": [],
                "new_case_id": "REC_003",
            }],
            "retired_items": {},
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        non_array_retired_violations = check_migration(
            retired_out,
            [{"用例编号": "REC_003"}],
            {"migration_file": non_array_retired.name},
        )
        s22_flatten_ok = (
            any("旧编号歧义" in item for item in duplicate_violations)
            and any("必须包含 retired_items 数组" in item for item in missing_retired_violations)
            and any("retired_items 必须是数组" in item for item in non_array_retired_violations)
        )
        results.append({
            "name": "s22_rejects_repeated_flattened_old_id_and_requires_v2_retired_array",
            "passed": s22_flatten_ok,
        })
        if not s22_flatten_ok:
            errors.append(
                f"S22 migration flatten/retired array gap: duplicate={duplicate_violations} "
                f"missing={missing_retired_violations} non_array={non_array_retired_violations}"
            )
    finally:
        if retired_migration_project.exists():
            shutil.rmtree(retired_migration_project)

    project = Path(tempfile.mkdtemp(prefix="_stable_id_export_", dir=PROJECTS))
    project_name = project.name
    try:
        specs_dir = project / "specs"
        specs_dir.mkdir(parents=True)
        (specs_dir / "录音.json").write_text(
            json.dumps({"module": "录音", "prefix": "REC", "cases": []}, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        cases_dir = project / "cases"
        cases_dir.mkdir(parents=True)
        source = cases_dir / "录音.json"
        source.write_text(json.dumps({
            "module": "录音",
            "cases": [{
                "用例编号": "REC_001", "功能模块": "录音", "功能点": "录音入口", "测试项": "入口检查",
                "测试点/检查项": "验证按键启动录音", "前置条件": "1.设备处于待机且TF卡剩余空间大于10MB",
                "操作步骤": "1.短按录音键", "预期结果": "1.设备开始录音并生成临时录音文件",
                "优先级": "P0", "兼容性": "N/A", "是否自动化": "否", "固件版本": "待测版本",
                "硬件型号": "待测型号", "测试方式": "人工执行", "备注": "",
            }],
        }, ensure_ascii=False, indent=2), encoding="utf-8")

        strict = run([str(SCRIPTS / "export_cases.py"), "--project", project_name])
        strict_failed = strict.returncode != 0 and "缺 _stable_id" in (strict.stdout + strict.stderr)
        results.append({"name": "legacy_case_strict_export_must_fail", "passed": strict_failed})
        if not strict_failed:
            errors.append("strict export accepted a legacy case without stable ID")

        renumber_without_migration = run([
            str(SCRIPTS / "export_cases.py"), "--project", project_name,
            "--renumber", "--legacy-bootstrap-stable-ids",
        ])
        renumber_failed = renumber_without_migration.returncode != 0 and "--migration-file" in (
            renumber_without_migration.stdout + renumber_without_migration.stderr
        )
        results.append({"name": "renumber_without_migration_must_fail", "passed": renumber_failed})
        if not renumber_failed:
            errors.append("renumber was allowed without a migration file")

        bootstrap = run([
            str(SCRIPTS / "export_cases.py"), "--project", project_name,
            "--legacy-bootstrap-stable-ids",
        ])
        payload = json.loads(source.read_text(encoding="utf-8"))
        persisted = str(payload["cases"][0].get("_stable_id", ""))
        index_path = project / "用例稳定索引.json"
        bootstrap_ok = bootstrap.returncode == 0 and persisted.startswith("CASE::") and index_path.exists()
        results.append({"name": "legacy_bootstrap_writes_uuid_and_index", "passed": bootstrap_ok})
        if not bootstrap_ok:
            errors.append(f"legacy bootstrap failed: {bootstrap.stdout} {bootstrap.stderr}")

        repeat = run([str(SCRIPTS / "export_cases.py"), "--project", project_name])
        payload_again = json.loads(source.read_text(encoding="utf-8"))
        repeat_ok = repeat.returncode == 0 and payload_again["cases"][0].get("_stable_id") == persisted
        results.append({"name": "strict_export_reuses_bootstrapped_uuid", "passed": repeat_ok})
        if not repeat_ok:
            errors.append("strict export did not reuse the bootstrapped stable ID")

        payload_again["cases"][0]["是否自动化"] = "是"
        payload_again["cases"][0]["测试方式"] = "自动化脚本"
        source.write_text(json.dumps(payload_again, ensure_ascii=False, indent=2), encoding="utf-8")
        automated_export = run([str(SCRIPTS / "export_cases.py"), "--project", project_name])
        automated_export_failed = automated_export.returncode != 0 and "功能测试用例人工执行合同未通过" in (
            automated_export.stdout + automated_export.stderr
        )
        results.append({"name": "functional_export_blocks_automation_rows", "passed": automated_export_failed})
        if not automated_export_failed:
            errors.append("functional export accepted an automation row")

        output_xlsx = project / f"{project_name}_全功能测试用例.xlsx"
        migration_file = project / "用例编号迁移.json"
        for generated in (output_xlsx, migration_file, index_path):
            generated.unlink(missing_ok=True)
        automated_renumber = run([
            str(SCRIPTS / "export_cases.py"), "--project", project_name,
            "--renumber", "--migration-file", migration_file.name,
        ])
        zero_write_block = (
            automated_renumber.returncode != 0
            and not output_xlsx.exists()
            and not migration_file.exists()
            and not index_path.exists()
        )
        results.append({"name": "functional_contract_failure_has_zero_export_writes", "passed": zero_write_block})
        if not zero_write_block:
            errors.append("functional contract failure wrote Excel, migration, or stable index output")

        repaired_payload = json.loads(source.read_text(encoding="utf-8"))
        repaired_payload["cases"][0]["是否自动化"] = "否"
        repaired_payload["cases"][0]["测试方式"] = "人工执行"
        repaired_payload["cases"][0]["用例编号"] = "REC_001"
        source.write_text(json.dumps(repaired_payload, ensure_ascii=False, indent=2), encoding="utf-8")
        baseline_export = run([str(SCRIPTS / "export_cases.py"), "--project", project_name])
        baseline_ok = baseline_export.returncode == 0 and index_path.exists()
        if not baseline_ok:
            errors.append(f"could not rebuild baseline stable index: {baseline_export.stdout} {baseline_export.stderr}")

        tampered_payload = json.loads(source.read_text(encoding="utf-8"))
        tampered_payload["cases"][0]["用例编号"] = "REC_999"
        source.write_text(json.dumps(tampered_payload, ensure_ascii=False, indent=2), encoding="utf-8")
        tampered_source_bytes = source.read_bytes()
        stable_index_bytes = index_path.read_bytes()
        drift_out = project / "drift-must-not-write.xlsx"
        drift_export = run([
            str(SCRIPTS / "export_cases.py"), "--project", project_name,
            "--out", str(drift_out),
        ])
        drift_zero_write = (
            baseline_ok
            and drift_export.returncode != 0
            and "stable_id -> case_id 映射发生漂移" in drift_export.stdout + drift_export.stderr
            and not drift_out.exists()
            and source.read_bytes() == tampered_source_bytes
            and index_path.read_bytes() == stable_index_bytes
        )
        results.append({"name": "non_renumber_export_blocks_case_id_drift_with_zero_writes", "passed": drift_zero_write})
        if not drift_zero_write:
            errors.append(f"non-renumber export overwrote drift or produced output: {drift_export.stdout} {drift_export.stderr}")

        explicit_migration = project / "显式编号迁移.json"
        explicit_out = project / "explicit-migration.xlsx"
        migrated = run([
            str(SCRIPTS / "export_cases.py"), "--project", project_name,
            "--out", str(explicit_out), "--renumber",
            "--migration-file", str(explicit_migration),
        ])
        migrated_source = json.loads(source.read_text(encoding="utf-8"))
        migrated_index = json.loads(index_path.read_text(encoding="utf-8")) if index_path.exists() else {}
        migrated_map = json.loads(explicit_migration.read_text(encoding="utf-8")) if explicit_migration.exists() else {}
        migrated_items = migrated_map.get("items", []) if isinstance(migrated_map, dict) else []
        migrated_item = next(
            (item for item in migrated_items if item.get("stable_id") == persisted),
            {},
        )
        explicit_migration_ok = (
            migrated.returncode == 0
            and explicit_out.exists()
            and migrated_source["cases"][0].get("用例编号") == "REC_001"
            and migrated_index.get("items", [{}])[0].get("case_id") == "REC_001"
            and migrated_map.get("schema_version") == 2
            and migrated_item.get("new_case_id") == "REC_001"
            and set(migrated_item.get("old_case_ids", [])) == {"REC_001", "REC_999"}
        )
        results.append({"name": "explicit_renumber_with_migration_repairs_and_persists_mapping", "passed": explicit_migration_ok})
        if not explicit_migration_ok:
            errors.append(f"explicit renumber migration failed: {migrated.stdout} {migrated.stderr} {migrated_map}")
        migration_gate_violations = check_migration(
            explicit_out,
            [{"用例编号": "REC_001"}],
            {"migration_file": explicit_migration.name},
        )
        migration_gate_ok = explicit_migration_ok and not migration_gate_violations
        results.append({"name": "s22_accepts_structured_stable_id_migration", "passed": migration_gate_ok})
        if not migration_gate_ok:
            errors.append(f"S22 rejected structured stable-ID migration: {migration_gate_violations}")

        stable_baseline_source = json.loads(source.read_text(encoding="utf-8"))
        stable_baseline_index = index_path.read_bytes()
        prefix_tail_variants = (
            ("wrong_prefix", "BAD_002", "不符合锁定前缀"),
            ("below_tail", "REC_000", "连续尾追加"),
            ("skipped_tail", "REC_003", "连续尾追加"),
        )
        for variant_name, candidate_id, expected_error in prefix_tail_variants:
            variant_payload = json.loads(json.dumps(stable_baseline_source, ensure_ascii=False))
            candidate = dict(variant_payload["cases"][0])
            candidate["_stable_id"] = f"CASE::NEW-{variant_name}"
            candidate["用例编号"] = candidate_id
            candidate["测试点/检查项"] = f"验证全新stable_id {variant_name} 被硬门禁检查"
            variant_payload["cases"].append(candidate)
            source.write_text(
                json.dumps(variant_payload, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            source_before = source.read_bytes()
            variant_out = project / f"{variant_name}-must-not-write.xlsx"
            blocked = run([
                str(SCRIPTS / "export_cases.py"), "--project", project_name,
                "--out", str(variant_out),
            ])
            variant_ok = (
                blocked.returncode != 0
                and expected_error in blocked.stdout + blocked.stderr
                and not variant_out.exists()
                and source.read_bytes() == source_before
                and index_path.read_bytes() == stable_baseline_index
            )
            results.append({
                "name": f"new_stable_id_{variant_name}_blocks_with_zero_writes",
                "passed": variant_ok,
            })
            if not variant_ok:
                errors.append(
                    f"new stable ID {variant_name} was accepted or wrote output: "
                    f"{blocked.stdout} {blocked.stderr}"
                )

        ambiguous_payload = json.loads(json.dumps(stable_baseline_source, ensure_ascii=False))
        ambiguous_payload["cases"][0]["用例编号"] = "REC_999"
        ambiguous_second = dict(ambiguous_payload["cases"][0])
        ambiguous_second["_stable_id"] = "CASE::AMBIGUOUS-SECOND"
        ambiguous_second["用例编号"] = "REC_001"
        ambiguous_second["测试点/检查项"] = "验证旧编号不能同时归属两个稳定身份"
        ambiguous_payload["cases"].append(ambiguous_second)
        source.write_text(
            json.dumps(ambiguous_payload, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        ambiguous_source_before = source.read_bytes()
        ambiguous_out = project / "ambiguous-must-not-write.xlsx"
        ambiguous_migration = project / "ambiguous-must-not-write.json"
        ambiguous = run([
            str(SCRIPTS / "export_cases.py"), "--project", project_name,
            "--out", str(ambiguous_out), "--renumber",
            "--migration-file", str(ambiguous_migration),
        ])
        ambiguity_ok = (
            ambiguous.returncode != 0
            and "显式迁移旧编号歧义" in ambiguous.stdout + ambiguous.stderr
            and not ambiguous_out.exists()
            and not ambiguous_migration.exists()
            and source.read_bytes() == ambiguous_source_before
            and index_path.read_bytes() == stable_baseline_index
        )
        results.append({"name": "ambiguous_old_id_migration_blocks_with_zero_writes", "passed": ambiguity_ok})
        if not ambiguity_ok:
            errors.append(f"ambiguous old-ID migration was accepted or wrote output: {ambiguous.stdout} {ambiguous.stderr}")

        lock_out = project / "lock-contention-must-not-write.xlsx"
        lock_code = (
            "import sys,time\n"
            f"sys.path.insert(0, {str(SCRIPTS)!r})\n"
            "from pathlib import Path\n"
            "from build_lock import project_build_lock\n"
            f"with project_build_lock(Path({str(project)!r})):\n"
            "    print('READY', flush=True)\n"
            "    time.sleep(2)\n"
        )
        holder = subprocess.Popen(
            [sys.executable, "-c", lock_code], cwd=WORKFLOW,
            text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            encoding="utf-8", errors="replace",
        )
        try:
            ready = holder.stdout.readline().strip() if holder.stdout is not None else ""
            locked = run([
                str(SCRIPTS / "export_cases.py"), "--project", project_name,
                "--out", str(lock_out),
            ])
            holder.wait(timeout=10)
        finally:
            if holder.poll() is None:
                holder.terminate()
                holder.wait(timeout=5)
        lock_ok = (
            ready == "READY"
            and locked.returncode != 0
            and "已有生成/导出进程持锁" in locked.stdout + locked.stderr
            and not lock_out.exists()
            and source.read_bytes() == ambiguous_source_before
            and index_path.read_bytes() == stable_baseline_index
            and (project / ".qa-build.lock").is_file()
        )
        results.append({"name": "project_lock_is_permanent_and_contention_blocks_zero_writes", "passed": lock_ok})
        if not lock_ok:
            errors.append(f"project lock did not block concurrent export: ready={ready!r} {locked.stdout} {locked.stderr}")
    finally:
        if project.exists():
            shutil.rmtree(project)

    output = {"success": not errors, "results": results, "errors": errors}
    print(json.dumps(output, ensure_ascii=False, indent=2))
    if errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
