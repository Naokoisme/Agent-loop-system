# -*- coding: utf-8 -*-
"""Stable testcase identity helpers shared by generation and export.

Display case numbers may change after sorting or insertion.  These helpers keep
the durable identity in source JSON and never derive it from testcase wording,
list position, or the current Excel row number.
"""
from __future__ import annotations

import errno
import os
import shutil
import time
from pathlib import Path
from typing import Any, Callable, Iterable
from uuid import uuid4


CASE_STABLE_KEYS = ("_stable_id", "stable_id", "_case_uid", "case_uid")
PAGE_STABLE_KEYS = ("_stable_id", "stable_id", "_page_uid", "page_uid")
MATRIX_KEY_KEYS = ("_matrix_key", "matrix_key")


class StableIdentityError(ValueError):
    """Raised when a record exposes conflicting stable-identity aliases."""


def _replace_with_retry(source: Path, target: Path, *, attempts: int = 20) -> None:
    """Retry transient Windows sharing/permission failures around atomic replace."""
    for attempt in range(attempts):
        try:
            os.replace(source, target)
            return
        except OSError as exc:
            transient = (
                isinstance(exc, PermissionError)
                or getattr(exc, "winerror", None) in {5, 32, 33}
                or getattr(exc, "errno", None) in {errno.EACCES, errno.EPERM, errno.EBUSY}
            )
            if not transient or attempt + 1 >= attempts:
                raise
            time.sleep(min(0.05 * (attempt + 1), 0.25))


def commit_staged_files(
    replacements: Iterable[tuple[Path, Path]],
    *,
    protected_paths: Iterable[Path] = (),
    post_commit: Callable[[], None] | None = None,
) -> None:
    """Commit multiple staged files with byte-for-byte rollback on failure.

    Each tuple is ``(staged, target)``. Target-side temporary copies avoid
    cross-volume ``os.replace`` failures. Protected paths cover files, such as
    build lineage, that ``post_commit`` may update.
    """
    pairs = [(Path(staged), Path(target)) for staged, target in replacements]
    targets = [target for _, target in pairs]
    if len({str(path.resolve()) for path in targets}) != len(targets):
        raise StableIdentityError("批量提交包含重复目标路径")
    missing = [str(staged) for staged, _ in pairs if not staged.is_file()]
    if missing:
        raise StableIdentityError(f"批量提交缺暂存文件: {missing}")

    protected = [Path(path) for path in protected_paths]
    guarded: list[Path] = []
    guarded_keys: set[str] = set()
    for path in [*targets, *protected]:
        key = str(path.resolve())
        if key not in guarded_keys:
            guarded.append(path)
            guarded_keys.add(key)

    backups: dict[Path, Path | None] = {}
    prepared: list[tuple[Path, Path]] = []
    cleanup_paths: set[Path] = set()
    token = uuid4().hex
    fault_enabled = str(os.environ.get("QA_TEST_ENABLE_FAULT_INJECTION", "") or "").strip() == "1"
    fail_value = str(os.environ.get("QA_TEST_FAIL_REPLACE_AT", "") or "").strip() if fault_enabled else ""
    fail_at = int(fail_value) if fail_value.isdigit() and int(fail_value) > 0 else 0
    fail_mode = str(os.environ.get("QA_TEST_FAIL_REPLACE_MODE", "before") or "before").strip()
    if fail_mode not in {"before", "after"}:
        fail_mode = "before"
    try:
        for path in guarded:
            if path.is_file():
                path.parent.mkdir(parents=True, exist_ok=True)
                backup = path.parent / f".{path.name}.qa-old-{token}"
                shutil.copy2(path, backup)
                backups[path] = backup
                cleanup_paths.add(backup)
            else:
                backups[path] = None

        for index, (staged, target) in enumerate(pairs, 1):
            target.parent.mkdir(parents=True, exist_ok=True)
            prepared_path = target.parent / f".{target.name}.qa-new-{token}-{index:04d}"
            shutil.copy2(staged, prepared_path)
            prepared.append((prepared_path, target))
            cleanup_paths.add(prepared_path)

        for index, (prepared_path, target) in enumerate(prepared, 1):
            if fail_at == index and fail_mode == "before":
                raise OSError(
                    f"QA_TEST_FAIL_REPLACE_AT={index} mode=before 故障注入"
                )
            _replace_with_retry(prepared_path, target)
            cleanup_paths.discard(prepared_path)
            if fail_at == index and fail_mode == "after":
                raise OSError(
                    f"QA_TEST_FAIL_REPLACE_AT={index} mode=after 故障注入"
                )

        if post_commit is not None:
            post_commit()
    except BaseException as exc:
        rollback_errors: list[str] = []
        for path in reversed(guarded):
            backup = backups.get(path)
            try:
                if backup is None:
                    path.unlink(missing_ok=True)
                elif backup.is_file():
                    _replace_with_retry(backup, path)
                    cleanup_paths.discard(backup)
                else:
                    rollback_errors.append(f"{path}: 备份缺失")
            except OSError as rollback_exc:
                rollback_errors.append(f"{path}: {rollback_exc}")
        if rollback_errors:
            raise RuntimeError(
                f"批量提交失败且回滚不完整: {exc}; rollback={rollback_errors}"
            ) from exc
        raise
    finally:
        for path in cleanup_paths:
            try:
                path.unlink(missing_ok=True)
            except OSError:
                pass


def _alias_value(record: dict, keys: tuple[str, ...], label: str) -> str:
    values = {
        str(record.get(key, "") or "").strip()
        for key in keys
        if str(record.get(key, "") or "").strip()
    }
    if len(values) > 1:
        raise StableIdentityError(f"{label}别名值冲突: {sorted(values)}")
    return next(iter(values), "")


def explicit_case_stable_id(case: dict) -> str:
    return _alias_value(case, CASE_STABLE_KEYS, "稳定ID")


def page_stable_id(page: dict) -> str:
    return _alias_value(page, PAGE_STABLE_KEYS, "页面稳定ID")


def matrix_key(case: dict) -> str:
    return _alias_value(case, MATRIX_KEY_KEYS, "matrix_key")


def case_stable_identity(case: dict) -> tuple[str, str]:
    """Return ``(canonical_identity, matrix_key)`` for a generated case."""
    stable_id = explicit_case_stable_id(case)
    key = matrix_key(case)
    return stable_id or (f"MATRIX::{key}" if key else ""), key


def ensure_case_stable_id(case: dict) -> tuple[str, bool]:
    """Persist a UUID identity on a normal/legacy case when it has none."""
    stable_id = explicit_case_stable_id(case)
    changed = False
    if not stable_id:
        stable_id = f"CASE::{uuid4()}"
        case["_stable_id"] = stable_id
        changed = True
    elif str(case.get("_stable_id", "") or "").strip() != stable_id:
        # Canonicalize aliases so downstream files always carry one known key.
        case["_stable_id"] = stable_id
        changed = True
    return stable_id, changed


def ensure_page_stable_id(page: dict) -> tuple[str, bool]:
    """Persist a UUID identity on a UI page definition when it has none."""
    stable_id = page_stable_id(page)
    changed = False
    if not stable_id:
        stable_id = f"PAGE::{uuid4()}"
        page["_stable_id"] = stable_id
        changed = True
    elif str(page.get("_stable_id", "") or "").strip() != stable_id:
        page["_stable_id"] = stable_id
        changed = True
    return stable_id, changed


def _case_id(record: dict[str, Any]) -> str:
    values = {
        str(record.get(key, "") or "").strip()
        for key in ("case_id", "用例编号", "id")
        if str(record.get(key, "") or "").strip()
    }
    if len(values) > 1:
        raise StableIdentityError(f"用例编号别名值冲突: {sorted(values)}")
    return next(iter(values), "")


def build_identity_maps(
    records: Iterable[dict[str, Any]],
    *,
    label: str,
) -> tuple[dict[str, str], dict[str, str]]:
    """Build a strict one-to-one stable_id <-> case_id mapping."""
    stable_to_case: dict[str, str] = {}
    case_to_stable: dict[str, str] = {}
    for index, record in enumerate(records, 1):
        location = f"{label}[{index}]"
        if not isinstance(record, dict):
            raise StableIdentityError(f"{location} 必须是对象")
        try:
            stable_value, _ = case_stable_identity(record)
        except StableIdentityError as exc:
            raise StableIdentityError(f"{location} {exc}") from exc
        case_id = _case_id(record)
        if not stable_value:
            raise StableIdentityError(f"{location} 缺 stable_id/matrix_key")
        if not case_id:
            raise StableIdentityError(f"{location} 缺 case_id/用例编号")
        if stable_value in stable_to_case:
            raise StableIdentityError(
                f"{label} stable_id重复: {stable_value} "
                f"({stable_to_case[stable_value]} / {case_id})"
            )
        if case_id in case_to_stable:
            raise StableIdentityError(
                f"{label} case_id重复或冲突: {case_id} "
                f"({case_to_stable[case_id]} / {stable_value})"
            )
        stable_to_case[stable_value] = case_id
        case_to_stable[case_id] = stable_value
    return stable_to_case, case_to_stable
