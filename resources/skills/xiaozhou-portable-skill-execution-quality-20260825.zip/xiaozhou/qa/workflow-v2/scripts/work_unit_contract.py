# -*- coding: utf-8 -*-
"""Standard contract and validation for isolated testcase work units."""
from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from execution_profile import load_profile
from project_paths import resolve_project, validate_component


CONTRACT_FILENAME = "工作单合同.json"
CONTRACT_SCHEMA_VERSION = 1


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _input_key(project: Path, path: Path) -> str:
    try:
        return path.resolve().relative_to(project.resolve()).as_posix()
    except ValueError:
        absolute = path.resolve().as_posix()
        digest = hashlib.sha256(absolute.encode("utf-8")).hexdigest()[:16]
        return f"external/{digest}/{path.name}"


def _resolve_project_path(project: Path, value: str) -> Path:
    path = Path(str(value or ""))
    return path.resolve() if path.is_absolute() else (project / path).resolve()


def _path_in(root: Path, candidate: Path) -> bool:
    try:
        candidate.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def build_contract(project_name: str, work_unit: str) -> dict[str, Any]:
    """Return the initial handoff contract for one complete business function."""
    unit = validate_component(work_unit, label="work-unit")
    write_root = (Path("workunits") / unit).as_posix()
    return {
        "schema_version": CONTRACT_SCHEMA_VERSION,
        "project": str(project_name),
        "work_unit": unit,
        "responsibility": {
            "feature_scope": unit,
            "write_root": write_root,
            "allowed_write_paths": [write_root],
            "forbidden_write_scopes": [
                "workunits/<其他功能>",
                "cases",
                "结果",
                "工作底稿/acceptance_runs",
                "共享规则、脚本、知识、模板和最终合并目录",
            ],
        },
        "shared_input_snapshot": {
            "status": "UNFROZEN",
            "snapshot_id": "",
            "input_hashes": {},
            "frozen_at": "",
        },
        "required_outputs": {
            "case_file": f"{write_root}/cases.json",
            "self_check_report": f"{write_root}/自检.json",
            "peer_review_report": f"{write_root}/同行评审.json",
        },
        "handoff": {
            "status": "PENDING",
            "case_file": f"{write_root}/cases.json",
            "case_count": 0,
            "current_sha256": "",
            "pending_confirmations": [],
            "self_check": {
                "status": "PENDING",
                "report_file": f"{write_root}/自检.json",
                "current_sha256": "",
            },
            "peer_review": {
                "status": "PENDING",
                "reviewer_work_unit": "",
                "report_file": f"{write_root}/同行评审.json",
                "current_sha256": "",
            },
            "submitted_by": "",
            "submitted_at": "",
        },
        "main_acceptance": {
            "status": "PENDING",
            "accepted_case_sha256": "",
            "accepted_by": "",
            "accepted_at": "",
            "notes": [],
        },
    }


def shared_input_hashes(project: Path) -> dict[str, str]:
    """Hash the frozen PRD, routing, field contract, blueprint, and release rules."""
    config_path = project / "trace.config.json"
    profile_path = project / "执行画像.json"
    blueprint_path = project / "用例设计蓝图.json"
    required = [config_path, profile_path, blueprint_path]
    missing = [path.name for path in required if not path.is_file()]
    if missing:
        raise ValueError(f"冻结工作单前缺少共享输入: {missing}")

    config = json.loads(config_path.read_text(encoding="utf-8"))
    prd_value = str(config.get("prd_path", "") or "").strip()
    if not prd_value or "<" in prd_value or ">" in prd_value:
        raise ValueError("冻结工作单前必须在 trace.config.json 填写真实 prd_path")
    prd_path = _resolve_project_path(project, prd_value)
    if not prd_path.is_file():
        raise ValueError(f"冻结工作单前 PRD 不存在: {prd_path}")

    files = [*required, prd_path]
    return {
        _input_key(project, path): sha256(path)
        for path in sorted(files, key=lambda value: str(value).lower())
    }


def _contract_path(project: Path, work_unit: str) -> Path:
    unit = validate_component(work_unit, label="work-unit")
    return project / "workunits" / unit / CONTRACT_FILENAME


def freeze_project_contracts(project: Path, profile: dict[str, Any]) -> dict[str, Any]:
    """Freeze one identical shared-input snapshot into every declared work unit."""
    hashes = shared_input_hashes(project)
    snapshot_id = hashlib.sha256(
        json.dumps(hashes, ensure_ascii=False, sort_keys=True).encode("utf-8")
    ).hexdigest()
    frozen_at = datetime.now(timezone.utc).isoformat()
    written: list[str] = []
    for unit in profile.get("work_units", []):
        path = _contract_path(project, str(unit))
        if not path.is_file():
            raise ValueError(f"工作单合同不存在: {path}")
        payload = json.loads(path.read_text(encoding="utf-8"))
        errors = validate_contract(project, path, payload, expected_work_unit=str(unit))
        if errors:
            raise ValueError("工作单合同无效:\n- " + "\n- ".join(errors))
        payload["shared_input_snapshot"] = {
            "status": "FROZEN",
            "snapshot_id": snapshot_id,
            "input_hashes": hashes,
            "frozen_at": frozen_at,
        }
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        written.append(path.relative_to(project).as_posix())
    return {
        "snapshot_id": snapshot_id,
        "input_hashes": hashes,
        "contracts": written,
    }


def _validate_scoped_file(
    project: Path,
    write_root: Path,
    value: Any,
    label: str,
    errors: list[str],
) -> Path | None:
    text = str(value or "").strip()
    if not text or Path(text).is_absolute():
        errors.append(f"{label} 必须是工作单内的项目相对路径")
        return None
    path = (project / text).resolve()
    if not _path_in(write_root, path):
        errors.append(f"{label} 越出当前工作单目录: {text}")
        return None
    return path


def _json_status(path: Path) -> str:
    payload = json.loads(path.read_text(encoding="utf-8"))
    return str(payload.get("status", "") or "") if isinstance(payload, dict) else ""


def _case_count(path: Path) -> int | None:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if isinstance(payload, list):
        return len([row for row in payload if isinstance(row, dict)])
    if isinstance(payload, dict) and isinstance(payload.get("cases"), list):
        return len([row for row in payload["cases"] if isinstance(row, dict)])
    return None


def validate_contract(
    project: Path,
    contract_path: Path,
    payload: Any,
    *,
    expected_work_unit: str,
    expected_project: str | None = None,
    require_frozen: bool = False,
    require_complete: bool = False,
    require_peer_review: bool = False,
    current_shared_hashes: dict[str, str] | None = None,
) -> list[str]:
    errors: list[str] = []
    if not isinstance(payload, dict):
        return [f"{contract_path}: 根节点必须是对象"]
    if payload.get("schema_version") != CONTRACT_SCHEMA_VERSION:
        errors.append(f"{expected_work_unit}: schema_version 必须为 {CONTRACT_SCHEMA_VERSION}")
    if payload.get("work_unit") != expected_work_unit:
        errors.append(f"{expected_work_unit}: work_unit 与目录不一致")
    if expected_project is not None and payload.get("project") != expected_project:
        errors.append(f"{expected_work_unit}: project 与 trace.config.json 不一致")

    expected_root_text = (Path("workunits") / expected_work_unit).as_posix()
    expected_root = (project / expected_root_text).resolve()
    responsibility = payload.get("responsibility", {})
    if not isinstance(responsibility, dict):
        errors.append(f"{expected_work_unit}: responsibility 必须是对象")
        responsibility = {}
    if responsibility.get("write_root") != expected_root_text:
        errors.append(f"{expected_work_unit}: write_root 必须为 {expected_root_text}")
    if responsibility.get("allowed_write_paths") != [expected_root_text]:
        errors.append(f"{expected_work_unit}: allowed_write_paths 只能包含自身目录")

    required_outputs = payload.get("required_outputs", {})
    if not isinstance(required_outputs, dict):
        errors.append(f"{expected_work_unit}: required_outputs 必须是对象")
        required_outputs = {}
    for key in ("case_file", "self_check_report", "peer_review_report"):
        _validate_scoped_file(project, expected_root, required_outputs.get(key), key, errors)

    snapshot = payload.get("shared_input_snapshot", {})
    if not isinstance(snapshot, dict):
        errors.append(f"{expected_work_unit}: shared_input_snapshot 必须是对象")
        snapshot = {}
    if snapshot.get("status") not in {"UNFROZEN", "FROZEN"}:
        errors.append(f"{expected_work_unit}: shared_input_snapshot.status 无效")
    if require_frozen or require_complete:
        if snapshot.get("status") != "FROZEN" or not str(snapshot.get("snapshot_id", "")):
            errors.append(f"{expected_work_unit}: 共享输入尚未冻结")
        hashes = snapshot.get("input_hashes")
        if not isinstance(hashes, dict) or not hashes:
            errors.append(f"{expected_work_unit}: 共享输入哈希为空")
        else:
            computed_snapshot_id = hashlib.sha256(
                json.dumps(hashes, ensure_ascii=False, sort_keys=True).encode("utf-8")
            ).hexdigest()
            if snapshot.get("snapshot_id") != computed_snapshot_id:
                errors.append(f"{expected_work_unit}: snapshot_id 与 input_hashes 不匹配")
            if current_shared_hashes is not None and hashes != current_shared_hashes:
                errors.append(f"{expected_work_unit}: 共享输入已变化，工作单快照失效")

    handoff = payload.get("handoff", {})
    if not isinstance(handoff, dict):
        errors.append(f"{expected_work_unit}: handoff 必须是对象")
        handoff = {}
    if not isinstance(handoff.get("pending_confirmations"), list):
        errors.append(f"{expected_work_unit}: pending_confirmations 必须是数组")
    case_path = _validate_scoped_file(
        project, expected_root, handoff.get("case_file"), "handoff.case_file", errors,
    )
    self_check = handoff.get("self_check", {})
    peer_review = handoff.get("peer_review", {})
    if not isinstance(self_check, dict):
        errors.append(f"{expected_work_unit}: self_check 必须是对象")
        self_check = {}
    if not isinstance(peer_review, dict):
        errors.append(f"{expected_work_unit}: peer_review 必须是对象")
        peer_review = {}
    self_path = _validate_scoped_file(
        project, expected_root, self_check.get("report_file"), "self_check.report_file", errors,
    )
    peer_path = _validate_scoped_file(
        project, expected_root, peer_review.get("report_file"), "peer_review.report_file", errors,
    )

    if require_complete:
        if handoff.get("status") not in {"SUBMITTED", "REVIEWED", "ACCEPTED"}:
            errors.append(f"{expected_work_unit}: handoff 尚未提交")
        if not isinstance(handoff.get("case_count"), int) or handoff.get("case_count", 0) <= 0:
            errors.append(f"{expected_work_unit}: case_count 必须大于 0")
        expected_case_hash = str(handoff.get("current_sha256", ""))
        if case_path is None or not case_path.is_file():
            errors.append(f"{expected_work_unit}: 用例文件不存在")
        else:
            if expected_case_hash != sha256(case_path):
                errors.append(f"{expected_work_unit}: 用例文件 SHA-256 不匹配")
            try:
                actual_count = _case_count(case_path)
            except (OSError, json.JSONDecodeError):
                actual_count = None
            if actual_count is None:
                errors.append(f"{expected_work_unit}: 用例文件必须是数组或含 cases 数组的对象")
            elif handoff.get("case_count") != actual_count:
                errors.append(f"{expected_work_unit}: case_count 与用例文件实际数量不一致")
        if not str(handoff.get("submitted_by", "") or "").strip():
            errors.append(f"{expected_work_unit}: submitted_by 未填写")
        if not str(handoff.get("submitted_at", "") or "").strip():
            errors.append(f"{expected_work_unit}: submitted_at 未填写")
        if self_check.get("status") != "PASS":
            errors.append(f"{expected_work_unit}: 自检未通过")
        if self_path is None or not self_path.is_file():
            errors.append(f"{expected_work_unit}: 自检报告不存在")
        else:
            if self_check.get("current_sha256") != sha256(self_path):
                errors.append(f"{expected_work_unit}: 自检报告 SHA-256 不匹配")
            try:
                if _json_status(self_path) != "PASS":
                    errors.append(f"{expected_work_unit}: 自检报告内容不是 PASS")
            except (OSError, json.JSONDecodeError):
                errors.append(f"{expected_work_unit}: 自检报告不是有效 JSON")
        if require_peer_review:
            if peer_review.get("status") != "PASS":
                errors.append(f"{expected_work_unit}: 同行评审未通过")
            reviewer = str(peer_review.get("reviewer_work_unit", "") or "")
            if not reviewer or reviewer == expected_work_unit:
                errors.append(f"{expected_work_unit}: 同行评审必须由其他工作单完成")
            if peer_path is None or not peer_path.is_file():
                errors.append(f"{expected_work_unit}: 同行评审报告不存在")
            else:
                if peer_review.get("current_sha256") != sha256(peer_path):
                    errors.append(f"{expected_work_unit}: 同行评审报告 SHA-256 不匹配")
                try:
                    if _json_status(peer_path) != "PASS":
                        errors.append(f"{expected_work_unit}: 同行评审报告内容不是 PASS")
                except (OSError, json.JSONDecodeError):
                    errors.append(f"{expected_work_unit}: 同行评审报告不是有效 JSON")
        acceptance = payload.get("main_acceptance", {})
        if not isinstance(acceptance, dict) or acceptance.get("status") != "PASS":
            errors.append(f"{expected_work_unit}: 主代理尚未验收")
        elif acceptance.get("accepted_case_sha256") != expected_case_hash:
            errors.append(f"{expected_work_unit}: 主验收未绑定当前用例哈希")
        else:
            if not str(acceptance.get("accepted_by", "") or "").strip():
                errors.append(f"{expected_work_unit}: accepted_by 未填写")
            if not str(acceptance.get("accepted_at", "") or "").strip():
                errors.append(f"{expected_work_unit}: accepted_at 未填写")
    return errors


def validate_project_contracts(
    project: Path,
    profile: dict[str, Any],
    *,
    require_frozen: bool = False,
    require_complete: bool = False,
) -> tuple[list[str], dict[str, Any]]:
    """Validate every declared unit and reject stale or cross-directory handoffs."""
    errors: list[str] = []
    units = [str(value) for value in profile.get("work_units", [])]
    project_name = ""
    config_path = project / "trace.config.json"
    if config_path.is_file():
        config = json.loads(config_path.read_text(encoding="utf-8"))
        project_name = str(config.get("project", "") or "")
    current_hashes: dict[str, str] | None = None
    if require_frozen or require_complete:
        try:
            current_hashes = shared_input_hashes(project)
        except (OSError, ValueError, json.JSONDecodeError) as exc:
            errors.append(str(exc))

    snapshot_ids: set[str] = set()
    validated = 0
    for unit in units:
        path = _contract_path(project, unit)
        if not path.is_file():
            errors.append(f"{unit}: 工作单合同不存在")
            continue
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            errors.append(f"{unit}: 工作单合同无法读取: {exc}")
            continue
        unit_errors = validate_contract(
            project,
            path,
            payload,
            expected_work_unit=unit,
            expected_project=project_name or None,
            require_frozen=require_frozen,
            require_complete=require_complete,
            require_peer_review="peer_review" in profile.get("capability_packs", []),
            current_shared_hashes=current_hashes,
        )
        if require_complete and "peer_review" in profile.get("capability_packs", []):
            peer = payload.get("handoff", {}).get("peer_review", {}) \
                if isinstance(payload.get("handoff"), dict) else {}
            reviewer = str(peer.get("reviewer_work_unit", "") or "") \
                if isinstance(peer, dict) else ""
            if reviewer and reviewer not in units:
                unit_errors.append(f"{unit}: reviewer_work_unit 未在执行画像 work_units 中声明")
        errors.extend(unit_errors)
        snapshot = payload.get("shared_input_snapshot", {})
        if isinstance(snapshot, dict) and snapshot.get("snapshot_id"):
            snapshot_ids.add(str(snapshot["snapshot_id"]))
        validated += 1
    if len(snapshot_ids) > 1:
        errors.append("各工作单共享输入 snapshot_id 不一致")
    return errors, {
        "work_units_declared": len(units),
        "work_unit_contracts_validated": validated,
        "shared_snapshot_count": len(snapshot_ids),
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="冻结或校验并行测试用例工作单合同")
    parser.add_argument("--project", required=True, help="项目名或绝对项目目录")
    parser.add_argument("--workspace-root", help="项目工作区根目录；--project 为名称时生效")
    action = parser.add_mutually_exclusive_group(required=True)
    action.add_argument("--freeze", action="store_true", help="冻结共享输入哈希到全部工作单")
    action.add_argument("--validate", action="store_true", help="校验全部工作单合同")
    parser.add_argument("--require-complete", action="store_true", help="要求交回、同行评审和主验收完成")
    parser.add_argument("--json", action="store_true", help="输出 JSON")
    args = parser.parse_args()

    project = resolve_project(args.project, workspace_root=args.workspace_root)
    try:
        profile = load_profile(project, legacy_strict=False)
        if args.freeze:
            result = {"success": True, **freeze_project_contracts(project, profile)}
        else:
            errors, metrics = validate_project_contracts(
                project,
                profile,
                require_frozen=args.require_complete,
                require_complete=args.require_complete,
            )
            result = {"success": not errors, "errors": errors, "metrics": metrics}
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        result = {"success": False, "errors": [str(exc)]}
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    raise SystemExit(0 if result["success"] else 1)


if __name__ == "__main__":
    main()
