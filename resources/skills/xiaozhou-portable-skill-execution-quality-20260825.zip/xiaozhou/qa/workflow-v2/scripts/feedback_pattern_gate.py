# -*- coding: utf-8 -*-
"""Validate that every reported testcase problem was scanned project-wide."""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from typing import Any

_SCRIPTS = Path(__file__).resolve().parent
if str(_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS))

import tc_excel  # noqa: E402


def _resolve(base: Path, value: str | Path) -> Path:
    path = Path(value)
    return path if path.is_absolute() else base / path


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _issue(code: str, message: str, pattern_id: str = "") -> dict[str, str]:
    issue = {"severity": "blocking", "code": code, "message": message}
    if pattern_id:
        issue["pattern_id"] = pattern_id
    return issue


def _nonempty(value: Any) -> bool:
    if isinstance(value, str):
        return bool(value.strip())
    if isinstance(value, (list, dict)):
        return bool(value)
    return value is not None


def _string_ids(value: Any) -> list[str] | None:
    if not isinstance(value, list):
        return None
    ids = [str(item).strip() for item in value]
    if any(not item for item in ids):
        return None
    return ids


def _patterns(payload: Any) -> list[Any] | None:
    if isinstance(payload, list):
        return payload
    if not isinstance(payload, dict):
        return None
    for key in ("patterns", "items", "feedback_patterns"):
        if key in payload:
            return payload[key] if isinstance(payload[key], list) else None
    return None


def evaluate(config_path: str | Path) -> dict[str, Any]:
    config_path = Path(config_path).resolve()
    config = json.loads(config_path.read_text(encoding="utf-8"))
    base = config_path.parent
    release = config.get("release_acceptance", {}) or {}
    issues: list[dict[str, str]] = []
    warnings: list[dict[str, str]] = []

    cases_value = config.get("cases_xlsx")
    if not cases_value:
        issues.append(_issue("CASES_XLSX_CONFIG_MISSING", "config.cases_xlsx 未配置"))
        cases_path = base / "<missing-cases.xlsx>"
        rows: list[dict] = []
        current_hash = ""
    else:
        cases_path = _resolve(base, str(cases_value))
        if not cases_path.exists():
            issues.append(_issue("CASES_XLSX_MISSING", f"最终Excel不存在: {cases_path}"))
            rows = []
            current_hash = ""
        else:
            rows = tc_excel.read_master_rows(cases_path)
            current_hash = _sha256(cases_path)

    known_case_ids = {
        str(row.get("用例编号", "") or "").strip()
        for row in rows if str(row.get("用例编号", "") or "").strip()
    }
    patterns_cfg = release.get("feedback_patterns")
    required = bool(release.get("feedback_patterns_required", release.get("required", False)))
    if isinstance(patterns_cfg, dict) and "required" in patterns_cfg:
        required = bool(patterns_cfg.get("required"))
    ledger_value = release.get("feedback_patterns_file", "工作底稿/反馈模式账本.json")
    ledger_path = _resolve(base, str(ledger_value))

    pattern_rows: list[Any] = []
    no_feedback_recorded = False
    if not ledger_path.exists():
        if required:
            issues.append(_issue("FEEDBACK_LEDGER_MISSING", f"反馈模式账本不存在: {ledger_path}"))
        else:
            warnings.append({
                "severity": "warning",
                "code": "FEEDBACK_LEDGER_NOT_REQUIRED",
                "message": f"反馈模式账本不存在但当前未设为必需: {ledger_path}",
            })
    else:
        try:
            payload = json.loads(ledger_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            issues.append(_issue("FEEDBACK_LEDGER_INVALID_JSON", f"反馈模式账本无法读取: {exc}"))
        else:
            loaded = _patterns(payload)
            if loaded is None:
                issues.append(_issue("FEEDBACK_LEDGER_SCHEMA_INVALID", "反馈模式账本必须是数组或包含patterns/items数组"))
            else:
                pattern_rows = loaded
                if required and not pattern_rows:
                    if isinstance(payload, dict) and payload.get("no_feedback_recorded") is True \
                            and _nonempty(payload.get("note")):
                        no_feedback_recorded = True
                    else:
                        issues.append(_issue(
                            "FEEDBACK_LEDGER_EMPTY_UNDECLARED",
                            "空反馈账本必须显式 no_feedback_recorded=true 并填写具体 note",
                        ))

    seen_pattern_ids: set[str] = set()
    valid_patterns = 0
    for index, item in enumerate(pattern_rows, 1):
        before = len(issues)
        if not isinstance(item, dict):
            issues.append(_issue("FEEDBACK_PATTERN_NOT_OBJECT", f"第{index}条反馈模式必须是对象"))
            continue
        pattern_id = str(item.get("pattern_id", "") or "").strip()
        if not pattern_id:
            issues.append(_issue("PATTERN_ID_MISSING", f"第{index}条反馈缺 pattern_id"))
        elif pattern_id in seen_pattern_ids:
            issues.append(_issue("PATTERN_ID_DUPLICATE", f"pattern_id 重复: {pattern_id}", pattern_id))
        seen_pattern_ids.add(pattern_id)

        reported_ids = _string_ids(item.get("reported_case_ids"))
        if reported_ids is None or not reported_ids:
            issues.append(_issue("REPORTED_CASE_IDS_INVALID", "reported_case_ids 必须是非空字符串数组", pattern_id))
        elif unknown := sorted(set(reported_ids) - known_case_ids):
            issues.append(_issue("REPORTED_CASE_ID_MISSING", f"reported_case_ids 引用不存在用例: {unknown}", pattern_id))

        if item.get("scope") != "all_project":
            issues.append(_issue("FEEDBACK_SCOPE_NOT_ALL_PROJECT", "scope 必须为 all_project", pattern_id))
        if item.get("scan_status") != "passed":
            issues.append(_issue("FEEDBACK_SCAN_NOT_PASSED", "scan_status 必须为 passed", pattern_id))
        scanned_count = item.get("scanned_case_count")
        if isinstance(scanned_count, bool) or not isinstance(scanned_count, int) or scanned_count != len(rows):
            issues.append(_issue(
                "FEEDBACK_SCAN_COUNT_MISMATCH",
                f"scanned_case_count={scanned_count!r}，当前Excel总行数={len(rows)}",
                pattern_id,
            ))

        matched_ids = _string_ids(item.get("matched_case_ids"))
        resolved_ids = _string_ids(item.get("resolved_case_ids"))
        if matched_ids is None:
            issues.append(_issue("MATCHED_CASE_IDS_INVALID", "matched_case_ids 必须是字符串数组", pattern_id))
        if resolved_ids is None:
            issues.append(_issue("RESOLVED_CASE_IDS_INVALID", "resolved_case_ids 必须是字符串数组", pattern_id))
        if matched_ids is not None and resolved_ids is not None:
            matched_set = set(matched_ids)
            resolved_set = set(resolved_ids)
            if matched_set != resolved_set:
                issues.append(_issue(
                    "FEEDBACK_NOT_FULLY_RESOLVED",
                    f"matched/resolved集合不一致，未解决={sorted(matched_set - resolved_set)}，多余={sorted(resolved_set - matched_set)}",
                    pattern_id,
                ))
            unknown = sorted((matched_set | resolved_set) - known_case_ids)
            if unknown:
                issues.append(_issue("FEEDBACK_MATCHED_CASE_ID_MISSING", f"matched/resolved引用不存在用例: {unknown}", pattern_id))

        if not _nonempty(item.get("evidence")):
            issues.append(_issue("FEEDBACK_EVIDENCE_MISSING", "evidence 必须提供具体扫描与修复证据", pattern_id))
        recorded_hash = str(item.get("input_xlsx_sha256", "") or "").strip().lower()
        if not recorded_hash:
            issues.append(_issue("FEEDBACK_INPUT_HASH_MISSING", "input_xlsx_sha256 缺失", pattern_id))
        elif recorded_hash != current_hash.lower():
            issues.append(_issue(
                "FEEDBACK_INPUT_HASH_STALE",
                f"input_xlsx_sha256 与当前Excel不一致: recorded={recorded_hash} current={current_hash}",
                pattern_id,
            ))
        if len(issues) == before:
            valid_patterns += 1

    status = "PASS" if not issues else "FAIL"
    return {
        "schema_version": 1,
        "tool": "feedback_pattern_gate",
        "status": status,
        "blocking_count": len(issues),
        "risk_count": 0,
        "warning_count": len(warnings),
        "issues": issues + warnings,
        "metrics": {
            "case_count": len(rows),
            "pattern_count": len(pattern_rows),
            "validated_pattern_count": valid_patterns,
            "required": required,
            "no_feedback_recorded": no_feedback_recorded,
        },
        "artifacts": {
            "config": str(config_path),
            "cases_xlsx": str(cases_path),
            "feedback_patterns_file": str(ledger_path),
            "input_xlsx_sha256": current_hash,
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="反馈问题全项目同模式扫描门禁")
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    try:
        report = evaluate(args.config)
    except Exception as exc:  # noqa: BLE001 - CLI must fail with machine-readable evidence
        report = {
            "schema_version": 1,
            "tool": "feedback_pattern_gate",
            "status": "FAIL",
            "blocking_count": 1,
            "risk_count": 0,
            "warning_count": 0,
            "issues": [_issue("GATE_EXECUTION_ERROR", str(exc))],
            "metrics": {},
            "artifacts": {"config": str(Path(args.config).resolve())},
        }
    print(json.dumps(report, ensure_ascii=False, indent=2))
    raise SystemExit(0 if report["status"] == "PASS" else 1)


if __name__ == "__main__":
    main()
