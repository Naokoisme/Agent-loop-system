# -*- coding: utf-8 -*-
"""结构/充分性检查器(门禁C)。团队交付前必跑,违规非0退出,机械拦截。

把 用例自审清单.md 里"可机械判定"的硬规则变成自动检查,不依赖个人自觉:
  S1 功能点块连续:同一(功能模块,功能点)不得在不相邻行重复出现(Excel合并/分组错乱来源)
  S2 禁止泛化"界面操作"功能点:功能点不得为"界面操作"(界面操作应是测试项,挂在页面功能点下)
  S3 界面操作一例一手势:测试项=界面操作 的测试点不得同时含多个手势(上滑/下滑/左滑/右滑/单击/双击/长按)
  S4 预期可判定:预期结果不得含 正常/符合预期/符合PRD/按规则处理/按页面规则响应/按优先级处理/阈值前/阈值点/阈值后
  S5 交叉场景单一功能点:同模块不得出现多个交叉类功能点(如 提醒交叉/主表盘交叉/数据页交叉 与 交叉场景 并存)
  S6 测试项泛化:测试项不得含具体数值/单位/平台/语言等枚举值
  S8 步骤/预期对应:操作步骤与预期结果必须使用同编号逐行对应
  S9 原子动作/结果:每个步骤编号只含一个动作,每个预期编号只含一个可观察结果
  FMC1-FMC2 人工功能用例合同:只允许人工执行,禁止自动化脚本/fixture/Mock/注入/定位器等实现细节
  S10 待确认红字:含 待确认/待产品确认 的 Excel 单元格必须红字,红字单元格必须含待确认标记
  S7/S11-S15 为配置型门禁,仅在 trace.config.json 的 quality_gates 配置后启用:
    S7 feature_order 主流程顺序
    S11 module_dependencies 依赖前置
    S12 unsupported_features 不支持能力禁入
    S13 page_input_matrix 页面输入矩阵
    S14 new_modules 新增模块纳入
    S15 new_modules.required_categories 新模块类别完整性
  S16-S22 执行体验门禁,依赖 quality_gates.excel_format:
    S16 前置编号 / S17 测试点"验证"开头 / S18 测试点长度 / S19 测试点非空泛 / S20 层级合并 / S21 合并读取回填 / S22 迁移一致性(轻量)
  S23-S35 语义门禁,其中 S23-S28 为项目适用性配置,S29-S35 为生产质量配置:
    S23 test_item_exception_objects 测试项含具体异常对象(应泛化,对象下沉)
    S24 cross_scene 交叉场景污染(测试项不含"交叉"、不混入普通流程/自身异常)
    S25 common_fixtures 公共前置高频重复(应进 common_fixtures)
    S26 navigation_expectations 跳转操作预期须观察目标页
    S27 blueprint 用例设计蓝图存在性与字段完整
    S28 ui_operation_order 界面操作就近排序(界面操作须排在页面可达之后;未配则用 page_input_matrix 带 anchor_keywords/ui_keywords 的项)
    S29 production_semantics 测试点/步骤/预期禁止模糊模板；参数必须写实际值并贯穿步骤和预期
    S30 production_semantics.preconditions 前置必须具体且可由测试人员建立,不得引用fixture
    S31 production_semantics 手工用例不得要求无治具的亚秒高频/严格并发
    S32 production_semantics 依赖模块不得承载受影响业务的交叉/中断用例
    S33 conflict_matrix_policy 冲突格须显式声明归属、复用、不适用或待确认
    S34 scenario_coverage PRD追溯之外的场景完整度矩阵不得有空格
    S35 manual_case_style 纯人工步骤只写业务动作,回归比较须有明确来源和对象
  S36 三级分组连续:同一(功能模块,功能点,测试项)默认只能形成一个连续区块；
    例外必须在蓝图 continuous_block_exceptions 中精确声明并写具体原因
  复发防护扩展(复用现有门禁编号,均为配置型):
    S5 cross_scene_block 交叉场景必须集中为一个连续区块
    S9/S29 case_granularity 禁止A/B/C数据组过度合并和完全等价重复拆分
    S23 test_item_taxonomy 禁止把边界测试/规则确认当作可见测试项
    S27 case_scale 必须有复杂度画像且禁止固定条数配额
    S20/S22 delivery_workbook 最终Excel表头/单表/字体/黑边框/合并/版本实物合同
读主表(全功能测试用例 sheet),按 功能模块 分组核对。

用法:
  python scripts/check_structure.py --xlsx projects/<项目>/<项目>_全功能测试用例.xlsx
  python scripts/check_structure.py --config projects/<项目>/trace.config.json
"""
from __future__ import annotations
import argparse
import json
import re
import sys
from pathlib import Path

import openpyxl

_SCRIPTS = Path(__file__).resolve().parent
sys.path.insert(0, str(_SCRIPTS))
import tc_excel  # noqa: E402
import quality_semantics  # noqa: E402
import delivery_quality  # noqa: E402

VAGUE = ["符合预期", "符合PRD", "符合 PRD", "按规则处理", "按页面规则响应",
         "按优先级处理", "阈值前", "阈值点", "阈值后"]
VAGUE_NORMAL_RE = re.compile(r"(?:功能|状态|响应|结果|显示|运行|工作|页面|设备|系统)?正常(?:\s*$|[，,。；;\n])")
GESTURES = ["上滑", "下滑", "左滑", "右滑", "单击", "双击", "长按"]
CROSS_FP_ALIASES = ["提醒交叉", "主表盘交叉", "数据页交叉", "交叉场景", "冲突场景"]
CONFIRM_MARKERS = ("待确认", "待产品确认")
# S16-S22(执行体验门禁): 仅在 trace.config.json -> quality_gates.excel_format 配置后启用,旧项目不受影响。
PRECOND_CONNECTOR_RE = re.compile(r"[；;]|并且")
HIER_COLS = ["功能模块", "功能点", "测试项"]
TEST_POINT_MAX_DEFAULT = 35
NUMBERED_LINE_RE = re.compile(r"^\s*(\d+)[\.\)）、．]\s*")
SPECIFIC_ITEM_RE = re.compile(
    r"(?i)("
    r"\d+(?:\.\d+)?\s*(?:KB|MB|GB|B|%|s|sec|秒|分钟|分|小时|h|天|次|条|℃|°C|km|公里|kcal|BPM|mmHg|mAh|V)"
    r"|[<>＝=≥≤]\s*\d+"
    r"|\d+\s*[<>＝=≥≤]"
    r"|Android|iOS|HarmonyOS|鸿蒙|中文|英文|每小时|每\d+分钟|每\d+小时"
    r")"
)
STEP_CONNECTOR_RE = re.compile(r"(同时|然后|随后|接着|并|且|及|再点击|再选择|后点击|后选择|;|；)")
CONTINUOUS_DRAG_RE = re.compile(
    r"(?:长按|按住)[^,，;；\n]{0,30}?(?:并)?(?:拖动|移动)(?:至|到)"
    r"[^,，;；\n]{1,30}?(?=(?:同时|然后|随后|接着|并|且|;|；|,|，|$))"
)
EXP_CONNECTOR_RE = re.compile(r"(同时|并且|且|随后|接着|;|；|、)")
COMMA_SEPARATOR_RE = re.compile(r"(?<!\d)[,，]|[,，](?!\d)")
SENTENCE_SEPARATOR_RE = re.compile(r"。|(?<=[\u4e00-\u9fff])\.(?=\s*[\u4e00-\u9fff])")
STEP_ACTION_RE = re.compile(
    r"(?:打开|关闭|开启|启动|停止|开始|结束|点击|点按|单击|双击|长按|短按|按下|松开|"
    r"上滑|下滑|左滑|右滑|滑动|拖动|旋转|进入|返回|退出|选择|切换|输入|修改|设置|"
    r"调整|新增|添加|删除|移除|清空|保存|提交|确认|取消|连接|断开|绑定|解绑|插入|拔出|"
    r"接入|晃动|抬腕|佩戴|摘下|移动|靠近|远离|扫描|登录|重启|开机|关机|充电|查看|"
    r"观察|等待|重复|执行|拍照|上传|下载|同步|唤醒|熄屏|锁屏|解锁|刷新|搜索|播放|"
    r"暂停|恢复|拨打|接听|挂断|发送|导入|导出|测量|记录|校准|触发)"
)
EXPECTED_RESULT_RE = re.compile(
    r"(?:显示|出现|弹出|跳转|进入|返回|停留|切换|选中|新增(?!项)|删除|保存|同步|上传|下载|"
    r"连接|断开|绑定|解绑|启动|停止|开始|结束|开启|关闭|点亮|熄灭|亮起|闪烁|振动|短振|"
    r"长振|响起|播放|暂停|恢复|刷新|更新|增加|减少|变为|保持|关机|开机|重启|生成|收到|"
    r"消失|隐藏|锁定|解锁|完成|成功|失败|可播放)"
)
EXPECTED_STATE_TRANSITION_RE = re.compile(
    r"(?:进入|返回|停留|跳转|切换|启动|停止|开始|结束|开启|关闭|关机|开机|重启|熄屏|锁屏|解锁)"
)
APP_RESULT_DOMAIN_RE = re.compile(r"(?:APP|App|app|页面|界面|弹窗|列表|图标|按钮|提示|[^\s，,]{1,8}页)")
DEVICE_RESULT_DOMAIN_RE = re.compile(
    r"(?:A036|设备(?!页)|手环|手表|灯光|指示灯|振动|震动|屏幕|蜂鸣|声音)"
)
COMMA_SUPPLEMENT_RE = re.compile(
    r"^(?:累计|共计|合计|使|以便|用于|从而|现场|期间|全程|结束时|开始时|完成后|操作后|"
    r"约?\d+(?:\.\d+)?\s*(?:毫秒|ms|秒|s|分钟|分|小时|时|米|m)后|未|不|没有|无)"
)
DEFAULT_DEP_NEGATIVE_KEYWORDS = [
    "关闭", "未开启", "无权限", "未授权", "断网", "断连", "失败", "不显示", "不触发", "禁用"
]
DEFAULT_UNSUPPORTED_ALLOW_KEYWORDS = [
    "不支持", "不提供", "不显示", "不出现", "无", "禁止", "不可", "不允许", "无法", "取消入口"
]
INPUT_ALIASES = {
    "左滑": ["左滑"],
    "右滑": ["右滑"],
    "上滑": ["上滑"],
    "下滑": ["下滑"],
    "点击": ["点击", "点按", "单击"],
    "点按": ["点击", "点按", "单击"],
    "编码器旋转": ["编码器旋转", "旋转编码器"],
    "旋转编码器": ["编码器旋转", "旋转编码器"],
    "编码器按压": ["编码器按压", "按压编码器"],
    "按压编码器": ["编码器按压", "按压编码器"],
    "下按键": ["下按键", "短按下按键", "按下下按键"],
}
DEFAULT_CATEGORY_KEYWORDS = {
    "入口": ["入口", "进入", "首页", "列表"],
    "页面展示": ["页面展示", "展示", "显示", "空态", "结果页", "弹窗"],
    "核心": ["核心", "开始", "发起", "测量", "录音", "校准", "保存", "同步", "上传", "生成"],
    "异常": ["异常", "失败", "未佩戴", "断连", "错误", "不足", "超时"],
    "中断": ["中断", "打断", "来电", "低电", "充电", "OTA", "解绑", "退出"],
    "交叉": ["交叉", "消息", "来电", "充电", "低电", "勿扰", "睡眠", "运动"],
    "界面操作": ["界面操作", "左滑", "右滑", "上滑", "下滑", "编码器", "下按键", "点击", "点按"],
}
# S23-S27(语义门禁): 均为配置型,仅在 trace.config.json -> quality_gates 出现对应键时启用,旧项目默认不受影响。
DEFAULT_EXC_OBJECTS = [
    "低电", "断连", "断开", "传输断开", "GPS丢失", "地磁干扰", "定位超时", "网络异常", "断网",
    "存储不足", "权限关闭", "未授权", "下载失败", "解压失败",
    "GPS异常", "低电异常", "传输异常", "地磁异常", "无数据异常",
]
GENERIC_EXC_ITEMS = "异常测试 / 中断测试 / 恢复测试 / 限制测试"
DEFAULT_FORBIDDEN_CROSS = [
    "页面跳转", "下载失败", "解压失败", "GPS丢失", "GPS恢复", "校准恢复", "传输断开",
    "定位成功", "双端同步", "下载完成", "下载进度", "运动切换", "地图显示", "定位地图",
]
DEFAULT_ALLOWED_CROSS = ["来电", "消息", "闹钟", "查找", "OTA", "勿扰", "运动模式推送", "表盘推送", "充电", "低电提醒"]
BLUEPRINT_KEYS = [
    "module_boundary", "feature_order", "page_state_anchors", "input_matrix",
    "exception_matrix", "cross_matrix", "common_fixtures", "case_precondition_rules", "unsupported_features",
]


def _numbered_lines(text: str) -> tuple[list[int], list[str]]:
    nums: list[int] = []
    unnumbered: list[str] = []
    for line in str(text or "").replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        line = line.strip()
        if not line:
            continue
        m = NUMBERED_LINE_RE.match(line)
        if m:
            nums.append(int(m.group(1)))
        else:
            unnumbered.append(line)
    return nums, unnumbered


def _content_lines(text: str) -> list[str]:
    return [line.strip() for line in str(text or "").replace("\r\n", "\n").replace("\r", "\n").split("\n") if line.strip()]


def _comma_has_independent_clauses(content: str, clause_pattern: re.Pattern[str]) -> bool:
    """Only treat a comma as atomicity-breaking when both sides stand alone.

    Purpose, condition, duration and supplementary clauses are intentionally
    excluded; a comma by itself is not evidence of a second action/result.
    """
    parts = [part.strip() for part in COMMA_SEPARATOR_RE.split(content) if part.strip()]
    if len(parts) < 2:
        return False
    for left, right in zip(parts, parts[1:]):
        if COMMA_SUPPLEMENT_RE.search(right):
            continue
        if clause_pattern.search(left) and clause_pattern.search(right):
            return True
    return False


def _sentence_has_independent_clauses(content: str, clause_pattern: re.Pattern[str]) -> bool:
    """Reject multiple actionable/observable sentences hidden under one number."""
    parts = [part.strip() for part in SENTENCE_SEPARATOR_RE.split(content) if part.strip()]
    return sum(bool(clause_pattern.search(part)) for part in parts) >= 2


def _step_has_explicit_multi_action(content: str) -> bool:
    """Require a connector plus two actions; temporal adverbs alone are valid."""
    without_continuous_drag = CONTINUOUS_DRAG_RE.sub("连续拖动手势", content)
    return (
        bool(STEP_CONNECTOR_RE.search(without_continuous_drag))
        and len(STEP_ACTION_RE.findall(without_continuous_drag)) >= 2
    )


def _expected_has_explicit_multi_result(content: str) -> bool:
    """Require a connector plus two observable results in the same line."""
    return (
        bool(EXP_CONNECTOR_RE.search(content))
        and len(EXPECTED_RESULT_RE.findall(content)) >= 2
    )


def _expected_domains(clause: str) -> set[str]:
    domains: set[str] = set()
    if APP_RESULT_DOMAIN_RE.search(clause):
        domains.add("app")
    if DEVICE_RESULT_DOMAIN_RE.search(clause):
        domains.add("device")
    return domains


def _expected_context_detail(left: str, right: str) -> bool:
    """Allow one state transition plus its same-surface manifestation/detail."""
    if not EXPECTED_STATE_TRANSITION_RE.search(left):
        return False
    left_domains = _expected_domains(left)
    right_domains = _expected_domains(right)
    return bool(left_domains and right_domains and left_domains & right_domains)


def _expected_comma_has_independent_results(content: str) -> bool:
    parts = [part.strip() for part in COMMA_SEPARATOR_RE.split(content) if part.strip()]
    if len(parts) < 2:
        return False
    for left, right in zip(parts, parts[1:]):
        if COMMA_SUPPLEMENT_RE.search(right) or _expected_context_detail(left, right):
            continue
        if EXPECTED_RESULT_RE.search(left) and EXPECTED_RESULT_RE.search(right):
            return True
    return False


def _font_is_red(cell) -> bool:
    color = cell.font.color
    if color is None:
        return False
    if color.type == "rgb" and color.rgb:
        return str(color.rgb).upper().endswith("FF0000")
    return False


def _as_list(value) -> list:
    if value is None:
        return []
    return value if isinstance(value, list) else [value]


def _rows_by_module(rows: list[dict]) -> dict[str, list[dict]]:
    by_mod: dict[str, list[dict]] = {}
    for r in rows:
        by_mod.setdefault(r.get("功能模块", ""), []).append(r)
    return by_mod


def _row_text(row: dict, fields: list[str] | None = None) -> str:
    fields = fields or ["功能点", "测试项", "测试点/检查项", "前置条件", "操作步骤", "预期结果", "备注"]
    return " ".join(str(row.get(f, "")) for f in fields)


def _hit_any(text: str, keywords: list[str]) -> bool:
    return any(str(k) in text for k in keywords if str(k))


def _module_gate_entries(gate_value) -> list[tuple[str, dict]]:
    """兼容 dict(module->config) 与 list({module,...}) 两种配置形态。"""
    entries: list[tuple[str, dict]] = []
    if isinstance(gate_value, dict):
        for module, cfg in gate_value.items():
            if isinstance(cfg, dict):
                item = dict(cfg)
            else:
                item = {"value": cfg}
            item.setdefault("module", module)
            entries.append((module, item))
    elif isinstance(gate_value, list):
        for cfg in gate_value:
            if isinstance(cfg, str):
                entries.append((cfg, {"module": cfg}))
            elif isinstance(cfg, dict):
                module = cfg.get("module") or cfg.get("name")
                if module:
                    entries.append((module, dict(cfg)))
    return entries


def check_confirm_styles(xlsx: Path) -> list[str]:
    violations: list[str] = []
    wb = openpyxl.load_workbook(xlsx, data_only=False)
    for ws in wb.worksheets:
        for row in ws.iter_rows(min_row=2):
            for cell in row:
                text = "" if cell.value is None else str(cell.value)
                has_marker = any(marker in text for marker in CONFIRM_MARKERS)
                is_red = _font_is_red(cell)
                if has_marker and not is_red:
                    violations.append(f"[S10 待确认未标红] {ws.title}!{cell.coordinate} 含待确认标记但字体非红色")
                elif is_red and not has_marker:
                    violations.append(f"[S10 红字误标] {ws.title}!{cell.coordinate} 红字但不含待确认标记")
    return violations


def check_feature_order(rows: list[dict], gate_value) -> list[str]:
    violations: list[str] = []
    by_mod = _rows_by_module(rows)
    for module, cfg in _module_gate_entries(gate_value):
        expected = cfg.get("order", cfg.get("feature_order", cfg.get("value", [])))
        expected = [str(x) for x in _as_list(expected) if str(x)]
        if not expected:
            continue
        mode = cfg.get("mode", "exact")
        required = bool(cfg.get("required", True))
        mrows = by_mod.get(module, [])
        actual: list[str] = []
        for r in mrows:
            fp = str(r.get("功能点", ""))
            if fp and (not actual or actual[-1] != fp):
                actual.append(fp)

        def index_for(fp: str) -> int | None:
            if mode == "contains":
                for i, token in enumerate(expected):
                    if token in fp:
                        return i
            elif fp in expected:
                return expected.index(fp)
            return None

        present_expected = set()
        last = -1
        for fp in actual:
            idx = index_for(fp)
            if idx is None:
                continue
            present_expected.add(expected[idx])
            if idx < last:
                violations.append(f"[S7 主流程顺序错误] {module} 功能点「{fp}」出现在前序功能点之后,配置顺序={expected}")
                break
            last = idx
        if required:
            missing = [fp for fp in expected if fp not in present_expected]
            if missing:
                violations.append(f"[S7 主流程功能点缺失] {module} 缺少配置的功能点 {missing}")
    return violations


def check_module_dependencies(rows: list[dict], gate_value) -> list[str]:
    violations: list[str] = []
    by_mod = _rows_by_module(rows)
    for module, cfg in _module_gate_entries(gate_value):
        required = cfg.get("required_preconditions", cfg.get("dependencies", cfg.get("value", [])))
        required = [str(x) for x in _as_list(required) if str(x)]
        if not required:
            continue
        negative_keywords = [str(x) for x in _as_list(cfg.get("negative_keywords", DEFAULT_DEP_NEGATIVE_KEYWORDS)) if str(x)]
        exclude_case_ids = {str(x) for x in _as_list(cfg.get("exclude_case_ids"))}
        scope_keywords = [str(x) for x in _as_list(cfg.get("scope_keywords")) if str(x)]
        for r in by_mod.get(module, []):
            cid = str(r.get("用例编号", ""))
            text = _row_text(r)
            if cid in exclude_case_ids:
                continue
            if scope_keywords and not _hit_any(text, scope_keywords):
                continue
            if _hit_any(text, negative_keywords):
                continue
            pre = str(r.get("前置条件", ""))
            missing = [x for x in required if x not in pre]
            if missing:
                violations.append(f"[S11 依赖前置缺失] {module}/{cid} 前置条件缺少 {missing}")
    return violations


def check_unsupported_features(rows: list[dict], gate_value) -> list[str]:
    violations: list[str] = []
    by_mod = _rows_by_module(rows)
    for module, cfg in _module_gate_entries(gate_value):
        raw_features = cfg.get("features", cfg.get("value", cfg))
        if isinstance(raw_features, dict) and "keywords" in raw_features:
            features = [raw_features]
        elif isinstance(raw_features, list):
            features = raw_features
        else:
            features = []
        for feature in features:
            if isinstance(feature, str):
                feature_cfg = {"feature": feature, "keywords": [feature]}
            elif isinstance(feature, dict):
                feature_cfg = feature
            else:
                continue
            name = feature_cfg.get("feature", feature_cfg.get("name", "未命名能力"))
            keywords = [str(x) for x in _as_list(feature_cfg.get("keywords", name)) if str(x)]
            allowed = [str(x) for x in _as_list(feature_cfg.get("allowed_negative_keywords", DEFAULT_UNSUPPORTED_ALLOW_KEYWORDS)) if str(x)]
            allow_case_ids = {str(x) for x in _as_list(feature_cfg.get("allow_case_ids"))}
            for r in by_mod.get(module, []):
                cid = str(r.get("用例编号", ""))
                text = _row_text(r)
                if cid in allow_case_ids or not _hit_any(text, keywords):
                    continue
                if _hit_any(text, allowed):
                    continue
                violations.append(f"[S12 不支持能力正向用例] {module}/{cid} 命中「{name}」关键词{keywords},但未体现不支持/不提供")
    return violations


def check_page_input_matrix(rows: list[dict], gate_value) -> list[str]:
    violations: list[str] = []
    by_mod = _rows_by_module(rows)
    page_entries: list[tuple[str, dict]] = []
    if isinstance(gate_value, dict):
        for module, pages in gate_value.items():
            for page in _as_list(pages):
                if isinstance(page, dict):
                    page_entries.append((module, dict(page)))
    elif isinstance(gate_value, list):
        for page in gate_value:
            if isinstance(page, dict) and page.get("module"):
                page_entries.append((str(page["module"]), dict(page)))
    for module, cfg in page_entries:
        page = str(cfg.get("page", cfg.get("feature_point", "")))
        fp = str(cfg.get("feature_point", cfg.get("fp", page)))
        inputs = [str(x) for x in _as_list(cfg.get("inputs", cfg.get("required_inputs"))) if str(x)]
        not_applicable = cfg.get("not_applicable", {}) or {}
        aliases = cfg.get("input_aliases", {}) or {}
        if not page or not inputs:
            continue
        candidates = [
            r for r in by_mod.get(module, [])
            if str(r.get("测试项", "")).strip() == "界面操作"
            and (str(r.get("功能点", "")) == fp or page in _row_text(r))
        ]
        for inp in inputs:
            reason = not_applicable.get(inp) if isinstance(not_applicable, dict) else None
            if reason:
                continue
            kws = [str(x) for x in _as_list(aliases.get(inp, INPUT_ALIASES.get(inp, [inp]))) if str(x)]
            if not any(_hit_any(_row_text(r), kws) for r in candidates):
                violations.append(f"[S13 输入矩阵缺失] {module}/{page} 缺少输入「{inp}」界面操作用例")
    return violations


def check_new_modules(rows: list[dict], gate_value, config_modules: list[dict]) -> list[str]:
    violations: list[str] = []
    by_mod = _rows_by_module(rows)
    configured_modules = {m.get("name") for m in config_modules}
    for module, cfg in _module_gate_entries(gate_value):
        if module not in configured_modules:
            violations.append(f"[S14 新增模块未纳入配置] {module} 不在 trace.config.json modules 中")
        mrows = by_mod.get(module, [])
        if not mrows:
            violations.append(f"[S14 新增模块无用例] {module} 未在用例表中出现")
            continue
        required = cfg.get("required_categories", cfg.get("categories", []))
        required = [str(x) for x in _as_list(required) if str(x)]
        category_keywords = dict(DEFAULT_CATEGORY_KEYWORDS)
        category_keywords.update(cfg.get("category_keywords", {}) or {})
        for cat in required:
            keywords = [str(x) for x in _as_list(category_keywords.get(cat, cat)) if str(x)]
            hit = False
            for r in mrows:
                if cat == "界面操作" and str(r.get("测试项", "")).strip() == "界面操作":
                    hit = True
                    break
                if _hit_any(_row_text(r), keywords):
                    hit = True
                    break
            if not hit:
                violations.append(f"[S15 新模块类别缺失] {module} 缺少「{cat}」类用例")
    return violations


def check_quality_gates(rows: list[dict], quality_gates: dict, config_modules: list[dict]) -> list[str]:
    violations: list[str] = []
    if not quality_gates:
        return violations
    violations.extend(check_feature_order(rows, quality_gates.get("feature_order", {})))
    violations.extend(check_module_dependencies(rows, quality_gates.get("module_dependencies", {})))
    violations.extend(check_unsupported_features(rows, quality_gates.get("unsupported_features", {})))
    violations.extend(check_page_input_matrix(rows, quality_gates.get("page_input_matrix", {})))
    violations.extend(check_new_modules(rows, quality_gates.get("new_modules", {}), config_modules))
    violations.extend(check_platform_coverage(rows, quality_gates.get("platform_coverage")))
    return violations


def _continuous_block_exception_map(exceptions: object) -> tuple[dict[tuple[str, str, str], int], list[str]]:
    allowed: dict[tuple[str, str, str], int] = {}
    violations: list[str] = []
    if exceptions in (None, []):
        return allowed, violations
    if not isinstance(exceptions, list):
        return allowed, ["[S36 连续区块例外无效] continuous_block_exceptions 必须是数组"]
    for index, item in enumerate(exceptions, 1):
        if not isinstance(item, dict):
            violations.append(f"[S36 连续区块例外无效] 第{index}项必须是对象")
            continue
        allowed_fields = {"module", "feature_point", "test_item", "reason", "max_blocks"}
        unknown_fields = sorted(set(item) - allowed_fields)
        if unknown_fields:
            violations.append(f"[S36 连续区块例外无效] 第{index}项含未知字段 {unknown_fields}")
            continue
        key = tuple(str(item.get(field, "") or "").strip() for field in (
            "module", "feature_point", "test_item",
        ))
        reason = str(item.get("reason", "") or "").strip()
        max_blocks = item.get("max_blocks", 2)
        if any(not value or value.startswith("<") for value in key):
            violations.append(
                f"[S36 连续区块例外无效] 第{index}项必须精确填写 module/feature_point/test_item"
            )
            continue
        if not reason or reason in {"N/A", "不适用", "待填写"}:
            violations.append(f"[S36 连续区块例外无效] 第{index}项缺具体业务原因")
            continue
        if not isinstance(max_blocks, int) or isinstance(max_blocks, bool) or max_blocks < 2:
            violations.append(f"[S36 连续区块例外无效] 第{index}项 max_blocks 必须是大于等于2的整数")
            continue
        if key in allowed:
            violations.append(f"[S36 连续区块例外重复] {' / '.join(key)}")
            continue
        allowed[key] = max_blocks
    return allowed, violations


def check_hierarchy_contiguous_blocks(
    rows: list[dict], exceptions: object = None
) -> list[str]:
    """Keep every module/feature/test-item group in one physical block by default."""
    allowed, violations = _continuous_block_exception_map(exceptions)
    block_counts: dict[tuple[str, str, str], int] = {}
    previous: tuple[str, str, str] | None = None
    for row in rows:
        key = tuple(str(row.get(field, "") or "").strip() for field in (
            "功能模块", "功能点", "测试项",
        ))
        if key != previous:
            block_counts[key] = block_counts.get(key, 0) + 1
            previous = key
    for key, count in block_counts.items():
        max_blocks = allowed.get(key, 1)
        if count > max_blocks:
            violations.append(
                f"[S36 三级分组不连续] {' / '.join(key)} 形成{count}个区块，允许{max_blocks}个"
            )
    for key, max_blocks in allowed.items():
        count = block_counts.get(key, 0)
        if count == 0:
            violations.append(f"[S36 连续区块例外失效] {' / '.join(key)} 未命中当前用例")
        elif count == 1:
            violations.append(f"[S36 连续区块例外失效] {' / '.join(key)} 当前只有1个区块，无需例外")
        elif count > max_blocks:
            continue
    return violations


def _platform_hit(text: str, platform: str) -> bool:
    normalized = text.casefold()
    target = platform.casefold()
    aliases = {
        "ios": ("ios", "iphone", "ipad"),
        "android": ("android", "安卓"),
        "harmonyos": ("harmonyos", "鸿蒙"),
    }
    return any(value in normalized for value in aliases.get(target, (target,)))


def check_platform_coverage(rows: list[dict], cfg: object) -> list[str]:
    if not isinstance(cfg, dict) or cfg.get("required") is not True:
        return []
    platforms = [str(value).strip() for value in _as_list(cfg.get("platforms")) if str(value).strip()]
    flows = _as_list(cfg.get("main_flow_feature_points"))
    fields = [str(value) for value in _as_list(cfg.get("fields")) if str(value)]
    violations: list[str] = []
    if not platforms:
        return ["[S37 平台覆盖配置缺失] platforms 必须声明至少一个平台"]
    if not flows or not fields:
        return ["[S37 平台覆盖配置缺失] main_flow_feature_points 与 fields 必须配置"]
    normalized_flows: list[tuple[str, str]] = []
    for index, item in enumerate(flows, 1):
        if isinstance(item, str):
            module, feature = "", item.strip()
        elif isinstance(item, dict):
            module = str(item.get("module", "") or "").strip()
            feature = str(item.get("feature_point", "") or "").strip()
        else:
            module, feature = "", ""
        if not feature or feature.startswith("<"):
            violations.append(f"[S37 平台覆盖配置缺失] main_flow_feature_points[{index}] 未填写真实功能点")
            continue
        normalized_flows.append((module, feature))
    for module, feature in normalized_flows:
        candidates = [
            row for row in rows
            if str(row.get("功能点", "") or "").strip() == feature
            and (not module or str(row.get("功能模块", "") or "").strip() == module)
        ]
        label = f"{module + ' / ' if module else ''}{feature}"
        if not candidates:
            violations.append(f"[S37 平台主流程缺失] 未找到功能点 {label}")
            continue
        for platform in platforms:
            if not any(_platform_hit(" ".join(str(row.get(field, "") or "") for field in fields), platform) for row in candidates):
                violations.append(f"[S37 平台主流程漏覆盖] {label} 未明确覆盖 {platform}")
    return violations


def check(rows: list[dict], *, enforce_manual_contract: bool = True, contiguous_exceptions: object = None) -> list[str]:
    violations: list[str] = []
    if enforce_manual_contract:
        violations.extend(quality_semantics.check_functional_manual_contract(rows))
    violations.extend(quality_semantics.check_step_expected_contract(rows))
    ids = [str(r.get("用例编号", "") or "").strip() for r in rows]
    seen_ids: set[str] = set()
    duplicate_ids: set[str] = set()
    for cid in ids:
        if not cid:
            violations.append("[S22 用例编号为空] 执行用例必须有稳定且唯一的用例编号")
        elif cid in seen_ids:
            duplicate_ids.add(cid)
        seen_ids.add(cid)
    for cid in sorted(duplicate_ids):
        violations.append(f"[S22 用例编号重复] {cid} 在最终Excel中重复")
    violations.extend(check_hierarchy_contiguous_blocks(rows, contiguous_exceptions))
    # 按模块分组(保序)
    by_mod: dict[str, list[dict]] = {}
    for r in rows:
        by_mod.setdefault(r.get("功能模块", ""), []).append(r)

    for mod, mrows in by_mod.items():
        # S1 功能点块连续
        seen_blocks: list[str] = []
        prev = None
        for r in mrows:
            fp = r.get("功能点", "")
            if fp != prev:
                if fp in seen_blocks:
                    violations.append(f"[S1 功能点不连续] {mod} / 功能点「{fp}」在不相邻处重复出现")
                seen_blocks.append(fp)
                prev = fp
        # S5 交叉类功能点是否唯一
        cross_fps = {r.get("功能点", "") for r in mrows
                     if r.get("功能点", "") in CROSS_FP_ALIASES and "冲突" not in r.get("功能点", "")}
        if len([f for f in cross_fps if f != "冲突场景"]) > 1:
            violations.append(f"[S5 交叉功能点不唯一] {mod} 存在多个交叉功能点 {sorted(cross_fps)},应统一为「交叉场景」")

        for r in mrows:
            fp = r.get("功能点", "")
            ti = r.get("测试项", "")
            tp = str(r.get("测试点/检查项", ""))
            steps = str(r.get("操作步骤", ""))
            exp = str(r.get("预期结果", ""))
            cid = r.get("用例编号", "")
            # S2 泛化界面操作功能点
            if fp.strip() == "界面操作":
                violations.append(f"[S2 泛化界面操作功能点] {mod}/{cid} 功能点为「界面操作」,应改为页面功能点+测试项=界面操作")
            # S3 界面操作一例一手势
            if ti.strip() == "界面操作":
                hit = [g for g in ("上滑", "下滑", "左滑", "右滑") if g in tp]
                if len(hit) >= 2:
                    violations.append(f"[S3 界面操作多手势合一] {mod}/{cid} 测试点含{hit},应拆分一例一手势")
            # S4 预期模糊
            for w in VAGUE:
                if w in exp:
                    violations.append(f"[S4 预期模糊] {mod}/{cid} 预期含「{w}」: {exp[:40]}")
                    break
            else:
                if VAGUE_NORMAL_RE.search(exp):
                    violations.append(f"[S4 预期模糊] {mod}/{cid} 预期仅写泛化正常结论: {exp[:40]}")
            # S6 测试项泛化
            if SPECIFIC_ITEM_RE.search(ti):
                violations.append(f"[S6 测试项未泛化] {mod}/{cid} 测试项「{ti}」含具体枚举/数值,应下沉到测试点/检查项")
            # S9 原子动作/结果
            for line in _content_lines(steps):
                content = NUMBERED_LINE_RE.sub("", line)
                step_bad = _step_has_explicit_multi_action(content) or _sentence_has_independent_clauses(
                    content, STEP_ACTION_RE
                )
                if enforce_manual_contract:
                    step_bad = step_bad or _comma_has_independent_clauses(content, STEP_ACTION_RE)
                if step_bad:
                    violations.append(f"[S9 步骤非原子动作] {mod}/{cid}: {line[:60]}")
            for line in _content_lines(exp):
                content = NUMBERED_LINE_RE.sub("", line)
                expected_bad = _expected_has_explicit_multi_result(content) or _sentence_has_independent_clauses(
                    content, EXPECTED_RESULT_RE
                )
                if enforce_manual_contract:
                    expected_bad = expected_bad or _expected_comma_has_independent_results(content)
                if expected_bad:
                    violations.append(f"[S9 预期非原子结果] {mod}/{cid}: {line[:60]}")
    return violations


def check_workbook_mirror(
    xlsx: Path,
    master_rows: list[dict],
    *,
    enforce_manual_contract: bool = True,
    require_module_sheets: bool = True,
    master_sheet: str = tc_excel.MASTER_SHEET,
    allowed_auxiliary_sheets: list[str] | None = None,
    required_auxiliary_sheets: list[str] | None = None,
) -> list[str]:
    """FMC4: module sheets mirror the master, unless single-sheet delivery is declared."""
    violations: list[str] = []
    workbook = openpyxl.load_workbook(xlsx, data_only=True)
    if master_sheet not in workbook.sheetnames:
        return [f"[FMC4 总表缺失] 工作簿缺少「{master_sheet}」sheet"]
    if not require_module_sheets:
        allowed = {str(name) for name in (allowed_auxiliary_sheets or []) if str(name).strip()}
        required = {str(name) for name in (required_auxiliary_sheets or []) if str(name).strip()}
        extras = [name for name in workbook.sheetnames if name != master_sheet and name not in allowed]
        missing = sorted(required - set(workbook.sheetnames))
        if extras:
            violations.append(f"[FMC4 单表模式含未授权sheet] {extras}")
        if missing:
            violations.append(f"[FMC4 单表模式缺少必需辅助sheet] {missing}")
        if violations:
            return violations
        return []

    expected_by_module: dict[str, list[dict]] = {}
    for row in master_rows:
        module = str(row.get("功能模块", "") or "").strip()
        expected_by_module.setdefault(module, []).append(row)

    actual_by_module: dict[str, tuple[str, list[dict]]] = {}
    for sheet_name in workbook.sheetnames:
        if sheet_name == master_sheet:
            continue
        sheet = workbook[sheet_name]
        col_off = 1 if str(sheet.cell(1, 1).value or "").strip() == tc_excel.SEQ_HEADER else 0
        sheet_has_values = any(
            cell.value is not None and str(cell.value).strip()
            for physical_row in sheet.iter_rows()
            for cell in physical_row
        )
        if sheet_has_values:
            for column_index, expected_header in enumerate(tc_excel.COLUMNS, 1 + col_off):
                actual_header = str(sheet.cell(1, column_index).value or "").strip()
                if actual_header != expected_header:
                    violations.append(
                        f"[FMC4 子表表头不一致] {sheet_name}!{sheet.cell(1, column_index).coordinate} "
                        f"应为{expected_header!r} / 实际{actual_header!r}"
                    )

        allowed_max_column = len(tc_excel.COLUMNS) + col_off
        for column_index in range(allowed_max_column + 1, sheet.max_column + 1):
            populated = [
                cell for cell in (sheet.cell(row_index, column_index) for row_index in range(1, sheet.max_row + 1))
                if cell.value is not None and str(cell.value).strip()
            ]
            if populated:
                coordinates = [cell.coordinate for cell in populated[:3]]
                violations.append(
                    f"[FMC4 非标准额外列] {sheet_name} 列{sheet.cell(1, column_index).column_letter} "
                    f"含非标准内容，示例单元格{coordinates}"
                )

        if enforce_manual_contract:
            for physical_row in sheet.iter_rows():
                for cell in physical_row:
                    if cell.value is None or not str(cell.value).strip():
                        continue
                    leak = quality_semantics.find_automation_implementation_leak(cell.value)
                    if leak:
                        label, matched = leak
                        violations.append(
                            f"[FMC4 子表自动化泄漏] {sheet_name}!{cell.coordinate} 命中{label}: {matched}"
                        )

        rows = tc_excel.read_sheet_rows(sheet)
        for row_index, row in enumerate(rows, 1):
            if not str(row.get("用例编号", "") or "").strip():
                violations.append(
                    f"[FMC4 子表空编号脏行] {sheet_name} 第{row_index}个有效数据行含内容但用例编号为空"
                )
        modules = {str(row.get("功能模块", "") or "").strip() for row in rows}
        modules.discard("")
        if len(modules) != 1:
            reason = "无用例行" if not rows else f"功能模块值不唯一: {sorted(modules)}"
            violations.append(f"[FMC4 多余或非法子表] {sheet_name}: {reason}")
            continue
        module = next(iter(modules))
        if module not in expected_by_module:
            violations.append(f"[FMC4 多余子表] {sheet_name} 模块「{module}」不在总表")
            continue
        if module in actual_by_module:
            previous = actual_by_module[module][0]
            violations.append(f"[FMC4 重复子表] 模块「{module}」同时存在于 {previous} / {sheet_name}")
            continue
        actual_by_module[module] = (sheet_name, rows)

    for module, expected_rows in expected_by_module.items():
        if module not in actual_by_module:
            violations.append(f"[FMC4 缺少子表] 总表模块「{module or '<空>'}」缺对应模块sheet")
            continue
        sheet_name, actual_rows = actual_by_module[module]
        identified_rows = [row for row in actual_rows if str(row.get("用例编号", "") or "").strip()]
        if len(actual_rows) != len(expected_rows) or len(identified_rows) != len(expected_rows):
            violations.append(
                f"[FMC4 子表行数不一致] {sheet_name}/{module} 总表{len(expected_rows)}行 / "
                f"子表{len(actual_rows)}个非空行（其中{len(identified_rows)}行有用例编号）"
            )
            continue
        actual_rows = identified_rows
        for row_index, (expected, actual) in enumerate(zip(expected_rows, actual_rows), 1):
            for column in tc_excel.COLUMNS:
                expected_value = str(expected.get(column, "") or "")
                actual_value = str(actual.get(column, "") or "")
                if actual_value != expected_value:
                    violations.append(
                        f"[FMC4 子表字段不一致] {sheet_name}/{module} 第{row_index}行 {column}: "
                        f"总表={expected_value!r} / 子表={actual_value!r}"
                    )
    return violations


def _excel_format_cfg(quality_gates) -> dict:
    return (quality_gates or {}).get("excel_format", {}) or {}


def check_precondition_numbering(rows: list[dict], ecfg: dict) -> list[str]:
    """S16 前置条件必须编号,且每个编号只写一个前置。"""
    if not ecfg.get("require_precondition_numbering"):
        return []
    v: list[str] = []
    for r in rows:
        cid = r.get("用例编号", "")
        pre = str(r.get("前置条件", "") or "")
        if not pre.strip():
            continue
        nums, unnum = _numbered_lines(pre)
        if not nums:
            v.append(f"[S16 前置条件未编号] {cid} 前置条件需逐条编号(1. ...)")
            continue
        if unnum:
            v.append(f"[S16 前置条件存在未编号行] {cid}: {unnum[0][:30]}")
        for line in _content_lines(pre):
            content = NUMBERED_LINE_RE.sub("", line)
            if PRECOND_CONNECTOR_RE.search(content):
                v.append(f"[S16 前置条件非原子] {cid} 一个编号只写一个前置: {line[:40]}")
                break
    return v


def check_precondition_completeness(rows: list[dict], ecfg: dict) -> list[str]:
    """项目可选门禁：命中指定状态词的用例必须填写独有前置条件。

    配置示例：
    excel_format.require_precondition_for_keywords = ["传输中", "写入阶段", "APP后台"]
    可选 exclude_case_ids 用于极少数动作自身已完整建立状态的豁免。
    """
    keywords = [str(x) for x in _as_list(ecfg.get("require_precondition_for_keywords")) if str(x)]
    if not keywords:
        return []
    exclude = {str(x) for x in _as_list(ecfg.get("precondition_exclude_case_ids"))}
    v: list[str] = []
    for r in rows:
        cid = str(r.get("用例编号", ""))
        if cid in exclude:
            continue
        text = " ".join(str(r.get(k, "") or "") for k in ("功能点", "测试项", "测试点/检查项", "操作步骤"))
        hits = [kw for kw in keywords if kw in text]
        if hits and not str(r.get("前置条件", "") or "").strip():
            v.append(f"[S16 前置条件缺失] {cid} 命中会改变执行路径的状态 {hits[:3]}，需填写独有前置")
    return v


def check_test_point_quality(rows: list[dict], ecfg: dict) -> list[str]:
    """S17 测试点以「验证」开头 / S18 测试点长度 / S19 测试点非空泛、不与测试项重复。"""
    v: list[str] = []
    need_verify = bool(ecfg.get("require_test_point_verify_prefix"))
    max_len = ecfg.get("test_point_max_length", TEST_POINT_MAX_DEFAULT) if "test_point_max_length" in ecfg else None
    for r in rows:
        cid = r.get("用例编号", "")
        tp = str(r.get("测试点/检查项", "") or "").strip()
        ti = str(r.get("测试项", "") or "").strip()
        if not tp:
            continue
        if need_verify and not tp.startswith("验证"):
            v.append(f"[S17 测试点未以验证开头] {cid}: {tp[:30]}")
        if isinstance(max_len, int) and max_len > 0 and len(tp) > max_len:
            v.append(f"[S18 测试点过长] {cid} 长度{len(tp)}>{max_len}: {tp[:20]}…")
        if tp == ti:
            v.append(f"[S19 测试点与测试项重复] {cid} 测试点不得等同测试项: {tp[:20]}")
        elif need_verify and tp.startswith("验证") and len(tp[2:].strip()) < 4:
            v.append(f"[S19 测试点空泛] {cid} 仅名词短语,缺可验证内容: {tp[:20]}")
    return v


def check_merge_hierarchy(xlsx: Path, rows: list[dict], ecfg: dict) -> list[str]:
    """S20 层级单元格(功能模块/功能点/测试项)相邻相同需合并 + S21 读取回填不为空。"""
    if not ecfg.get("merge_hierarchy_cells"):
        return []
    v: list[str] = []
    wb = openpyxl.load_workbook(xlsx, data_only=True)
    sheet = tc_excel.MASTER_SHEET if tc_excel.MASTER_SHEET in wb.sheetnames else wb.sheetnames[0]
    ws = wb[sheet]
    header = {c.value: i for i, c in enumerate(ws[1], 1)}
    vmember: dict[tuple[int, int], bool] = {}
    for rng in ws.merged_cells.ranges:
        if rng.max_row > rng.min_row:
            for rr in range(rng.min_row, rng.max_row + 1):
                for cc in range(rng.min_col, rng.max_col + 1):
                    vmember[(rr, cc)] = True
    hierarchy_indices = {
        "功能模块": header.get("功能模块"),
        "功能点": header.get("功能点"),
        "测试项": header.get("测试项"),
    }

    def effective_value(row_index: int, col_index: int | None):
        if not col_index:
            return None
        raw_value = ws.cell(row_index, col_index).value
        if raw_value is not None:
            return raw_value
        for merged_range in ws.merged_cells.ranges:
            if (
                merged_range.min_row <= row_index <= merged_range.max_row
                and merged_range.min_col <= col_index <= merged_range.max_col
            ):
                return ws.cell(merged_range.min_row, merged_range.min_col).value
        return None

    parent_names = {
        "功能模块": [],
        "功能点": ["功能模块"],
        "测试项": ["功能模块", "功能点"],
    }
    for colname in HIER_COLS:
        ci = header.get(colname)
        if not ci:
            continue
        eff_prev = None
        for rr in range(2, ws.max_row + 1):
            raw = ws.cell(rr, ci).value
            is_member = vmember.get((rr, ci), False)
            same_parent = all(
                str(effective_value(rr, hierarchy_indices.get(parent)))
                == str(effective_value(rr - 1, hierarchy_indices.get(parent)))
                for parent in parent_names.get(colname, [])
            )
            if (
                raw is not None and eff_prev is not None and str(raw) == str(eff_prev)
                and same_parent and not is_member
            ):
                v.append(f"[S20 层级未合并] 列「{colname}」第{rr}行与上一行同值未合并: {raw}")
            eff = raw if raw is not None else (eff_prev if is_member else raw)
            if eff is not None:
                eff_prev = eff
    # S21 读取回填: read_master_rows 后层级列必须 forward-fill,不为空
    for r in rows:
        for colname in HIER_COLS:
            if not str(r.get(colname, "") or "").strip():
                v.append(f"[S21 合并读取未回填] {r.get('用例编号','')} 列「{colname}」为空,读取脚本需forward-fill合并区")
                break
    return v


def check_migration(xlsx: Path, rows: list[dict], ecfg: dict) -> list[str]:
    """S22 用例迁移一致性检查(轻量级):存在用例编号迁移文件时,检查迁移文件可解析、
    迁移目标存在于当前用例、迁移目标不重复。属结构与追踪一致性检查,
    不做"测试点/操作步骤/预期结果"语义一致性判断,不替代人工语义复核。"""
    if not ecfg.get("check_migration", True):
        return []
    fname = ecfg.get("migration_file", "用例编号迁移.json")
    mpath = Path(xlsx).parent / fname
    if not mpath.exists():
        return []
    v: list[str] = []
    try:
        mig = json.loads(mpath.read_text(encoding="utf-8"))
    except Exception as e:  # noqa: BLE001
        return [f"[S22 迁移文件无法解析] {fname}: {e}"]
    ids = {str(r.get("用例编号", "")) for r in rows}
    if not isinstance(mig, dict):
        return [f"[S22 迁移文件格式异常] {fname} 顶层应为对象"]

    targets: list[str] = []
    if mig.get("schema_version") == 2:
        items = mig.get("items")
        if not isinstance(items, list):
            return [f"[S22 迁移文件格式异常] {fname} schema v2 必须包含 items 数组"]
        seen_stable: set[str] = set()
        old_owners: dict[str, str] = {}
        if "retired_items" not in mig:
            v.append(f"[S22 迁移文件格式异常] {fname} schema v2 必须包含 retired_items 数组")
        retired_items = mig.get("retired_items", [])
        if not isinstance(retired_items, list):
            v.append(f"[S22 迁移文件格式异常] {fname} retired_items 必须是数组")
            retired_items = []
        for index, item in enumerate(retired_items, 1):
            if not isinstance(item, dict):
                v.append(f"[S22 迁移文件格式异常] retired_items[{index}] 必须是对象")
                continue
            stable_id = str(item.get("stable_id", "") or "").strip()
            case_id = str(item.get("case_id", "") or "").strip()
            if not stable_id or not case_id:
                v.append(
                    f"[S22 迁移文件格式异常] retired_items[{index}] "
                    "必须包含 stable_id/case_id"
                )
                continue
            if stable_id in seen_stable:
                v.append(f"[S22 stable_id重复] {stable_id} 出现多条迁移/退休记录")
            seen_stable.add(stable_id)
            owner = old_owners.get(case_id)
            location = f"retired_items[{index}]/{stable_id}"
            if owner is not None:
                v.append(f"[S22 旧编号歧义] {case_id} 同时出现在 {owner} 与 {location}")
            else:
                old_owners[case_id] = location
            if case_id in ids:
                v.append(f"[S22 退休编号被复用] {case_id} 同时出现在当前用例编号集合")
        for index, item in enumerate(items, 1):
            if not isinstance(item, dict):
                v.append(f"[S22 迁移文件格式异常] items[{index}] 必须是对象")
                continue
            stable_id = str(item.get("stable_id", "") or "").strip()
            target = str(item.get("new_case_id", "") or "").strip()
            old_ids = item.get("old_case_ids")
            if not stable_id or not target or not isinstance(old_ids, list):
                v.append(
                    f"[S22 迁移文件格式异常] items[{index}] 必须包含 "
                    "stable_id/old_case_ids[]/new_case_id"
                )
                continue
            if stable_id in seen_stable:
                v.append(f"[S22 stable_id重复] {stable_id} 出现多条迁移/退休记录")
            seen_stable.add(stable_id)
            targets.append(target)
            if target not in ids:
                v.append(
                    f"[S22 迁移目标缺失] {stable_id}->{target} "
                    "不在当前用例编号集合,迁移可能失配"
                )
            for old_value in old_ids:
                old_id = str(old_value or "").strip()
                if not old_id:
                    v.append(f"[S22 旧编号为空] {stable_id} 包含空 old_case_id")
                    continue
                owner = old_owners.get(old_id)
                location = f"items[{index}]/{stable_id}"
                if owner is not None:
                    v.append(
                        f"[S22 旧编号歧义] {old_id} 同时出现在 {owner} 与 {location}"
                    )
                else:
                    old_owners[old_id] = location
    else:
        # Legacy projects may retain the historical old->new mapping. New
        # exports always emit schema v2 records bound by stable_id.
        targets = [str(x) for x in mig.values()]
        for key, value in mig.items():
            if str(value) not in ids:
                v.append(
                    f"[S22 迁移目标缺失] {key}->{value} "
                    "不在当前用例编号集合,迁移可能失配"
                )
    seen, dup = set(), set()
    for t in targets:
        if t in seen:
            dup.add(t)
        seen.add(t)
    for t in sorted(dup):
        v.append(f"[S22 迁移目标重复] {t} 被多个原始编号映射,重排迁移可能错配")
    return v


def check_test_item_exception_objects(rows: list[dict], quality_gates: dict) -> list[str]:
    """S23 测试项不得承载具体异常对象(低电/GPS丢失/传输断开/地磁干扰/下载失败...),
    应泛化为 异常测试/中断测试/恢复测试/限制测试, 对象下沉到测试点/前置/步骤/预期。
    配置: quality_gates.test_item_exception_objects = true(默认对象表) 或 [自定义对象...]。"""
    cfg = (quality_gates or {}).get("test_item_exception_objects")
    if not cfg:
        return []
    objs = cfg if isinstance(cfg, list) else DEFAULT_EXC_OBJECTS
    v: list[str] = []
    for r in rows:
        ti = str(r.get("测试项", "") or "")
        hit = [o for o in objs if o in ti]
        if hit:
            v.append(f"[S23 测试项含具体异常对象] {r.get('用例编号','')} 测试项「{ti}」含{hit},应泛化为 {GENERIC_EXC_ITEMS},对象下沉到测试点/前置/步骤/预期")
    return v


def check_cross_scene(rows: list[dict], quality_gates: dict) -> list[str]:
    """S24 交叉场景污染: 功能点=交叉场景 的测试项不得含"交叉"二字, 不得是普通流程/模块自身异常,
    应为外部能力/系统状态对象。配置: quality_gates.cross_scene = {allowed_cross_items, forbidden_cross_keywords}。"""
    cfg = (quality_gates or {}).get("cross_scene")
    if not cfg:
        return []
    cfg = cfg if isinstance(cfg, dict) else {}
    forbidden = [str(x) for x in _as_list(cfg.get("forbidden_cross_keywords", DEFAULT_FORBIDDEN_CROSS)) if str(x)]
    allowed = [str(x) for x in _as_list(cfg.get("allowed_cross_items")) if str(x)]
    v: list[str] = []
    for r in rows:
        fp = str(r.get("功能点", "") or "")
        if fp not in CROSS_FP_ALIASES or fp == "冲突场景":
            continue
        ti = str(r.get("测试项", "") or "")
        cid = r.get("用例编号", "")
        if "交叉" in ti:
            v.append(f"[S24 交叉测试项命名含交叉] {cid} 交叉场景测试项「{ti}」应写交叉对象, 不含交叉二字")
        fb = [k for k in forbidden if k in ti]
        if fb:
            v.append(f"[S24 交叉场景污染] {cid} 测试项「{ti}」含普通流程/自身异常关键词{fb},应移出交叉场景")
        if allowed and not any(a in ti for a in allowed):
            v.append(f"[S24 非外部交叉对象] {cid} 测试项「{ti}」不在允许的外部交叉对象白名单{allowed}")
    return v


def check_common_fixtures(rows: list[dict], quality_gates: dict) -> list[str]:
    """S25 公共前置高频重复: 项目级环境(App版本/已连接/已登录/固件版本)应进 common_fixtures,
    不应每条用例重复写。配置: quality_gates.common_fixtures = {phrases:[...], max_repeat_ratio|max_repeat_count}。"""
    cfg = (quality_gates or {}).get("common_fixtures")
    if not cfg or not isinstance(cfg, dict):
        return []
    phrases = [str(x) for x in _as_list(cfg.get("phrases")) if str(x)]
    # 内部 fixture 语法永远不允许进入人工功能用例；phrases=[] 不能关闭检测。
    internal_hits = [
        str(r.get("用例编号", "") or "<无编号>")
        for r in rows
        if quality_semantics.FIXTURE_REF_RE.search(str(r.get("前置条件", "") or ""))
    ]
    v: list[str] = []
    if internal_hits:
        v.append(
            f"[S25 人工用例内部fixture泄漏] {len(internal_hits)}条用例包含内部公共前置引用，"
            f"示例{internal_hits[:10]}"
        )
    if not phrases:
        return v
    total = len(rows) or 1
    max_ratio = cfg.get("max_repeat_ratio")
    max_count = cfg.get("max_repeat_count")
    for p in phrases:
        cnt = sum(1 for r in rows if p in str(r.get("前置条件", "") or ""))
        ratio = cnt / total
        bad = False
        if isinstance(max_count, (int, float)) and cnt > max_count:
            bad = True
        if isinstance(max_ratio, (int, float)) and ratio > max_ratio:
            bad = True
        if max_count is None and max_ratio is None and ratio > 0.5:
            bad = True
        if bad:
            v.append(f"[S25 公共前置高频重复] 前置「{p}」在 {cnt}/{total}({ratio*100:.0f}%) 条用例重复,应移入 common_fixtures/测试环境说明")
    return v


def check_navigation_expectations(rows: list[dict], quality_gates: dict) -> list[str]:
    """S26 跳转类操作预期须观察目标页。配置: quality_gates.navigation_expectations =
    [{module, source_feature_point, step_keywords, expected_keywords}]。"""
    cfg = (quality_gates or {}).get("navigation_expectations")
    if not cfg:
        return []
    v: list[str] = []
    for rule in _as_list(cfg):
        if not isinstance(rule, dict):
            continue
        module = rule.get("module")
        sfp = rule.get("source_feature_point")
        sk = [str(x) for x in _as_list(rule.get("step_keywords")) if str(x)]
        ek = [str(x) for x in _as_list(rule.get("expected_keywords")) if str(x)]
        if not sk or not ek:
            continue
        for r in rows:
            if module and str(r.get("功能模块", "")) != module:
                continue
            if sfp and str(r.get("功能点", "")) != sfp:
                continue
            steps = str(r.get("操作步骤", "") or "")
            exp = str(r.get("预期结果", "") or "")
            if any(k in steps for k in sk) and not any(k in exp for k in ek):
                v.append(f"[S26 跳转预期未观察目标页] {r.get('用例编号','')} 步骤含{[k for k in sk if k in steps]} 但预期未出现目标页关键词{ek}")
    return v


def check_blueprint(quality_gates: dict, xlsx: Path) -> list[str]:
    """S27 用例设计蓝图存在性。配置: quality_gates.blueprint = {required:true, files:[...], required_keys:[...]}。
    检查蓝图文件存在且含 9 个字段(module_boundary/feature_order/.../unsupported_features)。"""
    cfg = (quality_gates or {}).get("blueprint")
    if not cfg or not isinstance(cfg, dict) or not cfg.get("required"):
        return []
    files = [str(x) for x in _as_list(cfg.get("files", ["运行记录.md", "工作底稿/用例设计蓝图.json"])) if str(x)]
    keys = [str(x) for x in _as_list(cfg.get("required_keys", BLUEPRINT_KEYS)) if str(x)]
    base = Path(xlsx).parent
    found = None
    for f in files:
        p = base / f
        if p.exists():
            found = p
            break
    if not found:
        return [f"[S27 蓝图缺失] 未找到用例设计蓝图文件之一: {files}"]
    text = found.read_text(encoding="utf-8", errors="ignore")
    missing = [k for k in keys if k not in text]
    if missing:
        return [f"[S27 蓝图字段缺失] {found.name} 缺少蓝图字段 {missing}"]
    return []


def check_ui_operation_order(rows: list[dict], quality_gates: dict) -> list[str]:
    """S28 界面操作就近排序: 测试项=界面操作 的用例必须排在对应页面/状态可达之后,
    不得堆在功能点开头、不得在"进入/展示/到达该页面"的用例之前。
    配置: quality_gates.ui_operation_order = {enabled, strict_coverage, pages:[{module,page,feature_point,anchor_keywords,ui_keywords}]};
    strict_coverage=true 时,每条界面操作必须恰好命中一个完整页面配置；漏配、多配和配置缺字段均阻断。
    若未配置, 仅对 page_input_matrix 中显式带 anchor_keywords/ui_keywords 的页面项启用(默认不影响旧项目)。
    锚点: 配 anchor_keywords 时前序同功能点非界面操作用例须命中之; 未配时前序须存在至少一条同功能点非界面操作用例。"""
    if not quality_gates:
        return []
    page_entries: list[dict] = []
    cfg = quality_gates.get("ui_operation_order")
    strict_coverage = bool(
        isinstance(cfg, dict)
        and cfg.get("enabled", True)
        and cfg.get("strict_coverage", False)
    )
    v: list[str] = []
    if strict_coverage:
        raw_pages = cfg.get("pages")
        if not isinstance(raw_pages, list) or not raw_pages:
            v.append("[S28 严格覆盖配置缺失] ui_operation_order.pages 必须配置至少一个页面")
        else:
            for index, page_cfg in enumerate(raw_pages, 1):
                if not isinstance(page_cfg, dict):
                    v.append(f"[S28 严格覆盖配置错误] ui_operation_order.pages[{index}] 必须是对象")
                    continue
                missing: list[str] = []
                for field in ("module", "page", "feature_point"):
                    if not str(page_cfg.get(field, "") or "").strip():
                        missing.append(field)
                for field in ("ui_keywords", "anchor_keywords"):
                    values = [str(x).strip() for x in _as_list(page_cfg.get(field)) if str(x).strip()]
                    if not values:
                        missing.append(field)
                if missing:
                    v.append(
                        f"[S28 严格覆盖配置不完整] ui_operation_order.pages[{index}] 缺少 {missing}"
                    )
                    continue
                page_entries.append(dict(page_cfg))

        ui_rows = [
            (row_index, row) for row_index, row in enumerate(rows)
            if str(row.get("测试项", "")).strip() == "界面操作"
        ]
        for row_index, row in ui_rows:
            module = str(row.get("功能模块", "") or "").strip()
            fp = str(row.get("功能点", "") or "").strip()
            cid = str(row.get("用例编号", "") or "")
            row_text = _row_text(row)
            matches = [
                entry for entry in page_entries
                if str(entry.get("module", "") or "").strip() == module
                and str(entry.get("feature_point", "") or "").strip() == fp
                and _hit_any(row_text, [
                    str(x).strip() for x in _as_list(entry.get("ui_keywords")) if str(x).strip()
                ])
            ]
            if not matches:
                v.append(
                    f"[S28 严格覆盖漏配] {cid} {module}/{fp} 界面操作未命中任何pages配置"
                )
                continue
            if len(matches) > 1:
                pages = [str(entry.get("page", "")) for entry in matches]
                v.append(
                    f"[S28 严格覆盖多重配置] {cid} {module}/{fp} 同时命中页面 {pages}"
                )
                continue

            matched = matches[0]
            prior = [
                prior_row for prior_row in rows[:row_index]
                if str(prior_row.get("功能模块", "") or "").strip() == module
                and str(prior_row.get("功能点", "") or "").strip() == fp
                and str(prior_row.get("测试项", "") or "").strip() != "界面操作"
            ]
            anchor_kw = [
                str(x).strip() for x in _as_list(matched.get("anchor_keywords")) if str(x).strip()
            ]
            if not any(_hit_any(_row_text(prior_row), anchor_kw) for prior_row in prior):
                v.append(
                    f"[S28 界面操作缺少前序页面锚点] {cid} {module}/{fp}/{matched.get('page', '')} "
                    "界面操作排在页面可达前"
                )
        return v

    if isinstance(cfg, dict) and cfg.get("enabled", True):
        for p in _as_list(cfg.get("pages")):
            if isinstance(p, dict) and p.get("page"):
                page_entries.append(dict(p))
    if not page_entries:
        pim = quality_gates.get("page_input_matrix")
        entries: list[dict] = []
        if isinstance(pim, dict):
            for module, pages in pim.items():
                for p in _as_list(pages):
                    if isinstance(p, dict):
                        q = dict(p)
                        q.setdefault("module", module)
                        entries.append(q)
        elif isinstance(pim, list):
            for p in pim:
                if isinstance(p, dict):
                    entries.append(dict(p))
        page_entries = [e for e in entries if e.get("anchor_keywords") or e.get("ui_keywords")]
    if not page_entries:
        return []
    by_mod = _rows_by_module(rows)
    for c in page_entries:
        module = str(c.get("module", ""))
        page = str(c.get("page", c.get("feature_point", "")))
        fp = str(c.get("feature_point", c.get("fp", page)))
        if not page or not fp:
            continue
        anchor_kw = [str(x) for x in _as_list(c.get("anchor_keywords")) if str(x)]
        ui_kw = [str(x) for x in _as_list(c.get("ui_keywords")) if str(x)] or [page]
        mrows = by_mod.get(module, []) if module else rows
        for i, r in enumerate(mrows):
            if str(r.get("功能点", "")).strip() != fp:
                continue
            if str(r.get("测试项", "")).strip() != "界面操作":
                continue
            if not _hit_any(_row_text(r), ui_kw):
                continue
            cid = str(r.get("用例编号", ""))
            prior = [pr for pr in mrows[:i]
                     if str(pr.get("功能点", "")).strip() == fp and str(pr.get("测试项", "")).strip() != "界面操作"]
            if anchor_kw:
                ok = any(_hit_any(_row_text(pr), anchor_kw) for pr in prior)
            else:
                ok = len(prior) > 0
            if not ok:
                v.append(f"[S28 界面操作缺少前序页面锚点] {cid} {module}/{fp}/{page} 界面操作排在页面可达前")
    return v


def check_semantic_gates(
    rows: list[dict], quality_gates: dict, xlsx: Path, config_modules: list[dict] | None = None
) -> list[str]:
    """语义门禁(S23-S35)。"""
    if not quality_gates:
        return []
    v: list[str] = []
    v.extend(check_test_item_exception_objects(rows, quality_gates))
    v.extend(check_cross_scene(rows, quality_gates))
    v.extend(check_common_fixtures(rows, quality_gates))
    v.extend(check_navigation_expectations(rows, quality_gates))
    v.extend(check_blueprint(quality_gates, xlsx))
    v.extend(check_ui_operation_order(rows, quality_gates))
    v.extend(quality_semantics.check_production_semantics(rows, quality_gates))
    v.extend(quality_semantics.check_conflict_matrix(rows, quality_gates, xlsx))
    v.extend(quality_semantics.check_scenario_coverage(rows, quality_gates, xlsx, config_modules))
    v.extend(delivery_quality.check_quality(rows, quality_gates, xlsx))
    return v


def check_excel_format(xlsx: Path, rows: list[dict], quality_gates: dict) -> list[str]:
    """执行体验门禁(S16-S22),仅在 quality_gates.excel_format 配置后启用。"""
    ecfg = _excel_format_cfg(quality_gates)
    if not ecfg:
        return []
    v: list[str] = []
    v.extend(check_precondition_numbering(rows, ecfg))
    v.extend(check_precondition_completeness(rows, ecfg))
    v.extend(check_test_point_quality(rows, ecfg))
    v.extend(check_merge_hierarchy(xlsx, rows, ecfg))
    v.extend(check_migration(xlsx, rows, ecfg))
    return v


def main():
    ap = argparse.ArgumentParser(description="结构/充分性检查器(门禁C)")
    ap.add_argument("--xlsx")
    ap.add_argument("--config")
    args = ap.parse_args()
    quality_gates = {}
    config_modules: list[dict] = []
    enforce_manual_contract = True
    contiguous_exceptions: object = None
    if args.config:
        sys.path.insert(0, str(_SCRIPTS / "traceability"))
        from _common import load_config
        cfg = load_config(args.config)
        xlsx = cfg.cases_xlsx
        quality_gates = cfg.quality_gates
        config_modules = cfg.modules
        manual_profile = quality_gates.get("functional_manual_contract", {}) \
            if isinstance(quality_gates, dict) else {}
        manual_profile_required = isinstance(manual_profile, dict) \
            and manual_profile.get("required") is True
        contract_schema = 0
        contract_cfg = cfg.raw.get("generation_contract", {}) or {}
        contract_path = cfg._resolve(contract_cfg.get("file", "生成验收合同.json"))
        if contract_path.exists():
            try:
                contract_payload = json.loads(contract_path.read_text(encoding="utf-8"))
                contract_schema = int(contract_payload.get("schema_version", 0) or 0) \
                    if isinstance(contract_payload, dict) else 0
            except (OSError, ValueError, json.JSONDecodeError):
                contract_schema = 0
        # New projects and explicitly migrated legacy projects are strict.
        # Schema-v1 projects keep their historical mixed manual/specialty contract.
        enforce_manual_contract = manual_profile_required or contract_schema >= 3
        contiguous_cfg = quality_gates.get("hierarchy_contiguous_block", {}) \
            if isinstance(quality_gates, dict) else {}
        if isinstance(contiguous_cfg, dict) and contiguous_cfg.get("required") is True:
            exceptions_file = str(contiguous_cfg.get("exceptions_file", "用例设计蓝图.json") or "用例设计蓝图.json")
            exceptions_key = str(contiguous_cfg.get("exceptions_key", "continuous_block_exceptions") or "continuous_block_exceptions")
            if exceptions_file != "用例设计蓝图.json" or exceptions_key != "continuous_block_exceptions":
                raise SystemExit("S36 例外只能来自 用例设计蓝图.json#continuous_block_exceptions")
            exceptions_path = cfg._resolve("用例设计蓝图.json")
            if exceptions_path.exists():
                try:
                    payload = json.loads(exceptions_path.read_text(encoding="utf-8"))
                    contiguous_exceptions = payload.get(exceptions_key, []) if isinstance(payload, dict) else []
                except (OSError, json.JSONDecodeError) as exc:
                    contiguous_exceptions = [{"invalid": str(exc)}]
    elif args.xlsx:
        xlsx = Path(args.xlsx)
    else:
        raise SystemExit("需 --xlsx 或 --config")

    xlsx = Path(xlsx)
    delivery_cfg = quality_gates.get("delivery_workbook", {}) \
        if isinstance(quality_gates, dict) else {}
    implicit_module = ""
    if len(config_modules) == 1 and isinstance(config_modules[0], dict):
        implicit_module = str(config_modules[0].get("name", "") or "")
    rows = delivery_quality.read_case_rows(xlsx, delivery_cfg, implicit_module) \
        if delivery_cfg else tc_excel.read_master_rows(xlsx)
    violations = check(
        rows,
        enforce_manual_contract=enforce_manual_contract,
        contiguous_exceptions=contiguous_exceptions,
    )
    violations.extend(check_workbook_mirror(
        xlsx,
        rows,
        enforce_manual_contract=enforce_manual_contract,
        require_module_sheets=not bool(
            _excel_format_cfg(quality_gates).get("single_sheet")
            or delivery_cfg.get("single_sheet")
        ),
        master_sheet=str(delivery_cfg.get("sheet_name", tc_excel.MASTER_SHEET)),
        allowed_auxiliary_sheets=list(
            delivery_cfg.get(
                "allowed_auxiliary_sheets",
                _excel_format_cfg(quality_gates).get("allowed_auxiliary_sheets", []),
            ) or []
        ),
        required_auxiliary_sheets=list(delivery_cfg.get("required_auxiliary_sheets", []) or []),
    ))
    violations.extend(check_confirm_styles(xlsx))
    violations.extend(check_quality_gates(rows, quality_gates, config_modules))
    violations.extend(check_excel_format(xlsx, rows, quality_gates))
    violations.extend(check_semantic_gates(rows, quality_gates, xlsx, config_modules))
    if violations:
        print(f"门禁C 结构检查: FAIL ❌  共 {len(violations)} 处违规")
        for v in violations:
            print("  " + v)
        sys.exit(1)
    print(f"门禁C 结构检查: PASS ✅  ({len(rows)} 条用例,无结构违规)")
    sys.exit(0)


if __name__ == "__main__":
    main()
