# -*- coding: utf-8 -*-
"""Regression tests for compact and standard testcase trace extraction."""
from __future__ import annotations

import json
import sys
import tempfile
from pathlib import Path

from openpyxl import Workbook


SCRIPTS = Path(__file__).resolve().parent
TRACEABILITY = SCRIPTS / "traceability"
for path in (SCRIPTS, TRACEABILITY):
    if str(path) not in sys.path:
        sys.path.insert(0, str(path))

import tc_excel  # noqa: E402
import trace_extract  # noqa: E402


COMPACT_HEADERS = [
    "用例编号", "功能点", "测试项", "测试点", "前置条件",
    "操作步骤", "预期结果", "实际结果", "优先级", "备注",
]
COMPACT_COLMAP = {
    "id": 0, "功能点": 1, "测试项": 2, "测试点": 3,
    "前置": 4, "步骤": 5, "预期": 6,
}


def write_compact(path: Path) -> None:
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "全功能测试用例"
    sheet.append(COMPACT_HEADERS)
    sheet.append([
        "MUSIC_001", "音乐首页", "页面展示", "验证音乐首页显示",
        "1.手表已进入应用列表", "1.进入音乐首页", "1.页面显示音乐入口", "", "P0", "",
    ])
    sheet.append([
        "MUSIC_002", "歌曲播放", "播放暂停", "验证点击播放",
        "1.手表内有可播放歌曲", "1.点击播放按钮", "1.歌曲开始播放", "", "P0", "",
    ])
    workbook.save(path)


def standard_row() -> dict:
    return {
        "用例编号": "REC_001", "功能模块": "录音", "功能点": "录音入口", "测试项": "入口路径",
        "测试点/检查项": "验证进入录音页面", "前置条件": "1.设备处于主界面",
        "操作步骤": "1.点击录音入口", "预期结果": "1.进入录音页面", "优先级": "P0",
        "兼容性": "N/A", "是否自动化": "否", "固件版本": "待测", "硬件型号": "待测",
        "测试方式": "人工执行", "备注": "",
    }


def main() -> None:
    results: list[dict] = []

    def check(name: str, passed: bool, details: object = None) -> None:
        results.append({"name": name, "passed": passed, "details": details})

    with tempfile.TemporaryDirectory(prefix="trace-extract-") as temp_dir:
        root = Path(temp_dir)
        compact = root / "compact.xlsx"
        write_compact(compact)
        loaded = trace_extract.load_cases(
            compact, [{"name": "本地音乐"}], COMPACT_COLMAP,
        )
        rows = loaded.get("本地音乐", [])
        check(
            "compact_single_module_uses_declared_implicit_module",
            len(rows) == 2 and all(row.get("功能模块") == "本地音乐" for row in rows)
            and rows[0].get("功能点") == "音乐首页",
            rows,
        )

        message = ""
        try:
            trace_extract.load_cases(
                compact, [{"name": "音乐首页"}, {"name": "歌曲播放"}], COMPACT_COLMAP,
            )
        except SystemExit as exc:
            message = str(exc)
        check(
            "compact_multi_module_without_routing_is_blocked",
            "缺少功能模块列" in message and "case_index_file" in message,
            message,
        )

        standard = root / "standard.xlsx"
        tc_excel.write_workbook([standard_row()], standard, ["录音"])
        standard_map = {
            "id": 1, "功能模块": 2, "功能点": 3, "测试项": 4,
            "测试点": 5, "前置": 6, "步骤": 7, "预期": 8,
        }
        loaded = trace_extract.load_cases(standard, [{"name": "录音"}], standard_map)
        check(
            "standard_module_sheet_behavior_is_preserved",
            len(loaded.get("录音", [])) == 1
            and loaded["录音"][0].get("id") == "REC_001"
            and loaded["录音"][0].get("功能模块") == "录音",
            loaded,
        )

    failures = [item for item in results if not item["passed"]]
    print(json.dumps({"success": not failures, "results": results, "errors": failures}, ensure_ascii=False, indent=2))
    raise SystemExit(0 if not failures else 1)


if __name__ == "__main__":
    main()
