# -*- coding: utf-8 -*-
"""Regression tests for the P0 personnel execution-quality gate."""
from __future__ import annotations

import copy
import hashlib
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parent
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import execution_quality_gate  # noqa: E402
import release_acceptance  # noqa: E402
import tc_excel  # noqa: E402


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def case(case_id: str, item: str, expected: str, *, feature: str = "录音") -> dict:
    return {
        "用例编号": case_id,
        "功能模块": "AI录音",
        "功能点": feature,
        "测试项": item,
        "测试点/检查项": f"验证{item}行为",
        "前置条件": "1.手表已开机并进入表盘",
        "操作步骤": f"1.进入录音页面并执行{item}操作",
        "预期结果": expected,
        "优先级": "P1",
        "兼容性": "N/A",
        "是否自动化": "否",
        "固件版本": "待测版本",
        "硬件型号": "待测型号",
        "测试方式": "人工执行",
        "备注": "",
    }


def gate_config() -> dict:
    return {
        "required": True,
        "review_file": "工作底稿/人员执行质量复核.json",
        "blueprint_file": "用例设计蓝图.json",
        "order_map_key": "execution_order",
        "module_boundary_key": "module_boundary",
        "require_boundary_rules": True,
        "wording_fields": ["测试项", "测试点/检查项", "前置条件", "操作步骤", "预期结果", "备注"],
        "forbidden_phrases": ["终态", "状态包", "本端", "对端"],
        "contextual_test_item_terms": ["APP端", "设备端", "Android", "iOS", "已连接", "未连接", "断连"],
    }


def review(workbook_hash: str, case_count: int, *, feature_count: int = 1) -> dict:
    return {
        "schema_version": 1,
        "input_xlsx_sha256": workbook_hash,
        "status": "PASS",
        "reviewer": "QA复核员",
        "dimensions": {
            "wording": {
                "status": "PASS", "reviewed_case_count": case_count,
                "evidence": "逐条确认步骤可执行且结果可观察", "findings": [],
            },
            "classification": {
                "status": "PASS", "reviewed_case_count": case_count,
                "evidence": "逐条核对四级层级和业务归属", "findings": [],
            },
            "order": {
                "status": "PASS", "reviewed_feature_point_count": feature_count,
                "evidence": "按录音真实生命周期核对测试项顺序", "findings": [],
            },
            "feature_boundary": {
                "status": "PASS", "reviewed_case_count": case_count,
                "evidence": "逐条确认最终断言归属录音业务结果", "findings": [],
            },
        },
        "accepted_automatic_findings": [],
    }


def write_project(root: Path, rows: list[dict]) -> tuple[Path, Path, Path]:
    workbook = root / "cases.xlsx"
    tc_excel.write_workbook(rows, workbook, ["AI录音"])
    blueprint = root / "用例设计蓝图.json"
    blueprint.write_text(json.dumps({
        "module_boundary": {
            "AI录音": {
                "scope": "验证录音入口、录制过程和录音文件结果",
                "owned_outcome_keywords": ["录音"],
                "foreign_feature_keywords": ["AI翻译", "音乐播放"],
            },
        },
        "execution_order": {"AI录音": {"录音": [row["测试项"] for row in rows]}},
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    config = root / "trace.config.json"
    config.write_text(json.dumps({
        "project": "execution-quality-regression",
        "cases_xlsx": "cases.xlsx",
        "modules": [{"name": "AI录音"}],
        "release_acceptance": {"execution_quality_required": True},
        "quality_gates": {
            "delivery_workbook": {"single_sheet": True},
            "execution_quality": gate_config(),
        },
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    review_path = root / "工作底稿" / "人员执行质量复核.json"
    review_path.parent.mkdir(parents=True, exist_ok=True)
    review_path.write_text(
        json.dumps(review(sha256(workbook), len(rows)), ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return config, workbook, review_path


def codes(report: dict) -> set[str]:
    return {str(row.get("code", "")) for row in report.get("issues", []) if isinstance(row, dict)}


def run_cli(config: Path, out: Path) -> subprocess.CompletedProcess[str]:
    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    return subprocess.run(
        [sys.executable, str(SCRIPTS / "execution_quality_gate.py"), "--config", str(config), "--out", str(out)],
        cwd=str(SCRIPTS.parent), env=env, text=True, capture_output=True,
        encoding="utf-8", errors="replace",
    )


def main() -> None:
    errors: list[str] = []
    results: list[dict] = []

    def check(name: str, passed: bool, detail: object = "") -> None:
        results.append({"name": name, "passed": passed, "detail": detail})
        if not passed:
            errors.append(f"{name}: {detail}")

    base_rows = [
        case("REC-001", "入口显示", "1.录音入口显示在应用列表中"),
        case("REC-002", "正常录音", "1.录音开始并持续记录声音"),
        case("REC-003", "异常恢复", "1.录音失败提示显示且可重新开始录音"),
    ]
    with tempfile.TemporaryDirectory(prefix="qa-execution-quality-") as temp_dir:
        root = Path(temp_dir)
        good_dir = root / "good"
        good_dir.mkdir()
        config, workbook, review_path = write_project(good_dir, base_rows)

        good = execution_quality_gate.evaluate(config)
        check("complete_manual_review_passes", good.get("status") == "PASS", good)

        report_out = good_dir / "工作底稿" / "人员执行质量检查报告.json"
        cli = run_cli(config, report_out)
        check(
            "cli_writes_canonical_report",
            cli.returncode == 0 and report_out.is_file()
            and json.loads(report_out.read_text(encoding="utf-8")).get("status") == "PASS",
            cli.stdout + cli.stderr,
        )

        stale_review = json.loads(review_path.read_text(encoding="utf-8"))
        stale_review["input_xlsx_sha256"] = "0" * 64
        review_path.write_text(json.dumps(stale_review, ensure_ascii=False), encoding="utf-8")
        stale = execution_quality_gate.evaluate(config)
        check("stale_excel_hash_blocks", "EXECUTION_QUALITY_REVIEW_HASH_STALE" in codes(stale), stale)
        review_path.write_text(json.dumps(review(sha256(workbook), len(base_rows)), ensure_ascii=False), encoding="utf-8")

        wording_dir = root / "wording"
        wording_dir.mkdir()
        wording_rows = copy.deepcopy(base_rows)
        wording_rows[1]["预期结果"] = "1.录音进入终态"
        wording_config, _, _ = write_project(wording_dir, wording_rows)
        wording = execution_quality_gate.evaluate(wording_config)
        check("forbidden_internal_wording_blocks", "EXECUTION_QUALITY_AUTOMATIC_VIOLATION" in codes(wording), wording)

        vague_dir = root / "vague"
        vague_dir.mkdir()
        vague_rows = copy.deepcopy(base_rows)
        vague_rows[1]["预期结果"] = "1.正常"
        vague_config, _, _ = write_project(vague_dir, vague_rows)
        vague = execution_quality_gate.evaluate(vague_config)
        check("vague_expected_result_blocks", "EXECUTION_QUALITY_AUTOMATIC_VIOLATION" in codes(vague), vague)

        class_dir = root / "classification"
        class_dir.mkdir()
        class_rows = copy.deepcopy(base_rows)
        class_rows[0]["测试项"] = "录音"
        class_config, _, _ = write_project(class_dir, class_rows)
        classification = execution_quality_gate.evaluate(class_config)
        check("same_meaning_hierarchy_blocks", "EXECUTION_QUALITY_AUTOMATIC_VIOLATION" in codes(classification), classification)

        order_dir = root / "order"
        order_dir.mkdir()
        order_config, _, _ = write_project(order_dir, base_rows)
        order_blueprint = json.loads((order_dir / "用例设计蓝图.json").read_text(encoding="utf-8"))
        order_blueprint["execution_order"]["AI录音"]["录音"] = ["正常录音", "入口显示", "异常恢复"]
        (order_dir / "用例设计蓝图.json").write_text(json.dumps(order_blueprint, ensure_ascii=False), encoding="utf-8")
        wrong_order = execution_quality_gate.evaluate(order_config)
        check("blueprint_order_mismatch_blocks", "EXECUTION_QUALITY_AUTOMATIC_VIOLATION" in codes(wrong_order), wrong_order)

        boundary_dir = root / "boundary"
        boundary_dir.mkdir()
        boundary_rows = copy.deepcopy(base_rows)
        boundary_rows[2]["预期结果"] = "1.AI翻译结果显示在翻译页面"
        boundary_config, _, boundary_review_path = write_project(boundary_dir, boundary_rows)
        boundary = execution_quality_gate.evaluate(boundary_config)
        check("boundary_candidate_requires_review", "EXECUTION_QUALITY_CANDIDATE_UNRESOLVED" in codes(boundary), boundary)
        candidate = next(row for row in boundary.get("automatic_findings", []) if row.get("kind") == "candidate")
        accepted = json.loads(boundary_review_path.read_text(encoding="utf-8"))
        accepted["accepted_automatic_findings"] = [{
            "finding_id": candidate["finding_id"],
            "reason": "本用例验证录音文件交给翻译入口前的传递结果，录音文件仍是主验收对象",
            "reviewer": "QA复核员",
        }]
        boundary_review_path.write_text(json.dumps(accepted, ensure_ascii=False), encoding="utf-8")
        accepted_report = execution_quality_gate.evaluate(boundary_config)
        check("reviewed_boundary_candidate_passes", accepted_report.get("status") == "PASS", accepted_report)

        missing_reviewer = copy.deepcopy(accepted)
        missing_reviewer["accepted_automatic_findings"][0].pop("reviewer")
        boundary_review_path.write_text(json.dumps(missing_reviewer, ensure_ascii=False), encoding="utf-8")
        missing_reviewer_report = execution_quality_gate.evaluate(boundary_config)
        check(
            "accepted_candidate_requires_reviewer",
            "EXECUTION_QUALITY_ACCEPTED_REASON_MISSING" in codes(missing_reviewer_report),
            missing_reviewer_report,
        )

        config_issues: list[dict] = []
        should_run = release_acceptance.validate_execution_quality_gate_config(
            json.loads(config.read_text(encoding="utf-8")), config_issues, required=True,
        )
        check("release_gate_profile_accepts_complete_config", should_run and not config_issues, config_issues)
        disabled = json.loads(config.read_text(encoding="utf-8"))
        disabled["release_acceptance"].pop("execution_quality_required")
        disabled_issues: list[dict] = []
        release_acceptance.validate_execution_quality_gate_config(disabled, disabled_issues, required=True)
        check(
            "release_gate_profile_cannot_be_disabled",
            any(row.get("code") == "EXECUTION_QUALITY_REQUIRED_CONFIG_MISSING" for row in disabled_issues),
            disabled_issues,
        )
        propagated: list[dict] = []
        release_acceptance.append_command_failure({
            "name": "execution_quality",
            "returncode": 1,
            "stdout": json.dumps({
                "issues": [{
                    "severity": "blocking",
                    "code": "EXECUTION_QUALITY_AUTOMATIC_VIOLATION",
                    "message": "REC-002 预期结果含内部术语",
                }],
            }, ensure_ascii=False),
        }, propagated)
        check(
            "release_manifest_exposes_execution_quality_finding",
            any(
                row.get("code") == "EXECUTION_QUALITY_AUTOMATIC_VIOLATION"
                and row.get("source_gate") == "execution_quality"
                for row in propagated
            ) and any(row.get("code") == "GATE_FAILED" for row in propagated),
            propagated,
        )

    report = {"status": "PASS" if not errors else "FAIL", "tests": results, "errors": errors}
    print(json.dumps(report, ensure_ascii=False, indent=2))
    raise SystemExit(0 if not errors else 1)


if __name__ == "__main__":
    main()
