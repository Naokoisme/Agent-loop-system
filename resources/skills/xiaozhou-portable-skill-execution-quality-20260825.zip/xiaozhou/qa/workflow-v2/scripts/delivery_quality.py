# -*- coding: utf-8 -*-
"""Config-driven testcase design and final-workbook quality checks.

The checks in this module deliberately avoid case-count quotas.  They validate
the evidence used to derive the scope, definite duplicate/composite cases, and
the physical workbook contract that a reviewer actually receives.
"""
from __future__ import annotations

import argparse
import json
import re
from collections import defaultdict
from pathlib import Path
from typing import Any

import openpyxl


FIELD_ALIASES = {"测试点": "测试点/检查项", "测试步骤": "操作步骤", "测试结果": "实际结果"}
DEFAULT_COMPLEXITY_DIMENSIONS = (
    "main_flows",
    "states_and_modes",
    "rules_and_boundaries",
    "exceptions_and_recovery",
    "cross_scenarios",
    "data_and_sync",
    "compatibility",
)
DEFAULT_FORBIDDEN_TEST_ITEMS = ("功能测试", "边界测试", "边界场景", "规则确认", "规则测试", "规则校验")
QUOTA_KEYS = {
    "target_count", "target_cases", "minimum_cases", "maximum_cases", "min_cases", "max_cases",
    "case_quota", "count_quota", "count_range", "case_count_range", "target_case_count_range",
    "目标条数", "最低条数", "最高条数",
}
QUOTA_TEXT_RE = re.compile(
    r"(?:(?:目标|控制|限制|至少|最低|最多|最高|不低于|不超过|必须达到|建议|参考)[^\n]{0,12}|约\s*)"
    r"\d+\s*(?:[-~～至到]\s*\d+)?\s*条(?:以内|之内)?|\d+\s*条(?:以内|之内)"
)
QUOTA_CONTEXT_RE = re.compile(r"(?:测试用例|用例|测试点|case|可读性|配额|凑数|压缩|条数|数量目标|规模目标)", re.I)
QUOTA_POLICY_PATH_RE = re.compile(
    r"(?:compression_policy|scale_policy|case_scale|case_count|count_quota|数量规划|用例规模|压缩策略)",
    re.I,
)
GROUPED_SCENARIO_RE = re.compile(
    r"(?:按以下|下列)(?:数据组|场景|组合)(?:分别)?|(?:分别执行|逐组执行)"
)
MULTI_SCENARIO_CUE_RE = re.compile(
    r"(?:分别(?:准备|写入|完成|处于|设置|触发|验证)|"
    r"(?:各|不同)(?:播放)?(?:状态|模式|方式|场景|条件|数量)|"
    r"依次(?:点击|执行|触发)[^\n]{0,40}(?:、|及|和))"
)
GROUP_BRANCH_RE = re.compile(r"(?:^|\n)\s*[A-ZＡ-Ｚ][\.、:：\)）]\s*", re.MULTILINE)
VERSION_RE = re.compile(r"(?i)(?<![a-z0-9])v\d+(?:\.\d+)+(?![a-z0-9])")
PUNCT_RE = re.compile(r"[\s\u3000，。；：、,.!！?？;:'\"“”‘’（）()\[\]【】<>《》_-]+")
NUMBERED_LINE_RE = re.compile(r"(?m)^\s*\d+[.、]\s*(.+?)\s*$")


def _as_list(value: Any) -> list[Any]:
    if value is None:
        return []
    return list(value) if isinstance(value, (list, tuple)) else [value]


def _sheet_and_headers(xlsx: Path, cfg: dict) -> tuple[Any, list[str], int]:
    workbook = openpyxl.load_workbook(xlsx, data_only=False)
    sheet_name = str(cfg.get("sheet_name", "全功能测试用例") or "全功能测试用例")
    if sheet_name not in workbook.sheetnames:
        sheet_name = workbook.sheetnames[0]
    sheet = workbook[sheet_name]
    header_row = int(cfg.get("header_row", 1) or 1)
    headers = [str(sheet.cell(header_row, column).value or "").strip() for column in range(1, sheet.max_column + 1)]
    while headers and not headers[-1]:
        headers.pop()
    return sheet, headers, header_row


def _merged_fill(sheet: Any) -> dict[tuple[int, int], Any]:
    fill: dict[tuple[int, int], Any] = {}
    for cell_range in sheet.merged_cells.ranges:
        value = sheet.cell(cell_range.min_row, cell_range.min_col).value
        for row in range(cell_range.min_row, cell_range.max_row + 1):
            for column in range(cell_range.min_col, cell_range.max_col + 1):
                fill[(row, column)] = value
    return fill


def read_case_rows(xlsx: str | Path, cfg: dict, default_module: str = "") -> list[dict]:
    """Read configured columns and forward-fill merged hierarchy cells."""
    xlsx = Path(xlsx)
    sheet, headers, header_row = _sheet_and_headers(xlsx, cfg)
    fill = _merged_fill(sheet)
    rows: list[dict] = []
    for row_index in range(header_row + 1, sheet.max_row + 1):
        raw = {
            header: fill.get((row_index, column), sheet.cell(row_index, column).value)
            for column, header in enumerate(headers, 1)
            if header
        }
        if not any(str(value or "").strip() for value in raw.values()):
            continue
        row = {FIELD_ALIASES.get(key, key): (value if value is not None else "") for key, value in raw.items()}
        if not str(row.get("功能模块", "") or "").strip():
            row["功能模块"] = default_module or str(cfg.get("implicit_module", "") or "")
        rows.append(row)
    return rows


def _normalized(value: Any) -> str:
    text = str(value or "").strip().casefold()
    if text.startswith("验证"):
        text = text[2:]
    return PUNCT_RE.sub("", text)


def _numbered_items(value: Any) -> list[str]:
    text = str(value or "").strip()
    matches = [item.strip() for item in NUMBERED_LINE_RE.findall(text) if item.strip()]
    return matches or ([text] if text else [])


def check_manual_case_style(rows: list[dict], cfg: Any) -> list[str]:
    """Keep manual steps action-focused and regression comparisons decidable.

    This gate intentionally has no step-count threshold.  It rejects only
    configured vague/redundant wording and incomplete regression contracts.
    """
    if not isinstance(cfg, dict) or cfg.get("enabled", True) is not True:
        return []

    allow_ids = {str(value) for value in _as_list(cfg.get("allow_case_ids"))}
    manual_only = cfg.get("manual_only", True) is True
    precondition_action_prefixes = [
        str(value) for value in _as_list(cfg.get("precondition_action_prefixes", [
            "点击", "输入", "扫描", "切换", "进入", "退出", "重启", "断电", "长按", "确认",
        ])) if str(value)
    ]
    observation_step_prefixes = [
        str(value) for value in _as_list(cfg.get("observation_step_prefixes", [
            "查看", "核对", "观察", "询问测试人员",
        ])) if str(value)
    ]
    regression_keywords = [
        str(value) for value in _as_list(cfg.get("regression_item_keywords", ["回归"]))
        if str(value)
    ]
    regression_markers = [
        str(value) for value in _as_list(cfg.get("regression_markers", ["基线", "上一正式版", "上一正式版本"]))
        if str(value)
    ]
    forbidden_steps = [
        str(value) for value in _as_list(cfg.get("forbidden_step_phrases", [
            "基线终点", "观察至基线", "对照基线", "批准的有限终点",
        ])) if str(value)
    ]
    forbidden_expected = [
        str(value) for value in _as_list(cfg.get("forbidden_expected_phrases", [
            "结果与基线一致", "与现网基线一致", "与权限基线一致", "与并发基线一致",
        ])) if str(value)
    ]
    redundant_observations = [
        str(value) for value in _as_list(cfg.get("redundant_observation_phrases", [
            "查看结果", "核对结果", "观察结果", "核对状态", "询问测试人员",
        ])) if str(value)
    ]
    source_keywords = [
        str(value) for value in _as_list(cfg.get("baseline_source_keywords", [
            "上一正式版", "上一正式版本", "人工执行说明", "产品批准", "负责人批准",
        ])) if str(value)
    ]
    source_locator_keywords = [
        str(value) for value in _as_list(cfg.get("baseline_locator_keywords", [
            "版本号", "构建号", "记录编号", "记录位置", "人工执行说明",
        ])) if str(value)
    ]
    shared_baseline_reference = str(cfg.get("shared_baseline_reference", "") or "").strip()
    object_keywords = [
        str(value) for value in _as_list(cfg.get("comparison_object_keywords", [
            "页面", "提示", "文案", "按钮", "列表", "绑定状态", "设备状态", "最终状态", "数据",
        ])) if str(value)
    ]
    require_explicit = cfg.get("require_explicit_comparison", True) is True

    violations: list[str] = []
    for row in rows:
        case_id = str(row.get("用例编号", "") or "<无编号>")
        if case_id in allow_ids:
            continue
        if manual_only:
            method = str(row.get("测试方式", "") or "").strip()
            automation = str(row.get("是否自动化", "") or "").strip()
            explicitly_automated = ("自动化" in method and "人工" not in method) or automation in {"是", "Y", "Yes", "YES"}
            if explicitly_automated:
                continue

        steps = str(row.get("操作步骤", "") or "")
        expected = str(row.get("预期结果", "") or "")
        preconditions = str(row.get("前置条件", "") or "")
        scope_text = "\n".join(str(row.get(field, "") or "") for field in ("测试项", "测试点/检查项"))

        for state in _numbered_items(preconditions):
            if any(state.startswith(prefix) for prefix in precondition_action_prefixes):
                violations.append(
                    f"[S35 前置混入操作] {case_id} 前置「{state}」应改为执行开始时已成立的状态"
                )
                break
        for phrase in forbidden_steps:
            if phrase in steps:
                violations.append(
                    f"[S35 回归步骤终点模糊] {case_id} 操作步骤包含「{phrase}」，应写实际动作并把明确结果放入预期"
                )
        for phrase in forbidden_expected:
            if phrase in expected:
                violations.append(
                    f"[S35 回归预期不可判定] {case_id} 预期结果包含「{phrase}」，应写具体比较对象和唯一判定"
                )

        numbered_steps = _numbered_items(steps)
        display_only = len(numbered_steps) == 1
        for index, action in enumerate(numbered_steps):
            explicit_redundant = next((phrase for phrase in redundant_observations if phrase in action), "")
            observation_prefix = next((prefix for prefix in observation_step_prefixes if action.startswith(prefix)), "")
            matched = explicit_redundant or observation_prefix
            if matched:
                if not explicit_redundant and index == 0 and display_only:
                    continue
                violations.append(
                    f"[S35 冗余观察步骤] {case_id} 步骤「{action}」属于观察而非业务动作，应写入同编号预期；纯显示类单步查看除外"
                )
                break

        full_text = "\n".join((scope_text, preconditions, steps, expected))
        is_regression = any(keyword in scope_text for keyword in regression_keywords) \
            or any(marker in full_text for marker in regression_markers)
        if not is_regression or not require_explicit:
            continue
        source_text = f"{preconditions}\n{expected}"
        has_source = not source_keywords or any(keyword in source_text for keyword in source_keywords)
        has_locator = bool(shared_baseline_reference) \
            or not source_locator_keywords \
            or any(keyword in source_text for keyword in source_locator_keywords) \
            or bool(VERSION_RE.search(source_text))
        if not has_source or not has_locator:
            violations.append(
                f"[S35 回归比较来源缺失] {case_id} 未定位到具体版本/构建或人工执行说明中的批准记录"
            )
        if object_keywords and not any(keyword in expected for keyword in object_keywords):
            violations.append(
                f"[S35 回归比较对象缺失] {case_id} 未在预期中写明页面、提示、状态或数据等具体比较对象"
            )
    return violations


def check_case_granularity(rows: list[dict], cfg: dict) -> list[str]:
    """Reject definite duplicate intent and A/B/C-style bundled scenarios."""
    if not cfg:
        return []
    violations: list[str] = []
    allow_grouped = {str(value) for value in _as_list(cfg.get("allow_grouped_case_ids"))}
    if cfg.get("forbid_grouped_scenarios", True):
        for row in rows:
            case_id = str(row.get("用例编号", "") or "")
            if case_id in allow_grouped:
                continue
            text = "\n".join(str(row.get(field, "") or "") for field in (
                "测试点/检查项", "前置条件", "操作步骤", "预期结果"
            ))
            if GROUPED_SCENARIO_RE.search(text) or MULTI_SCENARIO_CUE_RE.search(text) \
                    or len(GROUP_BRANCH_RE.findall(text)) >= 2:
                violations.append(
                    f"[S9 独立场景过度合并] {case_id or '<无编号>'} 使用数据组/A-B-C分支承载多个场景，应按独立前置、动作和预期拆例"
                )

    if cfg.get("detect_exact_duplicates", True):
        fields = [str(value) for value in _as_list(cfg.get("duplicate_fields")) if str(value)] or [
            "功能模块", "功能点", "测试项", "测试点/检查项", "前置条件", "操作步骤", "预期结果"
        ]
        seen: dict[tuple[str, ...], str] = {}
        for row in rows:
            fingerprint = tuple(_normalized(row.get(field, "")) for field in fields)
            if not any(fingerprint):
                continue
            case_id = str(row.get("用例编号", "") or "<无编号>")
            previous = seen.get(fingerprint)
            if previous is not None:
                violations.append(
                    f"[S29 重复拆分验证意图] {previous} 与 {case_id} 的层级、前置、步骤和预期等价，不得为增加条数重复拆例"
                )
            else:
                seen[fingerprint] = case_id
    return violations


def check_test_item_taxonomy(rows: list[dict], cfg: Any) -> list[str]:
    """Boundary/rule are methods, not visible business test-item names."""
    if not cfg:
        return []
    config = cfg if isinstance(cfg, dict) else {}
    forbidden = {
        _normalized(value)
        for value in _as_list(config.get("forbidden_generic_items", DEFAULT_FORBIDDEN_TEST_ITEMS))
        if str(value).strip()
    }
    allow_ids = {str(value) for value in _as_list(config.get("allow_case_ids"))}
    violations: list[str] = []
    for row in rows:
        case_id = str(row.get("用例编号", "") or "<无编号>")
        item = str(row.get("测试项", "") or "").strip()
        if case_id not in allow_ids and _normalized(item) in forbidden:
            violations.append(
                f"[S23 泛化边界/规则测试项] {case_id} 测试项「{item}」应改为实际业务测试项，边界值或待确认规则下沉到测试点和用例详情"
            )
    return violations


def check_cross_block(rows: list[dict], cfg: Any) -> list[str]:
    if not cfg:
        return []
    config = cfg if isinstance(cfg, dict) else {}
    names = {str(value) for value in _as_list(config.get("feature_points", ["交叉场景"]))}
    cross_items = {str(value) for value in _as_list(config.get("cross_items")) if str(value)}
    by_module: dict[str, list[dict]] = defaultdict(list)
    if str(config.get("scope", "module")) == "global":
        by_module["<全表>"].extend(rows)
    else:
        for row in rows:
            by_module[str(row.get("功能模块", "") or "")].append(row)
    violations: list[str] = []
    for module, module_rows in by_module.items():
        blocks = 0
        in_block = False
        last_cross_index = -1
        for row_index, row in enumerate(module_rows):
            is_cross = str(row.get("功能点", "") or "") in names
            if is_cross and not in_block:
                blocks += 1
            if is_cross:
                last_cross_index = row_index
            in_block = is_cross
        if blocks > 1:
            violations.append(
                f"[S5 交叉场景区块分散] {module or '<默认模块>'} 的交叉场景分成{blocks}段，应统一为主流程后的一个连续功能点区块"
            )
        if (config.get("require_last") or config.get("require_tail")) \
                and last_cross_index >= 0 and last_cross_index != len(module_rows) - 1:
            violations.append(
                f"[S7 交叉场景位置错误] {module or '<默认模块>'} 的交叉场景后仍有主流程用例，应将完整交叉区块统一放到主流程之后"
            )
        if cross_items:
            misplaced = [
                str(row.get("用例编号", "") or "<无编号>")
                for row in module_rows
                if str(row.get("测试项", "") or "") in cross_items
                and str(row.get("功能点", "") or "") not in names
            ]
            if misplaced:
                violations.append(
                    f"[S5 交叉对象散落主流程] {module or '<默认模块>'} 的交叉测试项未归入统一交叉场景功能点，示例 {misplaced[:10]}"
                )
        if config.get("require_present") and last_cross_index < 0:
            violations.append(
                f"[S5 交叉场景区块缺失] {module or '<默认模块>'} 已声明交叉场景必需，但未发现统一交叉场景功能点"
            )
    return violations


def _contains_quota(value: Any, path: str = "") -> list[str]:
    hits: list[str] = []
    if isinstance(value, dict):
        for key, nested in value.items():
            key_text = str(key)
            child_path = f"{path}.{key_text}" if path else key_text
            if key_text in QUOTA_KEYS:
                hits.append(child_path)
            hits.extend(_contains_quota(nested, child_path))
    elif isinstance(value, list):
        for index, nested in enumerate(value):
            hits.extend(_contains_quota(nested, f"{path}[{index}]"))
    elif isinstance(value, str) and QUOTA_TEXT_RE.search(value):
        # Do not confuse a business boundary such as "最多99条歌曲" with a
        # testcase-count target.  Free-form text is only a quota when its
        # wording or containing policy path is explicitly about case scale.
        if QUOTA_CONTEXT_RE.search(value) or QUOTA_POLICY_PATH_RE.search(path):
            hits.append(path or "<text>")
    return hits


def _dimension_has_evidence(value: Any) -> bool:
    if isinstance(value, list):
        return bool(value) and all(str(item or "").strip() for item in value)
    if isinstance(value, dict):
        status = str(value.get("status", "") or "").strip()
        if status == "not_applicable":
            return bool(str(value.get("reason", "") or "").strip())
        evidence = value.get("evidence", value.get("items"))
        return status in {"applicable", "covered"} and _dimension_has_evidence(evidence)
    return bool(str(value or "").strip())


def check_case_scale(rows: list[dict], cfg: dict, xlsx: Path) -> list[str]:
    """Require complexity evidence while explicitly rejecting numeric quotas."""
    if not cfg:
        return []
    required = bool(cfg.get("required", True))
    file_name = str(cfg.get("file", "用例设计蓝图.json") or "用例设计蓝图.json")
    path = Path(file_name)
    if not path.is_absolute():
        path = xlsx.parent / path
    if not path.is_file():
        return [f"[S27 用例规模依据缺失] 未找到复杂度蓝图: {path.name}"] if required else []
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return [f"[S27 用例规模依据不可读] {path.name}: {exc}"]
    profile_key = str(cfg.get("profile_key", "complexity_profile") or "complexity_profile")
    profiles = payload.get(profile_key) if isinstance(payload, dict) else None
    if not isinstance(profiles, dict):
        return [f"[S27 用例规模依据缺失] {path.name} 缺少对象字段 {profile_key}"]
    violations: list[str] = []
    quota_hits = _contains_quota(payload)
    if quota_hits:
        violations.append(
            f"[S27 固定条数配额] {path.name} 含条数目标或上下限 {quota_hits[:8]}；用例数量只能是复杂度分析结果"
        )
    dimensions = [str(value) for value in _as_list(cfg.get("required_dimensions", DEFAULT_COMPLEXITY_DIMENSIONS))]
    modules = sorted({str(row.get("功能模块", "") or "").strip() for row in rows})
    modules = [module for module in modules if module]
    for module in modules:
        profile = profiles.get(module)
        if not isinstance(profile, dict):
            violations.append(f"[S27 模块复杂度画像缺失] {module} 未在 {profile_key} 中说明需求复杂度")
            continue
        if not str(profile.get("rationale", "") or "").strip():
            violations.append(f"[S27 模块规模说明缺失] {module} 缺少 rationale，不能只用最终条数反推完整性")
        missing = [dimension for dimension in dimensions if not _dimension_has_evidence(profile.get(dimension))]
        if missing:
            violations.append(f"[S27 复杂度维度无证据] {module} 缺少 {missing}；不适用项也必须写原因")
    return violations


def check_hierarchy_mapping(rows: list[dict], cfg: dict, xlsx: Path) -> list[str]:
    """Validate 功能点 -> 测试项 -> 测试点 against an explicit design map."""
    if not cfg:
        return []
    required = bool(cfg.get("required", True))
    file_name = str(cfg.get("file", "用例设计蓝图.json") or "用例设计蓝图.json")
    path = Path(file_name)
    if not path.is_absolute():
        path = xlsx.parent / path
    if not path.is_file():
        return [f"[S27 层级映射蓝图缺失] 未找到 {path.name}"] if required else []
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return [f"[S27 层级映射蓝图不可读] {path.name}: {exc}"]
    map_key = str(cfg.get("map_key", "hierarchy_map") or "hierarchy_map")
    mapping = payload.get(map_key) if isinstance(payload, dict) else None
    if not isinstance(mapping, dict):
        return [f"[S27 层级映射缺失] {path.name} 缺少对象字段 {map_key}"]
    allow_ids = {str(value) for value in _as_list(cfg.get("allow_case_ids"))}
    violations: list[str] = []
    for row in rows:
        case_id = str(row.get("用例编号", "") or "<无编号>")
        if case_id in allow_ids:
            continue
        module = str(row.get("功能模块", "") or "")
        feature = str(row.get("功能点", "") or "")
        item = str(row.get("测试项", "") or "")
        module_map = mapping.get(module)
        if not isinstance(module_map, dict):
            violations.append(f"[S19 功能点映射缺失] {case_id} 模块「{module}」未配置层级映射")
            continue
        feature_map = module_map.get(feature)
        if not isinstance(feature_map, dict):
            violations.append(f"[S19 功能点映射缺失] {case_id} 功能点「{feature}」不在模块「{module}」蓝图中")
            continue
        item_rule = feature_map.get(item)
        if item_rule is None:
            violations.append(f"[S19 测试项归属错误] {case_id} 测试项「{item}」不属于功能点「{feature}」")
            continue
        if isinstance(item_rule, list):
            keywords = [str(value) for value in item_rule if str(value)]
            mode = "any"
        elif isinstance(item_rule, dict):
            keywords = [
                str(value) for value in _as_list(
                    item_rule.get("intent_keywords", item_rule.get("required_intent_keywords"))
                ) if str(value)
            ]
            mode = str(item_rule.get("match", "any") or "any")
        else:
            keywords = [str(item_rule)] if str(item_rule) else []
            mode = "any"
        if not keywords:
            if required:
                violations.append(f"[S19 测试项意图映射缺失] {case_id} {feature}/{item} 未配置 intent_keywords")
            continue
        intent_text = _normalized(" ".join(
            str(row.get(field, "") or "") for field in ("测试点/检查项", "预期结果")
        ))
        normalized_keywords = [_normalized(keyword) for keyword in keywords]
        matched = all(keyword in intent_text for keyword in normalized_keywords) if mode == "all" \
            else any(keyword in intent_text for keyword in normalized_keywords)
        if not matched:
            violations.append(
                f"[S19 测试点意图错位] {case_id} {feature}/{item} 的测试点与预期未命中映射意图 {keywords}"
            )
    return violations


def _color_is_black(color: Any) -> bool:
    if color is None:
        return False
    color_type = getattr(color, "type", None)
    if color_type == "rgb":
        return str(getattr(color, "rgb", "") or "").upper().endswith("000000")
    if color_type == "indexed":
        # 0/8 are explicit indexed black values; 64 is an automatic/system
        # colour and therefore cannot prove the workbook has black borders.
        return getattr(color, "indexed", None) in {0, 8}
    return False


def _side_is_black(side: Any) -> bool:
    return bool(getattr(side, "style", None)) and _color_is_black(getattr(side, "color", None))


def _required_border_sides(sheet: Any, row: int, column: int) -> tuple[str, ...]:
    for cell_range in sheet.merged_cells.ranges:
        if cell_range.min_row <= row <= cell_range.max_row and cell_range.min_col <= column <= cell_range.max_col:
            required: list[str] = []
            if row == cell_range.min_row:
                required.append("top")
            if row == cell_range.max_row:
                required.append("bottom")
            if column == cell_range.min_col:
                required.append("left")
            if column == cell_range.max_col:
                required.append("right")
            return tuple(required)
    return ("top", "bottom", "left", "right")


def _is_merged_child(sheet: Any, row: int, column: int) -> bool:
    for cell_range in sheet.merged_cells.ranges:
        if cell_range.min_row <= row <= cell_range.max_row and cell_range.min_col <= column <= cell_range.max_col:
            return (row, column) != (cell_range.min_row, cell_range.min_col)
    return False


def _expected_merge_ranges(sheet: Any, headers: list[str], header_row: int, hierarchy: list[str]) -> set[str]:
    columns = {header: index for index, header in enumerate(headers, 1)}
    fill = _merged_fill(sheet)
    expected: set[str] = set()
    for level, header in enumerate(hierarchy):
        column = columns.get(header)
        if column is None:
            continue
        parent_headers = [name for name in hierarchy[:level] if name in columns]
        start = header_row + 1

        def key(row: int) -> tuple[str, ...]:
            values = [fill.get((row, columns[parent]), sheet.cell(row, columns[parent]).value) for parent in parent_headers]
            values.append(fill.get((row, column), sheet.cell(row, column).value))
            return tuple(str(value or "") for value in values)

        previous = key(start) if start <= sheet.max_row else ()
        for row in range(start + 1, sheet.max_row + 2):
            current = key(row) if row <= sheet.max_row else None
            if current != previous:
                end = row - 1
                if end > start and any(previous):
                    expected.add(str(openpyxl.worksheet.cell_range.CellRange(
                        min_col=column, min_row=start, max_col=column, max_row=end
                    )))
                start = row
                previous = current
    return expected


def check_delivery_workbook(xlsx: Path, cfg: dict) -> list[str]:
    """Validate the physical Excel contract, including merged-border perimeter."""
    if not cfg:
        return []
    workbook = openpyxl.load_workbook(xlsx, data_only=False)
    sheet_name = str(cfg.get("sheet_name", "全功能测试用例") or "全功能测试用例")
    violations: list[str] = []
    if cfg.get("single_sheet"):
        allowed_auxiliary = {
            str(value) for value in _as_list(cfg.get("allowed_auxiliary_sheets"))
            if str(value).strip()
        }
        required_auxiliary = {
            str(value) for value in _as_list(cfg.get("required_auxiliary_sheets"))
            if str(value).strip()
        }
        unexpected = [
            name for name in workbook.sheetnames
            if name != sheet_name and name not in allowed_auxiliary
        ]
        missing = sorted(required_auxiliary - set(workbook.sheetnames))
        if unexpected:
            violations.append(f"[S20 工作表结构错误] 存在未授权辅助sheet {unexpected}")
        if missing:
            violations.append(f"[S20 工作表结构错误] 缺少必需辅助sheet {missing}")
    if sheet_name not in workbook.sheetnames:
        violations.append(f"[S20 工作表缺失] 未找到「{sheet_name}」")
        return violations
    sheet = workbook[sheet_name]
    header_row = int(cfg.get("header_row", 1) or 1)
    actual_headers = [str(sheet.cell(header_row, column).value or "").strip() for column in range(1, sheet.max_column + 1)]
    while actual_headers and not actual_headers[-1]:
        actual_headers.pop()
    expected_headers = [str(value) for value in _as_list(cfg.get("headers"))]
    if expected_headers and actual_headers != expected_headers:
        violations.append(f"[S20 表头合同不一致] 期望={expected_headers} / 实际={actual_headers}")
    table_columns = len(expected_headers or actual_headers)

    font_name = str(cfg.get("font_name", "") or "")
    font_size = cfg.get("font_size")
    require_black_borders = bool(cfg.get("require_black_borders"))
    style_examples: list[str] = []
    border_examples: list[str] = []
    for row in range(header_row, sheet.max_row + 1):
        for column in range(1, table_columns + 1):
            cell = sheet.cell(row, column)
            if not _is_merged_child(sheet, row, column):
                if font_name and str(cell.font.name or "") != font_name:
                    style_examples.append(f"{cell.coordinate}:字体={cell.font.name}")
                if isinstance(font_size, (int, float)) and cell.font.sz != font_size:
                    style_examples.append(f"{cell.coordinate}:字号={cell.font.sz}")
            if require_black_borders:
                for side_name in _required_border_sides(sheet, row, column):
                    if not _side_is_black(getattr(cell.border, side_name)):
                        border_examples.append(f"{cell.coordinate}.{side_name}")
    if style_examples:
        violations.append(f"[S20 字体不一致] 应为{font_name or '*'} {font_size or '*'}号，示例 {style_examples[:10]}")
    if border_examples:
        violations.append(f"[S20 黑色边框缺失] 表格全部外显边框必须为黑色，示例 {border_examples[:12]}")

    hierarchy = [str(value) for value in _as_list(cfg.get("merge_hierarchy")) if str(value)]
    if hierarchy:
        expected_ranges = _expected_merge_ranges(sheet, actual_headers, header_row, hierarchy)
        header_columns = {header: index for index, header in enumerate(actual_headers, 1)}
        hierarchy_columns = {header_columns[name] for name in hierarchy if name in header_columns}
        blank_hierarchy: list[str] = []
        for header in hierarchy:
            column = header_columns.get(header)
            if column is None:
                continue
            for row in range(header_row + 1, sheet.max_row + 1):
                if sheet.cell(row, column).value in (None, "") and not _is_merged_child(sheet, row, column):
                    blank_hierarchy.append(sheet.cell(row, column).coordinate)
        if blank_hierarchy:
            violations.append(f"[S21 层级值空白且未合并] 层级列必须有值或位于合法合并区，示例 {blank_hierarchy[:12]}")
        actual_ranges = {
            str(cell_range)
            for cell_range in sheet.merged_cells.ranges
            if cell_range.min_col == cell_range.max_col and cell_range.min_col in hierarchy_columns
        }
        missing = sorted(expected_ranges - actual_ranges)
        extra = sorted(actual_ranges - expected_ranges)
        if missing:
            violations.append(f"[S20 相同层级文本未合并] 缺少合并区域 {missing[:12]}")
        if extra:
            violations.append(f"[S20 层级错误合并] 合并区域跨越了不同父级或不同文本 {extra[:12]}")
        if cfg.get("forbid_merges_outside_hierarchy"):
            outside = [
                str(cell_range)
                for cell_range in sheet.merged_cells.ranges
                if cell_range.min_col != cell_range.max_col or cell_range.min_col not in hierarchy_columns
            ]
            if outside:
                violations.append(f"[S20 非层级列错误合并] 仅允许层级列纵向合并，发现 {outside[:12]}")

    expected_version = str(cfg.get("expected_version", "") or "").strip()
    allowed_versions = {value.casefold() for value in _as_list(cfg.get("allowed_version_mentions")) if str(value)}
    if expected_version:
        allowed_versions.add(expected_version.casefold())
        if cfg.get("filename_must_contain_version", True) and expected_version.casefold() not in xlsx.name.casefold():
            violations.append(f"[S22 交付版本文件名不一致] 文件名未包含目标版本 {expected_version}: {xlsx.name}")
        if cfg.get("forbid_other_versions", True):
            filename_versions = {value.casefold(): value for value in VERSION_RE.findall(xlsx.name)}
            for normalized, version in filename_versions.items():
                if normalized not in allowed_versions:
                    violations.append(f"[S22 交付文件名旧版本残留] 目标={expected_version}，文件名还包含{version}: {xlsx.name}")
            scan_headers = [str(value) for value in _as_list(cfg.get("version_scan_fields")) if str(value)] or actual_headers
            columns = {header: index for index, header in enumerate(actual_headers, 1)}
            unexpected: dict[str, list[str]] = defaultdict(list)
            for header in scan_headers:
                column = columns.get(header)
                if column is None:
                    continue
                for row in range(header_row + 1, sheet.max_row + 1):
                    text = str(sheet.cell(row, column).value or "")
                    for version in VERSION_RE.findall(text):
                        if version.casefold() not in allowed_versions:
                            unexpected[version].append(sheet.cell(row, column).coordinate)
            for version, cells in unexpected.items():
                violations.append(f"[S22 活动用例旧版本残留] 目标={expected_version}，发现{version}于 {cells[:10]}")
        if cfg.get("require_expected_version_mention"):
            version_cells = [
                sheet.cell(row, column).coordinate
                for row in range(header_row + 1, sheet.max_row + 1)
                for column in range(1, table_columns + 1)
                if expected_version.casefold() in str(sheet.cell(row, column).value or "").casefold()
            ]
            if not version_cells:
                violations.append(f"[S22 活动用例目标版本缺失] 工作簿正文未出现目标版本 {expected_version}")
    if cfg.get("require_empty_actual_result") and "实际结果" in actual_headers:
        column = actual_headers.index("实际结果") + 1
        populated = [
            sheet.cell(row, column).coordinate
            for row in range(header_row + 1, sheet.max_row + 1)
            if str(sheet.cell(row, column).value or "").strip()
        ]
        if populated:
            violations.append(f"[S22 实际结果非空] 新交付执行表的实际结果列应留空，发现 {populated[:10]}")
    return violations


def check_quality(rows: list[dict], quality_gates: dict, xlsx: Path) -> list[str]:
    violations: list[str] = []
    violations.extend(check_test_item_taxonomy(rows, quality_gates.get("test_item_taxonomy")))
    violations.extend(check_case_granularity(rows, quality_gates.get("case_granularity", {})))
    violations.extend(check_cross_block(rows, quality_gates.get("cross_scene_block")))
    violations.extend(check_case_scale(rows, quality_gates.get("case_scale", {}), xlsx))
    violations.extend(check_hierarchy_mapping(rows, quality_gates.get("hierarchy_mapping", {}), xlsx))
    violations.extend(check_manual_case_style(rows, quality_gates.get("manual_case_style")))
    violations.extend(check_delivery_workbook(xlsx, quality_gates.get("delivery_workbook", {})))
    return violations


def main() -> None:
    parser = argparse.ArgumentParser(description="用例粒度、规模依据和最终Excel实物门禁")
    parser.add_argument("--xlsx")
    parser.add_argument("--config", help="workflow-v2 trace.config.json")
    parser.add_argument("--contract", help="只含 quality_gates 或门禁键的 JSON")
    parser.add_argument("--module", default="")
    parser.add_argument("--json", action="store_true")
    args = parser.parse_args()

    if args.config:
        config_path = Path(args.config).resolve()
        payload = json.loads(config_path.read_text(encoding="utf-8"))
        xlsx = Path(payload.get("cases_xlsx", ""))
        if not xlsx.is_absolute():
            xlsx = config_path.parent / xlsx
        quality_gates = payload.get("quality_gates", {}) or {}
        modules = payload.get("modules", []) or []
        default_module = str(modules[0].get("name", "")) if len(modules) == 1 and isinstance(modules[0], dict) else ""
    elif args.xlsx and args.contract:
        xlsx = Path(args.xlsx).resolve()
        contract_path = Path(args.contract).resolve()
        payload = json.loads(contract_path.read_text(encoding="utf-8"))
        quality_gates = payload.get("quality_gates", payload) if isinstance(payload, dict) else {}
        for gate_name in ("case_scale", "hierarchy_mapping"):
            gate = quality_gates.get(gate_name) if isinstance(quality_gates, dict) else None
            if isinstance(gate, dict) and gate.get("file"):
                gate_path = Path(str(gate["file"]))
                if not gate_path.is_absolute():
                    gate["file"] = str((contract_path.parent / gate_path).resolve())
        default_module = args.module
    else:
        raise SystemExit("需提供 --config，或同时提供 --xlsx 与 --contract")

    delivery_cfg = quality_gates.get("delivery_workbook", {}) or {}
    rows = read_case_rows(xlsx, delivery_cfg, default_module) if delivery_cfg else []
    violations = check_quality(rows, quality_gates, xlsx)
    result = {"success": not violations, "xlsx": str(xlsx), "cases": len(rows), "violations": violations}
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("最终用例交付门禁: " + ("PASS" if not violations else "FAIL"))
        for violation in violations:
            print("  " + violation)
    raise SystemExit(0 if not violations else 1)


if __name__ == "__main__":
    main()
