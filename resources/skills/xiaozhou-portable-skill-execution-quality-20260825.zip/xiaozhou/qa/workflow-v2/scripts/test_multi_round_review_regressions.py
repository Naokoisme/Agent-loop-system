# -*- coding: utf-8 -*-
"""Regression coverage for the multi-round, multi-agent testcase review gate."""
from __future__ import annotations

import copy
import hashlib
import json
import tempfile
from pathlib import Path

import multi_round_review_gate as gate
import tc_excel


CASE_IDS = ["QA_001"]


def _row() -> dict[str, str]:
    return {
        "用例编号": "QA_001",
        "功能模块": "绑定",
        "功能点": "扫码绑定",
        "测试项": "绑定流程",
        "测试点/检查项": "验证扫描二维码后完成绑定",
        "前置条件": "1.设备处于可绑定状态",
        "操作步骤": "1.使用App扫描设备二维码",
        "预期结果": "1.App显示绑定成功，设备进入已绑定状态",
        "优先级": "P0",
        "兼容性": "N/A",
        "是否自动化": "否",
        "固件版本": "v1.0",
        "硬件型号": "待测",
        "测试方式": "人工执行",
        "备注": "",
    }


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _case_ids_sha256() -> str:
    canonical = json.dumps(CASE_IDS, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _resolved_major(finding_id: str = "MR-001") -> dict:
    return {
        "finding_id": finding_id,
        "severity": "major",
        "category": "执行确定性",
        "case_ids": ["QA_001"],
        "description": "前置条件缺少可绑定状态定义",
        "status": "resolved",
        "resolution": "补充设备处于可绑定状态的明确前置",
    }


def _write_agent_report(
    root: Path,
    round_id: str,
    review_type: str,
    role: str,
    workbook_hash: str,
    prd_hash: str,
    *,
    source_findings: list[dict] | None = None,
    verified_finding_ids: list[str] | None = None,
    reviewed_case_ids: list[str] | None = None,
    suffix: str = "",
) -> dict:
    context_mode = gate.ROLE_CONTEXT_MODES[role]
    agent_id = f"agent-{role}"
    agent_run_id = f"run-{round_id}-{role}"
    findings = copy.deepcopy(source_findings or [])
    verified = list(verified_finding_ids or [])
    report = {
        "schema_version": 1,
        "agent_id": agent_id,
        "agent_run_id": agent_run_id,
        "review_type": review_type,
        "reviewer_role": role,
        "fork_turns": "none",
        "peer_reports_visible": False,
        "context_mode": context_mode,
        "scope": "all_project",
        "input_xlsx_sha256": workbook_hash,
        "prd_sha256": prd_hash,
        "reviewed_case_count": len(CASE_IDS),
        "reviewed_case_ids": CASE_IDS if reviewed_case_ids is None else reviewed_case_ids,
        "reviewed_case_ids_sha256": _case_ids_sha256(),
        "findings": findings,
        "verified_finding_ids": verified,
        "evidence": f"{role}已从原始产物逐条检查全部用例",
        "status": "completed",
    }
    relative = Path("工作底稿") / "agent_reviews" / f"{round_id}-{role}{suffix}.json"
    path = root / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return {
        "agent_id": agent_id,
        "agent_run_id": agent_run_id,
        "reviewer_role": role,
        "fork_turns": "none",
        "peer_reports_visible": False,
        "context_mode": context_mode,
        "scope": "all_project",
        "input_xlsx_sha256": workbook_hash,
        "prd_sha256": prd_hash,
        "reviewed_case_count": len(CASE_IDS),
        "reviewed_case_ids_sha256": _case_ids_sha256(),
        "report_path": relative.as_posix(),
        "report_sha256": _sha256(path),
        "finding_ids": [item["source_finding_id"] for item in findings],
        "verified_finding_ids": verified,
        "evidence": report["evidence"],
        "status": "completed",
    }


def _round(
    round_id: str,
    review_type: str,
    workbook_hash: str,
    *,
    findings: list[dict] | None = None,
    reviewed_case_count: int = 1,
    agent_reviews: list[dict] | None = None,
) -> dict:
    finding_rows = copy.deepcopy(findings or [])
    counts = {"blocker": 0, "major": 0, "minor": 0}
    for item in finding_rows:
        counts[item["severity"]] += 1
    return {
        "round_id": round_id,
        "review_type": review_type,
        "review_perspective": {
            "coverage_design": "需求覆盖与测试设计",
            "execution_detail": "首次执行人员",
            "adversarial": "双Agent反向挑错",
            "regression": "双Agent修订回归",
        }[review_type],
        "scope": "all_project",
        "input_xlsx_sha256": workbook_hash,
        "reviewed_case_count": reviewed_case_count,
        "finding_counts": counts,
        "findings": finding_rows,
        "agent_reviews": copy.deepcopy(agent_reviews or []),
        "evidence": f"{review_type}已逐条检查全部用例并记录问题关闭情况",
        "status": "completed",
    }


def _ledger(root: Path, workbook_hash: str, prd_hash: str) -> dict:
    old_hash = "1" * 64
    adversarial = [
        _write_agent_report(root, "R3", "adversarial", "adversarial-risk", workbook_hash, prd_hash),
        _write_agent_report(root, "R3", "adversarial", "adversarial-execution", workbook_hash, prd_hash),
    ]
    regression = [
        _write_agent_report(root, "R4", "regression", "regression-blind", workbook_hash, prd_hash),
        _write_agent_report(
            root,
            "R4",
            "regression",
            "regression-targeted",
            workbook_hash,
            prd_hash,
            verified_finding_ids=["MR-001"],
        ),
    ]
    return {
        "schema_version": 2,
        "input_xlsx_sha256": workbook_hash,
        "prd_sha256": prd_hash,
        "case_ids_sha256": _case_ids_sha256(),
        "case_count": 1,
        "generator_agent_ids": ["agent-generator"],
        "reviser_agent_ids": ["agent-reviser"],
        "review_control": {
            "execution_mode": "manual",
            "scope_lock": {
                "status": "locked",
                "prd_scope": "prd.md 全部扫码绑定需求",
                "blueprint": "用例设计蓝图.json",
                "input_xlsx_sha256": workbook_hash,
                "evidence": "已锁定纯人工交付、PRD范围、蓝图及当前Excel哈希",
            },
            "revision_batch_count": 1,
        },
        "required_review_types": list(gate.REQUIRED_REVIEW_TYPES),
        "rounds": [
            _round("R1", "coverage_design", old_hash, findings=[_resolved_major()]),
            _round("R2", "execution_detail", old_hash),
            _round("R3", "adversarial", workbook_hash, agent_reviews=adversarial),
            _round("R4", "regression", workbook_hash, agent_reviews=regression),
        ],
        "consecutive_clean_rounds": 3,
        "remaining_findings": [],
        "visual_inspection": {
            "status": "passed",
            "input_xlsx_sha256": workbook_hash,
            "checked_items": ["文字完整显示", "层级合并", "边框与字体", "冻结与筛选"],
            "evidence": "已重新打开最终Excel并检查全部数据行及首末屏显示",
        },
        "final_status": "PASS",
    }


def _codes(report: dict) -> set[str]:
    return {str(item.get("code")) for item in report.get("issues", [])}


def _agent_review(payload: dict, round_index: int, role: str) -> dict:
    return next(
        item for item in payload["rounds"][round_index]["agent_reviews"]
        if item["reviewer_role"] == role
    )


def main() -> None:
    results: list[dict] = []
    errors: list[str] = []
    with tempfile.TemporaryDirectory(prefix="multi-round-review-") as tmp:
        root = Path(tmp)
        (root / "工作底稿").mkdir()
        cases_path = root / "cases.xlsx"
        tc_excel.write_workbook([_row()], cases_path, ["绑定"])
        workbook_hash = _sha256(cases_path)
        prd_path = root / "prd.md"
        prd_path.write_text("# 需求\n\n扫描二维码后绑定成功。\n", encoding="utf-8")
        prd_hash = _sha256(prd_path)
        config = {
            "prd_path": "prd.md",
            "cases_xlsx": "cases.xlsx",
            "release_acceptance": {
                "multi_round_review_required": True,
                "multi_agent_review_required": True,
                "multi_round_review_file": "工作底稿/多轮测试用例评审.json",
                "review_control": {
                    "execution_mode": "manual",
                    "scope_lock_required": True,
                    "max_revision_batches": 2,
                },
            },
        }
        config_path = root / "trace.config.json"
        config_path.write_text(json.dumps(config, ensure_ascii=False), encoding="utf-8")
        ledger_path = root / "工作底稿" / "多轮测试用例评审.json"

        def check(name: str, payload: dict | None, expected_status: str, expected_code: str = "") -> None:
            if payload is None:
                ledger_path.unlink(missing_ok=True)
            else:
                ledger_path.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
            report = gate.evaluate(config_path)
            passed = report["status"] == expected_status
            if expected_code:
                passed = passed and expected_code in _codes(report)
            results.append({"name": name, "passed": passed, "status": report["status"], "issues": report["issues"]})
            if not passed:
                errors.append(name)

        valid = _ledger(root, workbook_hash, prd_hash)
        check("valid_four_agent_convergence_passes", valid, "PASS")

        def check_config(name: str, payload: dict, expected_code: str) -> None:
            config_path.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
            ledger_path.write_text(json.dumps(valid, ensure_ascii=False), encoding="utf-8")
            report = gate.evaluate(config_path)
            passed = report["status"] == "FAIL" and expected_code in _codes(report)
            results.append({"name": name, "passed": passed, "status": report["status"], "issues": report["issues"]})
            if not passed:
                errors.append(name)
            config_path.write_text(json.dumps(config, ensure_ascii=False), encoding="utf-8")

        missing_control_config = copy.deepcopy(config)
        del missing_control_config["release_acceptance"]["review_control"]
        check_config(
            "multi_agent_review_requires_review_control",
            missing_control_config,
            "MULTI_ROUND_REVIEW_CONTROL_REQUIRED",
        )

        expanded_limit_config = copy.deepcopy(config)
        expanded_limit_config["release_acceptance"]["review_control"]["max_revision_batches"] = 5
        check_config(
            "revision_cap_cannot_be_configured_above_two",
            expanded_limit_config,
            "MULTI_ROUND_REVIEW_CONTROL_INVALID",
        )

        unlocked = copy.deepcopy(valid)
        unlocked["review_control"]["scope_lock"] = {"status": "pending", "evidence": ""}
        check("review_scope_must_be_locked_before_agents", unlocked, "FAIL", "MULTI_ROUND_REVIEW_SCOPE_NOT_LOCKED")

        weak_lock = copy.deepcopy(valid)
        weak_lock["review_control"]["scope_lock"]["evidence"] = "x"
        check("one_character_scope_evidence_is_rejected", weak_lock, "FAIL", "MULTI_ROUND_REVIEW_SCOPE_NOT_LOCKED")

        stale_scope_hash = copy.deepcopy(valid)
        stale_scope_hash["review_control"]["scope_lock"]["input_xlsx_sha256"] = "0" * 64
        check("scope_lock_must_bind_current_excel", stale_scope_hash, "FAIL", "MULTI_ROUND_REVIEW_SCOPE_NOT_LOCKED")

        over_limit = copy.deepcopy(valid)
        over_limit["review_control"]["revision_batch_count"] = 3
        check("serious_revision_batches_cannot_exceed_cap", over_limit, "FAIL", "MULTI_ROUND_REVIEW_REVISION_LIMIT_EXCEEDED")

        wrong_mode = copy.deepcopy(valid)
        wrong_mode["review_control"]["execution_mode"] = "automation"
        check("review_execution_mode_must_match_delivery", wrong_mode, "FAIL", "MULTI_ROUND_REVIEW_EXECUTION_MODE_MISMATCH")

        check("missing_ledger_fails", None, "FAIL", "MULTI_ROUND_REVIEW_LEDGER_MISSING")

        stale = copy.deepcopy(valid)
        stale["input_xlsx_sha256"] = "0" * 64
        check("stale_top_level_hash_fails", stale, "FAIL", "MULTI_ROUND_REVIEW_INPUT_HASH_STALE")

        one_clean = copy.deepcopy(valid)
        one_clean["rounds"][-2] = _round(
            "R3", "adversarial", workbook_hash, findings=[_resolved_major("MR-002")],
            agent_reviews=valid["rounds"][-2]["agent_reviews"],
        )
        one_clean["consecutive_clean_rounds"] = 1
        check("one_clean_round_is_not_converged", one_clean, "FAIL", "MULTI_ROUND_REVIEW_NOT_CONVERGED")

        wrong_sequence = copy.deepcopy(valid)
        wrong_sequence["rounds"][-2]["review_type"] = "regression"
        wrong_sequence["rounds"][-2]["review_perspective"] = "修订回归"
        check("final_sequence_must_be_adversarial_then_regression", wrong_sequence, "FAIL", "MULTI_ROUND_REVIEW_FINAL_SEQUENCE")

        stale_final = copy.deepcopy(valid)
        stale_final["rounds"][-1]["input_xlsx_sha256"] = "2" * 64
        check("stale_final_round_hash_fails", stale_final, "FAIL", "MULTI_ROUND_REVIEW_FINAL_HASH_STALE")

        incomplete = copy.deepcopy(valid)
        incomplete["rounds"][-1]["reviewed_case_count"] = 2
        check("final_round_must_scan_current_count", incomplete, "FAIL", "MULTI_ROUND_REVIEW_FINAL_SCAN_INCOMPLETE")

        accepted_major = copy.deepcopy(valid)
        accepted_major["rounds"][0]["findings"][0].update({
            "status": "accepted", "owner": "测试负责人", "acceptance_reason": "暂不修改"
        })
        check("major_cannot_be_accepted", accepted_major, "FAIL", "MULTI_ROUND_REVIEW_SERIOUS_FINDING_ACCEPTED")

        bad_visual = copy.deepcopy(valid)
        bad_visual["visual_inspection"]["checked_items"] = ["文字完整显示"]
        check("visual_inspection_requires_minimum_items", bad_visual, "FAIL", "MULTI_ROUND_REVIEW_VISUAL_ITEMS_INSUFFICIENT")

        one_agent = copy.deepcopy(valid)
        one_agent["rounds"][-2]["agent_reviews"].pop()
        check("adversarial_requires_two_agents", one_agent, "FAIL", "MULTI_AGENT_REVIEW_COUNT_INVALID")

        reused = copy.deepcopy(valid)
        _agent_review(reused, -1, "regression-blind")["agent_id"] = \
            _agent_review(reused, -2, "adversarial-risk")["agent_id"]
        check("final_agents_cannot_be_reused", reused, "FAIL", "MULTI_AGENT_REVIEW_AGENT_REUSED")

        author_self_review = copy.deepcopy(valid)
        _agent_review(author_self_review, -2, "adversarial-risk")["agent_id"] = "agent-generator"
        check("generator_cannot_review", author_self_review, "FAIL", "MULTI_AGENT_REVIEW_ROLE_CONFLICT")

        leaked_context = copy.deepcopy(valid)
        _agent_review(leaked_context, -2, "adversarial-risk")["fork_turns"] = "all"
        check("review_context_must_be_isolated", leaked_context, "FAIL", "MULTI_AGENT_REVIEW_CONTEXT_NOT_ISOLATED")

        stale_report = copy.deepcopy(valid)
        _agent_review(stale_report, -2, "adversarial-risk")["report_sha256"] = "0" * 64
        check("agent_report_hash_must_match", stale_report, "FAIL", "MULTI_AGENT_REVIEW_REPORT_HASH_STALE")

        incomplete_ids = copy.deepcopy(valid)
        incomplete_ids_review = _write_agent_report(
            root, "R3", "adversarial", "adversarial-risk", workbook_hash, prd_hash,
            reviewed_case_ids=[], suffix="-incomplete-ids",
        )
        incomplete_ids["rounds"][-2]["agent_reviews"][0] = incomplete_ids_review
        check("agent_report_must_list_all_case_ids", incomplete_ids, "FAIL", "MULTI_AGENT_REVIEW_CASE_IDS_INCOMPLETE")

        missing_verification = copy.deepcopy(valid)
        missing_verification_review = _write_agent_report(
            root, "R4", "regression", "regression-targeted", workbook_hash, prd_hash,
            verified_finding_ids=[], suffix="-missing-verification",
        )
        missing_verification["rounds"][-1]["agent_reviews"][1] = missing_verification_review
        check(
            "targeted_regression_must_verify_all_resolutions",
            missing_verification,
            "FAIL",
            "MULTI_AGENT_REVIEW_RESOLUTIONS_NOT_VERIFIED",
        )

        union_gap = copy.deepcopy(valid)
        union_gap_review = _write_agent_report(
            root,
            "R3",
            "adversarial",
            "adversarial-risk",
            workbook_hash,
            prd_hash,
            source_findings=[{
                "source_finding_id": "AR-001",
                "severity": "major",
                "category": "覆盖遗漏",
                "case_ids": ["QA_001"],
                "description": "原始报告发现问题但汇总遗漏",
            }],
            suffix="-union-gap",
        )
        union_gap["rounds"][-2]["agent_reviews"][0] = union_gap_review
        check("agent_findings_must_be_merged_by_union", union_gap, "FAIL", "MULTI_AGENT_REVIEW_FINDING_UNION_MISMATCH")

    print(json.dumps({"success": not errors, "results": results, "errors": errors}, ensure_ascii=False, indent=2))
    if errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
