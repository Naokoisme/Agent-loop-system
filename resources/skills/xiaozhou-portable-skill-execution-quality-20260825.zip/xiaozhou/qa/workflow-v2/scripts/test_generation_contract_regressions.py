# -*- coding: utf-8 -*-
"""生成前验收合同、结构化用例和组合数据集的聚焦回归。"""
from __future__ import annotations

import copy
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


SCRIPTS = Path(__file__).resolve().parent
WORKFLOW = SCRIPTS.parent
PROJECTS = WORKFLOW / "projects"
sys.path.insert(0, str(SCRIPTS))
sys.path.insert(0, str(SCRIPTS / "traceability"))

from generation_contract import (  # noqa: E402
    GENERATION_CONTRACT_TEMPLATE,
    _factor_evidence_semantically_binds,
)
from traceability import trace_extract, trace_gate  # noqa: E402


def run_casegen(project_name: str, *, pilot: bool = False) -> subprocess.CompletedProcess[str]:
    args = [sys.executable, str(SCRIPTS / "casegen.py"), "--project", project_name]
    if pilot:
        args.append("--pilot")
    return subprocess.run(
        args,
        cwd=WORKFLOW,
        text=True,
        capture_output=True,
        encoding="utf-8",
        errors="replace",
    )


def blueprint() -> dict:
    return {
        "module_boundary": {}, "feature_order": {}, "page_state_anchors": {}, "input_matrix": {},
        "exception_matrix": [], "cross_matrix": [], "common_fixtures": {},
        "case_precondition_rules": [], "unsupported_features": [],
    }


def legacy_case(step: str = "1.点击保存且保持当前页面") -> dict:
    return {
        "_stable_id": "CASE::LEGACY-001",
        "fp": "记录保存", "ti": "功能测试", "tp": "验证保存后页面状态",
        "pre": "1.已生成一条待保存记录", "step": step,
        "exp": "1.记录保存成功且页面保持当前", "pri": "P1",
    }


def structured_case(stable_id: str = "CASE::STRUCTURED-001") -> dict:
    return {
        "_stable_id": stable_id,
        "fp": "记录保存", "ti": "功能测试", "tp": "验证保存及列表展示",
        "preconditions": ["已生成一条待保存记录"],
        "steps": ["点击保存", "返回记录列表"],
        "expected": ["记录保存成功", "列表展示新增记录"],
        "pri": "P1",
    }


def combination_case(
    dataset_id: str = "SAVE_DT_001",
    stable_id: str = "CASE::COMBO-001",
    summary: bool = False,
) -> dict:
    row = structured_case(stable_id)
    row.update({
        "tp": "验证登录与绑定组合下保存入口",
        "preconditions": ["账号未登录", "设备未绑定", "已生成一条待保存记录"],
        "method": "判定表法",
        "dataset_id": dataset_id,
        "factors": ["账号登录=否", "设备绑定=否"],
        "factor_evidence": [
            {"factor": "账号登录=否", "field": "pre", "fragments": ["账号未登录"]},
            {"factor": "设备绑定=否", "field": "pre", "fragments": ["设备未绑定"]},
        ],
    })
    if summary:
        row["steps"] = ["遍历所有组合并点击保存"]
        row["expected"] = ["各组合结果符合规则"]
    return row


def ordered_combination_case() -> dict:
    return {
        "_stable_id": "CASE::ORDERED-COMBO-001",
        "fp": "提醒仲裁", "ti": "组合规则", "tp": "验证消息后闹钟的仲裁结果",
        "preconditions": ["消息提醒与闹钟均已开启"],
        "steps": ["向测试手机发送消息", "等待预先设置的设备闹钟到点"],
        "expected": ["手机显示消息已发送", "设备显示闹钟提醒"],
        "pri": "P1",
        "method": "判定表法",
        "dataset_id": "ORDER_DT_001",
        "factors": ["事件A=消息", "事件B=闹钟", "顺序=A后B"],
        "factor_evidence": [
            {"factor": "事件A=消息", "field": "step", "fragments": ["发送消息"]},
            {"factor": "事件B=闹钟", "field": "step", "fragments": ["设备闹钟到点"]},
            {
                "factor": "顺序=A后B", "field": "step",
                "fragments": ["向测试手机发送消息", "等待预先设置的设备闹钟到点"],
            },
        ],
    }


def valid_contract(module: str = "记录") -> dict:
    contract = copy.deepcopy(GENERATION_CONTRACT_TEMPLATE)
    contract.update({
        "contract_state": "locked",
        "product_form": {"value": "app-iot", "locked": True},
        "modules": [{
            "name": module,
            "prefix": "SAVE",
            "prefix_locked": True,
            "in_scope": True,
            "applicable_test_methods": ["等价类划分法", "判定表法"],
        }],
        "combination_dataset_plan": [{
            "module": module, "method": "判定表法", "minimum_rows": 1, "locked": True,
        }],
        "special_test_applicability": [{
            "name": "稳定性测试", "status": "applicable", "modules": [module],
            "reason": "记录保存属于高频核心路径，需要连续操作稳定性验证",
        }],
        "delivery_boundaries": {
            "FW": {"scope": "设备端记录接收和状态反馈", "out_of_scope": "APP页面渲染", "locked": True},
            "TC": {"scope": "APP与设备联动用例设计", "out_of_scope": "研发单元测试", "locked": True},
            "JT": {"scope": "蓝牙链路端到端联调", "out_of_scope": "第三方云服务压测", "locked": True},
        },
        "risk_exit_policy": {
            "locked": True, "blocking_issue_policy": "block",
            "pending_confirmation_policy": "block", "accepted_risks": [],
        },
        "pilot_modules": [module, "先导模块B", "先导模块C"],
        "pilot_acceptance": {
            "status": "passed", "evidence": "已完成高风险先导模块抽样审查记录", "locked": True,
        },
    })
    # 合同校验要求所有先导模块均在范围内；测试夹具提供三个最小模块。
    contract["modules"].extend([
        {"name": "先导模块B", "prefix": "PILOTB", "prefix_locked": True,
         "in_scope": True, "applicable_test_methods": ["等价类划分法"]},
        {"name": "先导模块C", "prefix": "PILOTC", "prefix_locked": True,
         "in_scope": True, "applicable_test_methods": ["等价类划分法"]},
    ])
    contract["module_order"] = {
        "items": [row["name"] for row in contract["modules"]],
        "locked": True,
    }
    contract["test_item_taxonomy"] = {
        "locked": True,
        "allowed_generic_items": ["功能测试", "异常测试", "界面操作"],
        "forbidden_specific_patterns": ["具体数值不得进入测试项"],
    }
    contract["design_contract"] = {
        "locked": True,
        "required_blueprint_fields": [
            "module_boundary", "feature_order", "page_state_anchors", "input_matrix",
            "exception_matrix", "cross_matrix", "common_fixtures",
            "case_precondition_rules", "unsupported_features",
        ],
        "stable_id_policy": "persisted_uuid",
        "ordering_policy": "stable_id_preserving",
    }
    contract["coverage_policy"] = {
        "locked": True,
        "coverage_threshold": 0.95,
        "require_zero_partial": True,
        "pending_evidence_mode": "require_acceptance",
        "accepted_partial_req_ids": [],
        "accepted_pending_req_ids": [],
    }
    contract["pilot_risk_types"] = [
        "settings_or_configuration", "health_or_sensor", "complex_state_flow",
        "cross_app_device", "high_conflict", "ambiguous_requirement",
    ]
    risk_bindings = [
        ("settings_or_configuration", "先导模块B"),
        ("health_or_sensor", module),
        ("complex_state_flow", "先导模块C"),
        ("cross_app_device", module),
        ("high_conflict", "先导模块B"),
        ("ambiguous_requirement", "先导模块C"),
    ]
    contract["pilot_risk_evidence"] = [
        {
            "risk_type": risk_type,
            "module": pilot_module,
            "evidence_path": f"pilot_evidence/{index:02d}.json",
            "note": f"{pilot_module} 已完成 {risk_type} 风险审查",
        }
        for index, (risk_type, pilot_module) in enumerate(risk_bindings, 1)
    ]
    return contract


def write_project(
    project: Path,
    cases: list[dict],
    *,
    require_contract: bool,
    contract: dict | None,
    extra_modules: bool = True,
    manual_contract_required: bool = False,
    default_pre: str = "",
) -> None:
    specs = project / "specs"
    specs.mkdir(parents=True)
    payloads = [("记录", "SAVE", cases)]
    if extra_modules:
        payloads.extend([
            ("先导模块B", "PILOTB", [dict(legacy_case(), _stable_id="CASE::PILOT-B")]),
            ("先导模块C", "PILOTC", [dict(legacy_case(), _stable_id="CASE::PILOT-C")]),
        ])
    for module, prefix, module_cases in payloads:
        spec_payload = {"module": module, "prefix": prefix, "cases": module_cases}
        if module == "记录" and default_pre:
            spec_payload["default_pre"] = default_pre
        (specs / f"{module}.json").write_text(
            json.dumps(spec_payload, ensure_ascii=False, indent=2), encoding="utf-8"
        )
    (project / "用例设计蓝图.json").write_text(
        json.dumps(blueprint(), ensure_ascii=False, indent=2), encoding="utf-8"
    )
    if require_contract or manual_contract_required:
        config = {
            "coverage_threshold": 0.95,
            "coverage_policy": {
                "require_zero_partial": True,
                "pending_evidence_mode": "require_acceptance",
                "accepted_partial_req_ids": [],
                "accepted_pending_req_ids": [],
            },
            "modules": [{"name": module, "prefix": prefix} for module, prefix, _ in payloads],
        }
        if require_contract:
            config["generation_contract"] = {"required": True, "file": "生成验收合同.json"}
        if manual_contract_required:
            config["quality_gates"] = {"functional_manual_contract": {"required": True}}
        (project / "trace.config.json").write_text(
            json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8"
        )
    if contract is not None:
        (project / "生成验收合同.json").write_text(
            json.dumps(contract, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        evidence_dir = project / "pilot_evidence"
        for row in contract.get("pilot_risk_evidence", []):
            if not isinstance(row, dict) or not row.get("evidence_path"):
                continue
            if "<" in str(row["evidence_path"]) or ">" in str(row["evidence_path"]):
                continue
            if str(row["evidence_path"]).endswith("not-created.json"):
                continue
            evidence_path = project / str(row["evidence_path"])
            evidence_path.parent.mkdir(parents=True, exist_ok=True)
            evidence_path.write_text(
                json.dumps({
                    "status": "PASS",
                    "risk_type": row.get("risk_type"),
                    "module": row.get("module"),
                }, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )


def generated_rows(project: Path, module: str = "记录") -> list[dict]:
    return json.loads((project / "cases" / f"{module}.json").read_text(encoding="utf-8"))["cases"]


def main() -> None:
    PROJECTS.mkdir(parents=True, exist_ok=True)
    results: list[dict] = []
    errors: list[str] = []

    def check(name: str, passed: bool, detail: str = "") -> None:
        results.append({"name": name, "passed": passed})
        if not passed:
            errors.append(f"{name}: {detail}")

    check(
        "factor_value_check_ignores_opposite_character_inside_factor_name",
        _factor_evidence_semantically_binds("周期", "日", ["将统计周期切换到日视图"]),
    )
    check(
        "single_character_factor_level_must_exist_outside_factor_name",
        not _factor_evidence_semantically_binds("周期", "日", ["查看当前统计周期"]),
    )
    check(
        "multi_character_factor_level_may_overlap_factor_name",
        _factor_evidence_semantically_binds("网络", "移动网络", ["切换到移动网络"]),
    )

    def scenario(
        name: str,
        cases: list[dict],
        *,
        require_contract: bool = False,
        contract: dict | None = None,
        precreate_cases: bool = False,
        pilot: bool = False,
        extra_modules: bool = True,
        manual_contract_required: bool = False,
        default_pre: str = "",
    ) -> tuple[Path, subprocess.CompletedProcess[str]]:
        project = Path(tempfile.mkdtemp(prefix=f"_generation_contract_{name}_", dir=PROJECTS))
        write_project(
            project, cases, require_contract=require_contract, contract=contract,
            extra_modules=extra_modules, manual_contract_required=manual_contract_required,
            default_pre=default_pre,
        )
        if precreate_cases:
            output = project / "cases"
            output.mkdir()
            (output / "sentinel.txt").write_text("unchanged", encoding="utf-8")
        return project, run_casegen(project.name, pilot=pilot)

    projects: list[Path] = []
    try:
        project, proc = scenario("legacy", [legacy_case()])
        projects.append(project)
        rows = generated_rows(project) if proc.returncode == 0 else []
        check(
            "legacy_string_format_remains_compatible",
            proc.returncode == 0 and rows and rows[0]["操作步骤"] == "1.点击保存且保持当前页面",
            proc.stdout + proc.stderr,
        )
        check(
            "conjunction_text_is_not_guessed_or_split",
            rows and rows[0]["预期结果"] == "1.记录保存成功且页面保持当前",
            str(rows),
        )

        project, proc = scenario("structured", [structured_case()])
        projects.append(project)
        rows = generated_rows(project) if proc.returncode == 0 else []
        check(
            "structured_arrays_are_deterministically_numbered",
            proc.returncode == 0 and rows and
            rows[0]["前置条件"] == "1.已生成一条待保存记录" and
            rows[0]["操作步骤"] == "1.点击保存\n2.返回记录列表" and
            rows[0]["预期结果"] == "1.记录保存成功\n2.列表展示新增记录",
            proc.stdout + proc.stderr + str(rows),
        )

        fixture_leak = structured_case("CASE::FIXTURE-LEAK")
        fixture_leak["preconditions"] = ["引用公共前置:BASE_ENV", "已生成一条待保存记录"]
        project, proc = scenario("fixture_leak", [fixture_leak])
        projects.append(project)
        check(
            "casegen_blocks_fixture_in_manual_functional_case",
            proc.returncode != 0 and "FMC2 功能用例混入自动化实现细节" in proc.stdout + proc.stderr,
            proc.stdout + proc.stderr,
        )

        automation_case = structured_case("CASE::AUTOMATION-ROW")
        automation_case["auto"] = "是"
        automation_case["way"] = "自动化脚本"
        project, proc = scenario("automation_row", [automation_case])
        projects.append(project)
        check(
            "casegen_blocks_automation_row_in_functional_artifact",
            proc.returncode != 0 and "FMC1 功能用例非人工执行" in proc.stdout + proc.stderr,
            proc.stdout + proc.stderr,
        )

        automation_without_id = structured_case("CASE::TEMP")
        automation_without_id.pop("_stable_id")
        automation_without_id["auto"] = "是"
        automation_without_id["way"] = "自动化脚本"
        project, proc = scenario("automation_zero_write", [automation_without_id])
        projects.append(project)
        source_after = json.loads((project / "specs" / "记录.json").read_text(encoding="utf-8"))
        check(
            "manual_contract_failure_does_not_bootstrap_stable_ids_or_cases",
            proc.returncode != 0
            and "_stable_id" not in source_after["cases"][0]
            and not (project / "cases").exists(),
            proc.stdout + proc.stderr + str(source_after),
        )

        mixed = structured_case()
        mixed["step"] = "1.点击保存"
        project, proc = scenario("mixed", [mixed])
        projects.append(project)
        check(
            "mixed_legacy_and_structured_fields_fail",
            proc.returncode != 0 and "禁止混用" in proc.stdout + proc.stderr,
            proc.stdout + proc.stderr,
        )

        mismatch = structured_case()
        mismatch["expected"] = ["记录保存成功"]
        project, proc = scenario("mismatch", [mismatch])
        projects.append(project)
        check(
            "step_expected_count_mismatch_fails",
            proc.returncode != 0 and "数量不一致" in proc.stdout + proc.stderr,
            proc.stdout + proc.stderr,
        )

        project, proc = scenario("missing_contract", [combination_case()], require_contract=True)
        projects.append(project)
        check(
            "required_contract_missing_fails",
            proc.returncode != 0 and "文件缺失" in proc.stdout + proc.stderr,
            proc.stdout + proc.stderr,
        )

        project, proc = scenario(
            "placeholder_contract", [combination_case()], require_contract=True,
            contract=copy.deepcopy(GENERATION_CONTRACT_TEMPLATE),
        )
        projects.append(project)
        check(
            "placeholder_and_unlocked_contract_fails",
            proc.returncode != 0 and "未锁定" in proc.stdout + proc.stderr and "占位" in proc.stdout + proc.stderr,
            proc.stdout + proc.stderr,
        )

        missing_dataset = combination_case()
        missing_dataset.pop("dataset_id")
        project, proc = scenario("missing_dataset", [missing_dataset])
        projects.append(project)
        check(
            "combination_method_requires_dataset_id",
            proc.returncode != 0 and "缺 dataset_id" in proc.stdout + proc.stderr,
            proc.stdout + proc.stderr,
        )

        project, proc = scenario(
            "duplicate_dataset",
            [combination_case("SAVE_DT_001", "CASE::COMBO-A"),
             combination_case("SAVE_DT_001", "CASE::COMBO-B")],
        )
        projects.append(project)
        check(
            "dataset_id_is_globally_unique",
            proc.returncode != 0 and "dataset_id 全项目重复" in proc.stdout + proc.stderr,
            proc.stdout + proc.stderr,
        )

        duplicate_body_a = combination_case("SAVE_DT_BODY_001", "CASE::COMBO-BODY-A")
        duplicate_body_b = combination_case("SAVE_DT_BODY_002", "CASE::COMBO-BODY-B")
        duplicate_body_b["factors"] = ["账号登录=是", "设备绑定=否"]
        duplicate_body_b["tp"] = "验证已登录未绑定组合下保存入口"
        project, proc = scenario("duplicate_combination_body", [duplicate_body_a, duplicate_body_b])
        projects.append(project)
        check(
            "combination_rows_must_instantiate_factors_in_manual_body",
            proc.returncode != 0 and "组合方法数据行人工正文重复" in proc.stdout + proc.stderr,
            proc.stdout + proc.stderr,
        )

        instantiated_body_a = combination_case("SAVE_DT_BODY_003", "CASE::COMBO-BODY-C")
        instantiated_body_b = combination_case("SAVE_DT_BODY_004", "CASE::COMBO-BODY-D")
        instantiated_body_b["factors"] = ["账号登录=是", "设备绑定=否"]
        instantiated_body_b["preconditions"] = ["账号已登录", "设备未绑定", "已生成一条待保存记录"]
        instantiated_body_b["factor_evidence"][0] = {
            "factor": "账号登录=是", "field": "pre", "fragments": ["账号已登录"],
        }
        project, proc = scenario("instantiated_combination_body", [instantiated_body_a, instantiated_body_b])
        projects.append(project)
        check(
            "combination_rows_with_instantiated_manual_body_pass",
            proc.returncode == 0 and len(generated_rows(project)) == 2,
            proc.stdout + proc.stderr,
        )

        project, proc = scenario("summary_combo", [combination_case(summary=True)])
        projects.append(project)
        check(
            "combination_summary_sentence_fails",
            proc.returncode != 0 and "概括式组合描述" in proc.stdout + proc.stderr,
            proc.stdout + proc.stderr,
        )

        insufficient_contract = valid_contract()
        insufficient_contract["combination_dataset_plan"][0]["minimum_rows"] = 2
        project, proc = scenario(
            "insufficient_combo_rows", [combination_case()], require_contract=True,
            contract=insufficient_contract,
        )
        projects.append(project)
        check(
            "contract_combination_plan_requires_real_rows",
            proc.returncode != 0 and "至少2行" in proc.stdout + proc.stderr and "仅有1行" in proc.stdout + proc.stderr,
            proc.stdout + proc.stderr,
        )

        contract = valid_contract()
        project, proc = scenario(
            "valid_contract", [combination_case()], require_contract=True, contract=contract,
        )
        projects.append(project)
        rows = generated_rows(project) if proc.returncode == 0 else []
        check(
            "valid_locked_contract_generates_with_metadata",
            proc.returncode == 0 and rows and rows[0].get("_method") == "判定表法" and
            rows[0].get("_dataset_id") == "SAVE_DT_001" and
            rows[0].get("_factors") == ["账号登录=否", "设备绑定=否"] and
            rows[0].get("_design", {}).get("factor_evidence") == combination_case()["factor_evidence"],
            proc.stdout + proc.stderr + str(rows),
        )

        ordered = ordered_combination_case()
        project, proc = scenario(
            "ordered_factor_evidence", [ordered], require_contract=True,
            contract=valid_contract(),
        )
        projects.append(project)
        check(
            "factor_evidence_accepts_ordered_fragments_in_structured_body",
            proc.returncode == 0 and len(generated_rows(project)) == 1,
            proc.stdout + proc.stderr,
        )

        missing_factor_evidence = combination_case("SAVE_DT_EV_MISSING", "CASE::EV-MISSING")
        missing_factor_evidence.pop("factor_evidence")
        project, proc = scenario(
            "missing_factor_evidence", [missing_factor_evidence], require_contract=True,
            contract=valid_contract(), precreate_cases=True,
        )
        projects.append(project)
        check(
            "schema_v3_blocks_missing_factor_evidence_before_write",
            proc.returncode != 0 and "缺 factor_evidence" in proc.stdout + proc.stderr and
            (project / "cases" / "sentinel.txt").read_text(encoding="utf-8") == "unchanged",
            proc.stdout + proc.stderr,
        )

        evidence_missing_factor = combination_case("SAVE_DT_EV_GAP", "CASE::EV-GAP")
        evidence_missing_factor["factor_evidence"] = evidence_missing_factor["factor_evidence"][:1]
        project, proc = scenario(
            "factor_evidence_gap", [evidence_missing_factor], require_contract=True,
            contract=valid_contract(),
        )
        projects.append(project)
        check(
            "factor_evidence_requires_exactly_one_entry_per_factor",
            proc.returncode != 0 and "缺少 factors 证据" in proc.stdout + proc.stderr,
            proc.stdout + proc.stderr,
        )

        evidence_extra = combination_case("SAVE_DT_EV_EXTRA", "CASE::EV-EXTRA")
        evidence_extra["factor_evidence"].append({
            "factor": "网络=在线", "field": "pre", "fragments": ["账号未登录"],
        })
        project, proc = scenario(
            "factor_evidence_extra", [evidence_extra], require_contract=True,
            contract=valid_contract(),
        )
        projects.append(project)
        check(
            "factor_evidence_rejects_extra_factor",
            proc.returncode != 0 and "包含额外因子" in proc.stdout + proc.stderr,
            proc.stdout + proc.stderr,
        )

        evidence_duplicate = combination_case("SAVE_DT_EV_DUP", "CASE::EV-DUP")
        evidence_duplicate["factor_evidence"].append(copy.deepcopy(evidence_duplicate["factor_evidence"][0]))
        project, proc = scenario(
            "factor_evidence_duplicate", [evidence_duplicate], require_contract=True,
            contract=valid_contract(),
        )
        projects.append(project)
        check(
            "factor_evidence_rejects_duplicate_factor",
            proc.returncode != 0 and "factor_evidence 因子重复" in proc.stdout + proc.stderr,
            proc.stdout + proc.stderr,
        )

        evidence_bad_field = combination_case("SAVE_DT_EV_FIELD", "CASE::EV-FIELD")
        evidence_bad_field["factor_evidence"][0]["field"] = "tp"
        project, proc = scenario(
            "factor_evidence_bad_field", [evidence_bad_field], require_contract=True,
            contract=valid_contract(),
        )
        projects.append(project)
        check(
            "factor_evidence_rejects_non_body_field",
            proc.returncode != 0 and "仅允许 pre/step/exp" in proc.stdout + proc.stderr,
            proc.stdout + proc.stderr,
        )

        evidence_bad_fragment = combination_case("SAVE_DT_EV_TEXT", "CASE::EV-TEXT")
        evidence_bad_fragment["factor_evidence"][0]["fragments"] = ["账号已经登录"]
        project, proc = scenario(
            "factor_evidence_bad_fragment", [evidence_bad_fragment], require_contract=True,
            contract=valid_contract(),
        )
        projects.append(project)
        check(
            "factor_evidence_fragment_must_exist_in_declared_body_field",
            proc.returncode != 0 and "不存在于 pre 人工正文" in proc.stdout + proc.stderr,
            proc.stdout + proc.stderr,
        )

        evidence_short_fragment = combination_case("SAVE_DT_EV_SHORT", "CASE::EV-SHORT")
        evidence_short_fragment["factor_evidence"][0]["fragments"] = ["否"]
        project, proc = scenario(
            "factor_evidence_short_fragment", [evidence_short_fragment], require_contract=True,
            contract=valid_contract(),
        )
        projects.append(project)
        check(
            "factor_evidence_rejects_ambiguous_single_character_level",
            proc.returncode != 0 and "有效字符少于2个" in proc.stdout + proc.stderr,
            proc.stdout + proc.stderr,
        )

        evidence_wrong_order = ordered_combination_case()
        evidence_wrong_order["dataset_id"] = "ORDER_DT_002"
        evidence_wrong_order["_stable_id"] = "CASE::ORDERED-COMBO-002"
        evidence_wrong_order["factor_evidence"][2]["fragments"] = ["设备闹钟到点", "发送消息"]
        project, proc = scenario(
            "factor_evidence_wrong_order", [evidence_wrong_order], require_contract=True,
            contract=valid_contract(),
        )
        projects.append(project)
        check(
            "factor_evidence_rejects_fragment_order_mismatch",
            proc.returncode != 0 and "正文中的顺序错误" in proc.stdout + proc.stderr,
            proc.stdout + proc.stderr,
        )

        evidence_one_order_fragment = ordered_combination_case()
        evidence_one_order_fragment["dataset_id"] = "ORDER_DT_003"
        evidence_one_order_fragment["_stable_id"] = "CASE::ORDERED-COMBO-003"
        evidence_one_order_fragment["factor_evidence"][2]["fragments"] = ["发送消息"]
        project, proc = scenario(
            "factor_evidence_one_order_fragment", [evidence_one_order_fragment], require_contract=True,
            contract=valid_contract(),
        )
        projects.append(project)
        check(
            "ordered_factor_requires_two_evidence_fragments",
            proc.returncode != 0 and "至少需要2个有序正文片段" in proc.stdout + proc.stderr,
            proc.stdout + proc.stderr,
        )

        legacy_without_evidence = combination_case("SAVE_DT_LEGACY_EV", "CASE::LEGACY-EV")
        legacy_without_evidence.pop("factor_evidence")
        legacy_contract = valid_contract()
        legacy_contract["schema_version"] = 1
        project, proc = scenario(
            "legacy_factor_evidence_compat", [legacy_without_evidence], require_contract=True,
            contract=legacy_contract,
        )
        projects.append(project)
        check(
            "schema_v1_without_explicit_manual_contract_remains_compatible",
            proc.returncode == 0,
            proc.stdout + proc.stderr,
        )

        explicit_manual_without_evidence = combination_case("SAVE_DT_MANUAL_EV", "CASE::MANUAL-EV")
        explicit_manual_without_evidence.pop("factor_evidence")
        project, proc = scenario(
            "explicit_manual_factor_evidence", [explicit_manual_without_evidence],
            require_contract=True, contract=legacy_contract, manual_contract_required=True,
        )
        projects.append(project)
        check(
            "explicit_manual_contract_requires_factor_evidence_even_on_schema_v1",
            proc.returncode != 0 and "缺 factor_evidence" in proc.stdout + proc.stderr,
            proc.stdout + proc.stderr,
        )

        fullwidth_factor = combination_case("SAVE_DT_EV_WIDTH", "CASE::EV-WIDTH")
        fullwidth_factor["factors"] = ["账号登录：否", "设备绑定＝否"]
        fullwidth_factor["factor_evidence"][0]["factor"] = "账号登录＝否"
        fullwidth_factor["factor_evidence"][1]["factor"] = "设备绑定:否"
        project, proc = scenario(
            "factor_evidence_fullwidth", [fullwidth_factor], require_contract=True,
            contract=valid_contract(),
        )
        projects.append(project)
        check(
            "factor_and_evidence_share_fullwidth_separator_normalization",
            proc.returncode == 0,
            proc.stdout + proc.stderr,
        )

        polarity_bypass = combination_case("SAVE_DT_EV_POLARITY", "CASE::EV-POLARITY")
        polarity_bypass["factors"][0] = "账号登录=是"
        polarity_bypass["factor_evidence"][0]["factor"] = "账号登录=是"
        project, proc = scenario(
            "factor_evidence_polarity_bypass", [polarity_bypass], require_contract=True,
            contract=valid_contract(),
        )
        projects.append(project)
        check(
            "factor_evidence_rejects_opposite_polarity_substring",
            proc.returncode != 0 and "证据未受控绑定" in proc.stdout + proc.stderr,
            proc.stdout + proc.stderr,
        )

        reused_fragment = combination_case("SAVE_DT_EV_REUSE", "CASE::EV-REUSE")
        reused_fragment["factor_evidence"][1]["fragments"] = ["账号未登录"]
        project, proc = scenario(
            "factor_evidence_cross_factor_reuse", [reused_fragment], require_contract=True,
            contract=valid_contract(),
        )
        projects.append(project)
        check(
            "factor_evidence_rejects_cross_factor_fragment_reuse",
            proc.returncode != 0 and "与其他factor复用同一证据片段" in proc.stdout + proc.stderr,
            proc.stdout + proc.stderr,
        )

        duplicate_order_fragment = ordered_combination_case()
        duplicate_order_fragment["dataset_id"] = "ORDER_DT_004"
        duplicate_order_fragment["_stable_id"] = "CASE::ORDERED-COMBO-004"
        duplicate_order_fragment["factor_evidence"][2]["fragments"] = [
            "向测试手机发送消息", "向测试手机发送消息",
        ]
        project, proc = scenario(
            "factor_evidence_duplicate_order_fragment", [duplicate_order_fragment],
            require_contract=True, contract=valid_contract(),
        )
        projects.append(project)
        check(
            "ordered_factor_rejects_duplicate_action_anchor",
            proc.returncode != 0 and "顺序证据片段必须互异" in proc.stdout + proc.stderr,
            proc.stdout + proc.stderr,
        )

        alternate_order = ordered_combination_case()
        alternate_order["dataset_id"] = "ORDER_DT_005"
        alternate_order["_stable_id"] = "CASE::ORDERED-COMBO-005"
        alternate_order["factors"][2] = "时序=先消息再闹钟"
        alternate_order["factor_evidence"][2]["factor"] = "时序：先消息再闹钟"
        project, proc = scenario(
            "factor_evidence_alternate_order", [alternate_order], require_contract=True,
            contract=valid_contract(),
        )
        projects.append(project)
        check(
            "order_factor_name_and_natural_value_forms_are_enforced",
            proc.returncode == 0,
            proc.stdout + proc.stderr,
        )

        default_pre_case = combination_case("SAVE_DT_EV_DEFAULT_PRE", "CASE::EV-DEFAULT-PRE")
        default_pre_case.pop("preconditions")
        default_pre_case["step"] = "1.点击保存\n2.返回记录列表"
        default_pre_case["exp"] = "1.记录保存成功\n2.列表展示新增记录"
        default_pre_case.pop("steps")
        default_pre_case.pop("expected")
        project, proc = scenario(
            "factor_evidence_default_pre", [default_pre_case], require_contract=True,
            contract=valid_contract(), default_pre="1.账号未登录\n2.设备未绑定\n3.已生成一条待保存记录",
        )
        projects.append(project)
        check(
            "factor_evidence_pre_uses_effective_default_pre",
            proc.returncode == 0,
            proc.stdout + proc.stderr,
        )

        legacy_explicit_invalid = combination_case("SAVE_DT_LEGACY_BAD_EV", "CASE::LEGACY-BAD-EV")
        legacy_explicit_invalid["factor_evidence"][0]["fragments"] = ["完全不存在的登录状态"]
        project, proc = scenario(
            "legacy_explicit_bad_factor_evidence", [legacy_explicit_invalid],
            require_contract=True, contract=legacy_contract,
        )
        projects.append(project)
        check(
            "legacy_may_omit_but_cannot_propagate_explicit_invalid_evidence",
            proc.returncode != 0 and "不存在于 pre 人工正文" in proc.stdout + proc.stderr,
            proc.stdout + proc.stderr,
        )

        missing_risk_evidence = valid_contract()
        missing_risk_evidence["pilot_risk_evidence"] = missing_risk_evidence["pilot_risk_evidence"][:-1]
        project, proc = scenario(
            "missing_pilot_risk_evidence", [combination_case()], require_contract=True,
            contract=missing_risk_evidence,
        )
        projects.append(project)
        check(
            "schema_v3_requires_each_pilot_risk_type_to_have_module_evidence",
            proc.returncode != 0 and "缺逐模块证据绑定" in proc.stdout + proc.stderr,
            proc.stdout + proc.stderr,
        )

        missing_evidence_file = valid_contract()
        missing_evidence_file["pilot_risk_evidence"][0]["evidence_path"] = "pilot_evidence/not-created.json"
        project, proc = scenario(
            "missing_pilot_evidence_file", [combination_case()], require_contract=True,
            contract=missing_evidence_file,
        )
        projects.append(project)
        check(
            "schema_v3_requires_pilot_evidence_file_to_exist",
            proc.returncode != 0 and "证据文件不存在" in proc.stdout + proc.stderr,
            proc.stdout + proc.stderr,
        )

        risk_case = combination_case("SAVE_DT_RISK", "CASE::COMBO-RISK")
        risk_case["risk"] = {
            "state": "pending_confirmation",
            "owner": "产品",
            "question": "确认保存与设备同步的最终时序",
        }
        project, proc = scenario(
            "risk_metadata_trace_chain", [risk_case], require_contract=True,
            contract=valid_contract(),
        )
        projects.append(project)
        generated = generated_rows(project) if proc.returncode == 0 else []
        xlsx = project / "risk-chain.xlsx"
        export_proc = subprocess.run(
            [
                sys.executable, str(SCRIPTS / "export_cases.py"),
                "--project", project.name, "--out", str(xlsx),
                "--order", "记录", "先导模块B", "先导模块C",
            ],
            cwd=WORKFLOW, text=True, capture_output=True, encoding="utf-8", errors="replace",
        ) if generated else None
        loaded = trace_extract.load_cases(
            xlsx,
            [{"name": "记录"}],
            {"id": 1, "功能点": 3, "测试项": 4, "测试点": 5, "前置": 6, "步骤": 7, "预期": 8},
        ).get("记录", []) if export_proc and export_proc.returncode == 0 else []
        loaded_case = next((row for row in loaded if row.get("id") == "SAVE_001"), {})
        evidence_item = {"status": "已覆盖", "matched_ids": ["SAVE_001"]}
        if loaded_case:
            trace_gate.derive_item_evidence(evidence_item, {"SAVE_001": loaded_case})
        check(
            "risk_metadata_survives_casegen_export_trace_chain",
            bool(generated) and generated[0].get("_risk", {}).get("state") == "pending_confirmation" and
            generated[0].get("_design", {}).get("dataset_id") == "SAVE_DT_RISK" and
            generated[0].get("_detail_contract", {}).get("source_kind") == "structured" and
            loaded_case.get("risk", {}).get("state") == "pending_confirmation" and
            loaded_case.get("design", {}).get("dataset_id") == "SAVE_DT_RISK" and
            loaded_case.get("detail_contract", {}).get("source_kind") == "structured" and
            evidence_item.get("coverage_state") == "covered_pending_only",
            (proc.stdout + proc.stderr) +
            ((export_proc.stdout + export_proc.stderr) if export_proc else "") +
            str({"generated": generated, "loaded": loaded_case, "evidence": evidence_item}),
        )

        pilot_contract = valid_contract()
        pilot_contract["pilot_acceptance"] = {
            "status": "pending", "evidence": "<先导模块审查证据>", "locked": False,
        }
        pilot_contract["pilot_modules"] = ["记录", "先导模块B", "先导模块C"]
        project = Path(tempfile.mkdtemp(prefix="_generation_contract_pilot_first_", dir=PROJECTS))
        projects.append(project)
        write_project(
            project, [combination_case()], require_contract=True, contract=pilot_contract,
            extra_modules=True,
        )
        # 合同范围再增加一个尚未产出spec的模块，验证先导模式可先跑、正式模式仍阻断。
        pilot_contract["modules"].append({
            "name": "尚未扩量模块", "prefix": "EXPAND", "prefix_locked": True,
            "in_scope": True, "applicable_test_methods": ["等价类划分法"],
        })
        pilot_contract["module_order"]["items"].append("尚未扩量模块")
        trace_config = json.loads((project / "trace.config.json").read_text(encoding="utf-8"))
        trace_config["modules"].append({"name": "尚未扩量模块", "prefix": "EXPAND"})
        (project / "trace.config.json").write_text(
            json.dumps(trace_config, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        (project / "生成验收合同.json").write_text(
            json.dumps(pilot_contract, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        pilot_proc = run_casegen(project.name, pilot=True)
        pilot_files = sorted(path.name for path in (project / "pilot_cases").glob("*.json")) \
            if (project / "pilot_cases").exists() else []
        full_before_acceptance = run_casegen(project.name)
        check(
            "pilot_mode_runs_before_full_specs_and_acceptance",
            pilot_proc.returncode == 0 and len(pilot_files) == 3 and
            not (project / "cases").exists(),
            pilot_proc.stdout + pilot_proc.stderr + str(pilot_files),
        )
        check(
            "full_generation_blocks_before_pilot_acceptance",
            full_before_acceptance.returncode != 0 and
            "先导模块未验收通过" in full_before_acceptance.stdout + full_before_acceptance.stderr and
            "尚未扩量模块" in full_before_acceptance.stdout + full_before_acceptance.stderr,
            full_before_acceptance.stdout + full_before_acceptance.stderr,
        )
        # 完成先导审查并补齐剩余spec后，正式模式应通过且不覆盖pilot_cases。
        pilot_contract["pilot_acceptance"] = {
            "status": "passed", "evidence": "先导模块逐条语义审查通过", "locked": True,
        }
        (project / "生成验收合同.json").write_text(
            json.dumps(pilot_contract, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        (project / "specs" / "尚未扩量模块.json").write_text(json.dumps({
            "module": "尚未扩量模块", "prefix": "EXPAND",
            "cases": [dict(legacy_case(), _stable_id="CASE::EXPANDED")],
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        full_after_acceptance = run_casegen(project.name)
        check(
            "full_generation_passes_after_pilot_acceptance_and_expansion",
            full_after_acceptance.returncode == 0 and
            (project / "cases" / "尚未扩量模块.json").exists() and
            len(pilot_files) == len(list((project / "pilot_cases").glob("*.json"))),
            full_after_acceptance.stdout + full_after_acceptance.stderr,
        )

        project = Path(tempfile.mkdtemp(prefix="_generation_contract_pilot_full_config_", dir=PROJECTS))
        projects.append(project)
        write_project(
            project, [combination_case()], require_contract=True, contract=pilot_contract,
            extra_modules=True,
        )
        (project / "specs" / "尚未扩量模块.json").write_text(json.dumps({
            "module": "尚未扩量模块", "prefix": "EXPAND",
            "cases": [dict(legacy_case(), _stable_id="CASE::EXPAND-FULL-CONFIG")],
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        trace_config = json.loads((project / "trace.config.json").read_text(encoding="utf-8"))
        trace_config["modules"].append({"name": "尚未扩量模块", "prefix": "EXPAND"})
        (project / "trace.config.json").write_text(
            json.dumps(trace_config, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        (project / "ui_pages.json").write_text(json.dumps({
            "记录": [{"page": "记录首页", "fp": "记录保存"}],
            "尚未扩量模块": [{"page": "扩量页面", "fp": "扩量入口"}],
        }, ensure_ascii=False, indent=2), encoding="utf-8")
        (project / "cross.json").write_text(json.dumps({"items": [
            {
                "matrix_key": "记录|网络中断", "status": "covered", "coverage_kind": "generated",
                "affected_module": "记录", "action": "网络中断", "state": "保存中",
                "test_point": "验证保存中网络中断提示", "preconditions": "1.记录正在保存",
                "steps": "1.断开网络", "expected": "1.页面显示保存失败提示",
            },
            {
                "matrix_key": "扩量|网络中断", "status": "covered", "coverage_kind": "generated",
                "affected_module": "尚未扩量模块", "action": "网络中断", "state": "运行中",
                "test_point": "验证扩量流程网络中断提示", "preconditions": "1.扩量流程正在运行",
                "steps": "1.断开网络", "expected": "1.页面显示中断提示",
            },
        ]}, ensure_ascii=False, indent=2), encoding="utf-8")
        pilot_with_full_config = run_casegen(project.name, pilot=True)
        pilot_output = json.loads((project / "pilot_cases" / "记录.json").read_text(encoding="utf-8"))["cases"] \
            if pilot_with_full_config.returncode == 0 else []
        check(
            "pilot_mode_filters_non_pilot_ui_and_cross_config",
            pilot_with_full_config.returncode == 0 and
            not (project / "pilot_cases" / "尚未扩量模块.json").exists() and
            any(row.get("_matrix_key") == "记录|网络中断" for row in pilot_output) and
            not any(row.get("_matrix_key") == "扩量|网络中断" for row in pilot_output),
            pilot_with_full_config.stdout + pilot_with_full_config.stderr + str(pilot_output),
        )

        project = Path(tempfile.mkdtemp(prefix="_generation_contract_prefix_duplicate_", dir=PROJECTS))
        projects.append(project)
        write_project(project, [legacy_case()], require_contract=False, contract=None, extra_modules=True)
        duplicate_payload = json.loads((project / "specs" / "先导模块B.json").read_text(encoding="utf-8"))
        duplicate_payload["prefix"] = "SAVE"
        (project / "specs" / "先导模块B.json").write_text(
            json.dumps(duplicate_payload, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        duplicate_prefix_proc = run_casegen(project.name)
        check(
            "spec_prefix_must_be_globally_unique",
            duplicate_prefix_proc.returncode != 0 and
            "prefix 全项目重复" in duplicate_prefix_proc.stdout + duplicate_prefix_proc.stderr,
            duplicate_prefix_proc.stdout + duplicate_prefix_proc.stderr,
        )

        prefix_contract = valid_contract()
        prefix_contract["modules"][0]["prefix"] = "DIFFERENT"
        project, proc = scenario(
            "contract_prefix_mismatch", [combination_case()], require_contract=True,
            contract=prefix_contract,
        )
        projects.append(project)
        check(
            "contract_locks_module_prefix_against_spec",
            proc.returncode != 0 and "prefix 与合同不一致" in proc.stdout + proc.stderr,
            proc.stdout + proc.stderr,
        )

        scratch_name = "_generation_contract_new_project_template"
        scratch = PROJECTS / scratch_name
        if scratch.exists():
            shutil.rmtree(scratch)
        template_proc = subprocess.run(
            [sys.executable, str(SCRIPTS / "new_project.py"), "--name", scratch_name],
            cwd=WORKFLOW, text=True, capture_output=True, encoding="utf-8", errors="replace",
        )
        projects.append(scratch)
        config = json.loads((scratch / "trace.config.json").read_text(encoding="utf-8")) if template_proc.returncode == 0 else {}
        template = json.loads((scratch / "生成验收合同.json").read_text(encoding="utf-8")) if template_proc.returncode == 0 else {}
        decision_ledger = json.loads(
            (scratch / "工作底稿" / "需求决策账本.json").read_text(encoding="utf-8")
        ) if template_proc.returncode == 0 and (scratch / "工作底稿" / "需求决策账本.json").exists() else {}
        multi_round_review = json.loads(
            (scratch / "工作底稿" / "多轮测试用例评审.json").read_text(encoding="utf-8")
        ) if template_proc.returncode == 0 and (scratch / "工作底稿" / "多轮测试用例评审.json").exists() else {}
        project_blueprint = json.loads(
            (scratch / "用例设计蓝图.json").read_text(encoding="utf-8")
        ) if template_proc.returncode == 0 else {}
        check(
            "new_project_enables_strict_contract_template",
            template_proc.returncode == 0 and config.get("generation_contract") == {
                "required": True, "file": "生成验收合同.json",
            } and config.get("coverage_policy", {}).get("pending_evidence_mode") == "require_acceptance" and
            config.get("coverage_policy", {}).get("accepted_pending_req_ids") == [] and
            config.get("release_acceptance", {}).get("strata_not_applicable") == {} and
            template.get("contract_state") == "draft" and
            template.get("product_form", {}).get("locked") is False and
            template.get("modules", [{}])[0].get("prefix_locked") is False and
            template.get("module_order", {}).get("locked") is False and
            template.get("test_item_taxonomy", {}).get("locked") is False and
            template.get("design_contract", {}).get("locked") is False and
            template.get("coverage_policy", {}).get("locked") is False and
            len(template.get("pilot_modules", [])) == 3 and
            config.get("release_acceptance", {}).get("decision_ledger_file") == "工作底稿/需求决策账本.json" and
            config.get("release_acceptance", {}).get("multi_round_review_required") is True and
            config.get("release_acceptance", {}).get("multi_agent_review_required") is True and
            config.get("release_acceptance", {}).get("multi_round_review_file") == "工作底稿/多轮测试用例评审.json" and
            config.get("out_dirs", {}).get("draft") == "工作底稿/追溯" and
            config.get("quality_gates", {}).get("functional_manual_contract", {}).get("required") is True and
            config.get("quality_gates", {}).get("common_fixtures", {}).get("fixture_ids") == [] and
            config.get("quality_gates", {}).get("production_semantics", {}).get("preconditions", {}).get("fixture_ids") == [] and
            config.get("quality_gates", {}).get("production_semantics", {}).get("parameter_values") == {
                "enabled": True,
                "require_explicit_value": True,
                "require_value_in_steps_and_expected": True,
                "actual_value_labels": [],
            } and
            "BASE_ENV" not in json.dumps(project_blueprint, ensure_ascii=False) and
            decision_ledger.get("schema_version") == 1 and decision_ledger.get("items") == [] and
            multi_round_review.get("schema_version") == 2 and
            multi_round_review.get("generator_agent_ids") == ["<生成Agent ID>"] and
            multi_round_review.get("reviser_agent_ids") == ["<修订Agent ID>"] and
            (scratch / "工作底稿" / "agent_reviews").is_dir() and
            multi_round_review.get("required_review_types") == [
                "coverage_design", "execution_detail", "adversarial", "regression"
            ] and multi_round_review.get("rounds") == [],
            template_proc.stdout + template_proc.stderr + str(config) + str(template) + str(project_blueprint) + str(decision_ledger) + str(multi_round_review),
        )

        bad_contract = valid_contract()
        bad_contract["pilot_acceptance"]["status"] = "pending"
        project, proc = scenario(
            "zero_write", [combination_case()], require_contract=True, contract=bad_contract,
            precreate_cases=True,
        )
        projects.append(project)
        spec_payload = json.loads((project / "specs" / "记录.json").read_text(encoding="utf-8"))
        sentinel_ok = (project / "cases" / "sentinel.txt").read_text(encoding="utf-8") == "unchanged"
        check(
            "contract_failure_has_zero_generation_writes",
            proc.returncode != 0 and
            "先导模块未验收通过" in proc.stdout + proc.stderr and
            "_stable_id" in spec_payload["cases"][0] and
            not (project / "cases" / "记录.json").exists() and sentinel_ok,
            proc.stdout + proc.stderr,
        )

        no_id_combo = combination_case()
        no_id_combo.pop("_stable_id")
        project, proc = scenario(
            "zero_write_id", [no_id_combo], require_contract=True, contract=bad_contract,
        )
        projects.append(project)
        spec_payload = json.loads((project / "specs" / "记录.json").read_text(encoding="utf-8"))
        check(
            "contract_failure_does_not_bootstrap_stable_ids",
            proc.returncode != 0 and "_stable_id" not in spec_payload["cases"][0],
            proc.stdout + proc.stderr + str(spec_payload),
        )

        project, first_proc = scenario(
            "stale_cases_module", [combination_case()], require_contract=True,
            contract=valid_contract(),
        )
        projects.append(project)
        stale_path = project / "cases" / "旧模块.json"
        stale_path.write_text(json.dumps({"module": "旧模块", "cases": []}, ensure_ascii=False), encoding="utf-8")
        stale_proc = run_casegen(project.name)
        check(
            "schema_v3_rejects_stale_cases_module_file",
            first_proc.returncode == 0 and stale_proc.returncode != 0 and "非当前模块旧文件" in stale_proc.stdout + stale_proc.stderr,
            first_proc.stdout + first_proc.stderr + stale_proc.stdout + stale_proc.stderr,
        )
    finally:
        for project in projects:
            if project.exists():
                shutil.rmtree(project)

    output = {"success": not errors, "results": results, "errors": errors}
    print(json.dumps(output, ensure_ascii=False, indent=2))
    if errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
