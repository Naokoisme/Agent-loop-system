# -*- coding: utf-8 -*-
"""通用覆盖追溯 门禁。

读 <out_dirs.result>/<模块>.json → 算每模块 + 整体覆盖率（已覆盖/可测）
→ 与 config.coverage_threshold 比较：
  - 整体达标、无未覆盖 applicable 项、且部分覆盖策略满足 → PASS（退出码 0）
  - 否则 FAIL（退出码 1），并把每模块未覆盖/部分覆盖的可测项写成
    <out_dirs.gaps>/gaps_<模块>.json，供 AI 补充用例。

注意：本门禁只证明 PRD 显式条款追溯，不证明“全功能场景完整”。
全功能准出还必须通过 Gate C 的 scenario_coverage（S34）和最终 Excel 实物验收。
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

try:  # package import (judge_build/tests) and direct script execution are both supported
    from ._common import dump_json, load_config, load_json
except ImportError:  # pragma: no cover - exercised by direct CLI invocation
    from _common import dump_json, load_config, load_json


ALLOWED_STATUSES = {"已覆盖", "部分覆盖", "未覆盖", "非可测项"}
ALLOWED_COVERAGE_STATES = {
    "covered_confirmed", "covered_with_pending", "covered_pending_only",
    "partial", "uncovered", "not_testable",
}
ALLOWED_EVIDENCE_STATES = {"confirmed_only", "mixed_pending", "pending_only", "none"}
PENDING_MARKERS = ("待确认", "待产品确认", "待研发确认", "待硬件确认")


def _risk_metadata_is_pending(value: object) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, dict):
        if isinstance(value.get("pending"), bool):
            return bool(value["pending"])
        if isinstance(value.get("confirmed"), bool):
            return not bool(value["confirmed"])
        state = str(value.get("state", value.get("status", value.get("kind", ""))) or "").strip().lower()
        if state in {"confirmed", "resolved", "closed", "none", "not_applicable"}:
            return False
        if state in {"pending", "pending_confirmation", "unconfirmed", "accepted_risk", "risk"}:
            return True
        return any(marker in str(value) for marker in PENDING_MARKERS)
    text = str(value or "").strip().lower()
    if text in {"confirmed", "resolved", "closed", "none", "not_applicable", "false", "0"}:
        return False
    if text in {"pending", "pending_confirmation", "unconfirmed", "accepted_risk", "risk", "true", "1"}:
        return True
    return any(marker in str(value or "") for marker in PENDING_MARKERS)


def case_has_pending_risk(case: dict) -> bool:
    """Prefer explicit risk metadata; fall back to legacy confirmation markers."""
    if "risk" in case:
        return _risk_metadata_is_pending(case.get("risk"))
    legacy_text = "|".join(str(value) for value in case.values())
    return any(marker in legacy_text for marker in PENDING_MARKERS)


def derive_item_evidence(item: dict, cases_by_id: dict[str, dict]) -> tuple[str, str]:
    """Attach compatible derived coverage/evidence states to a result item."""
    status = str(item.get("status", "") or "")
    matched = item.get("matched_ids", [])
    matched = matched if isinstance(matched, list) else []
    flags = [case_has_pending_risk(cases_by_id[case_id]) for case_id in matched if case_id in cases_by_id]
    if not flags:
        evidence_state = "none" if not matched else "confirmed_only"
    elif all(flags):
        evidence_state = "pending_only"
    elif any(flags):
        evidence_state = "mixed_pending"
    else:
        evidence_state = "confirmed_only"

    if status == "已覆盖":
        coverage_state = {
            "pending_only": "covered_pending_only",
            "mixed_pending": "covered_with_pending",
        }.get(evidence_state, "covered_confirmed")
    elif status == "部分覆盖":
        coverage_state = "partial"
    elif status == "未覆盖":
        coverage_state = "uncovered"
    else:
        coverage_state = "not_testable"
    item["coverage_state"] = coverage_state
    item["evidence_state"] = evidence_state
    return coverage_state, evidence_state


def validate_result_items(module: str, items: object) -> list[str]:
    errors: list[str] = []
    if not isinstance(items, list):
        return [f"{module}: 判定结果 items 必须是数组"]
    req_ids: list[str] = []
    for index, item in enumerate(items, 1):
        if not isinstance(item, dict):
            errors.append(f"{module}: items[{index}] 必须是对象")
            continue
        req_id = str(item.get("req_id", "") or "")
        status = str(item.get("status", "") or "")
        testable = item.get("testable")
        matched_ids = item.get("matched_ids", [])
        if not req_id:
            errors.append(f"{module}: items[{index}] 缺 req_id")
        req_ids.append(req_id)
        if status not in ALLOWED_STATUSES:
            errors.append(f"{module}/{req_id}: 非法 status={status!r}")
        if not isinstance(testable, bool):
            errors.append(f"{module}/{req_id}: testable 必须是布尔值")
        if not isinstance(matched_ids, list) or not all(isinstance(x, str) and x for x in matched_ids):
            errors.append(f"{module}/{req_id}: matched_ids 必须是非空字符串数组或空数组")
        if status in {"已覆盖", "部分覆盖"} and not matched_ids:
            errors.append(f"{module}/{req_id}: {status} 必须引用 matched_ids")
        if status == "非可测项" and testable is not False:
            errors.append(f"{module}/{req_id}: 非可测项必须 testable=false")
        if status != "非可测项" and testable is not True:
            errors.append(f"{module}/{req_id}: 可测状态必须 testable=true")
        coverage_state = item.get("coverage_state")
        evidence_state = item.get("evidence_state")
        if coverage_state is not None and coverage_state not in ALLOWED_COVERAGE_STATES:
            errors.append(f"{module}/{req_id}: 非法 coverage_state={coverage_state!r}")
        if evidence_state is not None and evidence_state not in ALLOWED_EVIDENCE_STATES:
            errors.append(f"{module}/{req_id}: 非法 evidence_state={evidence_state!r}")
    duplicates = sorted(req_id for req_id in set(req_ids) if req_id and req_ids.count(req_id) > 1)
    if duplicates:
        errors.append(f"{module}: req_id 重复 {duplicates[:20]}")
    return errors


def safe_items(payload: object) -> list[dict]:
    """Return only dict items so malformed judgment output is reported, not crashed on."""
    if not isinstance(payload, dict):
        return []
    items = payload.get("items", [])
    if not isinstance(items, list):
        return []
    return [item for item in items if isinstance(item, dict)]


def load_all_cases(draft_dir: Path) -> dict[str, dict]:
    cases: dict[str, dict] = {}
    for draft_case_path in draft_dir.glob("*.json"):
        try:
            draft_payload = load_json(draft_case_path)
        except Exception:
            continue
        if not isinstance(draft_payload, dict):
            continue
        for item in draft_payload.get("cases", []):
            if not isinstance(item, dict):
                continue
            case_id = str(item.get("id", "") or "")
            if case_id:
                cases[case_id] = item
    return cases


def load_all_case_ids(draft_dir: Path) -> set[str]:
    """Compatibility helper retained for existing callers."""
    return set(load_all_cases(draft_dir))


def collect(cfg):
    res_dir = cfg.out_dir("result")
    draft_dir = cfg.out_dir("draft")
    per_module = []
    tot = dict(
        testable=0, cov=0, part=0, un=0, nt=0,
        covered_confirmed=0, covered_with_pending=0, covered_pending_only=0,
        partial=0, uncovered=0, not_testable=0, pending_evidence=[],
    )
    gaps_by_mod: dict[str, list[dict]] = {}
    validation_errors: list[str] = []
    cross_module_allowed = bool(cfg.raw.get("coverage_policy", {}).get("allow_cross_module_matched_ids", False))
    global_cases = load_all_cases(draft_dir) if cross_module_allowed else {}
    global_case_ids = set(global_cases)
    for name in cfg.module_order:
        f = res_dir / f"{name}.json"
        if not f.exists():
            per_module.append((name, None))
            continue
        result_payload = load_json(f)
        raw_items = result_payload.get("items", []) if isinstance(result_payload, dict) else []
        validation_errors.extend(validate_result_items(name, raw_items))
        items = safe_items(result_payload)
        if not isinstance(result_payload, dict):
            validation_errors.append(f"{name}: 判定结果根节点必须是对象")
        elif str(result_payload.get("module", name)) != name:
            validation_errors.append(f"{name}: result.module 与配置模块不一致")
        draft_file = draft_dir / f"{name}.json"
        module_cases: dict[str, dict] = {}
        if not draft_file.exists():
            validation_errors.append(f"{name}: 缺工作底稿 {draft_file.name}，无法验证req_id和matched_ids")
        else:
            draft = load_json(draft_file)
            expected_req_ids = [str(x.get("req_id", "")) for x in draft.get("requirements", [])]
            actual_req_ids = [str(x.get("req_id", "")) for x in items if isinstance(x, dict)]
            if actual_req_ids != expected_req_ids:
                validation_errors.append(
                    f"{name}: result req_id集合/顺序与工作底稿不一致 expected={expected_req_ids[:10]} actual={actual_req_ids[:10]}"
                )
            module_cases = {
                str(x.get("id", "")): x for x in draft.get("cases", [])
                if isinstance(x, dict) and str(x.get("id", ""))
            }
            case_ids = set(module_cases)
            for item in items:
                req_id = str(item.get("req_id", ""))
                status = str(item.get("status", ""))
                matched = [str(x) for x in item.get("matched_ids", []) if str(x)] if isinstance(item.get("matched_ids", []), list) else []
                valid_ids = global_case_ids if cross_module_allowed else case_ids
                invalid = [case_id for case_id in matched if case_id not in valid_ids]
                if invalid:
                    scope = "全部模块" if cross_module_allowed else "本模块"
                    validation_errors.append(f"{name}/{req_id}: matched_ids引用不存在{scope}用例 {invalid}")
                if status in {"未覆盖", "非可测项"} and matched:
                    validation_errors.append(f"{name}/{req_id}: {status} 不应引用 matched_ids {matched}")
                if status in {"部分覆盖", "未覆盖"} and not str(item.get("note", "") or "").strip():
                    validation_errors.append(f"{name}/{req_id}: {status} 必须写具体note")
        evidence_cases = global_cases if cross_module_allowed else module_cases
        for item in items:
            derive_item_evidence(item, evidence_cases)
        cov = sum(1 for x in items if x["status"] == "已覆盖")
        part = sum(1 for x in items if x["status"] == "部分覆盖")
        un = sum(1 for x in items if x["status"] == "未覆盖")
        nt = sum(1 for x in items if x["status"] == "非可测项")
        testable = cov + part + un
        state_counts = {
            state: sum(1 for x in items if x.get("coverage_state") == state)
            for state in ALLOWED_COVERAGE_STATES
        }
        pending_evidence = [
            {
                "module": name,
                "req_id": str(x.get("req_id", "")),
                "coverage_state": x.get("coverage_state"),
                "evidence_state": x.get("evidence_state"),
            }
            for x in items if x.get("coverage_state") in {"covered_with_pending", "covered_pending_only"}
        ]
        per_module.append((name, dict(
            testable=testable, cov=cov, part=part, un=un, nt=nt,
            pending_evidence=pending_evidence, **state_counts,
        )))
        tot["testable"] += testable
        tot["cov"] += cov
        tot["part"] += part
        tot["un"] += un
        tot["nt"] += nt
        for state, count in state_counts.items():
            tot[state] += count
        tot["pending_evidence"].extend(pending_evidence)
        # 缺口 = 可测且 未覆盖/部分覆盖
        gaps = [
            {"req_id": it["req_id"], "text": it.get("text", ""), "source": it.get("source", ""),
             "status": it["status"], "coverage_state": it.get("coverage_state"),
             "evidence_state": it.get("evidence_state"),
             "matched_ids": it.get("matched_ids", []), "note": it.get("note", "")}
            for it in items if it.get("testable") and it["status"] in ("未覆盖", "部分覆盖")
        ]
        if gaps:
            gaps_by_mod[name] = gaps
    return per_module, tot, gaps_by_mod, validation_errors


def evaluate_pending_evidence_policy(tot: dict, coverage_policy: dict) -> tuple[bool, list[str], list[str]]:
    """Evaluate pending evidence without changing the legacy coverage status model."""
    mode = str(coverage_policy.get("pending_evidence_mode", "report_only") or "report_only")
    if mode not in {"report_only", "require_acceptance", "block"}:
        return False, [], [f"非法 pending_evidence_mode={mode!r}"]
    accepted = {str(value) for value in coverage_policy.get("accepted_pending_req_ids", [])}
    pending_entries = list(tot.get("pending_evidence", []) or [])
    unexpected = [
        f"{entry.get('module','')}/{entry.get('req_id','')}:{entry.get('coverage_state','')}"
        for entry in pending_entries if str(entry.get("req_id", "")) not in accepted
    ]
    if mode == "report_only":
        return True, unexpected, []
    if mode == "block":
        return not pending_entries, unexpected, []
    return not unexpected, unexpected, []


def main() -> None:
    ap = argparse.ArgumentParser(description="覆盖追溯 门禁：算覆盖率、出缺口、PASS/FAIL")
    ap.add_argument("--config", required=True)
    ap.add_argument("--no-gaps", action="store_true", help="只判定，不写 gaps 文件")
    args = ap.parse_args()

    cfg = load_config(args.config)
    thr = cfg.coverage_threshold
    coverage_policy = cfg.raw.get("coverage_policy", {}) or {}
    require_zero_partial = bool(coverage_policy.get("require_zero_partial", True))
    accepted_partial_req_ids = {
        str(x) for x in coverage_policy.get("accepted_partial_req_ids", [])
    }
    per_module, tot, gaps_by_mod, validation_errors = collect(cfg)
    pending_ok, unexpected_pending, pending_policy_errors = evaluate_pending_evidence_policy(tot, coverage_policy)
    validation_errors.extend(pending_policy_errors)
    missing_result_modules = [name for name, summary in per_module if summary is None]

    print(f"{'模块':20s} 可测  已覆盖  部分  未覆盖  覆盖率")
    for name, s in per_module:
        if s is None:
            print(f"{name:20s}  [缺判定结果]")
            continue
        T = s["testable"]
        rate = f"{s['cov'] / T * 100:.1f}%" if T else "-"
        flag = "" if (not T or s["cov"] / T >= thr) else "  ←未达标"
        print(f"{name:20s} {T:4d}  {s['cov']:5d}  {s['part']:4d}  {s['un']:5d}   {rate:>6s}{flag}")

    T = tot["testable"]
    overall = tot["cov"] / T if T else 1.0
    print("-" * 60)
    print(f"{'整体':20s} {T:4d}  {tot['cov']:5d}  {tot['part']:4d}  {tot['un']:5d}   {overall * 100:.1f}%")
    print(f"阈值 {thr * 100:.0f}%  |  含部分 {(tot['cov'] + tot['part']) / T * 100:.1f}%" if T else "")
    print(
        "证据分层 "
        f"确定覆盖 {tot['covered_confirmed']} | 混合待确认 {tot['covered_with_pending']} | "
        f"仅待确认覆盖 {tot['covered_pending_only']}"
    )

    gap_total = sum(len(v) for v in gaps_by_mod.values())
    if not args.no_gaps and gaps_by_mod:
        gaps_dir = cfg.out_dir("gaps")
        for name, gaps in gaps_by_mod.items():
            dump_json({"module": name, "gap_count": len(gaps), "gaps": gaps}, gaps_dir / f"gaps_{name}.json")
        print(f"\n已写缺口清单 {gap_total} 条 -> {gaps_dir}（{len(gaps_by_mod)} 个模块）")

    accepted_partial = 0
    unexpected_partial: list[str] = []
    for name, gaps in gaps_by_mod.items():
        for gap in gaps:
            if gap.get("status") != "部分覆盖":
                continue
            req_id = str(gap.get("req_id", ""))
            if req_id in accepted_partial_req_ids:
                accepted_partial += 1
            else:
                unexpected_partial.append(f"{name}/{req_id}")

    partial_ok = not require_zero_partial or not unexpected_partial
    has_testable_requirements = T > 0
    passed = (
        not missing_result_modules
        and has_testable_requirements
        and overall >= thr
        and tot["un"] == 0
        and partial_ok
        and pending_ok
        and not validation_errors
    )
    print(f"\n门禁结果: {'PASS ✅' if passed else 'FAIL ❌'}"
          f"（整体 {overall * 100:.1f}% vs 阈值 {thr * 100:.0f}%，未覆盖 applicable {tot['un']} 条，"
          f"部分覆盖 {tot['part']} 条/已接受 {accepted_partial} 条）")
    if unexpected_partial:
        print(f"未接受的部分覆盖: {unexpected_partial[:20]}")
    pending_mode = str(coverage_policy.get("pending_evidence_mode", "report_only") or "report_only")
    if unexpected_pending:
        label = "待确认证据风险" if pending_mode == "report_only" else "未接受的待确认证据"
        print(f"{label}: {unexpected_pending[:20]}")
    if missing_result_modules:
        print(f"缺少模块判定结果: {missing_result_modules}")
    if not has_testable_requirements:
        print("可测需求为0：无法把空判定集视为覆盖PASS")
    if validation_errors:
        print("判定结果结构错误:")
        for error in validation_errors[:50]:
            print(f"- {error}")
    print("提示: Gate B 只证明 PRD 显式条款追溯；不得单独据此宣称全功能完整。")
    sys.exit(0 if passed else 1)


if __name__ == "__main__":
    main()
