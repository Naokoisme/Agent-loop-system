# -*- coding: utf-8 -*-
"""通用覆盖追溯 闭环回插。

读 <out_dirs.gaps>/new_<模块>.json（AI 据缺口补的新用例，每条带 _anchor_id 锚点、_covers_req 回指）
按锚点把补充用例插到基线用例表对应行之后，输出补强后用例表。
既有行/顺序/ID 完全不动；新行的「功能模块」取锚点行值以保证合并分组一致。

Excel 读写复用 tc_excel（标准 15 列、主表+分页、样式、合并），不再依赖任何项目专用脚本。
改写自原 scripts/insert_wd11_supplements.py（去硬编码，参数化为 config + CLI）。
"""
from __future__ import annotations

import argparse
import glob
import sys
from collections import defaultdict
from pathlib import Path

# 把 scripts/ 加进 sys.path,确保能 import tc_excel(不依赖 _common 的导入顺序)
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import tc_excel  # noqa: E402
from _common import load_config, load_json  # noqa: E402

COLUMNS = tc_excel.COLUMNS


def load_new_cases(gaps_dir: Path) -> dict[str, list[dict]]:
    """返回 {anchor_id: [case,...]}，保持各文件内顺序。"""
    by_anchor: dict[str, list[dict]] = defaultdict(list)
    total = 0
    for f in sorted(glob.glob(str(gaps_dir / "new_*.json"))):
        d = load_json(f)
        for c in d.get("cases", []):
            anchor = c.get("_anchor_id")
            if not anchor:
                print(f"  [警告] {Path(f).name} 有用例缺 _anchor_id，已跳过: {c.get('用例编号')}")
                continue
            by_anchor[anchor].append(c)
            total += 1
    print(f"待插入补充用例 {total} 条，锚点 {len(by_anchor)} 个")
    return by_anchor


def main() -> None:
    ap = argparse.ArgumentParser(description="覆盖追溯 闭环回插：补充用例按锚点插回主表")
    ap.add_argument("--config", required=True)
    ap.add_argument("--base", required=True, help="基线用例 xlsx（被插入的源）")
    ap.add_argument("--out", required=True, help="补强后用例 xlsx 输出路径")
    args = ap.parse_args()

    cfg = load_config(args.config)
    base_rows = tc_excel.read_master_rows(args.base)
    by_anchor = load_new_cases(cfg.out_dir("gaps"))

    out_rows: list[dict] = []
    inserted = 0
    seen_anchor: set[str] = set()
    for row in base_rows:
        out_rows.append(row)
        rid = str(row.get("用例编号", "")).strip()
        if rid in by_anchor:
            seen_anchor.add(rid)
            for c in by_anchor[rid]:
                newrow = {col: c.get(col, "") for col in COLUMNS}
                newrow["功能模块"] = row["功能模块"]  # 与锚点行一致，保证合并分组
                out_rows.append(newrow)
                inserted += 1

    missing = set(by_anchor) - seen_anchor
    if missing:
        print(f"[警告] 有锚点未在主表命中: {sorted(missing)}")

    print(f"原 {len(base_rows)} 行 + 插入 {inserted} 行 = {len(out_rows)} 行")
    out = tc_excel.write_workbook(out_rows, args.out, module_order=cfg.module_order)
    print(f"已生成 {out}")


if __name__ == "__main__":
    main()
