# -*- coding: utf-8 -*-
"""通用覆盖追溯 步骤3：汇总覆盖矩阵。

读 <out_dirs.result>/<模块>.json（AI 判定产物）+ <out_dirs.draft>/<模块>.json（回填 source/text）
按 config.modules 顺序 → 覆盖矩阵 xlsx：
  - sheet「总览」：各模块需求数/可测数/各状态数/覆盖率
  - 每模块一张 sheet：需求ID/描述/PRD来源/是否可测/覆盖状态/命中用例/说明，状态着色

改写自原 scripts/assemble_wd11_req_traceability.py（去硬编码 ORDER 与路径，参数化为 config）。
"""
from __future__ import annotations

import argparse
from pathlib import Path

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from _common import load_config, load_json

STATUS_FILL = {
    "已覆盖": PatternFill("solid", fgColor="C6EFCE"),
    "部分覆盖": PatternFill("solid", fgColor="FFEB9C"),
    "未覆盖": PatternFill("solid", fgColor="FFC7CE"),
    "非可测项": PatternFill("solid", fgColor="E7E6E6"),
}
STATUS_FONT = {
    "已覆盖": Font(color="006100"),
    "部分覆盖": Font(color="9C5700"),
    "未覆盖": Font(color="9C0006"),
    "非可测项": Font(color="808080"),
}
HEAD_FILL = PatternFill("solid", fgColor="305496")
HEAD_FONT = Font(color="FFFFFF", bold=True)
THIN = Side(style="thin", color="BFBFBF")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
WRAP = Alignment(wrap_text=True, vertical="top")
CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)


def _style_header(ws, ncol: int) -> None:
    for c in range(1, ncol + 1):
        cell = ws.cell(row=1, column=c)
        cell.fill = HEAD_FILL
        cell.font = HEAD_FONT
        cell.alignment = CENTER
        cell.border = BORDER
    ws.freeze_panes = "A2"


def load_results(cfg) -> dict[str, list[dict]]:
    res_dir = cfg.out_dir("result")
    draft_dir = cfg.out_dir("draft")
    data: dict[str, list[dict]] = {}
    for name in cfg.module_order:
        f = res_dir / f"{name}.json"
        if not f.exists():
            print(f"  [警告] 缺少判定结果: {name}.json（请先完成 AI 判定）")
            data[name] = []
            continue
        items = load_json(f).get("items", [])
        # 回填 source / text
        draft_f = draft_dir / f"{name}.json"
        if draft_f.exists():
            draft = load_json(draft_f)
            src = {r["req_id"]: r.get("source", "") for r in draft.get("requirements", [])}
            txt = {r["req_id"]: r.get("text", "") for r in draft.get("requirements", [])}
            for it in items:
                it.setdefault("source", src.get(it["req_id"], ""))
                if not it.get("text"):
                    it["text"] = txt.get(it["req_id"], "")
        data[name] = items
    return data


def build_overview(wb, cfg, results) -> dict:
    ov = wb.active
    ov.title = "总览"
    head = ["序号", "功能模块", "需求总条数", "可测条数", "已覆盖", "部分覆盖",
            "未覆盖", "非可测项", "覆盖率(已覆盖/可测)", "含部分(已+部分/可测)"]
    ov.append(head)
    _style_header(ov, len(head))

    tot = dict(total=0, testable=0, cov=0, part=0, un=0, nt=0)
    for i, name in enumerate(cfg.module_order, 1):
        items = results[name]
        total = len(items)
        cov = sum(1 for x in items if x["status"] == "已覆盖")
        part = sum(1 for x in items if x["status"] == "部分覆盖")
        un = sum(1 for x in items if x["status"] == "未覆盖")
        nt = sum(1 for x in items if x["status"] == "非可测项")
        testable = cov + part + un
        rate = f"{cov / testable * 100:.1f}%" if testable else "-"
        rate2 = f"{(cov + part) / testable * 100:.1f}%" if testable else "-"
        ov.append([i, name, total, testable, cov, part, un, nt, rate, rate2])
        for k, v in dict(total=total, testable=testable, cov=cov, part=part, un=un, nt=nt).items():
            tot[k] += v
        rcell = ov.cell(row=i + 1, column=9)
        if testable:
            r = cov / testable
            rcell.fill = (STATUS_FILL["已覆盖"] if r >= 0.9 else
                          STATUS_FILL["部分覆盖"] if r >= 0.7 else STATUS_FILL["未覆盖"])

    T = tot["testable"]
    ov.append(["", "合计", tot["total"], T, tot["cov"], tot["part"], tot["un"], tot["nt"],
               f"{tot['cov'] / T * 100:.1f}%" if T else "-",
               f"{(tot['cov'] + tot['part']) / T * 100:.1f}%" if T else "-"])
    last = ov.max_row
    for c in range(1, len(head) + 1):
        ov.cell(row=last, column=c).font = Font(bold=True)
        ov.cell(row=last, column=c).fill = PatternFill("solid", fgColor="DDEBF7")
    for r in range(2, ov.max_row + 1):
        for c in range(1, len(head) + 1):
            cell = ov.cell(row=r, column=c)
            cell.border = BORDER
            if c != 2:
                cell.alignment = Alignment(horizontal="center", vertical="center")
    for c, w in enumerate([5, 22, 11, 9, 8, 9, 8, 9, 18, 20], 1):
        ov.column_dimensions[get_column_letter(c)].width = w
    return tot


def build_module_sheets(wb, cfg, results) -> None:
    head = ["需求ID", "需求描述", "PRD来源", "是否可测", "覆盖状态", "命中用例编号", "说明/缺口"]
    used: set[str] = set()
    for name in cfg.module_order:
        title = name[:31]
        while title in used:
            title = title[:29] + "_2"
        used.add(title)
        ws = wb.create_sheet(title=title)
        ws.append(head)
        _style_header(ws, len(head))
        for it in results[name]:
            status = it["status"]
            ws.append([
                it["req_id"], it.get("text", ""), it.get("source", ""),
                "是" if it.get("testable") else "否", status,
                "、".join(it.get("matched_ids", []) or []), it.get("note", ""),
            ])
            r = ws.max_row
            sc = ws.cell(row=r, column=5)
            sc.fill = STATUS_FILL.get(status, PatternFill())
            sc.font = STATUS_FONT.get(status, Font())
            sc.alignment = CENTER
            for c in range(1, len(head) + 1):
                cell = ws.cell(row=r, column=c)
                cell.border = BORDER
                if c in (2, 6, 7):
                    cell.alignment = WRAP
                elif c != 5:
                    cell.alignment = Alignment(horizontal="center", vertical="top")
        for c, w in enumerate([15, 60, 13, 8, 10, 26, 50], 1):
            ws.column_dimensions[get_column_letter(c)].width = w


def main() -> None:
    ap = argparse.ArgumentParser(description="覆盖追溯 步骤3：汇总覆盖矩阵")
    ap.add_argument("--config", required=True)
    ap.add_argument("--out", help="输出 xlsx 路径，缺省 <项目目录>/<项目>_需求覆盖追溯表.xlsx")
    args = ap.parse_args()

    cfg = load_config(args.config)
    results = load_results(cfg)

    wb = Workbook()
    tot = build_overview(wb, cfg, results)
    build_module_sheets(wb, cfg, results)

    out = Path(args.out) if args.out else (cfg.base / f"{cfg.project}_需求覆盖追溯表.xlsx")
    out.parent.mkdir(parents=True, exist_ok=True)
    wb.save(out)

    T = tot["testable"]
    print(f"已生成 {out}")
    print(f"模块 {len(cfg.module_order)} 个 | 需求 {tot['total']} | 可测 {T} | "
          f"已覆盖 {tot['cov']} 部分 {tot['part']} 未覆盖 {tot['un']} 非可测 {tot['nt']}")
    if T:
        print(f"整体覆盖率(已覆盖/可测) {tot['cov'] / T * 100:.1f}% | "
              f"含部分 {(tot['cov'] + tot['part']) / T * 100:.1f}%")


if __name__ == "__main__":
    main()
