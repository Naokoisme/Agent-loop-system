# -*- coding: utf-8 -*-
"""通用覆盖追溯 步骤1：抽取。

读 trace.config.json：
  - 从 PRD 指定章节解析原子需求点（mode=section_by_indent，按缩进分级；
    或 mode=all_headings_bullets 兜底）
  - 从用例 xlsx 每模块 sheet 按 case_columns 加载用例
输出：<out_dirs.draft>/<模块>.json
  {module, prd_sections, requirement_count, case_count,
   requirements:[{req_id,indent,text,source}], cases:[{id,功能点,测试项,测试点,前置,步骤,预期}]}

改写自原 scripts/build_wd11_req_traceability.py（去硬编码，参数化为 config）。
"""
from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

from openpyxl import load_workbook

from _common import dump_json, load_config
from lineage import record_trace, verify_before_trace


def _parse_section_by_indent(text: str, section_header: str) -> dict[str, list[tuple[int, str]]]:
    """在 PRD 中定位 section_header（如 '## 6. 功能规则'），解析到下一个同级 '## ' 标题为止。
    内部按 '### 小节' 切分，每行按前导空格/2 计缩进层级。"""
    header = section_header.strip()
    lines = text.splitlines()
    in_section = False
    sec: str | None = None
    data: dict[str, list[tuple[int, str]]] = {}
    for line in lines:
        stripped = line.strip()
        if not in_section:
            if stripped == header or (header and stripped.startswith(header)):
                in_section = True
            continue
        # 遇到下一个 level-2 标题（## 开头但非 ###）→ 结束本章节
        if re.match(r"^##\s+", line) and not line.lstrip().startswith("###"):
            break
        m = re.match(r"^###\s*(.+)", line)
        if m:
            sec = m.group(1).strip()
            data.setdefault(sec, [])
            continue
        if sec is None or not stripped:
            continue
        leading = len(line) - len(line.lstrip(" "))
        indent = leading // 2
        body = re.sub(r"^[-*]\s*", "", stripped)
        if body:
            data[sec].append((indent, body))
    return data


def _parse_all_headings_bullets(text: str) -> dict[str, list[tuple[int, str]]]:
    """兜底模式：把每个二级/三级标题当作小节，标题下的列表项/段落作为需求。"""
    lines = text.splitlines()
    sec = "全文"
    data: dict[str, list[tuple[int, str]]] = {sec: []}
    for line in lines:
        stripped = line.strip()
        if not stripped:
            continue
        m = re.match(r"^#{2,4}\s*(.+)", line)
        if m:
            sec = m.group(1).strip()
            data.setdefault(sec, [])
            continue
        leading = len(line) - len(line.lstrip(" "))
        indent = leading // 2
        body = re.sub(r"^[-*]\s*", "", stripped)
        if body and not body.startswith("#"):
            data[sec].append((indent, body))
    return data


def parse_prd(prd_path: Path, section_headers: list[str], mode: str) -> dict[str, list[tuple[int, str]]]:
    """解析 PRD。section_headers 可含多个顶层章节(如 §4/§5/§6),逐个解析后合并;
    子小节名(### 后文本,如 '6.8 血氧规则')唯一,合并不冲突。"""
    text = prd_path.read_text(encoding="utf-8")
    if mode == "all_headings_bullets":
        return _parse_all_headings_bullets(text)
    merged: dict[str, list[tuple[int, str]]] = {}
    for header in section_headers:
        for sec, items in _parse_section_by_indent(text, header).items():
            merged.setdefault(sec, []).extend(items)
    return merged


def load_cases(xlsx: Path, modules: list[dict], colmap: dict[str, int]) -> dict[str, list[dict]]:
    wb = load_workbook(xlsx, read_only=False, data_only=True)
    out: dict[str, list[dict]] = {}

    def read_sheet(ws) -> list[dict]:
        fill: dict[tuple[int, int], object] = {}
        for rng in ws.merged_cells.ranges:
            v = ws.cell(rng.min_row, rng.min_col).value
            for row_idx in range(rng.min_row, rng.max_row + 1):
                for col_idx in range(rng.min_col, rng.max_col + 1):
                    fill[(row_idx, col_idx)] = v
        cases = []
        for row_idx in range(2, ws.max_row + 1):
            def g(key):
                idx = colmap.get(key)
                if idx is None:
                    return ""
                col_idx = idx + 1
                return fill.get((row_idx, col_idx), ws.cell(row_idx, col_idx).value) or ""
            cid = g("id")
            if not str(cid).strip():
                continue
            cases.append({
                "id": str(cid).strip(),
                "功能模块": g("功能模块"), "功能点": g("功能点"), "测试项": g("测试项"), "测试点": g("测试点"),
                "前置": g("前置"), "步骤": g("步骤"), "预期": g("预期"),
            })
        return cases

    stable_by_id: dict[str, dict] = {}
    stable_path = xlsx.parent / "用例稳定索引.json"
    if stable_path.exists():
        stable_payload = json.loads(stable_path.read_text(encoding="utf-8"))
        for item in stable_payload.get("items", []):
            case_id = str(item.get("case_id", ""))
            if case_id:
                stable_by_id[case_id] = item

    def attach_stable(cases: list[dict]) -> list[dict]:
        for case in cases:
            item = stable_by_id.get(case["id"], {})
            case["stable_id"] = str(item.get("stable_id", ""))
            case["matrix_key"] = str(item.get("matrix_key", ""))
            for metadata_key in ("risk", "design", "detail_contract"):
                if metadata_key in item:
                    case[metadata_key] = item[metadata_key]
        return cases

    master_sheet = wb["全功能测试用例"] if "全功能测试用例" in wb.sheetnames else wb[wb.sheetnames[0]]
    master_cases = attach_stable(read_sheet(master_sheet))
    if "功能模块" not in colmap:
        if len(modules) == 1:
            implicit_module = str(modules[0].get("name", "") or "")
            for case in master_cases:
                case["功能模块"] = implicit_module
        else:
            unresolved = [
                str(module.get("name", ""))
                for module in modules
                if str(module.get("name", "")) not in wb.sheetnames and not module.get("case_index_file")
            ]
            if unresolved:
                raise SystemExit(
                    "单总表缺少功能模块列且配置含多个模块，无法可靠分流: "
                    + ", ".join(unresolved)
                    + "；请增加功能模块列或为每个模块配置 case_index_file"
                )
    master_by_id = {case["id"]: case for case in master_cases}
    for mod in modules:
        name = mod["name"]
        case_index_file = mod.get("case_index_file")
        if case_index_file:
            index_path = Path(case_index_file)
            if not index_path.is_absolute():
                index_path = xlsx.parent / index_path
            payload = json.loads(index_path.read_text(encoding="utf-8"))
            items = payload.get("items", payload if isinstance(payload, list) else [])
            case_ids = [str(item.get("case_id", "")) for item in items if str(item.get("case_id", "")).strip()]
            out[name] = [master_by_id[cid] for cid in case_ids if cid in master_by_id]
            continue
        if name not in wb.sheetnames:
            out[name] = [case for case in master_cases if str(case.get("功能模块", "")) == name]
            if not out[name]:
                print(f"  [警告] 总表中未找到功能模块: {name}")
            continue
        out[name] = attach_stable(read_sheet(wb[name]))
    return out


def main() -> None:
    ap = argparse.ArgumentParser(description="覆盖追溯 步骤1：从 PRD+用例抽取每模块工作底稿")
    ap.add_argument("--config", required=True, help="trace.config.json 路径")
    args = ap.parse_args()

    cfg = load_config(args.config)
    verify_before_trace(cfg.base, cfg.cases_xlsx)
    prd = parse_prd(cfg.prd_path, cfg.prd_requirement_sections, cfg.prd_parse_mode)
    cases_by_mod = load_cases(cfg.cases_xlsx, cfg.modules, cfg.case_columns)
    draft_dir = cfg.out_dir("draft")

    missing: list[tuple[str, str]] = []
    summary: list[tuple[str, int, int]] = []
    for mod in cfg.modules:
        name, prefix = mod["name"], mod["prefix"]
        sections = mod.get("prd_sections", [name])
        reqs = []
        n = 0
        for sec in sections:
            if sec not in prd:
                missing.append((name, sec))
                continue
            for indent, body in prd[sec]:
                n += 1
                reqs.append({"req_id": f"REQ_{prefix}_{n:03d}", "indent": indent, "text": body, "source": sec})
        cases = cases_by_mod.get(name, [])
        payload = {
            "module": name, "prd_sections": sections,
            "requirement_count": len(reqs), "case_count": len(cases),
            "requirements": reqs, "cases": cases,
        }
        dump_json(payload, draft_dir / f"{name}.json")
        summary.append((name, len(reqs), len(cases)))
    record_trace(
        cfg.base, cfg.cases_xlsx, draft_dir,
        [draft_dir / f"{mod['name']}.json" for mod in cfg.modules],
    )

    print(f"已生成 {len(summary)} 个模块工作底稿 -> {draft_dir}")
    print(f"{'模块':18s} 需求条目  用例数")
    for name, nr, nc in summary:
        print(f"{name:18s} {nr:6d}  {nc:6d}")
    print(f"合计  需求 {sum(s[1] for s in summary)}  用例 {sum(s[2] for s in summary)}")
    if missing:
        print("\n[未匹配的 PRD 小节]")
        for sh, sec in missing:
            print(f"  {sh} <- {sec}")


if __name__ == "__main__":
    main()
