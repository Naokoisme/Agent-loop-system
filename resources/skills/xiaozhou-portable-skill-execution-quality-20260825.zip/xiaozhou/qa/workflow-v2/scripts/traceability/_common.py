# -*- coding: utf-8 -*-
"""覆盖追溯器共享助手：配置加载、路径解析、tc_excel 导入。"""
from __future__ import annotations

import json
import sys
from pathlib import Path

# 让同包脚本能 import scripts/tc_excel.py
_SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(_SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS_DIR))


class Config:
    """trace.config.json 的封装。所有相对路径都相对配置文件所在目录解析。"""

    def __init__(self, path: str | Path):
        self.path = Path(path).resolve()
        self.base = self.path.parent  # 配置文件所在目录，作为相对路径锚点
        self.raw = json.loads(self.path.read_text(encoding="utf-8"))

    # --- 标量 ---
    @property
    def project(self) -> str:
        return self.raw.get("project", self.base.name)

    @property
    def prd_requirement_section(self) -> str:
        return self.raw.get("prd_requirement_section", "")

    @property
    def prd_requirement_sections(self) -> list[str]:
        """支持多个顶层章节(如 §4/§5/§6);兼容单章节 prd_requirement_section。"""
        secs = self.raw.get("prd_requirement_sections")
        if secs:
            return secs
        return [self.prd_requirement_section] if self.prd_requirement_section else []

    @property
    def prd_parse_mode(self) -> str:
        return self.raw.get("prd_parse_mode", "section_by_indent")

    @property
    def coverage_threshold(self) -> float:
        return float(self.raw.get("coverage_threshold", 0.95))

    @property
    def modules(self) -> list[dict]:
        return self.raw.get("modules", [])

    @property
    def quality_gates(self) -> dict:
        """门禁C配置型规则。缺省为空,老项目不受影响。"""
        return self.raw.get("quality_gates", {})

    @property
    def module_order(self) -> list[str]:
        return [m["name"] for m in self.modules]

    @property
    def case_columns(self) -> dict[str, int]:
        return self.raw.get("case_columns", {
            "id": 0, "功能点": 2, "测试项": 3, "测试点": 4,
            "前置": 5, "步骤": 6, "预期": 7,
        })

    # --- 路径（相对配置文件目录）---
    def _resolve(self, rel: str) -> Path:
        p = Path(rel)
        return p if p.is_absolute() else (self.base / p)

    @property
    def prd_path(self) -> Path:
        return self._resolve(self.raw["prd_path"])

    @property
    def cases_xlsx(self) -> Path:
        return self._resolve(self.raw["cases_xlsx"])

    def out_dir(self, key: str) -> Path:
        """key ∈ draft/result/gaps。产物目录，落在配置文件所在目录内。"""
        rel = self.raw.get("out_dirs", {}).get(
            key, {"draft": "工作底稿", "result": "结果", "gaps": "补充用例"}[key]
        )
        d = self._resolve(rel)
        d.mkdir(parents=True, exist_ok=True)
        return d


def load_config(path: str | Path) -> Config:
    return Config(path)


def load_json(path: str | Path) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def dump_json(obj, path: str | Path) -> None:
    Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")
