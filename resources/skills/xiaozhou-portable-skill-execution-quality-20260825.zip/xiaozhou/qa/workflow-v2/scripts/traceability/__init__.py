"""通用覆盖追溯器。

trace_extract → (AI 判定) → trace_assemble / trace_gate → trace_insert
"""
