# -*- coding: utf-8 -*-
"""Canonical audit-result contract shared by workflow-v2 validation tools.

The contract deliberately separates blocking failures from accepted risks and
warnings.  Counts and status are always derived from ``issues`` so callers
cannot accidentally publish contradictory summaries.

Canonical top-level fields::

    schema_version, tool, status, blocking_count, risk_count, warning_count,
    issues, metrics, artifacts

Exit codes are stable across tools: PASS/PASS_WITH_RISKS=0, FAIL=1, and
BLOCKED or a malformed contract=2.
"""
from __future__ import annotations

import argparse
import copy
import json
import sys
from pathlib import Path
from typing import Any, Iterable, Mapping


SCHEMA_VERSION = 1
STATUSES = {"PASS", "PASS_WITH_RISKS", "FAIL", "BLOCKED"}
SEVERITIES = {"blocking", "risk", "warning"}
BLOCKING_KINDS = {"failure", "blocked"}
REQUIRED_FIELDS = (
    "schema_version",
    "tool",
    "status",
    "blocking_count",
    "risk_count",
    "warning_count",
    "issues",
    "metrics",
    "artifacts",
)


class AuditContractError(ValueError):
    """Raised when a payload claims to be canonical but violates the contract."""


def make_issue(
    severity: str,
    message: str,
    *,
    code: str = "AUDIT_ISSUE",
    kind: str | None = None,
    details: Any | None = None,
) -> dict[str, Any]:
    """Create one canonical issue.

    ``kind`` is required only for blocking issues.  ``failure`` means the tool
    completed and found a release-blocking problem; ``blocked`` means the tool
    could not complete its determination because required input or capability
    was unavailable.
    """
    severity = str(severity or "").strip().lower()
    if severity not in SEVERITIES:
        raise AuditContractError(f"invalid issue severity: {severity!r}")
    message = str(message or "").strip()
    code = str(code or "").strip()
    if not message:
        raise AuditContractError("issue message must be non-empty")
    if not code:
        raise AuditContractError("issue code must be non-empty")

    issue: dict[str, Any] = {"severity": severity, "code": code, "message": message}
    if severity == "blocking":
        blocking_kind = str(kind or "failure").strip().lower()
        if blocking_kind not in BLOCKING_KINDS:
            raise AuditContractError(f"invalid blocking issue kind: {blocking_kind!r}")
        issue["kind"] = blocking_kind
    elif kind is not None:
        raise AuditContractError("non-blocking issues must not declare kind")
    if details is not None:
        issue["details"] = details
    return issue


def _issue_counts(issues: Iterable[Mapping[str, Any]]) -> tuple[int, int, int]:
    blocking = risk = warning = 0
    for issue in issues:
        severity = str(issue.get("severity", "")).lower()
        if severity == "blocking":
            blocking += 1
        elif severity == "risk":
            risk += 1
        elif severity == "warning":
            warning += 1
    return blocking, risk, warning


def derive_status(issues: Iterable[Mapping[str, Any]]) -> str:
    """Derive the only valid status for a set of canonical issues."""
    issue_list = list(issues)
    blocking, risk, warning = _issue_counts(issue_list)
    if blocking:
        if any(
            str(issue.get("severity", "")).lower() == "blocking"
            and str(issue.get("kind", "failure")).lower() == "blocked"
            for issue in issue_list
        ):
            return "BLOCKED"
        return "FAIL"
    if risk or warning:
        return "PASS_WITH_RISKS"
    return "PASS"


def build_report(
    tool: str,
    *,
    issues: Iterable[Mapping[str, Any]] | None = None,
    metrics: Mapping[str, Any] | None = None,
    artifacts: Iterable[Any] | None = None,
    extensions: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Build a canonical report and derive all summary fields."""
    tool = str(tool or "").strip()
    if not tool:
        raise AuditContractError("tool must be a non-empty string")
    issue_list = [copy.deepcopy(dict(issue)) for issue in (issues or [])]
    for index, issue in enumerate(issue_list, 1):
        issue_errors = _validate_issue(issue, index)
        if issue_errors:
            raise AuditContractError("; ".join(issue_errors))
    blocking, risk, warning = _issue_counts(issue_list)
    report: dict[str, Any] = {
        "schema_version": SCHEMA_VERSION,
        "tool": tool,
        "status": derive_status(issue_list),
        "blocking_count": blocking,
        "risk_count": risk,
        "warning_count": warning,
        "issues": issue_list,
        "metrics": copy.deepcopy(dict(metrics or {})),
        "artifacts": copy.deepcopy(list(artifacts or [])),
    }
    for key, value in dict(extensions or {}).items():
        if key in REQUIRED_FIELDS:
            raise AuditContractError(f"extension cannot replace canonical field: {key}")
        report[key] = copy.deepcopy(value)
    validation_errors = validate_report(report)
    if validation_errors:
        raise AuditContractError("; ".join(validation_errors))
    return report


def _validate_issue(issue: Any, index: int) -> list[str]:
    prefix = f"issues[{index}]"
    if not isinstance(issue, dict):
        return [f"{prefix} must be an object"]
    errors: list[str] = []
    severity = issue.get("severity")
    if severity not in SEVERITIES:
        errors.append(f"{prefix}.severity must be one of {sorted(SEVERITIES)}")
    for field in ("code", "message"):
        if not isinstance(issue.get(field), str) or not issue[field].strip():
            errors.append(f"{prefix}.{field} must be a non-empty string")
    if severity == "blocking":
        if issue.get("kind") not in BLOCKING_KINDS:
            errors.append(f"{prefix}.kind must be one of {sorted(BLOCKING_KINDS)}")
    elif "kind" in issue:
        errors.append(f"{prefix}.kind is only valid for blocking issues")
    return errors


def validate_report(report: Any) -> list[str]:
    """Return contract violations without mutating the input."""
    if not isinstance(report, dict):
        return ["report must be an object"]
    errors: list[str] = []
    for field in REQUIRED_FIELDS:
        if field not in report:
            errors.append(f"missing required field: {field}")
    if errors:
        return errors

    if report.get("schema_version") != SCHEMA_VERSION:
        errors.append(f"schema_version must equal {SCHEMA_VERSION}")
    if not isinstance(report.get("tool"), str) or not report["tool"].strip():
        errors.append("tool must be a non-empty string")
    if report.get("status") not in STATUSES:
        errors.append(f"status must be one of {sorted(STATUSES)}")
    if not isinstance(report.get("issues"), list):
        errors.append("issues must be an array")
        issues: list[dict[str, Any]] = []
    else:
        issues = report["issues"]
        for index, issue in enumerate(issues, 1):
            errors.extend(_validate_issue(issue, index))
    if not isinstance(report.get("metrics"), dict):
        errors.append("metrics must be an object")
    if not isinstance(report.get("artifacts"), list):
        errors.append("artifacts must be an array")

    expected_counts = _issue_counts(issue for issue in issues if isinstance(issue, dict))
    for field, expected in zip(
        ("blocking_count", "risk_count", "warning_count"), expected_counts, strict=True
    ):
        value = report.get(field)
        if not isinstance(value, int) or isinstance(value, bool) or value < 0:
            errors.append(f"{field} must be a non-negative integer")
        elif value != expected:
            errors.append(f"{field} must be derived from issues ({expected}), got {value}")
    if not any(error.startswith("issues[") for error in errors):
        expected_status = derive_status(issue for issue in issues if isinstance(issue, dict))
        if report.get("status") != expected_status:
            errors.append(f"status must be derived from issues ({expected_status})")

    try:
        json.dumps(report, ensure_ascii=False)
    except (TypeError, ValueError) as exc:
        errors.append(f"report is not JSON serializable: {exc}")
    return errors


def _legacy_status(payload: Mapping[str, Any]) -> str:
    raw = str(payload.get("status", payload.get("final_status", "")) or "").strip().upper()
    direct = {
        "PASS": "PASS",
        "SUCCESS": "PASS",
        "PASS_WITH_RISKS": "PASS_WITH_RISKS",
        "FAIL": "FAIL",
        "FAILED": "FAIL",
        "BLOCKED": "BLOCKED",
    }
    if raw in direct:
        return direct[raw]
    if raw in {
        "SEMANTIC_REVIEW_REQUIRED",
        "NO_PROGRESS",
        "MAX_ROUNDS_REACHED",
        "UNKNOWN",
        "BLOCKED_COMMAND",
    }:
        return "BLOCKED"
    if payload.get("success") is False:
        return "FAIL"
    return "PASS"


def _severity_from_legacy(raw: Any, default: str) -> str:
    value = str(raw or "").strip().lower().replace("-", "_")
    if value in {"blocking", "blocker", "critical", "error", "fail", "failed", "failure", "major"}:
        return "blocking"
    if value in {"risk", "pending", "pending_confirmation"}:
        return "risk"
    if value in {"warning", "warn", "minor", "info", "notice"}:
        return "warning"
    return default


def _coerce_legacy_issue(raw: Any, *, default_severity: str, blocked: bool, index: int) -> dict[str, Any]:
    if isinstance(raw, dict):
        severity = _severity_from_legacy(raw.get("severity", raw.get("level")), default_severity)
        message = next(
            (
                str(raw.get(key, "")).strip()
                for key in ("message", "reason", "text", "title", "body")
                if str(raw.get(key, "")).strip()
            ),
            json.dumps(raw, ensure_ascii=False, sort_keys=True),
        )
        code = str(raw.get("code", raw.get("id", f"LEGACY_ISSUE_{index}")) or f"LEGACY_ISSUE_{index}")
        known = {"severity", "level", "message", "reason", "text", "title", "body", "code", "id", "kind"}
        details = {key: value for key, value in raw.items() if key not in known} or None
        kind = None
        if severity == "blocking":
            raw_kind = str(raw.get("kind", "")).strip().lower()
            kind = "blocked" if blocked or raw_kind == "blocked" else "failure"
        return make_issue(severity, message, code=code, kind=kind, details=details)
    severity = default_severity
    kind = "blocked" if severity == "blocking" and blocked else ("failure" if severity == "blocking" else None)
    return make_issue(severity, str(raw), code=f"LEGACY_ISSUE_{index}", kind=kind)


def normalize_report(payload: Any, *, tool: str | None = None) -> dict[str, Any]:
    """Normalize a legacy audit payload or validate an existing v1 payload.

    Existing canonical payloads are never silently repaired: contradictory
    counts/status are schema errors.  Legacy ``success``, ``status``,
    ``final_status``, ``errors`` and ``failures`` shapes remain readable.
    """
    if not isinstance(payload, dict):
        raise AuditContractError("audit payload must be an object")
    if "schema_version" in payload:
        errors = validate_report(payload)
        if errors:
            raise AuditContractError("; ".join(errors))
        return copy.deepcopy(payload)

    tool_name = str(tool or payload.get("tool") or payload.get("name") or "legacy.audit").strip()
    status_hint = _legacy_status(payload)
    blocked = status_hint == "BLOCKED"
    issues: list[dict[str, Any]] = []
    index = 0

    for raw in payload.get("issues", []) if isinstance(payload.get("issues", []), list) else [payload.get("issues")]:
        if raw in (None, ""):
            continue
        index += 1
        default = "blocking" if status_hint in {"FAIL", "BLOCKED"} else "warning"
        issues.append(_coerce_legacy_issue(raw, default_severity=default, blocked=blocked, index=index))

    for field, severity in (("errors", "blocking"), ("failures", "blocking"), ("risks", "risk"), ("warnings", "warning")):
        values = payload.get(field, [])
        values = values if isinstance(values, list) else ([] if values in (None, "") else [values])
        for raw in values:
            index += 1
            issues.append(_coerce_legacy_issue(raw, default_severity=severity, blocked=blocked, index=index))

    derived = derive_status(issues)
    needs_status_issue = (
        status_hint == "PASS_WITH_RISKS" and derived == "PASS"
    ) or (
        status_hint == "FAIL" and derived not in {"FAIL", "BLOCKED"}
    ) or (
        status_hint == "BLOCKED" and derived != "BLOCKED"
    )
    if needs_status_issue:
        severity = "risk" if status_hint == "PASS_WITH_RISKS" else "blocking"
        kind = "blocked" if status_hint == "BLOCKED" else ("failure" if severity == "blocking" else None)
        issues.append(
            make_issue(
                severity,
                f"legacy tool reported {status_hint} without issue details",
                code="LEGACY_STATUS_ONLY",
                kind=kind,
            )
        )

    metrics = payload.get("metrics") if isinstance(payload.get("metrics"), dict) else {}
    artifacts = payload.get("artifacts") if isinstance(payload.get("artifacts"), list) else []
    return build_report(tool_name, issues=issues, metrics=metrics, artifacts=artifacts)


def exit_code(report: Any) -> int:
    """Return the stable process code; malformed reports are schema errors."""
    if validate_report(report):
        return 2
    status = report["status"]
    if status in {"PASS", "PASS_WITH_RISKS"}:
        return 0
    if status == "FAIL":
        return 1
    return 2


def _load_input(path: str) -> Any:
    if path == "-":
        return json.load(sys.stdin)
    return json.loads(Path(path).read_text(encoding="utf-8"))


def _emit(report: Mapping[str, Any], output: str | None) -> None:
    text = json.dumps(report, ensure_ascii=False, indent=2)
    if output:
        Path(output).write_text(text + "\n", encoding="utf-8")
    print(text)


def main() -> None:
    parser = argparse.ArgumentParser(description="Normalize or validate a workflow-v2 audit JSON payload.")
    parser.add_argument("--input", required=True, help="Input JSON file, or - for stdin.")
    parser.add_argument("--output", help="Optional canonical JSON output file.")
    parser.add_argument("--tool", help="Tool name used when normalizing a legacy payload.")
    parser.add_argument("--strict", action="store_true", help="Require canonical v1 input; do not normalize legacy shapes.")
    parser.add_argument("--json", action="store_true", help="Compatibility flag; output is always JSON.")
    args = parser.parse_args()

    try:
        payload = _load_input(args.input)
        if args.strict:
            errors = validate_report(payload)
            if errors:
                raise AuditContractError("; ".join(errors))
            report = payload
        else:
            report = normalize_report(payload, tool=args.tool)
    except Exception as exc:  # noqa: BLE001 - CLI must convert schema/input errors to a contract
        report = build_report(
            "audit_contract",
            issues=[make_issue("blocking", str(exc), code="SCHEMA_ERROR", kind="blocked")],
        )
        _emit(report, args.output)
        raise SystemExit(2) from None

    _emit(report, args.output)
    raise SystemExit(exit_code(report))


if __name__ == "__main__":
    main()
