# -*- coding: utf-8 -*-
"""通用测试用例 Excel 读写器。

把原 WD11 专用 build_wd11_testcases.py 里的 write_workbook/style_sheet/
merge_hierarchy_cells，以及 insert_wd11_supplements.py 里的合并区展开读取，
抽成一个项目无关的工具。任何项目的标准 15 列用例表都可用它读/写。

读：read_master_rows(path) -> list[dict]   （展开合并单元格，无损）
写：write_workbook(rows, output, module_order=None)
     主表「全功能测试用例」+ 按 module_order（缺省=首次出现顺序）每模块一个分页，
     表头样式、自适应行高、列宽、层级合并（功能模块/功能点/测试项）。
"""
from __future__ import annotations

import re
import sys
from collections import defaultdict
from pathlib import Path

import openpyxl
from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

_SCRIPT_DIR = Path(__file__).resolve().parent
if str(_SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(_SCRIPT_DIR))

from quality_semantics import check_functional_manual_contract, check_step_expected_contract

# 标准 15 列（与原 build_wd11_testcases.COLUMNS 一致）
COLUMNS = [
    "用例编号", "功能模块", "功能点", "测试项", "测试点/检查项",
    "前置条件", "操作步骤", "预期结果", "优先级", "兼容性",
    "是否自动化", "固件版本", "硬件型号", "测试方式", "备注",
]

MASTER_SHEET = "全功能测试用例"
SEQ_HEADER = "序号"  # 自动生成的行序号列,作为第一列

# 样式常量
_HEADER_FILL = PatternFill("solid", fgColor="1F4E78")
_HEADER_FONT = Font(name="等线", size=10, color="FFFFFF", bold=True)
_BODY_FONT = Font(name="等线", size=10)
_BODY_CONFIRM_FONT = Font(name="等线", size=10, color="FF0000")
_BLACK_SIDE = Side(style="thin", color="000000")
_ALL_BLACK_BORDER = Border(
    left=_BLACK_SIDE,
    right=_BLACK_SIDE,
    top=_BLACK_SIDE,
    bottom=_BLACK_SIDE,
)
_WRAP = Alignment(vertical="center", wrap_text=True)
_CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)
_CONFIRM_MARKERS = ("待确认", "待产品确认")
# A=序号 之后接 15 标准列(B=用例编号 … P=备注)
_COL_WIDTHS = {
    "A": 6, "B": 15, "C": 18, "D": 20, "E": 18, "F": 36, "G": 36, "H": 42, "I": 46,
    "J": 8, "K": 18, "L": 12, "M": 12, "N": 12, "O": 16, "P": 28,
}


def read_sheet_rows(ws) -> list[dict]:
    """Read one testcase sheet and expand all merged hierarchy cells."""
    # 自动检测首列是否为「序号」列,有则读取时跳过(兼容新旧格式)
    col_off = 1 if str(ws.cell(1, 1).value).strip() == SEQ_HEADER else 0
    fill: dict[tuple[int, int], object] = {}
    for rng in ws.merged_cells.ranges:
        v = ws.cell(rng.min_row, rng.min_col).value
        for r in range(rng.min_row, rng.max_row + 1):
            for c in range(rng.min_col, rng.max_col + 1):
                fill[(r, c)] = v
    rows: list[dict] = []
    for r in range(2, ws.max_row + 1):
        row = {}
        for ci, col in enumerate(COLUMNS, 1 + col_off):
            v = fill.get((r, ci), ws.cell(r, ci).value)
            row[col] = v if v is not None else ""
        # 跳过完全空行
        if not str(row.get("用例编号", "")).strip() and not any(str(x).strip() for x in row.values()):
            continue
        rows.append(row)
    return rows


def read_master_rows(path: str | Path, sheet: str = MASTER_SHEET) -> list[dict]:
    """读主表为有序行列表，显式展开合并区（无损）。

    返回每行 {列名: 值}，缺失值填 ""。合并单元格的值回填到区域内每个单元格。
    """
    wb = openpyxl.load_workbook(path, data_only=True)
    ws = wb[sheet] if sheet in wb.sheetnames else wb[wb.sheetnames[0]]
    return read_sheet_rows(ws)


def _sheet_title(name: str, used: set[str]) -> str:
    title = re.sub(r"[\[\]\:\*\?\/\\]", "_", str(name)).strip()[:31] or "Sheet"
    original = title
    index = 2
    while title in used:
        suffix = f"_{index}"
        title = f"{original[:31 - len(suffix)]}{suffix}"
        index += 1
    used.add(title)
    return title


def _append_rows(ws, rows: list[dict]) -> None:
    ws.append([SEQ_HEADER] + COLUMNS)
    for i, row in enumerate(rows, 1):
        ws.append([i] + [row.get(col, "") for col in COLUMNS])


def _style_sheet(ws) -> None:
    for cell in ws[1]:
        cell.fill = _HEADER_FILL
        cell.font = _HEADER_FONT
        cell.alignment = _CENTER
        cell.border = _ALL_BLACK_BORDER
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            text = "" if cell.value is None else str(cell.value)
            cell.font = _BODY_CONFIRM_FONT if any(marker in text for marker in _CONFIRM_MARKERS) else _BODY_FONT
            cell.alignment = _WRAP
            cell.border = _ALL_BLACK_BORDER
        # 序号(A)、功能模块/功能点/测试项(C/D/E)居中
        for cell in (row[0], row[2], row[3], row[4]):
            cell.alignment = _CENTER
    for col, width in _COL_WIDTHS.items():
        ws.column_dimensions[col].width = width
    ws.freeze_panes = "A2"
    if ws.max_row >= 1:
        ws.auto_filter.ref = ws.dimensions
    # 自适应行高：按 测试点/前置/步骤/预期/备注 列(F/G/H/I/P=6/7/8/9/16)换行数估算
    for row_idx in range(2, ws.max_row + 1):
        max_lines = 1
        for col_idx in (6, 7, 8, 9, 16):
            value = ws.cell(row_idx, col_idx).value or ""
            max_lines = max(max_lines, str(value).count("\n") + 1)
        ws.row_dimensions[row_idx].height = min(120, max(28, max_lines * 18))


def _merge_hierarchy_cells(ws) -> None:
    """对第 3/4/5 列（功能模块/功能点/测试项,序号列之后）做层级合并。"""
    if ws.max_row <= 2:
        return
    values = {
        r: {"module": ws.cell(r, 3).value, "feature": ws.cell(r, 4).value, "item": ws.cell(r, 5).value}
        for r in range(2, ws.max_row + 1)
    }

    def merge_by(column: int, keys: list[str]) -> None:
        start = 2
        previous = tuple(values[start][k] for k in keys)
        for r in range(3, ws.max_row + 2):
            current = tuple(values[r][k] for k in keys) if r <= ws.max_row else None
            if current != previous:
                end = r - 1
                if end > start:
                    ws.merge_cells(start_row=start, start_column=column, end_row=end, end_column=column)
                    ws.cell(start, column).alignment = _CENTER
                start = r
                previous = current

    merge_by(3, ["module"])
    merge_by(4, ["module", "feature"])
    merge_by(5, ["module", "feature", "item"])


def write_workbook(
    rows: list[dict],
    output: str | Path,
    module_order: list[str] | None = None,
    *,
    include_module_sheets: bool = True,
    master_sheet: str = MASTER_SHEET,
) -> Path:
    """写主表，并按需追加每模块分页。

    rows: 行字典列表（主表顺序原样保留）。
    module_order: 分页顺序；缺省按行中「功能模块」首次出现顺序。
    include_module_sheets: False 时只交付单一总表。
    master_sheet: 总表工作表名称。
    """
    violations = check_functional_manual_contract(rows)
    violations.extend(check_step_expected_contract(rows))
    if violations:
        preview = "\n".join(f"- {item}" for item in violations[:50])
        extra = len(violations) - 50
        suffix = f"\n- ... 其余 {extra} 处" if extra > 0 else ""
        raise ValueError("功能测试用例人工执行合同未通过，禁止写入 Excel：\n" + preview + suffix)

    wb = Workbook()
    used: set[str] = set()

    ws = wb.active
    ws.title = _sheet_title(master_sheet, used)
    _append_rows(ws, rows)
    _style_sheet(ws)
    _merge_hierarchy_cells(ws)

    module_rows: defaultdict[str, list[dict]] = defaultdict(list)
    order: list[str] = []
    for row in rows:
        m = row.get("功能模块", "")
        if m not in module_rows:
            order.append(m)
        module_rows[m].append(row)

    seq = module_order or order
    # 补上 module_order 没列到、但行里有的模块
    for m in order:
        if m not in seq:
            seq = list(seq) + [m]

    if include_module_sheets:
        for module in seq:
            rows_for = module_rows.get(module)
            if not rows_for:
                continue
            mws = wb.create_sheet(_sheet_title(module, used))
            _append_rows(mws, rows_for)
            _style_sheet(mws)
            _merge_hierarchy_cells(mws)

    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    wb.save(output)
    return output
