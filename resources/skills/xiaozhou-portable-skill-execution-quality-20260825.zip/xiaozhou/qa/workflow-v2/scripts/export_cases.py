# -*- coding: utf-8 -*-
"""把 projects/<项目>/cases/*.json 的逐模块用例拼成标准 15 列 Excel。

每个 cases/*.json 形如 {"module": "...", "cases": [{...15列...}, ...]}。
按 config.module_order(若给)或文件名排序拼接,调用 tc_excel.write_workbook 导出
主表，并可按需追加每模块分页。供阶段6产出用例表、阶段9追溯的 cases_xlsx 来源。

生产用例默认必须已有稳定ID或matrix_key。仅确认导入遗留 cases JSON 时，才可显式使用
``--legacy-bootstrap-stable-ids`` 生成一次UUID并写回源文件；后续运行复用该ID。
"""
from __future__ import annotations

import argparse
import glob
import json
import re
import sys
import tempfile
from pathlib import Path

_SCRIPTS = Path(__file__).resolve().parent
if str(_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS))
import tc_excel  # noqa: E402
from build_lock import project_build_lock  # noqa: E402
from lineage import (  # noqa: E402
    LINEAGE_REL,
    LineageError,
    record_casegen,
    record_export,
    verify_before_export,
)
from quality_semantics import (  # noqa: E402
    check_functional_manual_contract,
    check_step_expected_contract,
)
from stable_ids import (  # noqa: E402
    StableIdentityError,
    build_identity_maps,
    case_stable_identity,
    commit_staged_files,
    ensure_case_stable_id,
)
from project_paths import resolve_project

ROOT = _SCRIPTS.parent  # workflow-v2/


def _locked_prefixes(project: Path) -> dict[str, str]:
    prefixes: dict[str, str] = {}
    contract_path = project / "生成验收合同.json"
    if contract_path.exists():
        contract = json.loads(contract_path.read_text(encoding="utf-8"))
        for row in contract.get("modules", []) if isinstance(contract, dict) else []:
            if not isinstance(row, dict) or row.get("prefix_locked") is not True:
                continue
            module = str(row.get("name", "") or "").strip()
            prefix = str(row.get("prefix", "") or "").strip()
            if module and prefix:
                prefixes[module] = prefix
    for path in sorted((project / "specs").glob("*.json")):
        payload = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            continue
        module = str(payload.get("module", "") or "").strip()
        prefix = str(payload.get("prefix", "") or "").strip()
        if not module or not prefix:
            continue
        existing = prefixes.get(module)
        if existing is not None and existing != prefix:
            raise SystemExit(
                f"模块 {module} 的锁定合同前缀 {existing} 与 spec 前缀 {prefix} 冲突"
            )
        prefixes[module] = prefix
    return prefixes


def _case_number(case_id: str, prefix: str) -> int | None:
    match = re.fullmatch(rf"{re.escape(prefix)}_(\d+)", case_id)
    return int(match.group(1)) if match else None


def _run(args, proj_dir: Path) -> None:
    cases_dir = proj_dir / "cases"
    files = sorted(glob.glob(str(cases_dir / "*.json")))
    if not files:
        raise SystemExit(f"未找到用例 JSON: {cases_dir}/*.json")
    verify_before_export(proj_dir)
    _export_locked(args, proj_dir, files)


def main() -> None:
    ap = argparse.ArgumentParser(description="逐模块用例 JSON → 标准 Excel")
    ap.add_argument("--project", required=True, help="projects/ 下的项目名")
    ap.add_argument("--workspace-root", help="项目工作区根目录；--project 为名称时生效")
    ap.add_argument("--out", help="输出 xlsx,缺省 projects/<项目>/<项目>_全功能测试用例.xlsx")
    ap.add_argument("--order", nargs="*", help="模块顺序(模块名);缺省按文件名排序")
    ap.add_argument("--single-sheet", action="store_true", help="只导出单一总表，不创建模块分页")
    ap.add_argument("--master-sheet", default=tc_excel.MASTER_SHEET, help="总表工作表名称")
    ap.add_argument("--renumber", action="store_true",
                    help="按最终行顺序重编号；仅可与 --migration-file 同时使用，避免破坏稳定引用")
    ap.add_argument("--migration-file", help="--renumber 时必填，写出 old_id->new_id 映射JSON")
    ap.add_argument(
        "--legacy-bootstrap-stable-ids",
        action="store_true",
        help="仅用于遗留 cases/*.json：为缺稳定ID的普通用例生成一次UUID并写回源JSON；默认仍严格拒绝",
    )
    args = ap.parse_args()

    proj_dir = resolve_project(args.project, workspace_root=args.workspace_root)
    try:
        with project_build_lock(proj_dir):
            _run(args, proj_dir)
    except RuntimeError as exc:
        raise SystemExit(str(exc)) from exc


def _export_locked(args, proj_dir: Path, files: list[str]) -> None:

    by_module: dict[str, list[dict]] = {}
    source_by_module: dict[str, tuple[Path, dict]] = {}
    file_order: list[str] = []
    module_sources: dict[str, str] = {}
    total = 0
    for f in files:
        d = json.loads(Path(f).read_text(encoding="utf-8"))
        mod = d.get("module", Path(f).stem)
        cases = d.get("cases", [])
        if not isinstance(cases, list):
            raise SystemExit(f"cases 字段必须是数组: {f}")
        if mod in by_module:
            raise SystemExit(f"功能模块重复出现在多个 cases JSON: {mod} ({module_sources[mod]} / {f})")
        by_module[mod] = cases
        source_by_module[mod] = (Path(f), d)
        module_sources[mod] = f
        file_order.append(mod)
        total += len(cases)
        print(f"  {mod}: {len(cases)} 条")

    order = args.order or file_order
    rows: list[dict] = []
    for mod in order:
        rows.extend(by_module.get(mod, []))
    # 补上 order 未列到的模块
    for mod in file_order:
        if mod not in order:
            rows.extend(by_module[mod])

    # 必须在迁移文件、稳定ID、Excel或索引发生任何写入前完成。
    contract_violations = check_functional_manual_contract(rows)
    contract_violations.extend(check_step_expected_contract(rows))
    if contract_violations:
        preview = "\n".join(f"  {item}" for item in contract_violations[:50])
        extra = len(contract_violations) - 50
        suffix = f"\n  ... 其余 {extra} 处" if extra > 0 else ""
        raise SystemExit(
            "功能测试用例人工执行合同未通过，禁止导出Excel：\n" + preview + suffix
        )

    if args.renumber and not args.migration_file:
        raise SystemExit("--renumber 会改变稳定引用，必须同时提供 --migration-file 写出迁移映射")
    if args.migration_file and not args.renumber:
        raise SystemExit("--migration-file 仅允许与 --renumber 同时使用")

    stable_index = proj_dir / "用例稳定索引.json"
    historical_stable_to_case: dict[str, str] = {}
    historical_case_to_stable: dict[str, str] = {}
    historical_records_by_stable: dict[str, dict] = {}
    historical_payload: dict = {"items": [], "retired_items": [], "high_water": {}}
    index_existed = stable_index.exists()
    if stable_index.exists():
        try:
            historical_payload = json.loads(stable_index.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            raise SystemExit(f"用例稳定索引无法读取或不是合法JSON: {stable_index} ({exc})") from exc
        historical_items = historical_payload.get("items") if isinstance(historical_payload, dict) else None
        if not isinstance(historical_items, list):
            raise SystemExit("用例稳定索引必须是包含 items 数组的对象")
        retired_items = historical_payload.get("retired_items", [])
        if not isinstance(retired_items, list):
            raise SystemExit("用例稳定索引 retired_items 必须是数组")
        historical_records = historical_items + retired_items
        try:
            historical_stable_to_case, historical_case_to_stable = build_identity_maps(
                historical_records,
                label="用例稳定索引历史",
            )
        except StableIdentityError as exc:
            raise SystemExit(f"用例稳定索引重复或冲突，禁止导出: {exc}") from exc
        for record in historical_records:
            stable_value, _ = case_stable_identity(record)
            historical_records_by_stable[stable_value] = dict(record)

    bootstrapped_modules: set[str] = set()
    for case in rows:
        case_id = str(case.get("用例编号", "") or "")
        try:
            stable_value, _ = case_stable_identity(case)
        except StableIdentityError as exc:
            raise SystemExit(f"{case_id or '<无编号>'} 稳定ID异常: {exc}") from exc
        if not stable_value and args.legacy_bootstrap_stable_ids:
            stable_value, _ = ensure_case_stable_id(case)
            module = str(case.get("功能模块", "") or "")
            if module not in source_by_module:
                raise SystemExit(f"{case_id or '<无编号>'} 无法定位源 cases JSON，遗留稳定ID未写回")
            bootstrapped_modules.add(module)
        if not stable_value:
            raise SystemExit(
                f"{case_id or '<无编号>'} 缺 _stable_id/case_uid/matrix_key，禁止导出不可稳定迁移的生产用例；"
                "确认属于遗留项目时可显式使用 --legacy-bootstrap-stable-ids 完成一次性写回"
            )
    try:
        current_stable_to_case, current_case_to_stable = build_identity_maps(
            rows,
            label="当前cases",
        )
    except StableIdentityError as exc:
        raise SystemExit(f"当前cases稳定编号重复或冲突，禁止导出: {exc}") from exc

    prefix_by_module = _locked_prefixes(proj_dir)
    history_high_water: dict[str, int] = {}
    for case_id in historical_case_to_stable:
        match = re.fullmatch(r"(.+)_(\d+)", case_id)
        if match:
            prefix = match.group(1)
            history_high_water[prefix] = max(
                history_high_water.get(prefix, 0), int(match.group(2))
            )
    declared_high_water = historical_payload.get("high_water", {})
    if not isinstance(declared_high_water, dict):
        raise SystemExit("用例稳定索引 high_water 必须是对象")
    for prefix, value in declared_high_water.items():
        if not isinstance(value, int) or isinstance(value, bool) or value < 0:
            raise SystemExit(f"用例稳定索引 high_water.{prefix} 必须是非负整数")
        if value < history_high_water.get(str(prefix), 0):
            raise SystemExit(
                f"用例稳定索引 high_water.{prefix}={value} 小于历史最大编号 "
                f"{history_high_water[str(prefix)]}"
            )
        history_high_water[str(prefix)] = value

    if not args.renumber:
        drift: list[str] = []
        for stable_value, case_id in current_stable_to_case.items():
            historical_id = historical_stable_to_case.get(stable_value)
            if historical_id is not None and historical_id != case_id:
                drift.append(f"{stable_value}: 历史={historical_id} 当前={case_id}")
            historical_stable = historical_case_to_stable.get(case_id)
            if historical_stable is not None and historical_stable != stable_value:
                drift.append(f"{case_id}: 历史stable_id={historical_stable} 当前={stable_value}")
        if drift:
            preview = "; ".join(drift[:20])
            suffix = f"；其余{len(drift) - 20}条" if len(drift) > 20 else ""
            raise SystemExit(
                "已有 stable_id -> case_id 映射发生漂移，禁止静默覆盖稳定索引: "
                f"{preview}{suffix}；仅显式 --renumber + --migration-file 可迁移"
            )

        for module, module_cases in by_module.items():
            prefix = prefix_by_module.get(str(module), "")
            new_cases = [
                case for case in module_cases
                if case_stable_identity(case)[0] not in historical_stable_to_case
            ]
            if new_cases and not prefix:
                if index_existed or not args.legacy_bootstrap_stable_ids:
                    raise SystemExit(
                        f"模块 {module} 有全新stable_id但缺锁定contract/spec前缀，禁止接受任意编号"
                    )
                continue
            next_number = history_high_water.get(prefix, 0) + 1
            for case in module_cases:
                stable_value, _ = case_stable_identity(case)
                case_id = str(case.get("用例编号", "") or "")
                if prefix and _case_number(case_id, prefix) is None:
                    raise SystemExit(
                        f"模块 {module} 用例 {stable_value} 编号 {case_id} 不符合锁定前缀 {prefix}"
                    )
                if stable_value in historical_stable_to_case:
                    continue
                expected_id = f"{prefix}_{next_number:03d}"
                if case_id != expected_id:
                    raise SystemExit(
                        f"全新stable_id必须从历史high_water连续尾追加: {stable_value} "
                        f"expected={expected_id} actual={case_id}"
                    )
                next_number += 1

    # 可选:按最终行顺序重排每模块 用例编号
    migration_payload: dict = {}
    renumbered_modules: set[str] = set()
    if args.renumber:
        pre_renumber_case_by_stable = dict(current_stable_to_case)
        current_stables = set(current_stable_to_case)
        retired_stables = set(historical_stable_to_case) - current_stables
        retired_case_ids = {historical_stable_to_case[value] for value in retired_stables}
        for mod, cases in by_module.items():
            prefix = prefix_by_module.get(str(mod), "")
            if not prefix:
                raise SystemExit(
                    f"--renumber 要求模块 {mod} 在锁定contract/spec中有明确prefix，禁止从当前编号猜测"
                )
            next_number = 1
            for c in cases:
                old_id = str(c.get("用例编号", "") or "")
                new_id = f"{prefix}_{next_number:03d}"
                while new_id in retired_case_ids:
                    next_number += 1
                    new_id = f"{prefix}_{next_number:03d}"
                next_number += 1
                c["用例编号"] = new_id
                if old_id != new_id:
                    renumbered_modules.add(mod)

        try:
            current_stable_to_case, current_case_to_stable = build_identity_maps(
                rows,
                label="重编号后cases",
            )
        except StableIdentityError as exc:
            raise SystemExit(f"显式重编号产生重复或冲突，禁止写入: {exc}") from exc

        old_id_owner: dict[str, tuple[str, str]] = {
            historical_stable_to_case[stable_value]: (stable_value, "<retired>")
            for stable_value in retired_stables
        }
        migration_items: list[dict] = []
        for case in rows:
            stable_value, _ = case_stable_identity(case)
            new_id = current_stable_to_case[stable_value]
            old_ids = []
            for old_id in (
                historical_stable_to_case.get(stable_value, ""),
                pre_renumber_case_by_stable.get(stable_value, ""),
            ):
                if old_id and old_id not in old_ids:
                    old_ids.append(old_id)
            for old_id in old_ids:
                previous = old_id_owner.get(old_id)
                if previous is not None and previous != (stable_value, new_id):
                    raise SystemExit(
                        f"显式迁移旧编号歧义: {old_id} 同时属于 "
                        f"{previous[0]}->{previous[1]} 与 {stable_value}->{new_id}；禁止写迁移文件"
                    )
                old_id_owner[old_id] = (stable_value, new_id)
            migration_items.append({
                "stable_id": stable_value,
                "old_case_ids": old_ids,
                "new_case_id": new_id,
            })
        migration_payload = {
            "schema_version": 2,
            "items": migration_items,
            "retired_items": [
                {
                    "stable_id": stable_value,
                    "case_id": historical_stable_to_case[stable_value],
                }
                for stable_value in sorted(retired_stables)
            ],
        }

    stable_items: list[dict[str, str]] = []
    for case in rows:
        case_id = str(case.get("用例编号", "") or "")
        stable_value, matrix_key = case_stable_identity(case)
        stable_item = {"case_id": case_id, "stable_id": stable_value, "matrix_key": matrix_key}
        # Keep execution-only metadata outside the fixed 15-column workbook while
        # making it available to traceability. Prefer public keys; underscore
        # aliases are accepted for generators that keep metadata internal.
        for metadata_key in ("risk", "design", "detail_contract"):
            metadata = case.get(metadata_key)
            if metadata is None:
                metadata = case.get(f"_{metadata_key}")
            if metadata not in (None, "", {}, []):
                stable_item[metadata_key] = metadata
        stable_items.append(stable_item)

    current_stable_values = {item["stable_id"] for item in stable_items}
    retired_items = [
        historical_records_by_stable[stable_value]
        for stable_value in sorted(set(historical_records_by_stable) - current_stable_values)
    ]
    final_high_water = dict(history_high_water)
    for item in stable_items + retired_items:
        case_id = str(item.get("case_id", "") or "")
        match = re.fullmatch(r"(.+)_(\d+)", case_id)
        if match:
            prefix = match.group(1)
            final_high_water[prefix] = max(
                final_high_water.get(prefix, 0), int(match.group(2))
            )
    stable_index_payload = {
        "schema_version": 2,
        "items": stable_items,
        "retired_items": retired_items,
        "high_water": dict(sorted(final_high_water.items())),
    }
    try:
        build_identity_maps(
            stable_items + retired_items,
            label="待写稳定索引历史",
        )
    except StableIdentityError as exc:
        raise SystemExit(f"待写稳定索引重复或冲突，禁止写入: {exc}") from exc

    migration_path: Path | None = None
    if args.renumber:
        migration_path = Path(args.migration_file)
        if not migration_path.is_absolute():
            migration_path = proj_dir / migration_path

    changed_modules = bootstrapped_modules | renumbered_modules
    out = Path(args.out) if args.out else (proj_dir / f"{args.project}_全功能测试用例.xlsx")

    # Stage and read back every artifact before replacing any final output.
    with tempfile.TemporaryDirectory(prefix=".qa-export-stage-", dir=proj_dir) as stage_value:
        stage = Path(stage_value)
        staged_sources: dict[Path, Path] = {}
        for module in sorted(changed_modules):
            source, payload = source_by_module[module]
            staged = stage / f"source-{len(staged_sources):04d}.json"
            staged.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            json.loads(staged.read_text(encoding="utf-8"))
            staged_sources[source] = staged

        staged_migration = stage / "migration.json"
        if migration_path is not None:
            staged_migration.write_text(
                json.dumps(migration_payload, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            json.loads(staged_migration.read_text(encoding="utf-8"))

        staged_index = stage / "stable-index.json"
        staged_index.write_text(
            json.dumps(stable_index_payload, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        json.loads(staged_index.read_text(encoding="utf-8"))

        staged_out = stage / "cases.xlsx"
        tc_excel.write_workbook(
            rows,
            staged_out,
            module_order=order,
            include_module_sheets=not args.single_sheet,
            master_sheet=args.master_sheet,
        )
        staged_rows = tc_excel.read_master_rows(staged_out)
        if [str(row.get("用例编号", "")) for row in staged_rows] != [
            str(row.get("用例编号", "")) for row in rows
        ]:
            raise SystemExit("暂存Excel回读用例编号与待导出cases不一致，禁止提交")

        commit_pairs = [(staged, source) for source, staged in staged_sources.items()]
        if migration_path is not None:
            commit_pairs.append((staged_migration, migration_path))
        commit_pairs.extend([(staged_out, out), (staged_index, stable_index)])

        def finalize_lineage() -> None:
            if changed_modules:
                record_casegen(proj_dir)
            record_export(proj_dir, out, stable_index)

        try:
            commit_staged_files(
                commit_pairs,
                protected_paths=[proj_dir / LINEAGE_REL],
                post_commit=finalize_lineage,
            )
        except (OSError, RuntimeError, StableIdentityError, LineageError) as exc:
            raise SystemExit(f"export批量提交失败，已回滚全部产物: {exc}") from exc

    for source in staged_sources:
        print(f"  cases稳定身份/编号已写回: {source}")
    print(f"\n已生成 {out}")
    print(f"稳定索引 {stable_index}")
    print(f"模块 {len(by_module)} 个 | 用例 {total} 条")


if __name__ == "__main__":
    main()
