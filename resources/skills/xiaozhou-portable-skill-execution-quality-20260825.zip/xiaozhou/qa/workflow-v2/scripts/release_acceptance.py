# -*- coding: utf-8 -*-
"""Versioned final release gate for workflow-v2 testcase projects."""
from __future__ import annotations

import argparse
import copy
import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

_SCRIPTS = Path(__file__).resolve().parent
if str(_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS))

import tc_excel  # noqa: E402
import delivery_quality  # noqa: E402
from execution_profile import PROFILE_FILENAME, has_pack, load_profile  # noqa: E402
from lineage import validate_release as validate_build_lineage  # noqa: E402
from stratified_acceptance_sample import CANONICAL_STRATA, STRATUM_ALIASES  # noqa: E402
from work_unit_contract import validate_project_contracts  # noqa: E402


REQUIRED_DELIVERY_PROJECTION_FIELDS = (
    "功能点", "测试项", "测试点/检查项", "前置条件",
    "操作步骤", "预期结果", "优先级", "备注",
)
REQUIRED_GENERIC_TEST_ITEMS = {
    "功能测试", "边界测试", "边界场景", "规则确认", "规则测试", "规则校验",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def resolve(base: Path, value: str | Path) -> Path:
    path = Path(value)
    return path if path.is_absolute() else base / path


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def issue(code: str, message: str) -> dict[str, str]:
    return {"severity": "blocking", "code": code, "message": message}


def command(name: str, argv: list[str], cwd: Path) -> dict[str, Any]:
    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    completed = subprocess.run(
        argv, cwd=cwd, env=env, text=True, capture_output=True,
        encoding="utf-8", errors="replace",
    )
    return {
        "name": name,
        "argv": argv,
        "returncode": completed.returncode,
        "stdout": completed.stdout.strip(),
        "stderr": completed.stderr.strip(),
    }


def append_command_failure(result: dict[str, Any], issues: list[dict]) -> None:
    """Keep the release manifest actionable without hiding the child gate report."""
    if result.get("returncode") == 0:
        return
    if result.get("name") == "execution_quality":
        try:
            payload = json.loads(str(result.get("stdout", "") or ""))
        except json.JSONDecodeError:
            payload = None
        child_issues = payload.get("issues", []) if isinstance(payload, dict) else []
        if isinstance(child_issues, list):
            for row in child_issues:
                if not isinstance(row, dict):
                    continue
                detail = copy.deepcopy(row)
                detail["source_gate"] = "execution_quality"
                issues.append(detail)
    issues.append(issue("GATE_FAILED", f"{result.get('name')} 退出码 {result.get('returncode')}"))


def case_payload(path: Path) -> list[dict]:
    payload = load_json(path)
    if isinstance(payload, list):
        return [row for row in payload if isinstance(row, dict)]
    if isinstance(payload, dict):
        return [row for row in payload.get("cases", []) if isinstance(row, dict)]
    return []


def collect_case_identity(project: Path, xlsx: Path, issues: list[dict]) -> dict[str, Any]:
    case_rows: list[dict] = []
    for path in sorted((project / "cases").glob("*.json")):
        case_rows.extend(case_payload(path))
    excel_rows = tc_excel.read_master_rows(xlsx) if xlsx.exists() else []
    index_path = project / "用例稳定索引.json"
    index_items = []
    if index_path.exists():
        payload = load_json(index_path)
        index_items = payload.get("items", []) if isinstance(payload, dict) else []
    else:
        issues.append(issue("STABLE_INDEX_MISSING", f"稳定索引不存在: {index_path}"))

    def ids(rows: list[dict], *keys: str) -> list[str]:
        values = []
        for row in rows:
            value = ""
            for key in keys:
                value = str(row.get(key, "") or "").strip()
                if value:
                    break
            values.append(value)
        return values

    case_ids = ids(case_rows, "用例编号", "id")
    case_stable = ids(case_rows, "_stable_id", "stable_id")
    excel_ids = ids(excel_rows, "用例编号")
    index_ids = ids(index_items, "case_id", "用例编号", "id")
    index_stable = ids(index_items, "stable_id", "_stable_id")
    for label, values in (
        ("cases case_id", case_ids), ("cases stable_id", case_stable),
        ("Excel case_id", excel_ids), ("index case_id", index_ids),
        ("index stable_id", index_stable),
    ):
        if not values or any(not value for value in values):
            issues.append(issue("IDENTITY_MISSING", f"{label} 存在空值或为空"))
        if len(values) != len(set(values)):
            issues.append(issue("IDENTITY_DUPLICATE", f"{label} 存在重复"))
    if set(case_ids) != set(excel_ids) or set(case_ids) != set(index_ids):
        issues.append(issue("CASE_ID_SET_MISMATCH", "cases/稳定索引/Excel 用例编号集合不一致"))
    if set(case_stable) != set(index_stable):
        issues.append(issue("STABLE_ID_SET_MISMATCH", "cases与稳定索引 stable ID集合不一致"))
    if len(case_rows) != len(excel_rows) or len(case_rows) != len(index_items):
        issues.append(issue(
            "CASE_COUNT_MISMATCH",
            f"cases/index/Excel计数不一致: {len(case_rows)}/{len(index_items)}/{len(excel_rows)}",
        ))

    result_dir = resolve(project, (load_json(project / "trace.config.json").get("out_dirs", {}) or {}).get("result", "结果"))
    result_refs: list[str] = []
    req_ids: list[str] = []
    for path in sorted(result_dir.glob("*.json")):
        payload = load_json(path)
        for item in payload.get("items", []) if isinstance(payload, dict) else []:
            if not isinstance(item, dict):
                continue
            req_id = str(item.get("req_id", "") or "").strip()
            if req_id:
                req_ids.append(req_id)
            matched = item.get("matched_ids", [])
            if isinstance(matched, list):
                result_refs.extend(str(value).strip() for value in matched if str(value).strip())
    missing_refs = sorted(set(result_refs) - set(case_ids))
    if missing_refs:
        issues.append(issue("RESULT_CASE_REFERENCE_MISSING", f"结果引用不存在用例: {missing_refs[:50]}"))
    if len(req_ids) != len(set(req_ids)):
        issues.append(issue("GLOBAL_REQ_ID_DUPLICATE", "当前结果中 req_id 跨模块重复"))
    return {
        "cases_rows": len(case_rows),
        "stable_index_items": len(index_items),
        "xlsx_rows": len(excel_rows),
        "result_matched_references": len(result_refs),
        "result_unique_req_ids": len(set(req_ids)),
    }


def input_files(config_path: Path, config: dict) -> list[Path]:
    base = config_path.parent
    files = [config_path]
    profile_path = base / PROFILE_FILENAME
    if profile_path.is_file():
        files.append(profile_path)
    profile_cfg = config.get("execution_profile", {}) or {}
    if isinstance(profile_cfg, dict) and profile_cfg.get("file"):
        files.append(resolve(base, profile_cfg["file"]))
    for value in (config.get("prd_path"), config.get("cases_xlsx")):
        if value:
            files.append(resolve(base, value))
    contract_cfg = config.get("generation_contract", {}) or {}
    contract_path = resolve(base, contract_cfg.get("file", "生成验收合同.json"))
    if contract_path.is_file() or contract_cfg.get("required") is True:
        files.append(contract_path)
    if contract_path.exists():
        contract = load_json(contract_path)
        for row in contract.get("pilot_risk_evidence", []) if isinstance(contract, dict) else []:
            if isinstance(row, dict) and row.get("evidence_path"):
                files.append(resolve(base, row["evidence_path"]))
    for value in ("用例稳定索引.json", "用例设计蓝图.json", "场景覆盖矩阵.json", "冲突矩阵索引.json"):
        files.append(base / value)
    release = config.get("release_acceptance", {}) or {}
    delivery = release.get("delivery_artifact", {}) or {}
    if isinstance(delivery, dict):
        if delivery.get("path"):
            files.append(resolve(base, delivery["path"]))
        if delivery.get("contract_file"):
            files.append(resolve(base, delivery["contract_file"]))
    for key in (
        "feedback_patterns_file",
        "multi_round_review_file",
        "changed_case_ids_file",
        "conflict_index_file",
    ):
        if release.get(key):
            files.append(resolve(base, release[key]))
    execution_quality = (config.get("quality_gates", {}) or {}).get("execution_quality", {}) or {}
    if isinstance(execution_quality, dict) and execution_quality.get("review_file"):
        files.append(resolve(base, execution_quality["review_file"]))
    multi_review_value = release.get("multi_round_review_file")
    if multi_review_value:
        multi_review_path = resolve(base, multi_review_value)
        if multi_review_path.is_file():
            multi_review_payload = load_json(multi_review_path)
            for round_row in multi_review_payload.get("rounds", []) \
                    if isinstance(multi_review_payload, dict) else []:
                if not isinstance(round_row, dict):
                    continue
                for agent_review in round_row.get("agent_reviews", []) \
                        if isinstance(round_row.get("agent_reviews"), list) else []:
                    if isinstance(agent_review, dict) and agent_review.get("report_path"):
                        files.append(resolve(base, agent_review["report_path"]))
    ledger_values: list[str] = []
    if release.get("decision_ledger_file"):
        ledger_values.append(str(release["decision_ledger_file"]))
    configured_ledgers = release.get("decision_ledger_files", [])
    if isinstance(configured_ledgers, list):
        ledger_values.extend(str(value) for value in configured_ledgers if str(value).strip())
    files.extend(resolve(base, value) for value in ledger_values)
    work_dir = base / "工作底稿"
    if work_dir.exists():
        for path in work_dir.glob("*.json"):
            name = path.name.lower()
            if (
                ("ledger" in name and any(marker in name for marker in ("req", "decision", "gate_b")))
                or ("账本" in path.name and any(marker in path.name for marker in ("需求", "决策")))
            ):
                files.append(path)
    for folder in ("specs", "cases"):
        files.extend(sorted((base / folder).glob("*.json")))
    workspace = config.get("workspace", {}) or {}
    workunits_dir = resolve(base, workspace.get("workunits_dir", "workunits"))
    if workunits_dir.is_dir():
        files.extend(sorted(path for path in workunits_dir.rglob("*") if path.is_file()))
    draft_dir = resolve(base, (config.get("out_dirs", {}) or {}).get("draft", "工作底稿"))
    files.extend(sorted(draft_dir.glob("*.json")))
    files.append(base / "工作底稿" / "build_lineage.json")
    result_dir = resolve(base, (config.get("out_dirs", {}) or {}).get("result", "结果"))
    files.extend(sorted(result_dir.glob("*.json")))
    unique: dict[str, Path] = {}
    for path in files:
        if path.exists() and path.is_file():
            unique[str(path.resolve()).lower()] = path.resolve()
    return sorted(unique.values(), key=lambda value: str(value).lower())


def _input_key(project: Path, path: Path) -> str:
    try:
        return str(path.resolve().relative_to(project.resolve())).replace("\\", "/")
    except ValueError:
        absolute = str(path.resolve()).replace("\\", "/")
        digest = hashlib.sha256(absolute.encode("utf-8")).hexdigest()[:16]
    return f"external/{digest}/{path.name}"


def execution_profile_routing_errors(release: dict, profile: dict) -> list[str]:
    """Compare new routing fields while preserving configs from before profiles existed."""
    legacy_strict = bool(profile.get("legacy_fallback"))
    strict_path = legacy_strict or profile.get("base_path") == "strict"
    expected = {
        "delivery_target": "STRICT_GO" if strict_path or has_pack(profile, "formal_release") else "READY_FOR_REVIEW",
        "full_traceability_required": strict_path or has_pack(profile, "full_traceability"),
        "pilot_required": strict_path or has_pack(profile, "pilot"),
        "formal_release_required": strict_path or has_pack(profile, "formal_release"),
    }
    errors: list[str] = []
    for key, value in expected.items():
        if legacy_strict and key not in release:
            continue
        if release.get(key) != value:
            errors.append(f"{key}={release.get(key)!r}，画像要求 {value!r}")
    return errors


def execution_profile_pointer_errors(config_path: Path, config: dict, profile: dict) -> list[str]:
    """Require new projects to bind the exact profile that controls routing."""
    if profile.get("legacy_fallback"):
        return []
    profile_cfg = config.get("execution_profile")
    if not isinstance(profile_cfg, dict) or not str(profile_cfg.get("file", "")).strip():
        return ["新项目 trace.config.json 缺 execution_profile.file"]
    configured = resolve(config_path.parent, profile_cfg["file"]).resolve()
    expected = (config_path.parent / PROFILE_FILENAME).resolve()
    if configured != expected:
        return [f"execution_profile.file 必须指向 {PROFILE_FILENAME}"]
    return []


def default_required_report_input_keys(config_path: Path, config: dict, hashes: dict[str, str]) -> list[str]:
    """Return the critical build inputs every hash-bound report must cover by default."""
    base = config_path.parent
    candidates: list[Path] = [config_path]
    profile_cfg = config.get("execution_profile", {}) or {}
    if isinstance(profile_cfg, dict) and profile_cfg.get("file"):
        candidates.append(resolve(base, profile_cfg["file"]))
    for value in (config.get("prd_path"), config.get("cases_xlsx")):
        if value:
            candidates.append(resolve(base, value))
    contract_cfg = config.get("generation_contract", {}) or {}
    candidates.append(resolve(base, contract_cfg.get("file", "生成验收合同.json")))
    candidates.append(base / "用例稳定索引.json")
    candidates.extend(sorted((base / "cases").glob("*.json")))
    result_dir = resolve(base, (config.get("out_dirs", {}) or {}).get("result", "结果"))
    candidates.extend(sorted(result_dir.glob("*.json")))
    for name in ("用例设计蓝图.json", "场景覆盖矩阵.json", "冲突矩阵索引.json"):
        candidates.append(base / name)
    release = config.get("release_acceptance", {}) or {}
    delivery = release.get("delivery_artifact", {}) or {}
    if isinstance(delivery, dict):
        if delivery.get("path"):
            candidates.append(resolve(base, delivery["path"]))
        if delivery.get("contract_file"):
            candidates.append(resolve(base, delivery["contract_file"]))
    keys: list[str] = []
    for path in candidates:
        if not path.exists() or not path.is_file():
            continue
        key = _input_key(base, path)
        if key in hashes and key not in keys:
            keys.append(key)
    return keys


def validate_required_reports(
    config_path: Path, config: dict, hashes: dict[str, str], issues: list[dict], *, required: bool | None = None
) -> tuple[list[str], list[dict[str, Any]]]:
    artifacts: list[str] = []
    nonblocking_issues: list[dict[str, Any]] = []
    release = config.get("release_acceptance", {}) or {}
    rows = release.get("required_reports")
    new_project = _generation_contract_schema_level(config_path, config) >= 3 \
        if required is None else required
    if new_project and (not isinstance(rows, list) or not rows):
        issues.append(issue(
            "REQUIRED_REPORTS_REQUIRED",
            "新项目 release_acceptance.required_reports 必须配置至少一项，禁止空清单直接准出",
        ))
        return artifacts, nonblocking_issues
    if rows is None:
        rows = []
    if not isinstance(rows, list):
        issues.append(issue("REQUIRED_REPORT_CONFIG_INVALID", "required_reports 必须是数组"))
        return artifacts, nonblocking_issues
    for row in rows:
        if not isinstance(row, dict) or not row.get("path"):
            issues.append(issue("REQUIRED_REPORT_CONFIG_INVALID", "required_reports条目必须包含path"))
            continue
        path = resolve(config_path.parent, row["path"])
        artifacts.append(str(path))
        if not path.exists():
            issues.append(issue("REQUIRED_REPORT_MISSING", f"必需报告不存在: {path}"))
            continue
        accepted_rows = row.get("accepted_statuses", ["PASS", "PASS_WITH_RISKS"])
        if not isinstance(accepted_rows, list) or not accepted_rows or any(not str(value).strip() for value in accepted_rows):
            issues.append(issue("REQUIRED_REPORT_CONFIG_INVALID", f"{path.name} accepted_statuses 必须是非空数组"))
            continue
        accepted = {str(value) for value in accepted_rows}
        try:
            payload = load_json(path)
        except (OSError, json.JSONDecodeError) as exc:
            issues.append(issue("REQUIRED_REPORT_INVALID", f"必需报告无法读取: {path} ({exc})"))
            continue
        if not isinstance(payload, dict):
            issues.append(issue("REQUIRED_REPORT_INVALID", f"必需报告根节点必须是对象: {path}"))
            continue
        if str(payload.get("status", "")) not in accepted:
            issues.append(issue("REQUIRED_REPORT_STATUS_FAIL", f"{path.name} status={payload.get('status')}"))
        else:
            nonblocking_issues.extend(_required_report_nonblocking_issues(path, payload))
        if "input_hashes" not in payload:
            issues.append(issue(
                "REQUIRED_REPORT_HASHES_MISSING",
                f"{path.name} 缺 input_hashes，禁止用文件时间代替密码学输入绑定",
            ))
            continue
        report_hashes = payload.get("input_hashes")
        if not isinstance(report_hashes, dict):
            issues.append(issue("REQUIRED_REPORT_HASHES_INVALID", f"{path.name} input_hashes 必须是对象"))
            continue
        if not report_hashes:
            issues.append(issue("REQUIRED_REPORT_HASHES_EMPTY", f"{path.name} input_hashes 为空，不能证明绑定当前输入"))
            continue

        required_keys = default_required_report_input_keys(config_path, config, hashes)
        configured_keys = row.get("required_input_keys", release.get("required_input_keys"))
        if configured_keys is not None:
            if not isinstance(configured_keys, list) or not configured_keys \
                    or any(not str(value).strip() for value in configured_keys):
                issues.append(issue(
                    "REQUIRED_REPORT_CONFIG_INVALID",
                    f"{path.name} required_input_keys 必须是非空字符串数组",
                ))
                continue
            for value in configured_keys:
                key = str(value).replace("\\", "/")
                if key not in required_keys:
                    required_keys.append(key)
        unknown_required = [key for key in required_keys if key not in hashes]
        if unknown_required:
            issues.append(issue(
                "REQUIRED_REPORT_INPUT_KEY_UNKNOWN",
                f"{path.name} required_input_keys 不在当前输入清单: {unknown_required[:20]}",
            ))
        missing_required = [key for key in required_keys if key not in report_hashes]
        if missing_required:
            issues.append(issue(
                "REQUIRED_REPORT_HASH_COVERAGE_MISSING",
                f"{path.name} input_hashes 未覆盖必需输入: {missing_required[:20]}",
            ))
        mismatches = [key for key, value in report_hashes.items() if hashes.get(key) != value]
        if mismatches:
            issues.append(issue("REQUIRED_REPORT_STALE_HASH", f"{path.name} 输入哈希过期: {mismatches[:20]}"))
    return artifacts, nonblocking_issues


def _required_report_nonblocking_issues(path: Path, payload: dict[str, Any]) -> list[dict[str, Any]]:
    """Preserve accepted risks and warnings from one required report."""
    findings: list[dict[str, Any]] = []
    seen: set[tuple[str, str, str]] = set()

    def add(severity: str, raw: Any, index: int) -> None:
        if isinstance(raw, dict):
            message = next((
                str(raw.get(key, "")).strip()
                for key in ("message", "reason", "text", "title", "body")
                if str(raw.get(key, "")).strip()
            ), json.dumps(raw, ensure_ascii=False, sort_keys=True))
            source_code = str(raw.get("code", raw.get("id", "")) or "").strip()
        else:
            message = str(raw).strip() or f"未提供第 {index} 项明细"
            source_code = ""
        fingerprint = (severity, source_code, message)
        if fingerprint in seen:
            return
        seen.add(fingerprint)
        findings.append({
            "severity": severity,
            "code": f"REQUIRED_REPORT_{severity.upper()}",
            "message": f"{path.name}: {message}",
            "details": {
                "source_report": str(path),
                "source_code": source_code,
            },
        })

    raw_issues = payload.get("issues", [])
    raw_issues = raw_issues if isinstance(raw_issues, list) else []
    for index, raw in enumerate(raw_issues, 1):
        if not isinstance(raw, dict):
            continue
        raw_severity = str(raw.get("severity", raw.get("level", "")) or "").strip().lower()
        if raw_severity in {"risk", "pending", "pending_confirmation"}:
            add("risk", raw, index)
        elif raw_severity in {"warning", "warn", "minor", "info", "notice"}:
            add("warning", raw, index)

    for field, severity in (("risks", "risk"), ("warnings", "warning")):
        rows = payload.get(field, [])
        rows = rows if isinstance(rows, list) else ([] if rows in (None, "") else [rows])
        for index, raw in enumerate(rows, 1):
            add(severity, raw, index)

    for severity, count_field in (("risk", "risk_count"), ("warning", "warning_count")):
        declared = payload.get(count_field, 0)
        declared = declared if isinstance(declared, int) and not isinstance(declared, bool) and declared > 0 else 0
        current = sum(1 for row in findings if row["severity"] == severity)
        for index in range(current + 1, declared + 1):
            add(severity, f"报告声明 {count_field}={declared}，未提供第 {index} 项明细", index)

    if str(payload.get("status", "")).strip().upper() == "PASS_WITH_RISKS" and not findings:
        add("risk", "报告状态为 PASS_WITH_RISKS，但未提供风险明细", 1)
    return findings


def validate_pilot_risk_evidence(config_path: Path, config: dict, hashes: dict[str, str], issues: list[dict]) -> int:
    """Validate schema-v3 pilot evidence without rerunning generation."""
    contract_cfg = config.get("generation_contract", {}) or {}
    contract_path = resolve(config_path.parent, contract_cfg.get("file", "生成验收合同.json"))
    if not contract_path.exists():
        return 0
    contract = load_json(contract_path)
    if not isinstance(contract, dict) or int(contract.get("schema_version", 0) or 0) < 3:
        return 0
    risk_types = {str(value).strip() for value in contract.get("pilot_risk_types", []) if str(value).strip()}
    pilot_modules = {str(value).strip() for value in contract.get("pilot_modules", []) if str(value).strip()}
    rows = contract.get("pilot_risk_evidence")
    if not isinstance(rows, list) or not rows:
        issues.append(issue("PILOT_RISK_EVIDENCE_REQUIRED", "schema v3 合同缺 pilot_risk_evidence"))
        return 0
    seen_pairs: set[tuple[str, str]] = set()
    covered_types: set[str] = set()
    covered_modules: set[str] = set()
    valid_files = 0
    for index, row in enumerate(rows, 1):
        if not isinstance(row, dict):
            issues.append(issue("PILOT_RISK_EVIDENCE_INVALID", f"pilot_risk_evidence[{index}] 必须是对象"))
            continue
        risk_type = str(row.get("risk_type", "") or "").strip()
        module = str(row.get("module", "") or "").strip()
        evidence_value = str(row.get("evidence_path", "") or "").strip()
        if risk_type not in risk_types or module not in pilot_modules or not evidence_value:
            issues.append(issue(
                "PILOT_RISK_EVIDENCE_INVALID",
                f"pilot_risk_evidence[{index}] 必须绑定已声明 risk_type、pilot module 和 evidence_path",
            ))
            continue
        pair = (risk_type, module)
        if pair in seen_pairs:
            issues.append(issue("PILOT_RISK_EVIDENCE_DUPLICATE", f"先导风险证据重复绑定: {risk_type}/{module}"))
            continue
        seen_pairs.add(pair)
        covered_types.add(risk_type)
        covered_modules.add(module)
        evidence_path = resolve(config_path.parent, evidence_value)
        rel = str(evidence_path.resolve().relative_to(config_path.parent)).replace("\\", "/") \
            if evidence_path.exists() else evidence_value.replace("\\", "/")
        if not evidence_path.is_file():
            issues.append(issue("PILOT_RISK_EVIDENCE_MISSING", f"先导风险证据不存在: {evidence_path}"))
        elif rel not in hashes:
            issues.append(issue("PILOT_RISK_EVIDENCE_UNHASHED", f"先导风险证据未进入输入哈希: {rel}"))
        else:
            valid_files += 1
    missing_types = sorted(risk_types - covered_types)
    missing_modules = sorted(pilot_modules - covered_modules)
    if missing_types:
        issues.append(issue("PILOT_RISK_TYPE_UNBOUND", f"先导风险类型缺模块证据绑定: {missing_types}"))
    if missing_modules:
        issues.append(issue("PILOT_MODULE_EVIDENCE_MISSING", f"先导模块缺风险证据绑定: {missing_modules}"))
    return valid_files


def _generation_contract_schema_level(config_path: Path, config: dict) -> int:
    contract_cfg = config.get("generation_contract", {}) or {}
    contract_path = resolve(config_path.parent, contract_cfg.get("file", "生成验收合同.json"))
    if not contract_path.exists():
        return 0
    try:
        contract = load_json(contract_path)
    except (OSError, json.JSONDecodeError):
        return 0
    raw_schema = contract.get("schema_version") if isinstance(contract, dict) else None
    return raw_schema if isinstance(raw_schema, int) and not isinstance(raw_schema, bool) else 0


def validate_required_strata_config(
    config_path: Path, config: dict, issues: list[dict], *, strict_required: bool | None = None
) -> bool:
    """Return whether sampling must run, enforcing the non-bypassable schema-v3 contract."""
    release = config.get("release_acceptance", {}) or {}
    raw_required = release.get("required_strata")
    if strict_required is False:
        return bool(raw_required)
    if strict_required is None and _generation_contract_schema_level(config_path, config) < 3:
        return bool(raw_required)

    if "required_strata" not in release:
        issues.append(issue(
            "REQUIRED_STRATA_CONFIG_MISSING",
            "schema v3 必须配置 release_acceptance.required_strata 全部标准验收分层",
        ))
        return True
    if not isinstance(raw_required, list):
        issues.append(issue(
            "REQUIRED_STRATA_CONFIG_INVALID",
            "schema v3 release_acceptance.required_strata 必须是非空数组",
        ))
        return True
    if not raw_required:
        issues.append(issue(
            "REQUIRED_STRATA_CONFIG_EMPTY",
            "schema v3 release_acceptance.required_strata 禁止为空",
        ))
        return True

    normalized: list[str] = []
    unknown: list[str] = []
    for value in raw_required:
        text = str(value or "").strip()
        canonical = STRATUM_ALIASES.get(text)
        if not canonical:
            unknown.append(text)
        elif canonical not in normalized:
            normalized.append(canonical)
    if unknown:
        issues.append(issue(
            "REQUIRED_STRATA_CONFIG_UNKNOWN",
            f"schema v3 required_strata 含未知分层: {unknown}",
        ))
    missing = [name for name in CANONICAL_STRATA if name not in normalized]
    if missing:
        issues.append(issue(
            "REQUIRED_STRATA_CONFIG_INCOMPLETE",
            f"schema v3 required_strata 缺少标准分层: {missing}",
        ))
    return True


def validate_feedback_gate_config(
    config_path: Path, config: dict, issues: list[dict], *, required: bool | None = None
) -> bool:
    """Return whether feedback scanning must run, making schema-v3 opt-out impossible."""
    release = config.get("release_acceptance", {}) or {}
    configured = release.get("feedback_patterns_required")
    if required is False:
        return bool(configured)
    if required is None and _generation_contract_schema_level(config_path, config) < 3:
        return bool(configured)
    if "feedback_patterns_required" not in release:
        issues.append(issue(
            "FEEDBACK_PATTERNS_REQUIRED_CONFIG_MISSING",
            "schema v3 必须显式配置 release_acceptance.feedback_patterns_required=true",
        ))
    elif configured is not True:
        issues.append(issue(
            "FEEDBACK_PATTERNS_REQUIRED_CONFIG_FALSE",
            "schema v3 禁止关闭反馈问题全项目同模式扫描门禁",
        ))
    return True


def validate_execution_quality_gate_config(
    config: dict, issues: list[dict], *, required: bool = False
) -> bool:
    """Validate and return whether the personnel execution-quality gate must run."""
    release = config.get("release_acceptance", {}) or {}
    configured = release.get("execution_quality_required")
    if not required and configured is not True:
        return False
    if configured is not True:
        issues.append(issue(
            "EXECUTION_QUALITY_REQUIRED_CONFIG_MISSING",
            "新画像必须显式配置 release_acceptance.execution_quality_required=true",
        ))
    gates = config.get("quality_gates", {}) or {}
    gate = gates.get("execution_quality") if isinstance(gates, dict) else None
    gate_ok = isinstance(gate, dict) \
        and gate.get("required") is True \
        and bool(str(gate.get("review_file", "")).strip()) \
        and bool(str(gate.get("blueprint_file", "")).strip()) \
        and bool(str(gate.get("order_map_key", "")).strip()) \
        and bool(str(gate.get("module_boundary_key", "")).strip()) \
        and gate.get("require_boundary_rules") is True
    if not gate_ok:
        issues.append(issue(
            "EXECUTION_QUALITY_PROFILE_DISABLED",
            "人员执行质量门禁必须启用，并绑定复核账本、设计蓝图、执行顺序和模块边界规则",
        ))
    return True


def validate_multi_round_review_gate_config(
    config_path: Path, config: dict, issues: list[dict], *, strict_required: bool | None = None
) -> bool:
    """Return whether multi-agent review must run; schema-v3 releases cannot bypass it."""
    release = config.get("release_acceptance", {}) or {}
    configured = release.get("multi_round_review_required")
    multi_agent_configured = release.get("multi_agent_review_required")
    schema_v3 = _generation_contract_schema_level(config_path, config) >= 3 \
        if strict_required is None else strict_required
    if not schema_v3:
        if "multi_round_review_required" not in release:
            return False
        if configured is not True:
            issues.append(issue(
                "MULTI_ROUND_REVIEW_REQUIRED_CONFIG_FALSE",
                "已声明多轮评审配置时，release_acceptance.multi_round_review_required必须为true",
            ))
        if "multi_agent_review_required" in release and multi_agent_configured is not True:
            issues.append(issue(
                "MULTI_AGENT_REVIEW_REQUIRED_CONFIG_FALSE",
                "已声明多 Agent 评审配置时，release_acceptance.multi_agent_review_required必须为true",
            ))
        return True
    if "multi_round_review_required" not in release:
        issues.append(issue(
            "MULTI_ROUND_REVIEW_REQUIRED_CONFIG_MISSING",
            "schema v3 必须显式配置 release_acceptance.multi_round_review_required=true",
        ))
    elif configured is not True:
        issues.append(issue(
            "MULTI_ROUND_REVIEW_REQUIRED_CONFIG_FALSE",
            "schema v3 禁止关闭多轮评审门禁",
        ))
    if "multi_agent_review_required" not in release:
        issues.append(issue(
            "MULTI_AGENT_REVIEW_REQUIRED_CONFIG_MISSING",
            "schema v3 必须显式配置 release_acceptance.multi_agent_review_required=true",
        ))
    elif multi_agent_configured is not True:
        issues.append(issue(
            "MULTI_AGENT_REVIEW_REQUIRED_CONFIG_FALSE",
            "schema v3 禁止关闭多 Agent 独立评审门禁",
        ))
    if multi_agent_configured is True and configured is not True:
        issues.append(issue(
            "MULTI_AGENT_REVIEW_WITHOUT_MULTI_ROUND",
            "multi_agent_review_required=true 时必须同时开启 multi_round_review_required=true",
        ))
    return True


def _concrete_reason(value: Any) -> bool:
    if isinstance(value, str):
        text = value.strip()
        return bool(text) and text not in {"N/A", "NA", "不适用", "not_applicable"}
    if isinstance(value, dict):
        return _concrete_reason(value.get("reason"))
    return False


def _deep_merge(base: dict, override: dict) -> dict:
    merged = copy.deepcopy(base)
    for key, value in override.items():
        if isinstance(value, dict) and isinstance(merged.get(key), dict):
            merged[key] = _deep_merge(merged[key], value)
        else:
            merged[key] = copy.deepcopy(value)
    return merged


def _delivery_gate_config(config_path: Path, config: dict, delivery: dict, issues: list[dict]) -> dict:
    project = config_path.parent
    gates: dict = {}
    contract_file = str(delivery.get("contract_file", "") or "").strip()
    if contract_file:
        path = resolve(project, contract_file)
        if not path.is_file():
            issues.append(issue("DELIVERY_CONTRACT_MISSING", f"交付质量合同不存在: {path}"))
            return {}
        try:
            payload = load_json(path)
        except (OSError, json.JSONDecodeError) as exc:
            issues.append(issue("DELIVERY_CONTRACT_INVALID", f"交付质量合同无法读取: {path} ({exc})"))
            return {}
        if isinstance(payload, dict):
            gates = payload.get("quality_gates", payload)
    elif isinstance(delivery.get("quality_gates"), dict):
        gates = delivery["quality_gates"]
    elif delivery.get("quality_gates_source", "top_level") == "top_level":
        gates = config.get("quality_gates", {})
    if not isinstance(gates, dict) or not gates:
        issues.append(issue("DELIVERY_QUALITY_PROFILE_MISSING", "delivery_artifact 未提供可执行的 quality_gates"))
        return {}
    overrides = delivery.get("quality_gate_overrides", {})
    if overrides:
        if not isinstance(overrides, dict):
            issues.append(issue("DELIVERY_QUALITY_PROFILE_INVALID", "quality_gate_overrides 必须是对象"))
            return {}
        gates = _deep_merge(gates, overrides)
    gates = copy.deepcopy(gates)
    # Contract paths belong to the testcase project, even when the delivery
    # workbook lives in an external outputs directory.
    for gate_name in ("case_scale", "hierarchy_mapping"):
        gate = gates.get(gate_name)
        if isinstance(gate, dict) and gate.get("file"):
            gate["file"] = str(resolve(project, gate["file"]).resolve())
    if delivery.get("expected_version"):
        workbook_gate = gates.setdefault("delivery_workbook", {})
        if isinstance(workbook_gate, dict):
            workbook_gate["expected_version"] = str(delivery["expected_version"])
    return gates


def _projection_value(row: dict, field: str) -> str:
    aliases = {"测试点": "测试点/检查项", "测试步骤": "操作步骤"}
    key = aliases.get(field, field)
    return str(row.get(key, "") or "").strip()


def _normalize_projection_field(field: Any) -> str:
    aliases = {"测试点": "测试点/检查项", "测试步骤": "操作步骤"}
    text = str(field or "").strip()
    return aliases.get(text, text)


def validate_delivery_quality_profile(
    gates: dict,
    issues: list[dict],
    *,
    require_scale: bool = True,
    require_execution_quality: bool = False,
) -> None:
    """Reject present-but-disabled delivery gates before they can look complete."""
    workbook = gates.get("delivery_workbook")
    workbook_ok = isinstance(workbook, dict) \
        and isinstance(workbook.get("single_sheet"), bool) \
        and isinstance(workbook.get("headers"), list) and bool(workbook.get("headers")) \
        and bool(str(workbook.get("font_name", "")).strip()) \
        and isinstance(workbook.get("font_size"), (int, float)) \
        and not isinstance(workbook.get("font_size"), bool) and workbook.get("font_size", 0) > 0 \
        and workbook.get("require_black_borders") is True \
        and isinstance(workbook.get("merge_hierarchy"), list) and bool(workbook.get("merge_hierarchy")) \
        and workbook.get("forbid_merges_outside_hierarchy") is True \
        and bool(str(workbook.get("expected_version", "")).strip()) \
        and "<" not in str(workbook.get("expected_version", "")) \
        and workbook.get("filename_must_contain_version") is True \
        and workbook.get("forbid_other_versions") is True \
        and isinstance(workbook.get("version_scan_fields"), list) and bool(workbook.get("version_scan_fields")) \
        and workbook.get("require_expected_version_mention") is True
    if isinstance(workbook, dict) and "实际结果" in workbook.get("headers", []):
        workbook_ok = workbook_ok and workbook.get("require_empty_actual_result") is True
    if not workbook_ok:
        issues.append(issue(
            "DELIVERY_WORKBOOK_PROFILE_DISABLED",
            "最终交付 delivery_workbook 必须锁定表头、字体字号、黑边框、层级合并、版本检查；含实际结果列时必须留空",
        ))

    taxonomy = gates.get("test_item_taxonomy")
    forbidden = {
        str(value).strip() for value in taxonomy.get("forbidden_generic_items", [])
    } if isinstance(taxonomy, dict) else set()
    if not REQUIRED_GENERIC_TEST_ITEMS.issubset(forbidden):
        issues.append(issue(
            "DELIVERY_TAXONOMY_PROFILE_DISABLED",
            "最终交付 test_item_taxonomy 必须阻断功能测试、边界测试/场景、规则确认/测试/校验",
        ))

    granularity = gates.get("case_granularity")
    if not isinstance(granularity, dict) \
            or granularity.get("forbid_grouped_scenarios") is not True \
            or granularity.get("detect_exact_duplicates") is not True:
        issues.append(issue(
            "DELIVERY_GRANULARITY_PROFILE_DISABLED",
            "最终交付 case_granularity 必须同时启用独立场景合并检测和等价重复检测",
        ))

    cross = gates.get("cross_scene_block")
    cross_present_or_na = isinstance(cross, dict) and (
        cross.get("require_present") is True or _concrete_reason(cross.get("not_applicable_reason"))
    )
    cross_ok = isinstance(cross, dict) \
        and isinstance(cross.get("feature_points"), list) and bool(cross.get("feature_points")) \
        and cross.get("scope") in {"global", "module"} \
        and cross.get("require_tail") is True \
        and isinstance(cross.get("cross_items"), list) and bool(cross.get("cross_items")) \
        and cross_present_or_na
    if not cross_ok:
        issues.append(issue(
            "DELIVERY_CROSS_BLOCK_PROFILE_DISABLED",
            "最终交付 cross_scene_block 必须配置交叉功能点、对象清单、末尾连续区块，并要求存在或写具体不适用原因",
        ))

    scale = gates.get("case_scale")
    scale_ok = isinstance(scale, dict) and scale.get("required") is True \
        and bool(str(scale.get("file", "")).strip()) \
        and bool(str(scale.get("profile_key", "")).strip())
    if require_scale and not scale_ok:
        issues.append(issue(
            "DELIVERY_SCALE_PROFILE_DISABLED",
            "最终交付 case_scale 必须启用并绑定复杂度画像文件与字段",
        ))

    hierarchy = gates.get("hierarchy_mapping")
    hierarchy_ok = isinstance(hierarchy, dict) and hierarchy.get("required") is True \
        and bool(str(hierarchy.get("file", "")).strip()) \
        and bool(str(hierarchy.get("map_key", "")).strip())
    if not hierarchy_ok:
        issues.append(issue(
            "DELIVERY_HIERARCHY_PROFILE_DISABLED",
            "最终交付 hierarchy_mapping 必须启用并绑定功能点到测试意图映射文件与字段",
        ))

    if require_execution_quality:
        execution = gates.get("execution_quality")
        execution_ok = isinstance(execution, dict) \
            and execution.get("required") is True \
            and bool(str(execution.get("review_file", "")).strip()) \
            and bool(str(execution.get("blueprint_file", "")).strip()) \
            and bool(str(execution.get("order_map_key", "")).strip()) \
            and bool(str(execution.get("module_boundary_key", "")).strip()) \
            and execution.get("require_boundary_rules") is True \
            and isinstance(execution.get("wording_fields"), list) \
            and bool(execution.get("wording_fields")) \
            and isinstance(execution.get("forbidden_phrases"), list) \
            and bool(execution.get("forbidden_phrases")) \
            and isinstance(execution.get("contextual_test_item_terms"), list) \
            and bool(execution.get("contextual_test_item_terms"))
        if not execution_ok:
            issues.append(issue(
                "DELIVERY_EXECUTION_QUALITY_PROFILE_DISABLED",
                "最终交付 execution_quality 必须锁定措辞、归类、顺序、功能边界及全表人工复核账本",
            ))


def validate_delivery_artifact(
    config_path: Path,
    config: dict,
    canonical_xlsx: Path,
    issues: list[dict],
    *,
    required: bool | None = None,
    require_scale: bool = True,
    require_execution_quality: bool = False,
) -> tuple[dict[str, Any], Path | None]:
    """Validate the actual workbook handed to the user and its canonical projection."""
    release = config.get("release_acceptance", {}) or {}
    delivery = release.get("delivery_artifact")
    waivers = release.get("quality_gate_not_applicable", {}) or {}
    waiver = waivers.get("delivery_artifact") if isinstance(waivers, dict) else None
    required = _generation_contract_schema_level(config_path, config) >= 3 \
        if required is None else required
    if not isinstance(delivery, dict) or not delivery:
        if required:
            issues.append(issue(
                "DELIVERY_ARTIFACT_CONFIG_MISSING",
                "schema v3 必须配置 release_acceptance.delivery_artifact；与canonical同表时也必须显式指向cases_xlsx",
            ))
            if waiver is not None:
                issues.append(issue(
                    "DELIVERY_ARTIFACT_WAIVER_FORBIDDEN",
                    "schema v3 最终用户交付物不得通过 quality_gate_not_applicable.delivery_artifact 豁免",
                ))
        return {}, None
    if waiver is not None:
        issues.append(issue(
            "DELIVERY_ARTIFACT_WAIVER_FORBIDDEN",
            "最终用户交付物已配置，不得再声明 quality_gate_not_applicable.delivery_artifact",
        ))
    value = str(delivery.get("path", "") or "").strip()
    if not value:
        issues.append(issue("DELIVERY_ARTIFACT_PATH_MISSING", "delivery_artifact.path 不能为空"))
        return {}, None
    path = resolve(config_path.parent, value).resolve()
    if not path.is_file():
        issues.append(issue("DELIVERY_ARTIFACT_MISSING", f"最终交付Excel不存在: {path}"))
        return {}, path
    gates = _delivery_gate_config(config_path, config, delivery, issues)
    required_gates = {
        "delivery_workbook", "test_item_taxonomy", "case_granularity",
        "hierarchy_mapping", "cross_scene_block",
    }
    if require_scale:
        required_gates.add("case_scale")
    if require_execution_quality:
        required_gates.add("execution_quality")
    if gates:
        missing = sorted(name for name in required_gates if not gates.get(name))
        if missing:
            issues.append(issue(
                "DELIVERY_QUALITY_PROFILE_INCOMPLETE",
                f"最终交付质量合同缺少门禁: {missing}",
            ))
        validate_delivery_quality_profile(
            gates,
            issues,
            require_scale=require_scale,
            require_execution_quality=require_execution_quality,
        )
        delivery_cfg = gates.get("delivery_workbook", {}) or {}
        modules = config.get("modules", []) or []
        default_module = str(delivery.get("module", "") or "")
        if not default_module and len(modules) == 1 and isinstance(modules[0], dict):
            default_module = str(modules[0].get("name", "") or "")
        try:
            rows = delivery_quality.read_case_rows(path, delivery_cfg, default_module)
            violations = delivery_quality.check_quality(rows, gates, path)
        except Exception as exc:  # noqa: BLE001
            issues.append(issue("DELIVERY_QUALITY_EXECUTION_ERROR", f"最终交付门禁执行失败: {exc}"))
            rows = []
            violations = []
        for violation in violations:
            issues.append(issue("DELIVERY_QUALITY_FAILED", violation))
    else:
        rows = []

    canonical_rows = tc_excel.read_master_rows(canonical_xlsx) if canonical_xlsx.is_file() else []
    projection = delivery.get("projection")
    if not isinstance(projection, dict):
        issues.append(issue("DELIVERY_PROJECTION_CONFIG_INVALID", "delivery_artifact.projection 必须是对象"))
        projection = {}
    mode = str(projection.get("mode", "") or "")
    if mode != "exact":
        issues.append(issue(
            "DELIVERY_PROJECTION_MODE_INVALID",
            "最终交付表只允许 exact 投影；不得通过删例、合例或改写正文形成另一套未追溯用例",
        ))
    canonical_ids = [_projection_value(row, "用例编号") for row in canonical_rows]
    delivery_ids = [_projection_value(row, "用例编号") for row in rows]
    duplicate_ids = sorted({case_id for case_id in delivery_ids if case_id and delivery_ids.count(case_id) > 1})
    if duplicate_ids:
        issues.append(issue("DELIVERY_CASE_ID_DUPLICATE", f"最终交付表用例编号重复: {duplicate_ids[:20]}"))
    if canonical_ids != delivery_ids:
        missing = [case_id for case_id in canonical_ids if case_id not in set(delivery_ids)]
        extra = [case_id for case_id in delivery_ids if case_id not in set(canonical_ids)]
        issues.append(issue(
            "DELIVERY_CASE_SEQUENCE_MISMATCH",
            f"最终交付表与canonical用例编号/顺序不一致: canonical={len(canonical_ids)}, delivery={len(delivery_ids)}, "
            f"缺少={missing[:12]}, 多出={extra[:12]}",
        ))
    configured_fields = projection.get("fields")
    normalized_fields = [
        _normalize_projection_field(value) for value in configured_fields
        if _normalize_projection_field(value)
    ] if isinstance(configured_fields, list) else []
    missing_projection_fields = [
        field for field in REQUIRED_DELIVERY_PROJECTION_FIELDS if field not in normalized_fields
    ]
    if missing_projection_fields:
        issues.append(issue(
            "DELIVERY_PROJECTION_FIELDS_INCOMPLETE",
            f"exact投影必须比较完整业务字段，缺少: {missing_projection_fields}",
        ))
    fields = list(REQUIRED_DELIVERY_PROJECTION_FIELDS)
    fields.extend(field for field in normalized_fields if field not in fields)
    canonical_by_id = {
        _projection_value(row, "用例编号"): row for row in canonical_rows if _projection_value(row, "用例编号")
    }
    differences: list[str] = []
    for row in rows:
        case_id = _projection_value(row, "用例编号")
        source = canonical_by_id.get(case_id)
        if source is None:
            continue
        for field in fields:
            if _projection_value(source, field) != _projection_value(row, field):
                differences.append(f"{case_id}.{field}")
    if differences:
        issues.append(issue(
            "DELIVERY_CASE_CONTENT_MISMATCH",
            f"最终交付表业务正文与canonical源不一致，示例: {differences[:20]}",
        ))
    return {
        "delivery_rows": len(rows),
        "delivery_sha256": sha256(path),
        "delivery_projection_fields": fields,
        "delivery_projection_difference_count": len(differences),
    }, path


def _nested_value(payload: dict, path: str) -> Any:
    value: Any = payload
    for key in path.split("."):
        if not isinstance(value, dict) or key not in value:
            return None
        value = value[key]
    return value


def validate_quality_profile(
    config_path: Path, config: dict, issues: list[dict], *, strict_required: bool | None = None
) -> None:
    """Reject schema-v3 quality profiles that remove or silently skip core Gate C checks."""
    if strict_required is False:
        gates = config.get("quality_gates")
        if not isinstance(gates, dict) or not gates:
            issues.append(issue("QUALITY_GATES_PROFILE_REQUIRED", "core 画像 quality_gates 必须是非空对象"))
            return
        required_core = (
            "functional_manual_contract", "excel_format", "blueprint",
            "production_semantics", "hierarchy_contiguous_block", "delivery_workbook",
            "test_item_taxonomy", "case_granularity", "hierarchy_mapping",
        )
        release = config.get("release_acceptance", {}) or {}
        if release.get("execution_quality_required") is True:
            required_core = (*required_core, "execution_quality")
        missing = [name for name in required_core if not gates.get(name)]
        if missing:
            issues.append(issue("CORE_QUALITY_GATE_MISSING", f"core 画像缺不可关闭门禁: {missing}"))
        return
    if strict_required is None and _generation_contract_schema_level(config_path, config) < 3:
        return
    gates = config.get("quality_gates")
    if not isinstance(gates, dict) or not gates:
        issues.append(issue("QUALITY_GATES_PROFILE_REQUIRED", "schema v3 quality_gates 必须是非空对象"))
        return
    release = config.get("release_acceptance", {}) or {}
    waivers = release.get("quality_gate_not_applicable", {})
    if waivers is None:
        waivers = {}
    if not isinstance(waivers, dict):
        issues.append(issue(
            "QUALITY_GATE_NA_CONFIG_INVALID",
            "release_acceptance.quality_gate_not_applicable 必须是门禁路径到具体原因的对象",
        ))
        waivers = {}

    required_gate_paths = (
        "feature_order", "module_dependencies", "unsupported_features", "page_input_matrix", "new_modules",
        "test_item_exception_objects", "cross_scene", "common_fixtures", "navigation_expectations",
        "test_item_taxonomy", "case_granularity", "cross_scene_block", "case_scale",
        "hierarchy_mapping", "delivery_workbook",
    )
    if release.get("execution_quality_required") is True:
        required_gate_paths = (*required_gate_paths, "execution_quality")
    for path in required_gate_paths:
        value = _nested_value(gates, path)
        reason = waivers.get(path)
        configured = value is not None
        if not configured and not _concrete_reason(reason):
            issues.append(issue(
                "QUALITY_GATE_CONFIG_MISSING",
                f"schema v3 quality_gates.{path} 必须配置；不适用时须在 quality_gate_not_applicable 写具体原因",
            ))
        elif reason is not None and not _concrete_reason(reason):
            issues.append(issue("QUALITY_GATE_NA_REASON_MISSING", f"quality_gate_not_applicable.{path} 缺具体原因"))
        elif configured and _concrete_reason(reason):
            issues.append(issue(
                "QUALITY_GATE_NA_CONFLICT",
                f"quality_gates.{path} 已配置，不得同时声明不适用",
            ))

    excel = gates.get("excel_format")
    excel_ok = isinstance(excel, dict) and excel.get("merge_hierarchy_cells") is True \
        and excel.get("require_precondition_numbering") is True \
        and excel.get("require_test_point_verify_prefix") is True \
        and isinstance(excel.get("test_point_max_length"), int) \
        and not isinstance(excel.get("test_point_max_length"), bool) \
        and excel.get("test_point_max_length", 0) > 0 \
        and isinstance(excel.get("check_migration"), bool)
    if not excel_ok:
        issues.append(issue("QUALITY_GATE_EXCEL_FORMAT_INVALID", "schema v3 excel_format 核心检查必须完整启用"))

    manual = gates.get("functional_manual_contract")
    manual_ok = isinstance(manual, dict) and manual.get("required") is True \
        and manual.get("execution_mode") == "manual" \
        and manual.get("forbid_automation_details") is True \
        and manual.get("step_expected_one_to_one") is True \
        and bool(str(manual.get("automation_conversion_artifact", "")).strip())
    if not manual_ok:
        issues.append(issue(
            "QUALITY_GATE_FUNCTIONAL_MANUAL_CONTRACT_INVALID",
            "schema v3 functional_manual_contract 必须锁定纯人工执行、步骤预期一一对应并声明独立自动化转换产物",
        ))

    blueprint = gates.get("blueprint")
    required_blueprint_keys = {
        "module_boundary", "feature_order", "page_state_anchors", "input_matrix", "exception_matrix",
        "cross_matrix", "common_fixtures", "case_precondition_rules", "unsupported_features",
        "complexity_profile", "hierarchy_map",
    }
    if release.get("execution_quality_required") is True:
        required_blueprint_keys.add("execution_order")
    blueprint_ok = isinstance(blueprint, dict) and blueprint.get("required") is True \
        and isinstance(blueprint.get("files"), list) and bool(blueprint.get("files")) \
        and required_blueprint_keys.issubset({str(value) for value in blueprint.get("required_keys", [])})
    if not blueprint_ok:
        issues.append(issue("QUALITY_GATE_BLUEPRINT_INVALID", "schema v3 blueprint 必须启用并声明复杂度及层级映射在内的完整 required_keys"))

    ui_order = gates.get("ui_operation_order")
    ui_reason = waivers.get("ui_operation_order.pages")
    ui_base_ok = isinstance(ui_order, dict) and ui_order.get("enabled") is True \
        and ui_order.get("strict_coverage") is True
    ui_pages_ok = ui_base_ok and isinstance(ui_order.get("pages"), list) and bool(ui_order.get("pages"))
    if not ui_base_ok or (not ui_pages_ok and not _concrete_reason(ui_reason)):
        issues.append(issue(
            "QUALITY_GATE_UI_ORDER_INVALID",
            "schema v3 ui_operation_order 必须启用严格覆盖并配置页面；无界面操作时须逐项写具体N/A理由",
        ))
    elif ui_pages_ok and _concrete_reason(ui_reason):
        issues.append(issue("QUALITY_GATE_NA_CONFLICT", "ui_operation_order.pages 已配置，不得同时声明不适用"))

    semantics = gates.get("production_semantics")
    semantics_ok = isinstance(semantics, dict) \
        and semantics.get("require_nonempty_core_fields") is True \
        and semantics.get("check_manual_feasibility") is True \
        and semantics.get("check_dependency_module_boundaries") is True \
        and isinstance(semantics.get("preconditions"), dict) \
        and semantics["preconditions"].get("require_nonempty") is True
    if not semantics_ok:
        issues.append(issue("QUALITY_GATE_PRODUCTION_SEMANTICS_INVALID", "schema v3 production_semantics 核心检查必须启用"))

    conflict = gates.get("conflict_matrix_policy")
    conflict_ok = isinstance(conflict, dict) and conflict.get("required_when_cross_cases") is True \
        and bool(str(conflict.get("index_file", "")).strip()) \
        and isinstance(conflict.get("allowed_statuses"), list) and bool(conflict.get("allowed_statuses"))
    if not conflict_ok:
        issues.append(issue("QUALITY_GATE_CONFLICT_MATRIX_INVALID", "schema v3 conflict_matrix_policy 必须启用交叉用例条件门禁"))

    scenario = gates.get("scenario_coverage")
    scenario_ok = isinstance(scenario, dict) and scenario.get("required") is True \
        and bool(str(scenario.get("file", "")).strip()) \
        and isinstance(scenario.get("expected_dimensions"), list) and bool(scenario.get("expected_dimensions")) \
        and isinstance(scenario.get("allow_pending"), bool)
    if not scenario_ok:
        issues.append(issue("QUALITY_GATE_SCENARIO_COVERAGE_INVALID", "schema v3 scenario_coverage 必须完整启用"))


def _decision_ledger_paths(config_path: Path, config: dict) -> list[Path]:
    base = config_path.parent
    release = config.get("release_acceptance", {}) or {}
    values: list[str] = []
    if release.get("decision_ledger_file"):
        values.append(str(release["decision_ledger_file"]))
    configured = release.get("decision_ledger_files", [])
    if isinstance(configured, list):
        values.extend(str(value) for value in configured if str(value).strip())
    work_dir = base / "工作底稿"
    if work_dir.exists():
        for path in work_dir.glob("*.json"):
            name = path.name.lower()
            if (
                ("ledger" in name and any(marker in name for marker in ("req", "decision", "gate_b")))
                or ("账本" in path.name and any(marker in path.name for marker in ("需求", "决策")))
            ):
                values.append(str(path))
    unique: dict[str, Path] = {}
    for value in values:
        path = resolve(base, value).resolve()
        unique[str(path).lower()] = path
    return sorted(unique.values(), key=lambda path: str(path).lower())


def _configured_decision_ledger_paths(config_path: Path, config: dict) -> list[Path]:
    release = config.get("release_acceptance", {}) or {}
    values: list[str] = []
    if release.get("decision_ledger_file"):
        values.append(str(release["decision_ledger_file"]))
    configured = release.get("decision_ledger_files", [])
    if isinstance(configured, list):
        values.extend(str(value) for value in configured if str(value).strip())
    unique: dict[str, Path] = {}
    for value in values:
        path = resolve(config_path.parent, value).resolve()
        unique[str(path).lower()] = path
    return sorted(unique.values(), key=lambda path: str(path).lower())


def _requires_decision_ledger(config_path: Path, config: dict, *, strict_required: bool | None = None) -> bool:
    release = config.get("release_acceptance", {}) or {}
    if strict_required is True or (
        strict_required is None and _generation_contract_schema_level(config_path, config) >= 3
    ):
        return True
    return bool(release.get("decision_ledger_file") or release.get("decision_ledger_files"))


def _current_trace_requirement_ids(config_path: Path, config: dict, issues: list[dict]) -> set[str]:
    """Load the complete current requirement-ID set from configured trace drafts."""
    base = config_path.parent
    draft_dir = resolve(base, (config.get("out_dirs", {}) or {}).get("draft", "工作底稿"))
    modules = config.get("modules")
    if not isinstance(modules, list) or not modules:
        issues.append(issue("DECISION_TRACE_MODULES_MISSING", "无法校验需求决策账本：config.modules 为空"))
        return set()
    req_ids: set[str] = set()
    duplicates: set[str] = set()
    for module in modules:
        name = str(module.get("name", "") or "").strip() if isinstance(module, dict) else ""
        if not name:
            issues.append(issue("DECISION_TRACE_MODULE_INVALID", "config.modules 存在缺 name 的条目"))
            continue
        path = draft_dir / f"{name}.json"
        if not path.exists():
            issues.append(issue("DECISION_TRACE_DRAFT_MISSING", f"需求决策账本缺当前追溯底稿: {path}"))
            continue
        try:
            payload = load_json(path)
        except (OSError, json.JSONDecodeError) as exc:
            issues.append(issue("DECISION_TRACE_DRAFT_INVALID", f"追溯底稿无法读取: {path} ({exc})"))
            continue
        rows = payload.get("requirements") if isinstance(payload, dict) else None
        if not isinstance(rows, list):
            issues.append(issue("DECISION_TRACE_DRAFT_INVALID", f"追溯底稿 requirements 必须是数组: {path}"))
            continue
        for index, row in enumerate(rows, 1):
            req_id = str(row.get("req_id", "") or "").strip() if isinstance(row, dict) else ""
            if not req_id:
                issues.append(issue("DECISION_TRACE_REQ_INVALID", f"{path.name} requirements[{index}] 缺 req_id"))
                continue
            if req_id in req_ids:
                duplicates.add(req_id)
            req_ids.add(req_id)
    if duplicates:
        issues.append(issue("DECISION_TRACE_REQ_DUPLICATE", f"当前追溯底稿 req_id 重复: {sorted(duplicates)[:20]}"))
    if not req_ids:
        issues.append(issue("DECISION_TRACE_REQUIREMENTS_EMPTY", "当前追溯底稿未提取到任何 req_id"))
    return req_ids


def validate_decision_ledgers(
    config_path: Path, config: dict, issues: list[dict], *, strict_required: bool | None = None
) -> int:
    """Reject ambiguous current decisions and broken supersession links in known ledgers."""
    configured_paths = _configured_decision_ledger_paths(config_path, config)
    if _requires_decision_ledger(config_path, config, strict_required=strict_required) and not configured_paths:
        issues.append(issue(
            "DECISION_LEDGER_REQUIRED",
            "新生产项目必须在 release_acceptance 配置至少一个 decision_ledger_file/decision_ledger_files",
        ))
    checked = 0
    flat_current_by_req: dict[str, list[tuple[Path, dict]]] = {}
    flat_all_req_ids: set[str] = set()
    saw_flat_ledger = False
    for path in _decision_ledger_paths(config_path, config):
        checked += 1
        if not path.exists():
            issues.append(issue("DECISION_LEDGER_MISSING", f"需求决策账本不存在: {path}"))
            continue
        try:
            payload = load_json(path)
        except (OSError, json.JSONDecodeError) as exc:
            issues.append(issue("DECISION_LEDGER_INVALID", f"需求决策账本无法读取: {path} ({exc})"))
            continue
        if not isinstance(payload, dict):
            issues.append(issue("DECISION_LEDGER_INVALID", f"需求决策账本根节点必须是对象: {path}"))
            continue

        audit_rows = (payload.get("covered_by_decisions") or {}).get("items") \
            if isinstance(payload.get("covered_by_decisions"), dict) else None
        if isinstance(audit_rows, list):
            current: dict[str, dict] = {}
            for index, row in enumerate(audit_rows, 1):
                if not isinstance(row, dict) or not str(row.get("req_id", "") or "").strip():
                    issues.append(issue("DECISION_LEDGER_INVALID", f"{path.name} current[{index}] 缺 req_id"))
                    continue
                req_id = str(row["req_id"]).strip()
                if req_id in current:
                    issues.append(issue("DECISION_CURRENT_DUPLICATE", f"{path.name} req_id 存在多个当前决策: {req_id}"))
                current[req_id] = row
            if (payload.get("covered_by_decisions") or {}).get("complete") is not True:
                issues.append(issue("DECISION_LEDGER_INCOMPLETE", f"{path.name} covered_by_decisions.complete 必须为 true"))
            if payload.get("missing_req_ids"):
                issues.append(issue("DECISION_LEDGER_INCOMPLETE", f"{path.name} 仍有 missing_req_ids"))
            invalid_stable = payload.get("invalid_stable_ids")
            if isinstance(invalid_stable, dict) and int(invalid_stable.get("count", 0) or 0) != 0:
                issues.append(issue("DECISION_LEDGER_STABLE_ID_INVALID", f"{path.name} 存在无效 stable ID"))
            history_items: list[dict] = []
            duplicates = payload.get("duplicates")
            conflicts = payload.get("conflicts")
            if isinstance(duplicates, dict) and isinstance(duplicates.get("items"), list):
                history_items.extend(row for row in duplicates["items"] if isinstance(row, dict))
            if isinstance(conflicts, dict) and isinstance(conflicts.get("items"), list):
                history_items.extend(row for row in conflicts["items"] if isinstance(row, dict))
            for row in history_items:
                req_id = str(row.get("req_id", "") or "").strip()
                chosen = current.get(req_id)
                if not chosen or not str(chosen.get("chosen_source", "") or "").strip() \
                        or not str(chosen.get("resolution_rule", "") or "").strip():
                    issues.append(issue("DECISION_SUPERSESSION_UNRESOLVED", f"{path.name} 历史重复/冲突未显式选定当前决策: {req_id}"))
                    continue
                decisions = {str(value) for value in row.get("decisions", [])} if isinstance(row.get("decisions"), list) else set()
                if decisions and str(chosen.get("action", "")) not in decisions:
                    issues.append(issue("DECISION_RESOLUTION_MISMATCH", f"{path.name} 当前动作不在历史候选中: {req_id}"))
            continue

        rows = payload.get("items", payload.get("decisions"))
        if not isinstance(rows, list) or not rows:
            issues.append(issue("DECISION_LEDGER_SCHEMA_INVALID", f"无法识别需求决策账本结构: {path}"))
            continue
        saw_flat_ledger = True
        by_id: dict[str, dict] = {}
        current_by_req: dict[str, list[dict]] = {}
        superseded: list[dict] = []
        for index, row in enumerate(rows, 1):
            if not isinstance(row, dict):
                issues.append(issue("DECISION_LEDGER_INVALID", f"{path.name} items[{index}] 必须是对象"))
                continue
            req_id = str(row.get("req_id", "") or "").strip()
            action = str(row.get("action", row.get("decision", "")) or "").strip()
            decision_id = str(row.get("decision_id", row.get("id", "")) or "").strip()
            state = str(row.get("status", row.get("state", "current")) or "current").strip().lower()
            superseded_by = str(row.get("superseded_by", "") or "").strip()
            if not req_id or not action:
                issues.append(issue("DECISION_LEDGER_INVALID", f"{path.name} items[{index}] 缺 req_id/action"))
                continue
            flat_all_req_ids.add(req_id)
            if decision_id:
                if decision_id in by_id:
                    issues.append(issue("DECISION_ID_DUPLICATE", f"{path.name} decision_id 重复: {decision_id}"))
                by_id[decision_id] = row
            is_superseded = bool(superseded_by) or state in {"superseded", "obsolete", "historical", "inactive"}
            if is_superseded:
                superseded.append(row)
            else:
                current_by_req.setdefault(req_id, []).append(row)
                flat_current_by_req.setdefault(req_id, []).append((path, row))
        for req_id, current_rows in current_by_req.items():
            if len(current_rows) != 1:
                issues.append(issue("DECISION_CURRENT_CONFLICT", f"{path.name} req_id 存在{len(current_rows)}个当前决策: {req_id}"))
        for row in superseded:
            req_id = str(row.get("req_id", "") or "").strip()
            target_id = str(row.get("superseded_by", "") or "").strip()
            target = by_id.get(target_id)
            if not target_id or not target:
                issues.append(issue("DECISION_SUPERSESSION_INVALID", f"{path.name} {req_id} 缺有效 superseded_by"))
            elif str(target.get("req_id", "") or "").strip() != req_id or target not in current_by_req.get(req_id, []):
                issues.append(issue("DECISION_SUPERSESSION_INVALID", f"{path.name} {req_id} superseded_by 未指向同需求当前决策"))
    if saw_flat_ledger:
        expected_req_ids = _current_trace_requirement_ids(config_path, config, issues)
        missing = sorted(expected_req_ids - set(flat_current_by_req))
        unknown = sorted(flat_all_req_ids - expected_req_ids)
        duplicate_current = sorted(
            req_id for req_id, rows in flat_current_by_req.items() if len(rows) != 1
        )
        if missing:
            issues.append(issue(
                "DECISION_CURRENT_MISSING",
                f"平铺需求决策账本缺当前决策: {missing[:20]}",
            ))
        if unknown:
            issues.append(issue(
                "DECISION_REQ_UNKNOWN",
                f"平铺需求决策账本包含当前追溯中不存在的 req_id: {unknown[:20]}",
            ))
        if duplicate_current:
            issues.append(issue(
                "DECISION_CURRENT_CONFLICT",
                f"跨需求决策账本存在多个当前决策: {duplicate_current[:20]}",
            ))
    return checked


def evaluate(config_path: str | Path) -> tuple[dict[str, Any], Path]:
    config_path = Path(config_path).resolve()
    project = config_path.parent
    config = load_json(config_path)
    profile = load_profile(project)
    legacy_strict = bool(profile.get("legacy_fallback"))
    new_strict = not legacy_strict and profile.get("base_path") == "strict"
    strict_path = legacy_strict or new_strict
    full_traceability = strict_path or has_pack(profile, "full_traceability")
    pilot_required = strict_path or has_pack(profile, "pilot")
    strict_review = new_strict or has_pack(profile, "strict_review")
    formal_release = new_strict or has_pack(profile, "formal_release")
    release = config.get("release_acceptance", {}) or {}
    execution_quality_required = release.get("execution_quality_required") is True
    routing_errors = [
        *execution_profile_routing_errors(release, profile),
        *execution_profile_pointer_errors(config_path, config, profile),
    ]
    files = input_files(config_path, config)
    hashes = {_input_key(project, path): sha256(path) for path in files}
    digest = hashlib.sha256(json.dumps(hashes, sort_keys=True).encode("utf-8")).hexdigest()[:12]
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    run_id = f"{stamp}-{digest}"
    run_dir = project / "工作底稿" / "acceptance_runs" / run_id
    run_dir.mkdir(parents=True, exist_ok=False)
    issues: list[dict] = [
        issue("EXECUTION_PROFILE_CONFIG_MISMATCH", message)
        for message in routing_errors
    ]
    work_unit_metrics: dict[str, Any] = {}
    if not legacy_strict and profile.get("parallel_generation") is True:
        work_unit_errors, work_unit_metrics = validate_project_contracts(
            project, profile, require_frozen=True, require_complete=True,
        )
        issues.extend(issue("WORK_UNIT_CONTRACT_INVALID", message) for message in work_unit_errors)
    pilot_evidence_count = validate_pilot_risk_evidence(config_path, config, hashes, issues) \
        if pilot_required else 0
    decision_ledger_count = validate_decision_ledgers(
        config_path, config, issues,
        strict_required=None if legacy_strict else formal_release,
    )
    validate_quality_profile(
        config_path, config, issues,
        strict_required=None if legacy_strict else strict_path,
    )
    lineage_issues, lineage_metrics = validate_build_lineage(config_path, config)
    issues.extend(lineage_issues)
    xlsx = resolve(project, config.get("cases_xlsx", ""))
    metrics = collect_case_identity(project, xlsx, issues) if xlsx.exists() else {}
    if not xlsx.exists():
        issues.append(issue("CASES_XLSX_MISSING", f"最终Excel不存在: {xlsx}"))
    delivery_metrics, delivery_path = validate_delivery_artifact(
        config_path, config, xlsx, issues,
        required=None if legacy_strict else True,
        require_scale=pilot_required,
        require_execution_quality=execution_quality_required,
    )

    commands = [
        command("gate_c", [sys.executable, str(_SCRIPTS / "check_structure.py"), "--config", str(config_path)], _SCRIPTS.parent),
    ]
    if full_traceability:
        commands.append(command(
            "gate_b",
            [sys.executable, str(_SCRIPTS / "traceability" / "trace_gate.py"), "--config", str(config_path), "--no-gaps"],
            _SCRIPTS.parent,
        ))
    run_feedback_gate = validate_feedback_gate_config(
        config_path, config, issues,
        required=None if legacy_strict else formal_release,
    )
    run_multi_round_review_gate = validate_multi_round_review_gate_config(
        config_path, config, issues,
        strict_required=None if legacy_strict else strict_review,
    )
    run_stratified_sample = validate_required_strata_config(
        config_path, config, issues,
        strict_required=None if legacy_strict else formal_release,
    )
    run_execution_quality_gate = validate_execution_quality_gate_config(
        config,
        issues,
        required=not legacy_strict,
    )
    execution_quality_report = run_dir / "人员执行质量检查报告.json"
    if run_execution_quality_gate:
        commands.append(command(
            "execution_quality",
            [
                sys.executable,
                str(_SCRIPTS / "execution_quality_gate.py"),
                "--config", str(config_path),
                "--out", str(execution_quality_report),
            ],
            _SCRIPTS.parent,
        ))
    if run_feedback_gate:
        commands.append(command(
            "feedback_patterns", [sys.executable, str(_SCRIPTS / "feedback_pattern_gate.py"), "--config", str(config_path)], _SCRIPTS.parent,
        ))
    if run_multi_round_review_gate:
        commands.append(command(
            "multi_round_review",
            [sys.executable, str(_SCRIPTS / "multi_round_review_gate.py"), "--config", str(config_path)],
            _SCRIPTS.parent,
        ))
    if run_stratified_sample:
        commands.append(command(
            "stratified_sample",
            [sys.executable, str(_SCRIPTS / "stratified_acceptance_sample.py"), "--config", str(config_path), "--out", str(run_dir / "stratified_sample.json")],
            _SCRIPTS.parent,
        ))
    for result in commands:
        if result["returncode"] != 0:
            append_command_failure(result, issues)

    required_reports, report_nonblocking_issues = validate_required_reports(
        config_path, config, hashes, issues,
        required=None if legacy_strict else formal_release,
    )
    all_issues = [*issues, *report_nonblocking_issues]
    blocking_count = sum(1 for row in all_issues if row.get("severity") == "blocking")
    risk_count = sum(1 for row in all_issues if row.get("severity") == "risk")
    warning_count = sum(1 for row in all_issues if row.get("severity") == "warning")
    status = "FAIL" if blocking_count else ("PASS_WITH_RISKS" if risk_count or warning_count else "PASS")
    if status in {"PASS", "PASS_WITH_RISKS"}:
        release_decision = "GO"
        readiness_level = "READY_WITH_RISKS" if status == "PASS_WITH_RISKS" else (
            "STRICT_GO" if strict_path or formal_release else "READY_FOR_REVIEW"
        )
    else:
        release_decision = "NO_GO"
        readiness_level = "DRAFT"
    delivery_status = readiness_level if status in {"PASS", "PASS_WITH_RISKS"} else "NO_GO"
    manifest = {
        "schema_version": 1,
        "tool": "release_acceptance",
        "run_id": run_id,
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "status": status,
        "release_decision": release_decision,
        "readiness_level": readiness_level,
        # Compatibility alias for consumers created before readiness_level existed.
        "delivery_status": delivery_status,
        "release_level": "strict" if strict_path else "core",
        "blocking_count": blocking_count,
        "risk_count": risk_count,
        "warning_count": warning_count,
        "issues": all_issues,
        "metrics": {
            **metrics,
            **delivery_metrics,
            "input_file_count": len(files),
            "pilot_risk_evidence_files": pilot_evidence_count,
            "decision_ledgers_checked": decision_ledger_count,
            "execution_profile": profile.get("base_path"),
            "legacy_strict": legacy_strict,
            "capability_packs": profile.get("capability_packs", []),
            **work_unit_metrics,
            **lineage_metrics,
        },
        "input_hashes": hashes,
        "commands": commands,
        "artifacts": [
            str(run_dir / "manifest.json"),
            *([str(delivery_path)] if delivery_path is not None else []),
            *([str(execution_quality_report)] if run_execution_quality_gate else []),
            *required_reports,
        ],
    }
    manifest_path = run_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    latest = project / "工作底稿" / "acceptance_runs" / "latest.json"
    latest.write_text(json.dumps({
        "run_id": run_id, "status": status, "manifest": str(manifest_path),
        "input_digest": digest,
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    return manifest, manifest_path


def main() -> None:
    parser = argparse.ArgumentParser(description="workflow-v2 单一最终准出器")
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    try:
        report, path = evaluate(args.config)
    except Exception as exc:  # noqa: BLE001
        print(json.dumps({"status": "FAIL", "blocking_count": 1, "issues": [issue("EXECUTION_ERROR", str(exc))]}, ensure_ascii=False, indent=2))
        raise SystemExit(1) from exc
    print(json.dumps({**report, "manifest_path": str(path)}, ensure_ascii=False, indent=2))
    raise SystemExit(0 if report["status"] in {"PASS", "PASS_WITH_RISKS"} else 1)


if __name__ == "__main__":
    main()
