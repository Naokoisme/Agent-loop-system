# -*- coding: utf-8 -*-
"""Deterministic build lineage for schema-v3 testcase projects."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
from typing import Any
from uuid import uuid4

LINEAGE_REL = Path("工作底稿") / "build_lineage.json"
_LINEAGE_WRITE_COUNT = 0


class LineageError(RuntimeError):
    pass


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _key(project: Path, path: Path) -> str:
    try:
        return str(path.resolve().relative_to(project.resolve())).replace("\\", "/")
    except ValueError as exc:
        raise LineageError(f"schema v3 构建输入必须位于项目目录内: {path.resolve()}") from exc


def _digest(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _load_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def contract_schema(project: Path) -> int:
    config_path = project / "trace.config.json"
    if not config_path.exists():
        return 0
    config = _load_json(config_path)
    contract_name = (config.get("generation_contract", {}) or {}).get("file", "生成验收合同.json")
    contract_path = project / contract_name
    if not contract_path.exists():
        return 0
    value = _load_json(contract_path).get("schema_version", 0)
    return value if isinstance(value, int) and not isinstance(value, bool) else 0


def required(project: Path) -> bool:
    return contract_schema(project) >= 3


def _source_paths(project: Path, *, strict: bool) -> list[Path]:
    config_path = project / "trace.config.json"
    contract_path = project / "生成验收合同.json"
    if config_path.exists():
        config = _load_json(config_path)
        contract_path = project / (config.get("generation_contract", {}) or {}).get(
            "file", "生成验收合同.json"
        )
    fixed = [config_path, contract_path, project / "用例设计蓝图.json"]
    profile_path = project / "执行画像.json"
    if profile_path.is_file():
        fixed.append(profile_path)
    specs = sorted((project / "specs").glob("*.json"))
    if strict:
        missing = [str(path) for path in fixed if not path.is_file()]
        if not specs:
            missing.append(str(project / "specs" / "*.json"))
        if missing:
            raise LineageError(f"schema v3 构建血缘缺源文件: {missing}")
    optional = [project / name for name in ("ui_pages.json", "cross.json", "fpmap.json")]
    return [path for path in [*fixed, *specs, *optional] if path.is_file()]


def _hashes(project: Path, paths: list[Path]) -> dict[str, str]:
    return {_key(project, path): sha256(path) for path in paths}


def _case_hashes(project: Path) -> dict[str, str]:
    paths = sorted((project / "cases").glob("*.json"))
    if not paths:
        raise LineageError(f"schema v3 构建血缘缺正式 cases: {project / 'cases'}")
    return _hashes(project, paths)


def expected_modules(project: Path) -> list[str]:
    config = _load_json(project / "trace.config.json")
    return [str(row.get("name", "")) for row in config.get("modules", []) if isinstance(row, dict) and str(row.get("name", ""))]


def _assert_module_file_set(project: Path, folder: Path, label: str) -> list[Path]:
    paths = sorted(folder.glob("*.json"))
    actual = {path.stem for path in paths}
    expected = set(expected_modules(project))
    if actual != expected:
        raise LineageError(f"{label}模块文件集合与当前配置不一致: expected={sorted(expected)} actual={sorted(actual)}")
    return paths


def _read(project: Path) -> dict:
    path = project / LINEAGE_REL
    if not path.exists():
        raise LineageError(f"schema v3 缺构建血缘文件: {path}")
    payload = _load_json(path)
    if not isinstance(payload, dict):
        raise LineageError(f"构建血缘根节点必须是对象: {path}")
    return payload


def _write(project: Path, payload: dict) -> None:
    global _LINEAGE_WRITE_COUNT
    _LINEAGE_WRITE_COUNT += 1
    path = project / LINEAGE_REL
    path.parent.mkdir(parents=True, exist_ok=True)
    fault_enabled = str(os.environ.get("QA_TEST_ENABLE_FAULT_INJECTION", "") or "").strip() == "1"
    legacy_fail = str(os.environ.get("QA_TEST_FAIL_LINEAGE_WRITE", "") or "").strip() if fault_enabled else ""
    fail_value = str(os.environ.get("QA_TEST_FAIL_LINEAGE_WRITE_AT", "") or "").strip() if fault_enabled else ""
    fail_at = int(fail_value) if fail_value.isdigit() and int(fail_value) > 0 else (1 if legacy_fail == "1" else 0)
    fail_mode = str(os.environ.get("QA_TEST_FAIL_LINEAGE_WRITE_MODE", "before") or "before").strip()
    if fail_mode not in {"before", "after"}:
        fail_mode = "before"
    if fail_at == _LINEAGE_WRITE_COUNT and fail_mode == "before":
        raise OSError(
            f"QA_TEST_FAIL_LINEAGE_WRITE_AT={_LINEAGE_WRITE_COUNT} mode=before 故障注入"
        )
    temporary = path.parent / f".{path.name}.qa-new-{uuid4().hex}"
    try:
        temporary.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        json.loads(temporary.read_text(encoding="utf-8"))
        os.replace(temporary, path)
        if fail_at == _LINEAGE_WRITE_COUNT and fail_mode == "after":
            raise OSError(
                f"QA_TEST_FAIL_LINEAGE_WRITE_AT={_LINEAGE_WRITE_COUNT} mode=after 故障注入"
            )
    finally:
        temporary.unlink(missing_ok=True)


def record_casegen(project: Path) -> None:
    if not required(project):
        return
    source_hashes = _hashes(project, _source_paths(project, strict=True))
    _assert_module_file_set(project, project / "cases", "cases")
    cases_hashes = _case_hashes(project)
    source_build_id = _digest(source_hashes)
    payload = {
        "schema_version": 1,
        "contract_schema_version": contract_schema(project),
        "source_hashes": source_hashes,
        "source_build_id": source_build_id,
        "cases_hashes": cases_hashes,
        "cases_parent_source_build_id": source_build_id,
        "cases_build_id": _digest({"parent": source_build_id, "hashes": cases_hashes}),
    }
    lineage_path = project / LINEAGE_REL
    if lineage_path.exists():
        existing = _load_json(lineage_path)
        stable_path = existing.get("stable_index_path") if isinstance(existing, dict) else None
        stable_hash = existing.get("stable_index_hash") if isinstance(existing, dict) else None
        if isinstance(stable_path, str) and stable_path and isinstance(stable_hash, str) and stable_hash:
            payload["stable_index_path"] = stable_path
            payload["stable_index_hash"] = stable_hash
    _write(project, payload)


def _mismatch(recorded: Any, current: dict[str, str], label: str) -> None:
    if not isinstance(recorded, dict) or recorded != current:
        raise LineageError(f"{label}哈希与当前文件不一致，必须从对应阶段重新构建")


def verify_casegen(project: Path) -> dict:
    payload = _read(project)
    source_hashes = _hashes(project, _source_paths(project, strict=True))
    _assert_module_file_set(project, project / "cases", "cases")
    cases_hashes = _case_hashes(project)
    _mismatch(payload.get("source_hashes"), source_hashes, "source")
    _mismatch(payload.get("cases_hashes"), cases_hashes, "cases")
    source_build_id = _digest(source_hashes)
    cases_build_id = _digest({"parent": source_build_id, "hashes": cases_hashes})
    if payload.get("source_build_id") != source_build_id:
        raise LineageError("source_build_id 无效")
    if payload.get("cases_parent_source_build_id") != source_build_id:
        raise LineageError("cases 未绑定当前 source_build_id")
    if payload.get("cases_build_id") != cases_build_id:
        raise LineageError("cases_build_id 无效")
    return payload


def verify_stable_index_history(project: Path) -> None:
    """Require the last exported stable-index history before another write."""
    if not required(project):
        return
    lineage_path = project / LINEAGE_REL
    stable_default = project / "用例稳定索引.json"
    cases_exist = any((project / "cases").glob("*.json"))
    if not lineage_path.exists():
        if stable_default.exists() or cases_exist:
            raise LineageError(
                "schema v3 已有cases/稳定索引但缺构建血缘，禁止重置稳定编号历史"
            )
        return

    payload = _read(project)
    stable_key = payload.get("stable_index_path")
    stable_hash = payload.get("stable_index_hash")
    export_marker_keys = (
        "stable_index_path", "stable_index_hash", "xlsx_path", "xlsx_hash",
        "export_parent_cases_build_id", "export_build_id",
    )
    has_export_marker = any(payload.get(key) not in (None, "") for key in export_marker_keys)
    if stable_key in (None, "") and stable_hash in (None, ""):
        if stable_default.exists() or has_export_marker:
            raise LineageError("构建血缘缺稳定索引路径/历史哈希，禁止继续生成")
        return
    if not isinstance(stable_key, str) or not stable_key or not isinstance(stable_hash, str) or not stable_hash:
        raise LineageError("构建血缘中的稳定索引路径/哈希不完整")
    expected_key = _key(project, stable_default)
    if stable_key != expected_key:
        raise LineageError(
            f"构建血缘稳定索引路径必须为 {expected_key}，实际为 {stable_key}"
        )
    stable_path = project / stable_key
    if not stable_path.is_file():
        raise LineageError(f"构建血缘引用的稳定索引不存在: {stable_path}")
    if sha256(stable_path) != stable_hash:
        raise LineageError("稳定索引哈希与最近导出血缘不一致，禁止重置墓碑或high_water")
    if payload.get("export_build_id"):
        expected_export_id = _digest({
            "parent": payload.get("cases_build_id"),
            "stable_index_hash": stable_hash,
            "xlsx_hash": payload.get("xlsx_hash"),
        })
        if payload.get("export_build_id") != expected_export_id:
            raise LineageError("export_build_id 无效，禁止信任稳定索引历史")


def verify_before_export(project: Path) -> None:
    if required(project):
        verify_stable_index_history(project)
        verify_casegen(project)


def record_export(project: Path, xlsx: Path, stable_index: Path) -> None:
    if not required(project):
        return
    payload = verify_casegen(project)
    if not xlsx.is_file() or not stable_index.is_file():
        raise LineageError("导出阶段缺 Excel 或稳定索引")
    payload.update({
        "stable_index_path": _key(project, stable_index),
        "stable_index_hash": sha256(stable_index),
        "xlsx_path": _key(project, xlsx),
        "xlsx_hash": sha256(xlsx),
        "export_parent_cases_build_id": payload["cases_build_id"],
    })
    payload["export_build_id"] = _digest({
        "parent": payload["cases_build_id"],
        "stable_index_hash": payload["stable_index_hash"],
        "xlsx_hash": payload["xlsx_hash"],
    })
    for key in (
        "draft_hashes", "draft_build_id", "draft_prd_path", "draft_prd_hash",
        "draft_parent_export_build_id", "draft_parent_xlsx_hash",
        "result_hashes", "result_parent_draft_build_id", "results_build_id",
    ):
        payload.pop(key, None)
    _write(project, payload)


def verify_export(project: Path, xlsx: Path | None = None) -> dict:
    payload = verify_casegen(project)
    stable_path = project / str(payload.get("stable_index_path", ""))
    xlsx_path = xlsx or (project / str(payload.get("xlsx_path", "")))
    if xlsx is not None and _key(project, xlsx_path) != payload.get("xlsx_path"):
        raise LineageError("trace/release 使用的 Excel 路径不是当前导出产物")
    if not stable_path.is_file() or not xlsx_path.is_file():
        raise LineageError("导出血缘引用的 Excel/稳定索引不存在")
    if payload.get("stable_index_hash") != sha256(stable_path):
        raise LineageError("稳定索引已变化，必须重新导出")
    if payload.get("xlsx_hash") != sha256(xlsx_path):
        raise LineageError("Excel 已变化，必须重新导出")
    if payload.get("export_parent_cases_build_id") != payload.get("cases_build_id"):
        raise LineageError("export 未绑定当前 cases_build_id")
    expected = _digest({
        "parent": payload.get("cases_build_id"),
        "stable_index_hash": payload.get("stable_index_hash"),
        "xlsx_hash": payload.get("xlsx_hash"),
    })
    if payload.get("export_build_id") != expected:
        raise LineageError("export_build_id 无效")
    return payload


def verify_before_trace(project: Path, xlsx: Path) -> None:
    if required(project):
        verify_export(project, xlsx)


def record_trace(
    project: Path, xlsx: Path, draft_dir: Path, draft_paths: list[Path] | None = None
) -> None:
    if not required(project):
        return
    payload = verify_export(project, xlsx)
    drafts = sorted(draft_paths or [
        path for path in draft_dir.glob("*.json") if path.resolve() != (project / LINEAGE_REL).resolve()
    ])
    if not drafts:
        raise LineageError(f"追溯阶段未生成工作底稿: {draft_dir}")
    draft_hashes = _hashes(project, drafts)
    config = _load_json(project / "trace.config.json")
    prd_path = Path(config.get("prd_path", ""))
    if not prd_path.is_absolute():
        prd_path = project / prd_path
    if not prd_path.is_file():
        raise LineageError(f"追溯阶段缺 PRD: {prd_path}")
    prd_key = _key(project, prd_path)
    prd_hash = sha256(prd_path)
    payload.update({
        "draft_hashes": draft_hashes,
        "draft_prd_path": prd_key,
        "draft_prd_hash": prd_hash,
        "draft_parent_export_build_id": payload["export_build_id"],
        "draft_parent_xlsx_hash": payload["xlsx_hash"],
    })
    payload["draft_build_id"] = _digest({
        "parent": payload["export_build_id"],
        "xlsx_hash": payload["xlsx_hash"],
        "prd_hash": prd_hash,
        "hashes": draft_hashes,
    })
    for key in ("result_hashes", "result_parent_draft_build_id", "results_build_id"):
        payload.pop(key, None)
    _write(project, payload)


def result_binding(project: Path, draft_path: Path) -> dict[str, Any]:
    """Return the cryptographic binding a schema-v3 result must carry."""
    if not required(project):
        return {}
    payload = verify_export(project)
    draft_key = _key(project, draft_path)
    recorded = payload.get("draft_hashes")
    if not isinstance(recorded, dict) or draft_key not in recorded:
        raise LineageError(f"draft 未登记在当前构建血缘: {draft_key}")
    current_hash = sha256(draft_path)
    if recorded[draft_key] != current_hash:
        raise LineageError(f"draft 已变化，必须重新运行 trace_extract: {draft_key}")
    expected_draft_id = _digest({
        "parent": payload.get("export_build_id"),
        "xlsx_hash": payload.get("xlsx_hash"),
        "prd_hash": payload.get("draft_prd_hash"),
        "hashes": recorded,
    })
    if payload.get("draft_build_id") != expected_draft_id:
        raise LineageError("draft_build_id 无效")
    return {
        "schema_version": 1,
        "draft_path": draft_key,
        "draft_sha256": current_hash,
        "draft_build_id": expected_draft_id,
    }


def validate_judgment_binding(project: Path, draft_path: Path, judgment: dict) -> None:
    if not required(project):
        return
    expected = result_binding(project, draft_path)
    if judgment.get("_lineage") != expected:
        raise LineageError(f"judgment 未密码学绑定当前 draft: {draft_path.name}")


def record_results(project: Path, result_paths: list[Path]) -> None:
    """Finalize the current result set after all module judgments are written."""
    if not required(project):
        return
    payload = verify_export(project)
    result_dir = result_paths[0].parent if result_paths else project / "结果"
    actual_paths = _assert_module_file_set(project, result_dir, "result")
    if not result_paths or any(not path.is_file() for path in result_paths):
        raise LineageError("结果阶段缺模块结果文件")
    if {path.resolve() for path in result_paths} != {path.resolve() for path in actual_paths}:
        raise LineageError("finalize结果集合与当前配置不一致")
    draft_build_id = payload.get("draft_build_id")
    if not draft_build_id:
        raise LineageError("结果阶段缺 draft_build_id")
    result_hashes = _hashes(project, sorted(result_paths))
    payload.update({
        "result_hashes": result_hashes,
        "result_parent_draft_build_id": draft_build_id,
    })
    payload["results_build_id"] = _digest({
        "parent": draft_build_id,
        "hashes": result_hashes,
    })
    _write(project, payload)


def validate_release(config_path: Path, config: dict) -> tuple[list[dict[str, str]], dict[str, Any]]:
    project = config_path.parent
    if not required(project):
        return [], {"lineage_required": False}
    issues: list[dict[str, str]] = []
    try:
        xlsx = Path(config.get("cases_xlsx", ""))
        if not xlsx.is_absolute():
            xlsx = project / xlsx
        payload = verify_export(project, xlsx)
        draft_dir = Path((config.get("out_dirs", {}) or {}).get("draft", "工作底稿"))
        if not draft_dir.is_absolute():
            draft_dir = project / draft_dir
        recorded_drafts = payload.get("draft_hashes")
        if not isinstance(recorded_drafts, dict) or not recorded_drafts:
            raise LineageError("构建血缘缺 draft_hashes")
        current_drafts = _hashes(project, [project / key for key in recorded_drafts])
        _mismatch(recorded_drafts, current_drafts, "draft")
        prd_path = Path(str(payload.get("draft_prd_path", "")))
        if not prd_path.is_absolute():
            prd_path = project / prd_path
        if not prd_path.is_file() or payload.get("draft_prd_hash") != sha256(prd_path):
            raise LineageError("PRD 已变化，必须重新运行 trace_extract")
        if payload.get("draft_parent_export_build_id") != payload.get("export_build_id"):
            raise LineageError("draft 未绑定当前 export_build_id")
        if payload.get("draft_parent_xlsx_hash") != payload.get("xlsx_hash"):
            raise LineageError("draft 未绑定当前 xlsx_hash")
        expected_draft_id = _digest({
            "parent": payload.get("export_build_id"),
            "xlsx_hash": payload.get("xlsx_hash"),
            "prd_hash": payload.get("draft_prd_hash"),
            "hashes": current_drafts,
        })
        if payload.get("draft_build_id") != expected_draft_id:
            raise LineageError("draft_build_id 无效")
        result_dir = Path((config.get("out_dirs", {}) or {}).get("result", "结果"))
        if not result_dir.is_absolute():
            result_dir = project / result_dir
        _assert_module_file_set(project, result_dir, "result")
        current_results: list[Path] = []
        for draft_key in current_drafts:
            draft_path = project / draft_key
            result_path = result_dir / draft_path.name
            if not result_path.is_file():
                raise LineageError(f"当前 draft 缺对应结果文件: {result_path}")
            result_payload = _load_json(result_path)
            binding = result_payload.get("_lineage") if isinstance(result_payload, dict) else None
            expected_binding = {
                "schema_version": 1,
                "draft_path": draft_key,
                "draft_sha256": current_drafts[draft_key],
                "draft_build_id": expected_draft_id,
            }
            if binding != expected_binding:
                raise LineageError(f"结果未密码学绑定当前 draft: {result_path.name}")
            if result_path.stat().st_mtime < draft_path.stat().st_mtime:
                raise LineageError(f"结果早于当前 draft，判定已过期: {result_path.name}")
            current_results.append(result_path)
        result_hashes = _hashes(project, sorted(current_results))
        _mismatch(payload.get("result_hashes"), result_hashes, "result")
        if payload.get("result_parent_draft_build_id") != expected_draft_id:
            raise LineageError("results 未绑定当前 draft_build_id")
        expected_results_id = _digest({"parent": expected_draft_id, "hashes": result_hashes})
        if payload.get("results_build_id") != expected_results_id:
            raise LineageError("results_build_id 无效")
    except (LineageError, OSError, json.JSONDecodeError, ValueError) as exc:
        issues.append({"severity": "blocking", "code": "BUILD_LINEAGE_INVALID", "message": str(exc)})
        return issues, {"lineage_required": True, "lineage_valid": False}
    return [], {
        "lineage_required": True,
        "lineage_valid": True,
        "source_build_id": payload.get("source_build_id"),
        "cases_build_id": payload.get("cases_build_id"),
        "export_build_id": payload.get("export_build_id"),
        "draft_build_id": payload.get("draft_build_id"),
        "results_build_id": payload.get("results_build_id"),
    }
