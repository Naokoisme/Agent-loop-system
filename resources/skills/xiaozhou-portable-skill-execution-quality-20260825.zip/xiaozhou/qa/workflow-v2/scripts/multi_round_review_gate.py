# -*- coding: utf-8 -*-
"""Validate the hash-bound, multi-round testcase review ledger."""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path
from typing import Any

_SCRIPTS = Path(__file__).resolve().parent
if str(_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS))

import audit_contract  # noqa: E402
import tc_excel  # noqa: E402


REQUIRED_REVIEW_TYPES = (
    "coverage_design",
    "execution_detail",
    "adversarial",
    "regression",
)
FINAL_REVIEW_SEQUENCE = ("adversarial", "regression")
FINAL_AGENT_ROLES = {
    "adversarial": {"adversarial-risk", "adversarial-execution"},
    "regression": {"regression-blind", "regression-targeted"},
}
ROLE_CONTEXT_MODES = {
    "adversarial-risk": "raw_artifacts_only",
    "adversarial-execution": "raw_artifacts_only",
    "regression-blind": "raw_artifacts_only",
    "regression-targeted": "raw_artifacts_and_closed_findings",
}
SEVERITIES = ("blocker", "major", "minor")
SEVERITY_RANK = {"minor": 1, "major": 2, "blocker": 3}
CLOSED_STATUSES = {"resolved", "accepted"}
VISUAL_CHECK_MINIMUM = 4
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")


def _resolve(base: Path, value: str | Path) -> Path:
    path = Path(value)
    return path if path.is_absolute() else base / path


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _case_ids_sha256(case_ids: list[str]) -> str:
    canonical = json.dumps(case_ids, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def _is_within(path: Path, base: Path) -> bool:
    try:
        path.resolve().relative_to(base.resolve())
    except ValueError:
        return False
    return True


def _text(value: Any) -> str:
    return str(value or "").strip()


def _blocking(code: str, message: str, *, details: Any | None = None) -> dict[str, Any]:
    return audit_contract.make_issue(
        "blocking", message, code=code, kind="failure", details=details
    )


def _string_list(value: Any) -> list[str] | None:
    if not isinstance(value, list):
        return None
    rows = [_text(item) for item in value]
    return rows if all(rows) else None


def _valid_nonnegative_int(value: Any) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and value >= 0


def _valid_positive_int(value: Any) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and value > 0


def _round_counts(row: Any) -> dict[str, int] | None:
    if not isinstance(row, dict):
        return None
    result: dict[str, int] = {}
    for severity in SEVERITIES:
        value = row.get(severity)
        if not _valid_nonnegative_int(value):
            return None
        result[severity] = value
    return result


def evaluate(config_path: str | Path) -> dict[str, Any]:
    config_path = Path(config_path).resolve()
    base = config_path.parent
    issues: list[dict[str, Any]] = []
    try:
        config = json.loads(config_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        return audit_contract.build_report(
            "multi_round_review_gate",
            issues=[_blocking("CONFIG_INVALID", f"配置文件无法读取: {exc}")],
            artifacts=[str(config_path)],
        )

    release = config.get("release_acceptance", {}) or {}
    required = release.get("multi_round_review_required") is True
    multi_agent_required = release.get("multi_agent_review_required") is True
    review_control_cfg = release.get("review_control")
    review_execution_mode = ""
    scope_lock_required = False
    max_revision_batches = 0
    revision_batch_count = 0
    if multi_agent_required and review_control_cfg is None:
        issues.append(_blocking(
            "MULTI_ROUND_REVIEW_CONTROL_REQUIRED",
            "启用多Agent评审时必须配置 release_acceptance.review_control",
        ))
    if review_control_cfg is not None:
        if not isinstance(review_control_cfg, dict):
            issues.append(_blocking(
                "MULTI_ROUND_REVIEW_CONTROL_INVALID",
                "release_acceptance.review_control 必须是对象",
            ))
        else:
            review_execution_mode = _text(review_control_cfg.get("execution_mode"))
            scope_lock_required = review_control_cfg.get("scope_lock_required") is True
            max_revision_batches = review_control_cfg.get("max_revision_batches")
            if not review_execution_mode:
                issues.append(_blocking(
                    "MULTI_ROUND_REVIEW_CONTROL_INVALID",
                    "review_control.execution_mode 不能为空",
                ))
            if not _valid_positive_int(max_revision_batches) or max_revision_batches > 2:
                issues.append(_blocking(
                    "MULTI_ROUND_REVIEW_CONTROL_INVALID",
                    "review_control.max_revision_batches 必须是1或2，禁止通过配置扩大严重问题整改上限",
                ))
                max_revision_batches = 0
    if multi_agent_required and not required:
        issues.append(_blocking(
            "MULTI_AGENT_REVIEW_REQUIRES_MULTI_ROUND",
            "multi_agent_review_required=true 时必须同时开启 multi_round_review_required=true",
        ))
    cases_value = _text(config.get("cases_xlsx"))
    cases_path = _resolve(base, cases_value) if cases_value else base / "<missing-cases.xlsx>"
    rows: list[dict[str, Any]] = []
    current_hash = ""
    if not cases_value:
        issues.append(_blocking("CASES_XLSX_CONFIG_MISSING", "config.cases_xlsx 未配置"))
    elif not cases_path.is_file():
        issues.append(_blocking("CASES_XLSX_MISSING", f"最终Excel不存在: {cases_path}"))
    else:
        try:
            rows = tc_excel.read_master_rows(cases_path)
            current_hash = _sha256(cases_path)
        except Exception as exc:  # noqa: BLE001 - report deterministic gate failure
            issues.append(_blocking("CASES_XLSX_INVALID", f"最终Excel无法读取: {exc}"))

    ordered_case_ids = [
        _text(row.get("用例编号")) for row in rows if _text(row.get("用例编号"))
    ]
    known_case_ids = set(ordered_case_ids)
    current_case_ids_hash = _case_ids_sha256(ordered_case_ids)
    prd_value = _text(config.get("prd_path"))
    prd_path = _resolve(base, prd_value) if prd_value else base / "<missing-prd>"
    current_prd_hash = ""
    if multi_agent_required:
        if not prd_value:
            issues.append(_blocking("MULTI_AGENT_REVIEW_PRD_CONFIG_MISSING", "config.prd_path 未配置"))
        elif not prd_path.is_file():
            issues.append(_blocking("MULTI_AGENT_REVIEW_PRD_MISSING", f"PRD不存在: {prd_path}"))
        else:
            current_prd_hash = _sha256(prd_path)
    ledger_value = _text(
        release.get("multi_round_review_file", "工作底稿/多轮测试用例评审.json")
    )
    ledger_path = _resolve(base, ledger_value)
    payload: dict[str, Any] = {}
    final_agent_counts = {"adversarial": 0, "regression": 0}
    if not ledger_path.is_file():
        if required:
            issues.append(_blocking("MULTI_ROUND_REVIEW_LEDGER_MISSING", f"多轮评审账本不存在: {ledger_path}"))
        else:
            issues.append(_blocking("MULTI_ROUND_REVIEW_NOT_ENABLED", "多轮评审门禁未启用且账本不存在"))
    else:
        try:
            loaded = json.loads(ledger_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            issues.append(_blocking("MULTI_ROUND_REVIEW_LEDGER_INVALID", f"多轮评审账本无法读取: {exc}"))
        else:
            if isinstance(loaded, dict):
                payload = loaded
            else:
                issues.append(_blocking("MULTI_ROUND_REVIEW_LEDGER_SCHEMA", "多轮评审账本根节点必须是对象"))

    if payload:
        if isinstance(review_control_cfg, dict):
            review_control = payload.get("review_control")
            if not isinstance(review_control, dict):
                issues.append(_blocking(
                    "MULTI_ROUND_REVIEW_CONTROL_INVALID",
                    "评审账本缺少 review_control 对象",
                ))
            else:
                ledger_mode = _text(review_control.get("execution_mode"))
                if review_execution_mode and ledger_mode != review_execution_mode:
                    issues.append(_blocking(
                        "MULTI_ROUND_REVIEW_EXECUTION_MODE_MISMATCH",
                        f"账本执行方式={ledger_mode!r}，配置要求={review_execution_mode!r}",
                    ))
                scope_lock = review_control.get("scope_lock")
                scope_lock_valid = isinstance(scope_lock, dict) \
                    and scope_lock.get("status") == "locked" \
                    and bool(_text(scope_lock.get("prd_scope"))) \
                    and bool(_text(scope_lock.get("blueprint"))) \
                    and _text(scope_lock.get("input_xlsx_sha256")).lower() == current_hash \
                    and len(_text(scope_lock.get("evidence"))) >= 8
                if scope_lock_required and not scope_lock_valid:
                    issues.append(_blocking(
                        "MULTI_ROUND_REVIEW_SCOPE_NOT_LOCKED",
                        "scope_lock 必须结构化锁定 PRD范围、蓝图、当前Excel哈希，并填写可审计证据",
                    ))
                revision_batch_count = review_control.get("revision_batch_count")
                if not _valid_nonnegative_int(revision_batch_count):
                    issues.append(_blocking(
                        "MULTI_ROUND_REVIEW_REVISION_COUNT_INVALID",
                        "review_control.revision_batch_count 必须是非负整数",
                    ))
                    revision_batch_count = 0
                elif max_revision_batches and revision_batch_count > max_revision_batches:
                    issues.append(_blocking(
                        "MULTI_ROUND_REVIEW_REVISION_LIMIT_EXCEEDED",
                        f"严重问题整改批次={revision_batch_count}，超过上限={max_revision_batches}；应保持NO_GO并输出阻断清单",
                    ))

        schema_version = payload.get("schema_version")
        if multi_agent_required and schema_version != 2:
            issues.append(_blocking(
                "MULTI_AGENT_REVIEW_SCHEMA_VERSION",
                "启用多 Agent 评审时账本 schema_version 必须为2，旧账本必须真实重跑而非补字段",
            ))
        elif not multi_agent_required and schema_version not in {1, 2}:
            issues.append(_blocking("MULTI_ROUND_REVIEW_SCHEMA_VERSION", "多轮评审账本 schema_version 必须为1或2"))
        recorded_hash = _text(payload.get("input_xlsx_sha256")).lower()
        if not SHA256_RE.fullmatch(recorded_hash):
            issues.append(_blocking("MULTI_ROUND_REVIEW_INPUT_HASH_INVALID", "账本 input_xlsx_sha256 必须是64位SHA-256"))
        elif current_hash and recorded_hash != current_hash:
            issues.append(_blocking(
                "MULTI_ROUND_REVIEW_INPUT_HASH_STALE",
                "多轮评审账本未绑定当前最终Excel",
                details={"recorded": recorded_hash, "current": current_hash},
            ))
        case_count = payload.get("case_count")
        if not _valid_nonnegative_int(case_count) or case_count != len(rows):
            issues.append(_blocking(
                "MULTI_ROUND_REVIEW_CASE_COUNT_MISMATCH",
                f"账本 case_count={case_count!r}，当前Excel用例数={len(rows)}",
            ))
        generator_agent_ids: set[str] = set()
        reviser_agent_ids: set[str] = set()
        if multi_agent_required:
            recorded_prd_hash = _text(payload.get("prd_sha256")).lower()
            if not SHA256_RE.fullmatch(recorded_prd_hash):
                issues.append(_blocking("MULTI_AGENT_REVIEW_PRD_HASH_INVALID", "账本 prd_sha256 必须是64位SHA-256"))
            elif current_prd_hash and recorded_prd_hash != current_prd_hash:
                issues.append(_blocking("MULTI_AGENT_REVIEW_PRD_HASH_STALE", "多 Agent 评审账本未绑定当前PRD"))
            recorded_case_ids_hash = _text(payload.get("case_ids_sha256")).lower()
            if recorded_case_ids_hash != current_case_ids_hash:
                issues.append(_blocking(
                    "MULTI_AGENT_REVIEW_CASE_IDS_HASH_STALE",
                    "账本 case_ids_sha256 未绑定当前Excel用例编号及顺序",
                ))
            generator_values = _string_list(payload.get("generator_agent_ids"))
            reviser_values = _string_list(payload.get("reviser_agent_ids"))
            if not generator_values:
                issues.append(_blocking("MULTI_AGENT_REVIEW_GENERATOR_IDS_MISSING", "缺 generator_agent_ids"))
            else:
                generator_agent_ids = set(generator_values)
            if not reviser_values:
                issues.append(_blocking("MULTI_AGENT_REVIEW_REVISER_IDS_MISSING", "缺 reviser_agent_ids"))
            else:
                reviser_agent_ids = set(reviser_values)
        declared_types = _string_list(payload.get("required_review_types"))
        if declared_types != list(REQUIRED_REVIEW_TYPES):
            issues.append(_blocking(
                "MULTI_ROUND_REVIEW_TYPES_INVALID",
                f"required_review_types 必须按顺序等于 {list(REQUIRED_REVIEW_TYPES)}",
            ))

        round_rows = payload.get("rounds")
        if not isinstance(round_rows, list):
            issues.append(_blocking("MULTI_ROUND_REVIEW_ROUNDS_INVALID", "rounds 必须是数组"))
            round_rows = []
        if len(round_rows) < len(REQUIRED_REVIEW_TYPES):
            issues.append(_blocking(
                "MULTI_ROUND_REVIEW_ROUNDS_INSUFFICIENT",
                f"至少需要{len(REQUIRED_REVIEW_TYPES)}轮评审，当前={len(round_rows)}",
            ))

        seen_round_ids: set[str] = set()
        seen_finding_ids: set[str] = set()
        resolved_finding_ids: set[str] = set()
        seen_types: list[str] = []
        normalized_rounds: list[dict[str, Any]] = []
        all_final_agent_ids: set[str] = set()
        all_final_agent_run_ids: set[str] = set()
        all_report_paths: set[str] = set()
        for index, item in enumerate(round_rows, 1):
            prefix = f"第{index}轮"
            if not isinstance(item, dict):
                issues.append(_blocking("MULTI_ROUND_REVIEW_ROUND_NOT_OBJECT", f"{prefix}必须是对象"))
                normalized_rounds.append({"review_type": "", "hash": "", "counts": {}})
                continue
            round_id = _text(item.get("round_id"))
            if not round_id:
                issues.append(_blocking("MULTI_ROUND_REVIEW_ROUND_ID_MISSING", f"{prefix}缺 round_id"))
            elif round_id in seen_round_ids:
                issues.append(_blocking("MULTI_ROUND_REVIEW_ROUND_ID_DUPLICATE", f"round_id重复: {round_id}"))
            seen_round_ids.add(round_id)

            review_type = _text(item.get("review_type"))
            if review_type not in REQUIRED_REVIEW_TYPES:
                issues.append(_blocking("MULTI_ROUND_REVIEW_TYPE_UNKNOWN", f"{prefix} review_type无效: {review_type}"))
            elif review_type not in seen_types:
                seen_types.append(review_type)
            if not _text(item.get("review_perspective")):
                issues.append(_blocking("MULTI_ROUND_REVIEW_PERSPECTIVE_MISSING", f"{prefix}缺 review_perspective"))
            if item.get("scope") != "all_project":
                issues.append(_blocking("MULTI_ROUND_REVIEW_SCOPE_INVALID", f"{prefix} scope必须为all_project"))
            if item.get("status") != "completed":
                issues.append(_blocking("MULTI_ROUND_REVIEW_ROUND_INCOMPLETE", f"{prefix} status必须为completed"))
            if not _text(item.get("evidence")):
                issues.append(_blocking("MULTI_ROUND_REVIEW_EVIDENCE_MISSING", f"{prefix}缺具体evidence"))

            round_hash = _text(item.get("input_xlsx_sha256")).lower()
            if not SHA256_RE.fullmatch(round_hash):
                issues.append(_blocking("MULTI_ROUND_REVIEW_ROUND_HASH_INVALID", f"{prefix} input_xlsx_sha256无效"))
            reviewed_count = item.get("reviewed_case_count")
            if not isinstance(reviewed_count, int) or isinstance(reviewed_count, bool) or reviewed_count <= 0:
                issues.append(_blocking("MULTI_ROUND_REVIEW_SCAN_COUNT_INVALID", f"{prefix} reviewed_case_count必须为正整数"))

            declared_counts = _round_counts(item.get("finding_counts"))
            if declared_counts is None:
                issues.append(_blocking("MULTI_ROUND_REVIEW_FINDING_COUNTS_INVALID", f"{prefix} finding_counts无效"))
                declared_counts = {severity: -1 for severity in SEVERITIES}
            findings = item.get("findings")
            if not isinstance(findings, list):
                issues.append(_blocking("MULTI_ROUND_REVIEW_FINDINGS_INVALID", f"{prefix} findings必须是数组"))
                findings = []
            actual_counts = {severity: 0 for severity in SEVERITIES}
            aggregate_source_refs: set[str] = set()
            aggregate_ref_severity: dict[str, str] = {}
            for finding_index, finding in enumerate(findings, 1):
                finding_prefix = f"{prefix}第{finding_index}个问题"
                if not isinstance(finding, dict):
                    issues.append(_blocking("MULTI_ROUND_REVIEW_FINDING_NOT_OBJECT", f"{finding_prefix}必须是对象"))
                    continue
                finding_id = _text(finding.get("finding_id"))
                if not finding_id:
                    issues.append(_blocking("MULTI_ROUND_REVIEW_FINDING_ID_MISSING", f"{finding_prefix}缺 finding_id"))
                elif finding_id in seen_finding_ids:
                    issues.append(_blocking("MULTI_ROUND_REVIEW_FINDING_ID_DUPLICATE", f"finding_id重复: {finding_id}"))
                seen_finding_ids.add(finding_id)
                severity = _text(finding.get("severity")).lower()
                if severity not in SEVERITIES:
                    issues.append(_blocking("MULTI_ROUND_REVIEW_SEVERITY_INVALID", f"{finding_prefix} severity无效"))
                else:
                    actual_counts[severity] += 1
                if not _text(finding.get("category")) or not _text(finding.get("description")):
                    issues.append(_blocking("MULTI_ROUND_REVIEW_FINDING_DETAIL_MISSING", f"{finding_prefix}缺category或description"))
                case_ids = _string_list(finding.get("case_ids"))
                if case_ids is None:
                    issues.append(_blocking("MULTI_ROUND_REVIEW_FINDING_CASE_IDS_INVALID", f"{finding_prefix} case_ids必须是字符串数组"))
                elif unknown := sorted(set(case_ids) - known_case_ids):
                    issues.append(_blocking(
                        "MULTI_ROUND_REVIEW_FINDING_CASE_ID_UNKNOWN",
                        f"{finding_prefix}引用当前不存在用例: {unknown}",
                    ))
                finding_status = _text(finding.get("status")).lower()
                if finding_status not in CLOSED_STATUSES:
                    issues.append(_blocking("MULTI_ROUND_REVIEW_FINDING_OPEN", f"{finding_prefix}未关闭"))
                elif severity in {"blocker", "major"} and finding_status != "resolved":
                    issues.append(_blocking("MULTI_ROUND_REVIEW_SERIOUS_FINDING_ACCEPTED", f"{finding_prefix} Blocker/Major必须解决"))
                elif finding_status == "resolved" and not _text(finding.get("resolution")):
                    issues.append(_blocking("MULTI_ROUND_REVIEW_RESOLUTION_MISSING", f"{finding_prefix}缺resolution"))
                elif finding_status == "accepted" and (
                    not _text(finding.get("acceptance_reason")) or not _text(finding.get("owner"))
                ):
                    issues.append(_blocking("MULTI_ROUND_REVIEW_ACCEPTANCE_INVALID", f"{finding_prefix}接受Minor必须填写owner和acceptance_reason"))
                if finding_status == "resolved" and finding_id:
                    resolved_finding_ids.add(finding_id)
                if multi_agent_required and index > len(round_rows) - 2:
                    source_refs = _string_list(finding.get("source_refs"))
                    if not source_refs:
                        issues.append(_blocking(
                            "MULTI_AGENT_REVIEW_SOURCE_REFS_MISSING",
                            f"{finding_prefix}缺 source_refs，无法证明保留全部Agent原始发现",
                        ))
                    else:
                        for source_ref in source_refs:
                            if source_ref in aggregate_source_refs:
                                issues.append(_blocking(
                                    "MULTI_AGENT_REVIEW_SOURCE_REF_DUPLICATE",
                                    f"{prefix} source_ref重复归并: {source_ref}",
                                ))
                            aggregate_source_refs.add(source_ref)
                            aggregate_ref_severity[source_ref] = severity
                    if finding_status == "resolved" and _text(
                        finding.get("resolved_in_xlsx_sha256")
                    ).lower() != current_hash:
                        issues.append(_blocking(
                            "MULTI_AGENT_REVIEW_RESOLUTION_HASH_STALE",
                            f"{finding_prefix} resolved_in_xlsx_sha256 未绑定当前最终Excel",
                        ))
            if declared_counts != actual_counts:
                issues.append(_blocking(
                    "MULTI_ROUND_REVIEW_FINDING_COUNT_MISMATCH",
                    f"{prefix} finding_counts与findings不一致",
                    details={"declared": declared_counts, "actual": actual_counts},
                ))

            round_agent_ids: set[str] = set()
            round_agent_run_ids: set[str] = set()
            round_roles: set[str] = set()
            round_verified_finding_ids: set[str] = set()
            round_verified_by_role: dict[str, set[str]] = {}
            report_source_refs: set[str] = set()
            report_source_severity: dict[str, str] = {}
            is_final_batch = index > len(round_rows) - 2
            if multi_agent_required and is_final_batch:
                agent_reviews = item.get("agent_reviews")
                if not isinstance(agent_reviews, list):
                    issues.append(_blocking(
                        "MULTI_AGENT_REVIEW_RECORDS_MISSING",
                        f"{prefix} agent_reviews 必须是数组",
                    ))
                    agent_reviews = []
                expected_roles = FINAL_AGENT_ROLES.get(review_type, set())
                if len(agent_reviews) != len(expected_roles):
                    issues.append(_blocking(
                        "MULTI_AGENT_REVIEW_COUNT_INVALID",
                        f"{prefix} 必须包含{len(expected_roles)}个独立Agent，当前={len(agent_reviews)}",
                    ))
                for review_index, agent_review in enumerate(agent_reviews, 1):
                    agent_prefix = f"{prefix}第{review_index}个Agent"
                    if not isinstance(agent_review, dict):
                        issues.append(_blocking("MULTI_AGENT_REVIEW_NOT_OBJECT", f"{agent_prefix}必须是对象"))
                        continue
                    agent_id = _text(agent_review.get("agent_id"))
                    agent_run_id = _text(agent_review.get("agent_run_id"))
                    role = _text(agent_review.get("reviewer_role"))
                    if not agent_id or not agent_run_id:
                        issues.append(_blocking(
                            "MULTI_AGENT_REVIEW_ID_MISSING",
                            f"{agent_prefix}缺 agent_id 或 agent_run_id",
                        ))
                    if agent_id in round_agent_ids or agent_id in all_final_agent_ids:
                        issues.append(_blocking(
                            "MULTI_AGENT_REVIEW_AGENT_REUSED",
                            f"最终评审Agent身份重复: {agent_id}",
                        ))
                    if agent_run_id in round_agent_run_ids or agent_run_id in all_final_agent_run_ids:
                        issues.append(_blocking(
                            "MULTI_AGENT_REVIEW_RUN_REUSED",
                            f"最终评审agent_run_id重复: {agent_run_id}",
                        ))
                    if agent_id:
                        round_agent_ids.add(agent_id)
                        all_final_agent_ids.add(agent_id)
                    if agent_run_id:
                        round_agent_run_ids.add(agent_run_id)
                        all_final_agent_run_ids.add(agent_run_id)
                    if agent_id and agent_id in generator_agent_ids | reviser_agent_ids:
                        issues.append(_blocking(
                            "MULTI_AGENT_REVIEW_ROLE_CONFLICT",
                            f"{agent_prefix}与生成者或修订者身份冲突: {agent_id}",
                        ))
                    if role not in expected_roles:
                        issues.append(_blocking(
                            "MULTI_AGENT_REVIEW_ROLE_INVALID",
                            f"{agent_prefix} reviewer_role无效: {role}",
                        ))
                    elif role in round_roles:
                        issues.append(_blocking(
                            "MULTI_AGENT_REVIEW_ROLE_DUPLICATE",
                            f"{prefix} reviewer_role重复: {role}",
                        ))
                    round_roles.add(role)
                    if agent_review.get("fork_turns") != "none":
                        issues.append(_blocking(
                            "MULTI_AGENT_REVIEW_CONTEXT_NOT_ISOLATED",
                            f"{agent_prefix} fork_turns必须为none",
                        ))
                    if agent_review.get("peer_reports_visible") is not False:
                        issues.append(_blocking(
                            "MULTI_AGENT_REVIEW_PEER_REPORT_LEAKED",
                            f"{agent_prefix} peer_reports_visible必须为false",
                        ))
                    expected_context = ROLE_CONTEXT_MODES.get(role)
                    if expected_context and agent_review.get("context_mode") != expected_context:
                        issues.append(_blocking(
                            "MULTI_AGENT_REVIEW_CONTEXT_MODE_INVALID",
                            f"{agent_prefix} context_mode必须为{expected_context}",
                        ))
                    if agent_review.get("scope") != "all_project":
                        issues.append(_blocking(
                            "MULTI_AGENT_REVIEW_SCOPE_INVALID",
                            f"{agent_prefix} scope必须为all_project",
                        ))
                    if agent_review.get("status") != "completed":
                        issues.append(_blocking(
                            "MULTI_AGENT_REVIEW_INCOMPLETE",
                            f"{agent_prefix} status必须为completed",
                        ))
                    if not _text(agent_review.get("evidence")):
                        issues.append(_blocking(
                            "MULTI_AGENT_REVIEW_EVIDENCE_MISSING",
                            f"{agent_prefix}缺evidence",
                        ))
                    if _text(agent_review.get("input_xlsx_sha256")).lower() != current_hash:
                        issues.append(_blocking(
                            "MULTI_AGENT_REVIEW_XLSX_HASH_STALE",
                            f"{agent_prefix}未绑定当前最终Excel",
                        ))
                    if _text(agent_review.get("prd_sha256")).lower() != current_prd_hash:
                        issues.append(_blocking(
                            "MULTI_AGENT_REVIEW_PRD_HASH_STALE",
                            f"{agent_prefix}未绑定当前PRD",
                        ))
                    if agent_review.get("reviewed_case_count") != len(rows):
                        issues.append(_blocking(
                            "MULTI_AGENT_REVIEW_SCAN_COUNT_INVALID",
                            f"{agent_prefix}未全量扫描当前Excel",
                        ))
                    if _text(agent_review.get("reviewed_case_ids_sha256")).lower() != current_case_ids_hash:
                        issues.append(_blocking(
                            "MULTI_AGENT_REVIEW_CASE_IDS_HASH_STALE",
                            f"{agent_prefix}用例编号有序摘要不匹配",
                        ))

                    report_value = _text(agent_review.get("report_path"))
                    report_path = _resolve(base, report_value) if report_value else base / "<missing-agent-report>"
                    report_key = str(report_path.resolve())
                    if not report_value:
                        issues.append(_blocking("MULTI_AGENT_REVIEW_REPORT_PATH_MISSING", f"{agent_prefix}缺report_path"))
                    elif not _is_within(report_path, base):
                        issues.append(_blocking(
                            "MULTI_AGENT_REVIEW_REPORT_OUTSIDE_PROJECT",
                            f"{agent_prefix} report_path必须位于项目目录内",
                        ))
                    elif report_key in all_report_paths:
                        issues.append(_blocking(
                            "MULTI_AGENT_REVIEW_REPORT_REUSED",
                            f"Agent原始报告路径重复: {report_path}",
                        ))
                    else:
                        all_report_paths.add(report_key)
                    report_hash = _text(agent_review.get("report_sha256")).lower()
                    report_payload: dict[str, Any] = {}
                    if not report_path.is_file():
                        issues.append(_blocking(
                            "MULTI_AGENT_REVIEW_REPORT_MISSING",
                            f"{agent_prefix}原始报告不存在: {report_path}",
                        ))
                    elif not SHA256_RE.fullmatch(report_hash) or _sha256(report_path) != report_hash:
                        issues.append(_blocking(
                            "MULTI_AGENT_REVIEW_REPORT_HASH_STALE",
                            f"{agent_prefix}原始报告SHA-256不匹配",
                        ))
                    else:
                        try:
                            loaded_report = json.loads(report_path.read_text(encoding="utf-8"))
                        except (OSError, json.JSONDecodeError) as exc:
                            issues.append(_blocking(
                                "MULTI_AGENT_REVIEW_REPORT_INVALID",
                                f"{agent_prefix}原始报告无法读取: {exc}",
                            ))
                        else:
                            if isinstance(loaded_report, dict):
                                report_payload = loaded_report
                            else:
                                issues.append(_blocking(
                                    "MULTI_AGENT_REVIEW_REPORT_SCHEMA",
                                    f"{agent_prefix}原始报告根节点必须是对象",
                                ))
                    if report_payload:
                        expected_report_values = {
                            "schema_version": 1,
                            "agent_id": agent_id,
                            "agent_run_id": agent_run_id,
                            "review_type": review_type,
                            "reviewer_role": role,
                            "fork_turns": "none",
                            "peer_reports_visible": False,
                            "context_mode": ROLE_CONTEXT_MODES.get(role),
                            "scope": "all_project",
                            "input_xlsx_sha256": current_hash,
                            "prd_sha256": current_prd_hash,
                            "reviewed_case_count": len(rows),
                            "reviewed_case_ids_sha256": current_case_ids_hash,
                            "status": "completed",
                        }
                        for field, expected_value in expected_report_values.items():
                            if report_payload.get(field) != expected_value:
                                issues.append(_blocking(
                                    "MULTI_AGENT_REVIEW_REPORT_BINDING_MISMATCH",
                                    f"{agent_prefix}原始报告字段{field}与账本或当前输入不一致",
                                ))
                        if report_payload.get("reviewed_case_ids") != ordered_case_ids:
                            issues.append(_blocking(
                                "MULTI_AGENT_REVIEW_CASE_IDS_INCOMPLETE",
                                f"{agent_prefix}原始报告未按当前Excel顺序列出全部用例编号",
                            ))
                        if not _text(report_payload.get("evidence")):
                            issues.append(_blocking(
                                "MULTI_AGENT_REVIEW_REPORT_EVIDENCE_MISSING",
                                f"{agent_prefix}原始报告缺evidence",
                            ))
                        report_findings = report_payload.get("findings")
                        if not isinstance(report_findings, list):
                            issues.append(_blocking(
                                "MULTI_AGENT_REVIEW_REPORT_FINDINGS_INVALID",
                                f"{agent_prefix}原始报告findings必须是数组",
                            ))
                            report_findings = []
                        local_source_ids: set[str] = set()
                        for source_index, source_finding in enumerate(report_findings, 1):
                            source_prefix = f"{agent_prefix}原始报告第{source_index}个问题"
                            if not isinstance(source_finding, dict):
                                issues.append(_blocking(
                                    "MULTI_AGENT_REVIEW_SOURCE_FINDING_INVALID",
                                    f"{source_prefix}必须是对象",
                                ))
                                continue
                            source_id = _text(source_finding.get("source_finding_id"))
                            source_severity = _text(source_finding.get("severity")).lower()
                            if not source_id:
                                issues.append(_blocking(
                                    "MULTI_AGENT_REVIEW_SOURCE_FINDING_ID_MISSING",
                                    f"{source_prefix}缺source_finding_id",
                                ))
                                continue
                            if source_id in local_source_ids:
                                issues.append(_blocking(
                                    "MULTI_AGENT_REVIEW_SOURCE_FINDING_ID_DUPLICATE",
                                    f"{agent_prefix} source_finding_id重复: {source_id}",
                                ))
                            local_source_ids.add(source_id)
                            if source_severity not in SEVERITIES:
                                issues.append(_blocking(
                                    "MULTI_AGENT_REVIEW_SOURCE_SEVERITY_INVALID",
                                    f"{source_prefix} severity无效",
                                ))
                            if not _text(source_finding.get("category")) or not _text(
                                source_finding.get("description")
                            ):
                                issues.append(_blocking(
                                    "MULTI_AGENT_REVIEW_SOURCE_DETAIL_MISSING",
                                    f"{source_prefix}缺category或description",
                                ))
                            source_case_ids = _string_list(source_finding.get("case_ids"))
                            if source_case_ids is None:
                                issues.append(_blocking(
                                    "MULTI_AGENT_REVIEW_SOURCE_CASE_IDS_INVALID",
                                    f"{source_prefix} case_ids必须是字符串数组",
                                ))
                            elif unknown := sorted(set(source_case_ids) - known_case_ids):
                                issues.append(_blocking(
                                    "MULTI_AGENT_REVIEW_SOURCE_CASE_ID_UNKNOWN",
                                    f"{source_prefix}引用当前不存在用例: {unknown}",
                                ))
                            source_ref = f"{agent_run_id}:{source_id}"
                            report_source_refs.add(source_ref)
                            report_source_severity[source_ref] = source_severity
                        ledger_finding_ids = _string_list(agent_review.get("finding_ids"))
                        if ledger_finding_ids is None or set(ledger_finding_ids) != local_source_ids:
                            issues.append(_blocking(
                                "MULTI_AGENT_REVIEW_FINDING_IDS_MISMATCH",
                                f"{agent_prefix} finding_ids与原始报告不一致",
                            ))
                        report_verified = _string_list(report_payload.get("verified_finding_ids"))
                        ledger_verified = _string_list(agent_review.get("verified_finding_ids"))
                        if report_verified is None or ledger_verified is None or report_verified != ledger_verified:
                            issues.append(_blocking(
                                "MULTI_AGENT_REVIEW_VERIFIED_IDS_MISMATCH",
                                f"{agent_prefix} verified_finding_ids与原始报告不一致",
                            ))
                        else:
                            round_verified_finding_ids.update(report_verified)
                            round_verified_by_role.setdefault(role, set()).update(report_verified)
                if round_roles != expected_roles:
                    issues.append(_blocking(
                        "MULTI_AGENT_REVIEW_ROLES_INCOMPLETE",
                        f"{prefix}角色必须为{sorted(expected_roles)}，当前={sorted(round_roles)}",
                    ))
                if report_source_refs != aggregate_source_refs:
                    issues.append(_blocking(
                        "MULTI_AGENT_REVIEW_FINDING_UNION_MISMATCH",
                        f"{prefix}汇总发现未完整覆盖全部Agent原始报告并集",
                        details={
                            "missing": sorted(report_source_refs - aggregate_source_refs),
                            "extra": sorted(aggregate_source_refs - report_source_refs),
                        },
                    ))
                for source_ref in report_source_refs & aggregate_source_refs:
                    source_severity = report_source_severity.get(source_ref, "")
                    aggregate_severity = aggregate_ref_severity.get(source_ref, "")
                    if (
                        source_severity in SEVERITY_RANK
                        and aggregate_severity in SEVERITY_RANK
                        and SEVERITY_RANK[aggregate_severity] < SEVERITY_RANK[source_severity]
                    ):
                        issues.append(_blocking(
                            "MULTI_AGENT_REVIEW_SEVERITY_DOWNGRADED",
                            f"{prefix}汇总时降低了原始问题严重级: {source_ref}",
                        ))
            normalized_rounds.append({
                "review_type": review_type,
                "hash": round_hash,
                "count": reviewed_count,
                "counts": actual_counts,
                "agent_ids": round_agent_ids,
                "agent_run_ids": round_agent_run_ids,
                "roles": round_roles,
                "verified_finding_ids": round_verified_finding_ids,
                "verified_by_role": round_verified_by_role,
            })

        positions = {
            name: next((i for i, item in enumerate(normalized_rounds) if item["review_type"] == name), -1)
            for name in REQUIRED_REVIEW_TYPES
        }
        missing_types = [name for name, position in positions.items() if position < 0]
        if missing_types:
            issues.append(_blocking("MULTI_ROUND_REVIEW_TYPE_MISSING", f"缺少强制评审类型: {missing_types}"))
        elif list(positions.values()) != sorted(positions.values()):
            issues.append(_blocking("MULTI_ROUND_REVIEW_TYPE_ORDER", "四种强制评审视角首次出现顺序错误"))

        trailing_clean = 0
        for item in reversed(normalized_rounds):
            counts = item.get("counts", {})
            if counts.get("blocker") == 0 and counts.get("major") == 0:
                trailing_clean += 1
            else:
                break
        claimed_clean = payload.get("consecutive_clean_rounds")
        if not _valid_nonnegative_int(claimed_clean) or claimed_clean != trailing_clean:
            issues.append(_blocking(
                "MULTI_ROUND_REVIEW_CLEAN_COUNT_MISMATCH",
                f"consecutive_clean_rounds={claimed_clean!r}，实际连续干净轮次={trailing_clean}",
            ))
        if trailing_clean < 2:
            issues.append(_blocking("MULTI_ROUND_REVIEW_NOT_CONVERGED", "最后至少需要连续两轮Blocker=0且Major=0"))

        if len(normalized_rounds) >= 2:
            final_two = normalized_rounds[-2:]
            final_agent_counts = final_agent_counts | {
                item["review_type"]: len(item.get("agent_ids", set()))
                for item in final_two
                if item["review_type"] in FINAL_AGENT_ROLES
            }
            final_types = tuple(item["review_type"] for item in final_two)
            if final_types != FINAL_REVIEW_SEQUENCE:
                issues.append(_blocking(
                    "MULTI_ROUND_REVIEW_FINAL_SEQUENCE",
                    f"最后两轮必须为{list(FINAL_REVIEW_SEQUENCE)}，当前={list(final_types)}",
                ))
            for offset, item in enumerate(final_two, len(normalized_rounds) - 1):
                if current_hash and item["hash"] != current_hash:
                    issues.append(_blocking("MULTI_ROUND_REVIEW_FINAL_HASH_STALE", f"第{offset}轮未绑定当前最终Excel"))
                if item["count"] != len(rows):
                    issues.append(_blocking(
                        "MULTI_ROUND_REVIEW_FINAL_SCAN_INCOMPLETE",
                        f"第{offset}轮 reviewed_case_count={item['count']!r}，当前Excel用例数={len(rows)}",
                    ))
                if item["counts"].get("blocker") or item["counts"].get("major"):
                    issues.append(_blocking("MULTI_ROUND_REVIEW_FINAL_ROUND_DIRTY", f"第{offset}轮仍有Blocker/Major"))
            if multi_agent_required:
                targeted_verified = final_two[-1].get("verified_by_role", {}).get(
                    "regression-targeted", set()
                )
                if targeted_verified != resolved_finding_ids:
                    issues.append(_blocking(
                        "MULTI_AGENT_REVIEW_RESOLUTIONS_NOT_VERIFIED",
                        "regression-targeted 未逐项验证全部已解决问题",
                        details={
                            "missing": sorted(resolved_finding_ids - targeted_verified),
                            "extra": sorted(targeted_verified - resolved_finding_ids),
                        },
                    ))

        serious_indices = [
            index for index, item in enumerate(normalized_rounds)
            if item["counts"].get("blocker", 0) + item["counts"].get("major", 0) > 0
        ]
        regression_indices = [
            index for index, item in enumerate(normalized_rounds)
            if item["review_type"] == "regression"
        ]
        if serious_indices and not any(index > max(serious_indices) for index in regression_indices):
            issues.append(_blocking("MULTI_ROUND_REVIEW_REGRESSION_MISSING", "最后一次Blocker/Major之后缺少修订回归"))

        remaining = payload.get("remaining_findings")
        if not isinstance(remaining, list) or remaining:
            issues.append(_blocking("MULTI_ROUND_REVIEW_REMAINING_FINDINGS", "remaining_findings必须是空数组"))
        if payload.get("final_status") != "PASS":
            issues.append(_blocking("MULTI_ROUND_REVIEW_FINAL_STATUS", "final_status必须为PASS"))

        visual = payload.get("visual_inspection")
        if not isinstance(visual, dict):
            issues.append(_blocking("MULTI_ROUND_REVIEW_VISUAL_MISSING", "缺少最终Excel实物检查记录"))
        else:
            if visual.get("status") != "passed":
                issues.append(_blocking("MULTI_ROUND_REVIEW_VISUAL_NOT_PASSED", "visual_inspection.status必须为passed"))
            visual_hash = _text(visual.get("input_xlsx_sha256")).lower()
            if current_hash and visual_hash != current_hash:
                issues.append(_blocking("MULTI_ROUND_REVIEW_VISUAL_HASH_STALE", "最终Excel实物检查未绑定当前文件"))
            checked_items = _string_list(visual.get("checked_items"))
            if checked_items is None or len(set(checked_items)) < VISUAL_CHECK_MINIMUM:
                issues.append(_blocking(
                    "MULTI_ROUND_REVIEW_VISUAL_ITEMS_INSUFFICIENT",
                    f"最终Excel实物检查至少需要{VISUAL_CHECK_MINIMUM}个不同检查项",
                ))
            if not _text(visual.get("evidence")):
                issues.append(_blocking("MULTI_ROUND_REVIEW_VISUAL_EVIDENCE_MISSING", "最终Excel实物检查缺evidence"))

    return audit_contract.build_report(
        "multi_round_review_gate",
        issues=issues,
        metrics={
            "required": required,
            "multi_agent_required": multi_agent_required,
            "case_count": len(rows),
            "round_count": len(payload.get("rounds", [])) if isinstance(payload.get("rounds"), list) else 0,
            "consecutive_clean_rounds": payload.get("consecutive_clean_rounds", 0),
            "adversarial_agent_count": final_agent_counts.get("adversarial", 0),
            "regression_agent_count": final_agent_counts.get("regression", 0),
            "revision_batch_count": revision_batch_count,
            "max_revision_batches": max_revision_batches,
        },
        artifacts=[str(config_path), str(cases_path), str(prd_path), str(ledger_path)],
        extensions={
            "input_xlsx_sha256": current_hash,
            "prd_sha256": current_prd_hash,
            "case_ids_sha256": current_case_ids_hash,
        },
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="测试用例多轮评审硬门禁")
    parser.add_argument("--config", required=True)
    args = parser.parse_args()
    try:
        report = evaluate(args.config)
    except Exception as exc:  # noqa: BLE001 - CLI must keep a canonical result
        report = audit_contract.build_report(
            "multi_round_review_gate",
            issues=[_blocking("MULTI_ROUND_REVIEW_EXECUTION_ERROR", str(exc))],
            artifacts=[str(Path(args.config).resolve())],
        )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    raise SystemExit(audit_contract.exit_code(report))


if __name__ == "__main__":
    main()
