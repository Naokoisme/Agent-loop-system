# -*- coding: utf-8 -*-
"""人员执行质量门禁：措辞、归类、顺序和功能边界。

确定性问题直接阻断；需要业务判断的候选项必须在全表人工复核账本中逐条处置。
复核账本与当前最终 Excel 的 SHA-256 绑定，文件变化后旧结论自动失效。
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any


_SCRIPTS = Path(__file__).resolve().parent
if str(_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS))

import audit_contract  # noqa: E402
import delivery_quality  # noqa: E402


DIMENSIONS = ("wording", "classification", "order", "feature_boundary")
CASE_FIELDS = ("测试项", "测试点/检查项", "前置条件", "操作步骤", "预期结果", "备注")
DEFAULT_FORBIDDEN_PHRASES = (
    "终态", "初态", "状态包", "批准口径", "能力显示", "流程不可达", "测试资产",
    "候选维度", "端侧", "本端", "对端", "串号", "半文件", "收尾确认态",
)
DEFAULT_CONTEXTUAL_TEST_ITEM_TERMS = ("APP端", "设备端", "Android", "iOS", "已连接", "未连接", "断连")
VAGUE_EXPECTED_RE = re.compile(
    r"^(?:\d+[.、]\s*)?(?:功能|页面|结果|状态|流程)?(?:表现)?(?:正常|符合预期|符合设计|按规则处理)[。.]?$"
)
NORMALIZE_RE = re.compile(r"[\s\u3000，。；：、,.!！?？;:'\"“”‘’（）()\[\]【】<>《》_-]+")


def _resolve(base: Path, value: str | Path) -> Path:
    path = Path(value)
    return path if path.is_absolute() else base / path


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _as_list(value: Any) -> list[Any]:
    if value is None:
        return []
    return list(value) if isinstance(value, (list, tuple)) else [value]


def _concrete(value: Any, minimum: int = 2) -> bool:
    return isinstance(value, str) and len(value.strip()) >= minimum and "<" not in value


def _normalize(value: Any) -> str:
    text = str(value or "").strip().casefold()
    if text.startswith("验证"):
        text = text[2:]
    return NORMALIZE_RE.sub("", text)


def _case_id(row: dict, index: int) -> str:
    return str(row.get("用例编号", "") or "").strip() or f"ROW_{index}"


def _finding_id(dimension: str, case_id: str, field: str, marker: str) -> str:
    raw = "|".join((dimension, case_id, field, marker))
    return "EQ-" + hashlib.sha256(raw.encode("utf-8")).hexdigest()[:12].upper()


def _finding(
    dimension: str,
    kind: str,
    case_id: str,
    field: str,
    marker: str,
    message: str,
) -> dict[str, str]:
    return {
        "finding_id": _finding_id(dimension, case_id, field, marker),
        "dimension": dimension,
        "kind": kind,
        "case_id": case_id,
        "field": field,
        "marker": marker,
        "message": message,
    }


def _load_blueprint(base: Path, cfg: dict, issues: list[dict[str, Any]]) -> tuple[dict, Path]:
    path = _resolve(base, str(cfg.get("blueprint_file", "用例设计蓝图.json")))
    if not path.is_file():
        issues.append(audit_contract.make_issue(
            "blocking",
            f"人员执行质量门禁缺用例设计蓝图: {path}",
            code="EXECUTION_QUALITY_BLUEPRINT_MISSING",
            kind="blocked",
        ))
        return {}, path
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        issues.append(audit_contract.make_issue(
            "blocking",
            f"人员执行质量蓝图无法读取: {exc}",
            code="EXECUTION_QUALITY_BLUEPRINT_INVALID",
            kind="blocked",
        ))
        return {}, path
    if not isinstance(payload, dict):
        issues.append(audit_contract.make_issue(
            "blocking",
            "用例设计蓝图根节点必须是对象",
            code="EXECUTION_QUALITY_BLUEPRINT_SCHEMA_INVALID",
            kind="blocked",
        ))
        return {}, path
    return payload, path


def _wording_findings(rows: list[dict], cfg: dict) -> list[dict[str, str]]:
    findings: list[dict[str, str]] = []
    phrases = [
        str(value).strip() for value in _as_list(
            cfg.get("forbidden_phrases", DEFAULT_FORBIDDEN_PHRASES)
        ) if str(value).strip()
    ]
    fields = [str(value) for value in _as_list(cfg.get("wording_fields", CASE_FIELDS)) if str(value)]
    for index, row in enumerate(rows, 1):
        cid = _case_id(row, index)
        for field in fields:
            text = str(row.get(field, "") or "")
            for phrase in phrases:
                if phrase in text:
                    findings.append(_finding(
                        "wording", "violation", cid, field, phrase,
                        f"{cid} {field} 含不便执行人员理解的表达“{phrase}”",
                    ))
        expected = str(row.get("预期结果", "") or "").strip()
        if expected and VAGUE_EXPECTED_RE.fullmatch(expected):
            findings.append(_finding(
                "wording", "violation", cid, "预期结果", "vague_expected",
                f"{cid} 预期结果只有泛化结论，未写可观察页面、文案、状态、数值或数据",
            ))
    return findings


def _classification_findings(rows: list[dict], cfg: dict) -> list[dict[str, str]]:
    findings: list[dict[str, str]] = []
    contextual = [
        str(value).strip() for value in _as_list(
            cfg.get("contextual_test_item_terms", DEFAULT_CONTEXTUAL_TEST_ITEM_TERMS)
        ) if str(value).strip()
    ]
    for index, row in enumerate(rows, 1):
        cid = _case_id(row, index)
        feature = str(row.get("功能点", "") or "").strip()
        test_item = str(row.get("测试项", "") or "").strip()
        test_point = str(row.get("测试点/检查项", "") or "").strip()
        if feature and test_item and _normalize(feature) == _normalize(test_item):
            findings.append(_finding(
                "classification", "violation", cid, "测试项", "same_as_feature",
                f"{cid} 功能点与测试项同义重复: {feature!r}",
            ))
        if test_item and test_point and _normalize(test_item) == _normalize(test_point):
            findings.append(_finding(
                "classification", "violation", cid, "测试项", "same_as_test_point",
                f"{cid} 测试项与测试点同义重复: {test_item!r}",
            ))
        for term in contextual:
            if term and term.casefold() in test_item.casefold():
                findings.append(_finding(
                    "classification", "candidate", cid, "测试项", term,
                    f"{cid} 测试项含上下文词“{term}”，需确认它是否真正改变触发链或验证目的",
                ))
    return findings


def _order_value(value: Any) -> list[str] | None:
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]
    if isinstance(value, dict) and isinstance(value.get("order"), list):
        return [str(item).strip() for item in value["order"] if str(item).strip()]
    return None


def _order_findings(rows: list[dict], cfg: dict, blueprint: dict) -> list[dict[str, str]]:
    findings: list[dict[str, str]] = []
    order_key = str(cfg.get("order_map_key", "execution_order") or "execution_order")
    mapping = blueprint.get(order_key)
    if not isinstance(mapping, dict):
        return [_finding(
            "order", "violation", "PROJECT", order_key, "map_missing",
            f"用例设计蓝图缺少 {order_key} 执行顺序映射",
        )]

    grouped: dict[tuple[str, str], list[str]] = defaultdict(list)
    for row in rows:
        module = str(row.get("功能模块", "") or "").strip()
        feature = str(row.get("功能点", "") or "").strip()
        item = str(row.get("测试项", "") or "").strip()
        if item and (not grouped[(module, feature)] or grouped[(module, feature)][-1] != item):
            grouped[(module, feature)].append(item)

    for (module, feature), actual in grouped.items():
        module_map = mapping.get(module)
        expected = _order_value(module_map.get(feature)) if isinstance(module_map, dict) else None
        marker = f"{module}/{feature}"
        if not expected:
            findings.append(_finding(
                "order", "violation", "PROJECT", "测试项顺序", marker,
                f"执行顺序映射未覆盖功能点: {marker}",
            ))
            continue
        if len(expected) != len(set(expected)):
            findings.append(_finding(
                "order", "violation", "PROJECT", "测试项顺序", marker + "/duplicate",
                f"执行顺序映射含重复测试项: {marker}",
            ))
            continue
        if set(actual) != set(expected):
            missing = [item for item in actual if item not in expected]
            stale = [item for item in expected if item not in actual]
            findings.append(_finding(
                "order", "violation", "PROJECT", "测试项顺序", marker + "/coverage",
                f"执行顺序映射与当前用例不一致: {marker}，漏配={missing}，失效={stale}",
            ))
        elif actual != expected:
            findings.append(_finding(
                "order", "violation", "PROJECT", "测试项顺序", marker + "/sequence",
                f"功能点内测试项顺序错误: {marker}，当前={actual}，应为={expected}",
            ))
    return findings


def _feature_boundary_findings(rows: list[dict], cfg: dict, blueprint: dict) -> list[dict[str, str]]:
    findings: list[dict[str, str]] = []
    boundary_key = str(cfg.get("module_boundary_key", "module_boundary") or "module_boundary")
    rules = blueprint.get(boundary_key)
    if not isinstance(rules, dict):
        return [_finding(
            "feature_boundary", "violation", "PROJECT", boundary_key, "map_missing",
            f"用例设计蓝图缺少 {boundary_key} 功能边界规则",
        )]

    modules = sorted({str(row.get("功能模块", "") or "").strip() for row in rows if str(row.get("功能模块", "") or "").strip()})
    if cfg.get("require_boundary_rules", True) is True:
        for module in modules:
            rule = rules.get(module)
            if not isinstance(rule, dict) or not _concrete(rule.get("scope")):
                findings.append(_finding(
                    "feature_boundary", "violation", "PROJECT", boundary_key, module,
                    f"功能模块“{module}”缺具体 scope 边界说明",
                ))

    for index, row in enumerate(rows, 1):
        module = str(row.get("功能模块", "") or "").strip()
        rule = rules.get(module)
        if not isinstance(rule, dict):
            continue
        cid = _case_id(row, index)
        expected = str(row.get("预期结果", "") or "")
        owned = [str(value).strip() for value in _as_list(rule.get("owned_outcome_keywords")) if str(value).strip()]
        foreign = [str(value).strip() for value in _as_list(rule.get("foreign_feature_keywords")) if str(value).strip()]
        foreign_hits = [value for value in foreign if value.casefold() in expected.casefold()]
        owned_hit = any(value.casefold() in expected.casefold() for value in owned)
        if foreign_hits and not owned_hit:
            marker = ",".join(foreign_hits)
            findings.append(_finding(
                "feature_boundary", "candidate", cid, "预期结果", marker,
                f"{cid} 预期只命中其他功能 {foreign_hits}，需确认最终验收是否仍落在“{module}”",
            ))
    return findings


def automatic_findings(rows: list[dict], cfg: dict, blueprint: dict) -> list[dict[str, str]]:
    return [
        *_wording_findings(rows, cfg),
        *_classification_findings(rows, cfg),
        *_order_findings(rows, cfg, blueprint),
        *_feature_boundary_findings(rows, cfg, blueprint),
    ]


def build_review_template(current_hash: str, case_count: int, feature_point_count: int) -> dict[str, Any]:
    return {
        "schema_version": 1,
        "input_xlsx_sha256": current_hash or "<当前最终Excel SHA-256>",
        "status": "PENDING",
        "reviewer": "<复核人>",
        "dimensions": {
            "wording": {"status": "PENDING", "reviewed_case_count": 0, "evidence": "", "findings": []},
            "classification": {"status": "PENDING", "reviewed_case_count": 0, "evidence": "", "findings": []},
            "order": {"status": "PENDING", "reviewed_feature_point_count": 0, "evidence": "", "findings": []},
            "feature_boundary": {"status": "PENDING", "reviewed_case_count": 0, "evidence": "", "findings": []},
        },
        "accepted_automatic_findings": [],
        "note": f"当前候选共{case_count}条用例、{feature_point_count}个功能点；四项全表复核完成后才能改为PASS。",
    }


def _validate_review(
    review: Any,
    *,
    current_hash: str,
    case_count: int,
    feature_point_count: int,
    findings: list[dict[str, str]],
) -> tuple[list[dict[str, Any]], dict[str, Any]]:
    issues: list[dict[str, Any]] = []
    summary: dict[str, Any] = {}
    if not isinstance(review, dict):
        return [audit_contract.make_issue(
            "blocking", "人员执行质量复核文件根节点必须是对象",
            code="EXECUTION_QUALITY_REVIEW_SCHEMA_INVALID", kind="blocked",
        )], summary

    recorded_hash = str(review.get("input_xlsx_sha256", "") or "").strip().lower()
    if recorded_hash != current_hash.lower():
        issues.append(audit_contract.make_issue(
            "blocking",
            f"人员执行质量复核已过期: recorded={recorded_hash or '<空>'} current={current_hash}",
            code="EXECUTION_QUALITY_REVIEW_HASH_STALE",
            kind="failure",
        ))
    if review.get("status") != "PASS":
        issues.append(audit_contract.make_issue(
            "blocking", "人员执行质量复核总状态必须为PASS",
            code="EXECUTION_QUALITY_REVIEW_NOT_PASSED", kind="failure",
        ))
    if not _concrete(review.get("reviewer")):
        issues.append(audit_contract.make_issue(
            "blocking", "人员执行质量复核必须填写具体复核人",
            code="EXECUTION_QUALITY_REVIEWER_MISSING", kind="failure",
        ))

    dimensions = review.get("dimensions")
    if not isinstance(dimensions, dict):
        issues.append(audit_contract.make_issue(
            "blocking", "人员执行质量复核缺dimensions对象",
            code="EXECUTION_QUALITY_DIMENSIONS_MISSING", kind="blocked",
        ))
        dimensions = {}
    for dimension in DIMENSIONS:
        row = dimensions.get(dimension)
        if not isinstance(row, dict):
            issues.append(audit_contract.make_issue(
                "blocking", f"人员执行质量复核缺维度: {dimension}",
                code="EXECUTION_QUALITY_DIMENSION_MISSING", kind="blocked",
            ))
            continue
        if row.get("status") != "PASS":
            issues.append(audit_contract.make_issue(
                "blocking", f"人员执行质量维度未通过: {dimension}",
                code="EXECUTION_QUALITY_DIMENSION_NOT_PASSED", kind="failure",
            ))
        count_key = "reviewed_feature_point_count" if dimension == "order" else "reviewed_case_count"
        expected_count = feature_point_count if dimension == "order" else case_count
        if row.get(count_key) != expected_count:
            issues.append(audit_contract.make_issue(
                "blocking", f"{dimension}.{count_key}={row.get(count_key)!r}，应为{expected_count}",
                code="EXECUTION_QUALITY_REVIEW_SCOPE_INCOMPLETE", kind="failure",
            ))
        if not _concrete(row.get("evidence"), 4):
            issues.append(audit_contract.make_issue(
                "blocking", f"人员执行质量维度缺具体复核证据: {dimension}",
                code="EXECUTION_QUALITY_EVIDENCE_MISSING", kind="failure",
            ))
        human_findings = row.get("findings", [])
        if not isinstance(human_findings, list):
            issues.append(audit_contract.make_issue(
                "blocking", f"{dimension}.findings 必须是数组",
                code="EXECUTION_QUALITY_FINDINGS_INVALID", kind="blocked",
            ))
            human_findings = []
        for index, item in enumerate(human_findings, 1):
            if not isinstance(item, dict) or item.get("status") not in {"resolved", "not_issue"} \
                    or not _concrete(item.get("evidence"), 4):
                issues.append(audit_contract.make_issue(
                    "blocking", f"{dimension}.findings[{index}] 未闭环或缺具体证据",
                    code="EXECUTION_QUALITY_HUMAN_FINDING_OPEN", kind="failure",
                ))
        summary[dimension] = {
            "status": row.get("status"),
            count_key: row.get(count_key),
            "finding_count": len(human_findings),
        }

    accepted_rows = review.get("accepted_automatic_findings", [])
    if not isinstance(accepted_rows, list):
        issues.append(audit_contract.make_issue(
            "blocking", "accepted_automatic_findings 必须是数组",
            code="EXECUTION_QUALITY_ACCEPTED_INVALID", kind="blocked",
        ))
        accepted_rows = []
    accepted: dict[str, str] = {}
    for index, item in enumerate(accepted_rows, 1):
        if not isinstance(item, dict):
            issues.append(audit_contract.make_issue(
                "blocking", f"accepted_automatic_findings[{index}] 必须是对象",
                code="EXECUTION_QUALITY_ACCEPTED_INVALID", kind="blocked",
            ))
            continue
        finding_id = str(item.get("finding_id", "") or "").strip()
        reason = str(item.get("reason", "") or "").strip()
        reviewer = str(item.get("reviewer", "") or "").strip()
        if not finding_id or not _concrete(reason, 4) or not _concrete(reviewer):
            issues.append(audit_contract.make_issue(
                "blocking", f"accepted_automatic_findings[{index}] 缺finding_id、具体理由或复核人",
                code="EXECUTION_QUALITY_ACCEPTED_REASON_MISSING", kind="failure",
            ))
            continue
        accepted[finding_id] = reason

    known = {row["finding_id"]: row for row in findings}
    stale = sorted(set(accepted) - set(known))
    if stale:
        issues.append(audit_contract.make_issue(
            "blocking", f"复核账本包含已失效的自动候选: {stale}",
            code="EXECUTION_QUALITY_ACCEPTED_STALE", kind="failure",
        ))
    for finding in findings:
        if finding["kind"] == "violation":
            issues.append(audit_contract.make_issue(
                "blocking", finding["message"], code="EXECUTION_QUALITY_AUTOMATIC_VIOLATION",
                kind="failure", details=finding,
            ))
        elif finding["finding_id"] not in accepted:
            issues.append(audit_contract.make_issue(
                "blocking", finding["message"], code="EXECUTION_QUALITY_CANDIDATE_UNRESOLVED",
                kind="failure", details=finding,
            ))
    summary["accepted_automatic_finding_count"] = len(accepted)
    return issues, summary


def evaluate(config_path: str | Path, *, init_review: bool = False, force: bool = False) -> dict[str, Any]:
    config_path = Path(config_path).resolve()
    base = config_path.parent
    config = json.loads(config_path.read_text(encoding="utf-8"))
    issues: list[dict[str, Any]] = []
    gates = config.get("quality_gates", {}) or {}
    cfg = gates.get("execution_quality")
    if not isinstance(cfg, dict) or cfg.get("required") is not True:
        return audit_contract.build_report(
            "execution_quality_gate",
            issues=[audit_contract.make_issue(
                "blocking", "quality_gates.execution_quality 必须配置且 required=true",
                code="EXECUTION_QUALITY_CONFIG_MISSING", kind="blocked",
            )],
            artifacts=[str(config_path)],
        )

    xlsx_value = str(config.get("cases_xlsx", "") or "").strip()
    xlsx = _resolve(base, xlsx_value) if xlsx_value else base / "<missing-cases.xlsx>"
    if not xlsx.is_file():
        return audit_contract.build_report(
            "execution_quality_gate",
            issues=[audit_contract.make_issue(
                "blocking", f"最终Excel不存在: {xlsx}", code="EXECUTION_QUALITY_XLSX_MISSING", kind="blocked",
            )],
            artifacts=[str(config_path), str(xlsx)],
        )
    current_hash = _sha256(xlsx)
    delivery_cfg = gates.get("delivery_workbook", {}) or {}
    modules = config.get("modules", []) or []
    default_module = str(modules[0].get("name", "")) if len(modules) == 1 and isinstance(modules[0], dict) else ""
    rows = delivery_quality.read_case_rows(xlsx, delivery_cfg, default_module)
    feature_point_count = len({
        (str(row.get("功能模块", "") or "").strip(), str(row.get("功能点", "") or "").strip())
        for row in rows
    })
    blueprint, blueprint_path = _load_blueprint(base, cfg, issues)
    findings = automatic_findings(rows, cfg, blueprint) if blueprint else []

    review_path = _resolve(base, str(cfg.get("review_file", "工作底稿/人员执行质量复核.json")))
    if init_review:
        if review_path.exists() and not force:
            issues.append(audit_contract.make_issue(
                "blocking", f"复核文件已存在，未覆盖: {review_path}",
                code="EXECUTION_QUALITY_REVIEW_EXISTS", kind="blocked",
            ))
        else:
            review_path.parent.mkdir(parents=True, exist_ok=True)
            review_path.write_text(
                json.dumps(build_review_template(current_hash, len(rows), feature_point_count), ensure_ascii=False, indent=2) + "\n",
                encoding="utf-8",
            )

    review: Any = None
    if not review_path.is_file():
        issues.append(audit_contract.make_issue(
            "blocking", f"人员执行质量复核文件不存在: {review_path}",
            code="EXECUTION_QUALITY_REVIEW_MISSING", kind="blocked",
        ))
    else:
        try:
            review = json.loads(review_path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as exc:
            issues.append(audit_contract.make_issue(
                "blocking", f"人员执行质量复核文件无法读取: {exc}",
                code="EXECUTION_QUALITY_REVIEW_INVALID", kind="blocked",
            ))

    review_summary: dict[str, Any] = {}
    if review is not None:
        review_issues, review_summary = _validate_review(
            review,
            current_hash=current_hash,
            case_count=len(rows),
            feature_point_count=feature_point_count,
            findings=findings,
        )
        issues.extend(review_issues)

    counts = {
        dimension: sum(1 for row in findings if row["dimension"] == dimension)
        for dimension in DIMENSIONS
    }
    return audit_contract.build_report(
        "execution_quality_gate",
        issues=issues,
        metrics={
            "case_count": len(rows),
            "feature_point_count": feature_point_count,
            "automatic_finding_count": len(findings),
            "automatic_finding_counts": counts,
        },
        artifacts=[str(config_path), str(xlsx), str(blueprint_path), str(review_path)],
        extensions={
            "dimensions": review_summary,
            "automatic_findings": findings,
            "input_xlsx_sha256": current_hash,
        },
    )


def main() -> None:
    parser = argparse.ArgumentParser(description="测试用例人员执行质量门禁")
    parser.add_argument("--config", required=True)
    parser.add_argument("--init-review", action="store_true", help="生成与当前Excel绑定的待复核模板")
    parser.add_argument("--force", action="store_true", help="配合--init-review覆盖已有复核模板")
    parser.add_argument("--out", help="额外写出规范化检查报告")
    args = parser.parse_args()
    try:
        report = evaluate(args.config, init_review=args.init_review, force=args.force)
    except Exception as exc:  # noqa: BLE001 - CLI must always emit canonical evidence
        report = audit_contract.build_report(
            "execution_quality_gate",
            issues=[audit_contract.make_issue(
                "blocking", str(exc), code="EXECUTION_QUALITY_EXECUTION_ERROR", kind="blocked",
            )],
            artifacts=[str(Path(args.config).resolve())],
        )
    text = json.dumps(report, ensure_ascii=False, indent=2)
    if args.out:
        output = Path(args.out).resolve()
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(text + "\n", encoding="utf-8")
    print(text)
    raise SystemExit(audit_contract.exit_code(report))


if __name__ == "__main__":
    main()
