# -*- coding: utf-8 -*-
"""Run a bounded structure-gate fix loop for workflow-v2 projects.

The script targets mechanical S6/S8/S9/S10 issues in projects/<name>/cases/*.json:

- S6: genericize test-item values that contain concrete numbers/platforms.
- S8: normalize step/expected text into matching numbered lines.
- S9: preserve explicit numbered/newline detail only; ambiguous prose is reported
  for semantic review instead of being guessed apart.
- S10: re-export through tc_excel so confirmation markers are styled red.

It intentionally does not rewrite higher-risk semantic gates. Those remain in the
gate log for human/model review.
"""
from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path

_SCRIPTS = Path(__file__).resolve().parent
_ROOT = _SCRIPTS.parent
_TRACE = _SCRIPTS / "traceability"
for _p in (_SCRIPTS, _TRACE):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

from _common import load_config  # noqa: E402


STEP_NO_RE = re.compile(r"(?:^|[;\n\r])\s*(\d+)[\.\)）、．]\s*")
NUMBERED_LINE_RE = re.compile(r"^\s*(\d+)[\.\)）、．]\s*(.*)$")
SPECIFIC_ITEM_RE = re.compile(
    r"(?i)("
    r"\d+(?:\.\d+)?\s*(?:KB|MB|GB|B|%|s|sec|秒|分钟|分|小时|h|天|次|条|℃|°C|km|公里|kcal|BPM|mmHg|mAh|V)"
    r"|[<>＝=≥≤]\s*\d+"
    r"|\d+\s*[<>＝=≥≤]"
    r"|Android|iOS|HarmonyOS|鸿蒙|中文|英文|每小时|每\d+分钟|每\d+小时"
    r")"
)

ITEM_NORMALIZE = {
    "步数>20重置": "步数阈值重置",
    "步数<20判定": "步数阈值判定",
}


@dataclass
class CommandResult:
    code: int
    output: str


def run_command(args: list[str], cwd: Path) -> CommandResult:
    proc = subprocess.run(
        args,
        cwd=str(cwd),
        text=True,
        encoding="utf-8",
        errors="replace",
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
    )
    return CommandResult(proc.returncode, proc.stdout)


def clean_fragment(text: object) -> str:
    return re.sub(r"\s+", " ", str(text or "").strip(" ;；,，、\n\r\t"))


def split_numbered_steps(text: object) -> list[str]:
    text = str(text or "").strip()
    if not text:
        return []
    matches = list(STEP_NO_RE.finditer(text))
    if matches:
        raw_parts: list[str] = []
        for i, match in enumerate(matches):
            start = match.end()
            end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
            part = clean_fragment(text[start:end])
            if part:
                raw_parts.append(part)
    else:
        # A single prose line has no reliable step boundary. In particular,
        # Chinese conjunctions such as 并/且/及/同时 frequently join one atomic
        # business meaning (for example "保存并同步"), so never guess-split it.
        raw_parts = [clean_fragment(line) for line in text.replace("\r\n", "\n").replace("\r", "\n").split("\n") if clean_fragment(line)]
    return raw_parts


def split_plain_result(text: object) -> list[str]:
    text = str(text or "").strip()
    if not text:
        return []
    matches = list(STEP_NO_RE.finditer(text))
    if len(matches) > 1:
        parts: list[str] = []
        for i, match in enumerate(matches):
            start = match.end()
            end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
            part = clean_fragment(text[start:end])
            if part:
                parts.append(part)
        return parts
    numbered: list[str] = []
    for line in text.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        line = line.strip()
        if not line:
            continue
        match = NUMBERED_LINE_RE.match(line)
        numbered.append(clean_fragment(match.group(2).strip() if match else line))
    return numbered or [clean_fragment(text)]


def numbered(lines: list[str]) -> str:
    return "\n".join(f"{i}.{clean_fragment(line)}" for i, line in enumerate(lines, 1) if clean_fragment(line))


def align_steps_and_expected(steps: list[str], expected: object) -> tuple[list[str], list[str]]:
    steps = [clean_fragment(s) for s in steps if clean_fragment(s)]
    parts = split_plain_result(expected)
    if not steps:
        raise ValueError("操作步骤为空，禁止自动补生成器占位句")
    if not parts:
        raise ValueError("预期结果为空，禁止自动补生成器占位句")
    parts = [clean_fragment(p) for p in parts if clean_fragment(p)]
    if len(parts) != len(steps):
        raise ValueError(
            f"步骤/预期拆分后数量不一致({len(steps)}!={len(parts)})，需按业务语义人工拆分，禁止复制或填充占位句"
        )
    return steps, parts


def _has_explicit_detail_boundaries(text: object) -> bool:
    """True only when the author supplied numbered or newline boundaries."""
    value = str(text or "").strip()
    if not value:
        return False
    if len([line for line in value.replace("\r\n", "\n").replace("\r", "\n").split("\n") if line.strip()]) > 1:
        return True
    return bool(STEP_NO_RE.search(value))


def normalize_case(case: dict) -> tuple[bool, list[str]]:
    changed = False
    touched: list[str] = []

    raw_steps = case.get("操作步骤", "")
    raw_expected = case.get("预期结果", "")
    if not _has_explicit_detail_boundaries(raw_steps) or not _has_explicit_detail_boundaries(raw_expected):
        raise ValueError("步骤/预期缺少显式编号或换行边界，禁止按中文连接词猜拆；需按业务语义人工结构化")

    steps = split_numbered_steps(raw_steps)
    steps, expected_parts = align_steps_and_expected(steps, raw_expected)
    new_steps = numbered(steps)
    if case.get("操作步骤", "") != new_steps:
        case["操作步骤"] = new_steps
        changed = True
        touched.append("S8/S9:操作步骤")

    new_expected = numbered(expected_parts)
    if case.get("预期结果", "") != new_expected:
        case["预期结果"] = new_expected
        changed = True
        touched.append("S8/S9:预期结果")

    item = str(case.get("测试项", ""))
    new_item = ITEM_NORMALIZE.get(item, item)
    if new_item == item and SPECIFIC_ITEM_RE.search(item):
        point = str(case.get("测试点/检查项", ""))
        if "默认" in point:
            new_item = "默认值"
        elif "范围" in point or "选项" in point:
            new_item = "选项范围"
        elif "阈值" in point or "步数" in point:
            new_item = "阈值判定"
        else:
            new_item = re.sub(SPECIFIC_ITEM_RE, "参数", item).strip() or "参数规则"
    if new_item != item:
        case["测试项"] = new_item
        changed = True
        touched.append("S6:测试项泛化")

    return changed, touched


def cases_dir_for(project_dir: Path) -> Path:
    cases_dir = project_dir / "cases"
    if not cases_dir.exists():
        raise SystemExit(f"未找到用例 JSON 目录: {cases_dir}")
    return cases_dir


def module_prefixes(cfg) -> dict[str, str]:
    return {str(m.get("name", "")): str(m.get("prefix", "")) for m in cfg.modules if m.get("name") and m.get("prefix")}


def normalize_cases(project_dir: Path, cfg, dry_run: bool) -> dict[str, object]:
    cases_dir = cases_dir_for(project_dir)
    prefixes = module_prefixes(cfg)
    total = 0
    changed = 0
    changed_files = 0
    id_filled = 0
    id_rewritten = 0
    touched_rules: dict[str, int] = {}
    changed_case_ids: list[str] = []
    blocked_cases: list[dict[str, str]] = []

    for path in sorted(cases_dir.glob("*.json")):
        data = json.loads(path.read_text(encoding="utf-8"))
        module = str(data.get("module", path.stem))
        prefix = prefixes.get(module, "")
        file_changed = False
        for index, case in enumerate(data.get("cases", []), 1):
            total += 1
            try:
                did_change, touched = normalize_case(case)
            except ValueError as exc:
                cid = str(case.get("用例编号", "") or f"{path.stem}#{index}")
                blocked_cases.append({"case_id": cid, "reason": str(exc)})
                continue
            expected_id = f"{prefix}_{index:03d}" if prefix else ""
            current_id = str(case.get("用例编号", "") or "").strip()
            if expected_id and not current_id:
                id_filled += 1
                case["用例编号"] = expected_id
                did_change = True
                touched.append("ID:用例编号补齐")
            if did_change:
                changed += 1
                file_changed = True
                cid = str(case.get("用例编号", "") or f"{path.stem}#{index}")
                if len(changed_case_ids) < 50:
                    changed_case_ids.append(cid)
                for rule in touched:
                    touched_rules[rule] = touched_rules.get(rule, 0) + 1
        if file_changed:
            changed_files += 1
            if not dry_run:
                path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    return {
        "total_cases": total,
        "changed_cases": changed,
        "changed_files": changed_files,
        "id_filled": id_filled,
        "id_rewritten": id_rewritten,
        "touched_rules": touched_rules,
        "sample_changed_case_ids": changed_case_ids,
        "blocked_cases": blocked_cases,
    }


def export_cases(project: str, cfg, out: Path, renumber: bool) -> CommandResult:
    args = [
        sys.executable,
        str(_SCRIPTS / "export_cases.py"),
        "--project",
        project,
        "--out",
        str(out),
        "--order",
        *cfg.module_order,
    ]
    if renumber:
        args.extend(["--renumber", "--migration-file", "用例编号迁移.json"])
    return run_command(args, _ROOT)


def gate(config_path: Path) -> CommandResult:
    return run_command(
        [sys.executable, str(_SCRIPTS / "check_structure.py"), "--config", str(config_path)],
        _ROOT,
    )


def count_violations(output: str) -> dict[str, int]:
    counts: dict[str, int] = {}
    for match in re.finditer(r"\[(S\d+)\s", output):
        key = match.group(1)
        counts[key] = counts.get(key, 0) + 1
    return counts


def write_report(project_dir: Path, report: dict[str, object]) -> Path:
    out = project_dir / "gate_fix_loop_report.md"
    lines = [
        "# 门禁补强闭环报告",
        "",
        f"- project: {report['project']}",
        f"- config: {report['config']}",
        f"- max_rounds: {report['max_rounds']}",
        f"- final_status: {report['final_status']}",
        "",
        "## 轮次",
        "",
    ]
    for round_info in report["rounds"]:
        lines.extend([
            f"### Round {round_info['round']}",
            "",
            f"- before_exit: {round_info['before_exit']}",
            f"- before_violations: {round_info['before_violations']}",
            f"- normalized: {round_info['normalized']}",
            f"- export_exit: {round_info['export_exit']}",
            f"- after_exit: {round_info['after_exit']}",
            f"- after_violations: {round_info['after_violations']}",
            "",
            "#### before output",
            "",
            "```text",
            str(round_info["before_output"]).strip()[:4000],
            "```",
            "",
            "#### export output",
            "",
            "```text",
            str(round_info["export_output"]).strip()[:2000],
            "```",
            "",
            "#### after output",
            "",
            "```text",
            str(round_info["after_output"]).strip()[:4000],
            "```",
            "",
        ])
    out.write_text("\n".join(lines), encoding="utf-8")
    return out


def main() -> None:
    ap = argparse.ArgumentParser(description="workflow-v2 门禁失败自动补强闭环")
    ap.add_argument("--config", required=True, help="projects/<项目>/trace.config.json")
    ap.add_argument("--max-rounds", type=int, default=3)
    ap.add_argument("--dry-run", action="store_true", help="只分析和报告,不写 cases 或 Excel")
    ap.add_argument("--no-renumber", action="store_true", help="导出时不使用 --renumber")
    args = ap.parse_args()

    config_path = Path(args.config).resolve()
    cfg = load_config(config_path)
    project_dir = cfg.base
    project = cfg.project
    report: dict[str, object] = {
        "project": project,
        "config": str(config_path),
        "max_rounds": args.max_rounds,
        "rounds": [],
        "final_status": "UNKNOWN",
    }

    final_gate = gate(config_path)
    for round_no in range(1, args.max_rounds + 1):
        before = final_gate
        before_counts = count_violations(before.output)
        if before.code == 0:
            report["final_status"] = "PASS"
            break

        normalized = normalize_cases(project_dir, cfg, dry_run=args.dry_run)
        if normalized.get("blocked_cases"):
            report["rounds"].append({
                "round": round_no,
                "before_exit": before.code,
                "before_violations": before_counts,
                "before_output": before.output,
                "normalized": normalized,
                "export_exit": 1,
                "export_output": "semantic manual fix required; export skipped",
                "after_exit": before.code,
                "after_violations": before_counts,
                "after_output": before.output,
            })
            report["final_status"] = "SEMANTIC_REVIEW_REQUIRED"
            final_gate = before
            break
        export_result = CommandResult(0, "dry-run: export skipped")
        if not args.dry_run:
            export_result = export_cases(project, cfg, cfg.cases_xlsx, renumber=not args.no_renumber)
        after = gate(config_path)
        after_counts = count_violations(after.output)

        report["rounds"].append({
            "round": round_no,
            "before_exit": before.code,
            "before_violations": before_counts,
            "before_output": before.output,
            "normalized": normalized,
            "export_exit": export_result.code,
            "export_output": export_result.output,
            "after_exit": after.code,
            "after_violations": after_counts,
            "after_output": after.output,
        })

        final_gate = after
        if after.code == 0:
            report["final_status"] = "PASS"
            break
        if normalized["changed_cases"] == 0:
            report["final_status"] = "NO_PROGRESS"
            break
    else:
        report["final_status"] = "MAX_ROUNDS_REACHED" if final_gate.code else "PASS"

    if not report["rounds"] and final_gate.code == 0:
        report["rounds"].append({
            "round": 0,
            "before_exit": 0,
            "before_violations": {},
            "before_output": final_gate.output,
            "normalized": {"total_cases": 0, "changed_cases": 0, "changed_files": 0, "touched_rules": {}, "sample_changed_case_ids": []},
            "export_exit": 0,
            "export_output": "gate already passed; export skipped",
            "after_exit": 0,
            "after_violations": {},
            "after_output": final_gate.output,
        })

    report_path = write_report(project_dir, report)
    print(f"final_status={report['final_status']}")
    print(f"report={report_path}")
    print(final_gate.output.strip())
    sys.exit(0 if report["final_status"] == "PASS" else 1)


if __name__ == "__main__":
    main()
