# -*- coding: utf-8 -*-
"""Project path resolution shared by workflow-v2 command-line tools."""
from __future__ import annotations

from pathlib import Path


WORKFLOW_ROOT = Path(__file__).resolve().parents[1]
LEGACY_PROJECTS_ROOT = WORKFLOW_ROOT / "projects"


def resolve_workspace_root(value: str | Path | None) -> Path:
    """Return an explicit project-container path without creating it."""
    if value is None or not str(value).strip():
        return LEGACY_PROJECTS_ROOT
    return Path(value).expanduser().resolve()


def validate_component(value: str | Path, *, label: str = "project") -> str:
    """Require one portable path component for project and work-unit names."""
    text = str(value or "").strip()
    candidate = Path(text)
    if (
        not text
        or candidate.is_absolute()
        or text in {".", ".."}
        or len(candidate.parts) != 1
        or any(separator in text for separator in ("/", "\\"))
    ):
        raise ValueError(f"{label} 必须是单个安全目录名，不能包含绝对路径、分隔符或 ..: {text!r}")
    return text


def resolve_project(
    project: str | Path,
    *,
    workspace_root: str | Path | None = None,
) -> Path:
    """Resolve either an absolute project directory or a name under a workspace."""
    value = Path(project).expanduser()
    if value.is_absolute():
        if workspace_root is not None and str(workspace_root).strip():
            raise ValueError("--workspace-root 与绝对 --project 不能同时使用")
        return value.resolve()
    name = validate_component(project, label="project")
    root = resolve_workspace_root(workspace_root)
    resolved = (root / name).resolve()
    if resolved.parent != root:
        raise ValueError(f"project 解析后越出工作区: {resolved}")
    return resolved
