# -*- coding: utf-8 -*-
"""项目脚手架：为一个新项目建好端到端工作区骨架。

用法：
  python scripts/new_project.py --name <项目名>
  python scripts/new_project.py --name <项目名> --prd ../某PRD.md --cases ../某用例.xlsx

产物（workflow-v2/projects/<项目名>/）：
  工作底稿/ 结果/ 补充用例/      —— 覆盖追溯三步的产物目录
  trace.config.json              —— 覆盖追溯配置模板（占位待填）
  运行记录.md                    —— 端到端各阶段的运行记录骨架
不覆盖已存在文件（除非 --force）。
"""
from __future__ import annotations

import argparse
import copy
import json
from pathlib import Path

from execution_profile import (
    apply_profile_to_config,
    build_profile,
    has_pack,
    required_blueprint_keys,
    write_profile,
)
from generation_contract import GENERATION_CONTRACT_TEMPLATE
from project_paths import resolve_project, validate_component
from work_unit_contract import CONTRACT_FILENAME, build_contract

ROOT = Path(__file__).resolve().parents[1]          # workflow-v2/

CONFIG_TEMPLATE = {
    "project": "<项目名>",
    "prd_path": "<项目>_PRD需求解析.md",
    "prd_requirement_section": "## 6. 功能规则",
    "prd_parse_mode": "section_by_indent",
    "cases_xlsx": "<项目>_全功能测试用例.xlsx",
    "case_columns": {"id": 0, "功能点": 2, "测试项": 3, "测试点": 4, "前置": 5, "步骤": 6, "预期": 7},
    "coverage_threshold": 0.95,
    "coverage_policy": {
        "require_zero_partial": True,
        "accepted_partial_req_ids": [],
        "pending_evidence_mode": "require_acceptance",
        "accepted_pending_req_ids": []
    },
    "generation_contract": {
        "required": True,
        "file": "生成验收合同.json"
    },
    "release_acceptance": {
        "execution_quality_required": True,
        "feedback_patterns_required": True,
        "feedback_patterns_file": "工作底稿/反馈模式账本.json",
        "multi_round_review_required": True,
        "multi_agent_review_required": True,
        "multi_round_review_file": "工作底稿/多轮测试用例评审.json",
        "review_control": {
            "execution_mode": "manual",
            "scope_lock_required": True,
            "max_revision_batches": 2
        },
        "changed_case_ids_file": "工作底稿/最近变更用例ID.json",
        "decision_ledger_file": "工作底稿/需求决策账本.json",
        "required_strata": ["changed", "high_risk", "pending", "conflict", "feature_point"],
        "strata_not_applicable": {},
        "delivery_artifact": {
            "required": True,
            "path": "<项目>_全功能测试用例.xlsx",
            "quality_gates_source": "top_level",
            "projection": {
                "mode": "exact",
                "fields": [
                    "功能点", "测试项", "测试点/检查项", "前置条件",
                    "操作步骤", "预期结果", "优先级", "备注"
                ]
            }
        },
        "required_reports": []
    },
    "out_dirs": {"draft": "工作底稿/追溯", "result": "结果", "gaps": "补充用例"},
    "modules": [
        {"name": "<模块名>", "prefix": "<英文前缀>", "prd_sections": ["<对应PRD小节名>"]}
    ],
    "quality_gates": {
        "manual_case_style": {
            "enabled": True,
            "manual_only": True,
            "precondition_action_prefixes": [
                "点击", "输入", "扫描", "切换", "进入", "退出", "重启", "断电", "长按", "确认"
            ],
            "observation_step_prefixes": [
                "查看", "核对", "观察", "询问测试人员"
            ],
            "regression_item_keywords": ["回归"],
            "regression_markers": ["基线", "上一正式版", "上一正式版本"],
            "forbidden_step_phrases": [
                "基线终点", "观察至基线", "对照基线", "批准的有限终点"
            ],
            "forbidden_expected_phrases": [
                "结果与基线一致", "与现网基线一致", "与权限基线一致", "与并发基线一致"
            ],
            "redundant_observation_phrases": [
                "查看结果", "核对结果", "观察结果", "核对状态", "询问测试人员"
            ],
            "baseline_source_keywords": [
                "上一正式版", "上一正式版本", "人工执行说明", "产品批准", "负责人批准"
            ],
            "baseline_locator_keywords": [
                "版本号", "构建号", "记录编号", "记录位置", "人工执行说明"
            ],
            "shared_baseline_reference": "",
            "comparison_object_keywords": [
                "页面", "提示", "文案", "按钮", "列表", "绑定状态", "设备状态", "最终状态", "数据"
            ],
            "require_explicit_comparison": True,
            "allow_case_ids": []
        },
        "feature_order": {
            "<模块名>": {
                "order": ["<入口功能点>", "<页面展示功能点>", "<核心流程功能点>", "<异常场景>", "<中断场景>", "<交叉场景>"],
                "required": True,
                "mode": "exact"
            }
        },
        "module_dependencies": {
            "<模块名>": {
                "required_preconditions": ["<依赖已开启/已授权>"],
                "negative_keywords": ["<依赖关闭负向场景关键词>"],
                "exclude_case_ids": []
            }
        },
        "unsupported_features": {
            "<模块名>": {
                "features": [
                    {
                        "feature": "<不支持能力名>",
                        "keywords": ["<不支持能力关键词>"],
                        "allowed_negative_keywords": ["不支持", "不提供", "不显示", "不出现", "禁止"]
                    }
                ]
            }
        },
        "page_input_matrix": {
            "<模块名>": [
                {
                    "page": "<页面名>",
                    "feature_point": "<功能点名>",
                    "inputs": ["左滑", "右滑", "上滑", "下滑", "点击", "编码器旋转", "编码器按压", "下按键"],
                    "not_applicable": {}
                }
            ]
        },
        "new_modules": {
            "<新增模块名>": {
                "required_categories": ["入口", "页面展示", "核心", "异常", "中断", "交叉", "界面操作"]
            }
        },
        "excel_format": {
            "merge_hierarchy_cells": True,
            "require_precondition_numbering": True,
            "require_test_point_verify_prefix": True,
            "test_point_max_length": 35,
            "require_precondition_for_keywords": [],
            "check_migration": False,
            "migration_file": "用例编号迁移.json"
        },
        "delivery_workbook": {
            "single_sheet": True,
            "sheet_name": "全功能测试用例",
            "headers": [
                "序号", "用例编号", "功能模块", "功能点", "测试项", "测试点/检查项",
                "前置条件", "操作步骤", "预期结果", "优先级", "兼容性", "是否自动化",
                "固件版本", "硬件型号", "测试方式", "备注"
            ],
            "font_name": "等线",
            "font_size": 10,
            "require_black_borders": True,
            "merge_hierarchy": ["功能模块", "功能点", "测试项"],
            "forbid_merges_outside_hierarchy": True,
            "expected_version": "<交付目标版本>",
            "filename_must_contain_version": True,
            "forbid_other_versions": True,
            "version_scan_fields": ["前置条件", "固件版本", "备注"],
            "require_expected_version_mention": True
        },
        "test_item_taxonomy": {
            "forbidden_generic_items": ["功能测试", "边界测试", "边界场景", "规则确认", "规则测试", "规则校验"]
        },
        "case_granularity": {
            "forbid_grouped_scenarios": True,
            "detect_exact_duplicates": True,
            "allow_grouped_case_ids": []
        },
        "cross_scene_block": {
            "feature_points": ["交叉场景"],
            "scope": "global",
            "require_present": True,
            "require_tail": True,
            "cross_items": ["来电", "消息", "闹钟", "低电", "充电", "固件OTA", "查找设备", "手机断连", "模式切换", "音乐传输"]
        },
        "case_scale": {
            "required": True,
            "file": "用例设计蓝图.json",
            "profile_key": "complexity_profile"
        },
        "hierarchy_mapping": {
            "required": True,
            "file": "用例设计蓝图.json",
            "map_key": "hierarchy_map"
        },
        "execution_quality": {
            "required": True,
            "review_file": "工作底稿/人员执行质量复核.json",
            "blueprint_file": "用例设计蓝图.json",
            "order_map_key": "execution_order",
            "module_boundary_key": "module_boundary",
            "require_boundary_rules": True,
            "wording_fields": [
                "测试项", "测试点/检查项", "前置条件", "操作步骤", "预期结果", "备注"
            ],
            "forbidden_phrases": [
                "终态", "初态", "状态包", "批准口径", "能力显示", "流程不可达",
                "测试资产", "候选维度", "端侧", "本端", "对端", "串号", "半文件", "收尾确认态"
            ],
            "contextual_test_item_terms": [
                "APP端", "设备端", "Android", "iOS", "已连接", "未连接", "断连"
            ]
        },
        "test_item_exception_objects": True,
        "cross_scene": {
            "allowed_cross_items": [],
            "forbidden_cross_keywords": []
        },
        "common_fixtures": {
            "fixture_ids": [],
            "phrases": [],
            "max_repeat_ratio": 0.5
        },
        "functional_manual_contract": {
            "required": True,
            "execution_mode": "manual",
            "forbid_automation_details": True,
            "step_expected_one_to_one": True,
            "automation_conversion_artifact": "separate"
        },
        "navigation_expectations": [],
        "blueprint": {
            "required": True,
            "files": ["用例设计蓝图.json"],
            "required_keys": [
                "module_boundary", "feature_order", "execution_order", "page_state_anchors", "input_matrix",
                "exception_matrix", "cross_matrix", "common_fixtures", "case_precondition_rules",
                "unsupported_features", "complexity_profile", "hierarchy_map"
            ]
        },
        "ui_operation_order": {"enabled": True, "strict_coverage": True, "pages": []},
        "production_semantics": {
            "require_nonempty_core_fields": True,
            "check_manual_feasibility": True,
            "manual_max_actions_per_second": 4,
            "check_dependency_module_boundaries": True,
            "parameter_values": {
                "enabled": True,
                "require_explicit_value": True,
                "require_value_in_steps_and_expected": True,
                "actual_value_labels": []
            },
            "preconditions": {
                "require_nonempty": True,
                "fixture_ids": [],
                "placeholder_phrases": [
                    "具备测试条件", "满足测试条件", "前置条件满足", "测试环境正常",
                    "环境正常", "设备正常", "无特殊前置", "无需前置", "N/A", "无", "-"
                ]
            }
        },
        "conflict_matrix_policy": {
            "required": False,
            "required_when_cross_cases": True,
            "index_file": "冲突矩阵索引.json",
            "require_cartesian": False,
            "allowed_statuses": ["covered", "pending_confirmation", "rule_only", "not_applicable"],
            "covered_kinds": ["generated", "reused", "existing_case"],
            "require_reason_for": ["pending_confirmation", "rule_only", "not_applicable"],
            "forbid_case_id_for": ["pending_confirmation", "rule_only", "not_applicable"],
            "require_affected_module_for": ["covered", "pending_confirmation"],
            "require_target_case_id_for": ["covered"]
        },
        "scenario_coverage": {
            "required": True,
            "file": "场景覆盖矩阵.json",
            "expected_dimensions": [
                "入口与初始化", "主流程与业务规则", "边界与限制", "异常与负向",
                "中断与恢复", "交叉与冲突", "数据保存与一致性", "稳定性", "兼容性", "人工体验"
            ],
            "allow_pending": False,
            "accepted_pending_keys": []
        }
    }
}

RUNLOG_TEMPLATE = """# {name} 端到端运行记录

> 测试工作流 v2 主控（test-workflow-orchestrator）。逐阶段记录,两个门禁结论必须留痕。

| 阶段 | 状态 | 产物 | 备注 |
|---|---|---|---|
| 1 提需求/输入 | ☐ | 来源: | |
| 2-3 蓝湖拆解→PRD | ☐ | {name}_PRD需求解析.md | |
| 4 PRD审查【门禁A】 | ☐ | PRD审查报告.md | Blocker= |
| 5 识别产品形态 | ☐ | 形态: | |
| 6 第一版用例 | ☐ | {name}_全功能测试用例.xlsx | |
| 7-8 用例审查+完善 | ☐ | | |
| 多 Agent 全量评审【门禁D】 | ☐ | 工作底稿/多轮测试用例评审.json | 双对抗Agent+双回归Agent=；最后两轮连续无Blocker/Major= |
| 9 覆盖度审查【门禁B】 | ☐ | {name}_需求覆盖追溯表.xlsx | PRD追溯覆盖率=；部分覆盖=；该结论不代表全功能完整 |
| 9-loop 补强循环 | ☐ | 补充用例/ | 轮次= |
| 场景完整度【门禁C/S34】 | ☐ | 场景覆盖矩阵.json | 适用维度缺口= |
| 人员执行质量 | ☐ | 工作底稿/人员执行质量检查报告.json | 措辞/归类/顺序/功能边界= |
| 最终Excel实物验收 | ☐ | | 语义/样式/ZIP完整性= |
| 产物就绪 | ☐ | | 外部发送仅在用户明确指定渠道与收件人时执行 |
"""

BLUEPRINT_TEMPLATE = {
    "module_boundary": {
        "<模块名>": {
            "scope": "<说明当前模块负责验证的用户能力和最终结果>",
            "owned_outcome_keywords": ["<当前模块主要结果关键词>"],
            "foreign_feature_keywords": ["<其他功能名称；仅可作为前置或冲突条件>"],
        }
    },
    "feature_order": {},
    "execution_order": {
        "<模块名>": {
            "<功能点>": ["<入口或页面测试项>", "<正常流程测试项>", "<异常恢复测试项>"]
        }
    },
    "page_state_anchors": {},
    "input_matrix": {},
    "exception_matrix": [],
    "cross_matrix": [],
    "common_fixtures": {
        "测试环境说明": "<公共版本、样机和账号只在项目测试环境说明维护一次，不写入每条人工用例>"
    },
    "case_precondition_rules": [
        "功能测试用例按正常人工执行设计，只写测试人员可直接建立的具体业务状态",
        "禁止写内部环境别名、fixture ID、脚本、Mock、注入、定位器或其他自动化实现条件",
        "每个操作步骤必须有且仅有一个同编号预期结果，自动化操作用例另行转换和交付"
    ],
    "unsupported_features": [],
    "complexity_profile": {
        "<模块名>": {
            "rationale": "<说明需求复杂度如何形成当前用例集合；不得填写目标条数或条数区间>",
            "main_flows": ["<真实用户主流程>"],
            "states_and_modes": ["<状态或模式分支>"],
            "rules_and_boundaries": ["<业务规则及其具体边界>"],
            "exceptions_and_recovery": ["<异常、中断与恢复链路>"],
            "cross_scenarios": ["<真实可触发交叉对象；不适用时改为status/reason对象>"],
            "data_and_sync": ["<保存、同步或数据归属；不适用时改为status/reason对象>"],
            "compatibility": ["<平台、设备或版本适用范围>"],
            "no_fixed_target": True
        }
    },
    "hierarchy_map": {
        "<模块名>": {
            "<功能点>": {
                "<测试项>": {"intent_keywords": ["<测试点及预期必须命中的业务意图词>"]}
            }
        }
    },
    "continuous_block_exceptions": [],
    "platform_scope": [],
    "main_risks": [],
    "generation_state": "pre_generation"
}

CONFLICT_INDEX_TEMPLATE = {
    "schema_version": 1,
    "note": "生成前按真实触发关系逐格填写；无规则使用pending_confirmation/rule_only/not_applicable，不得猜测。",
    "items": []
}

SCENARIO_MATRIX_TEMPLATE = {
    "schema_version": 1,
    "note": "每个执行模块和适用维度填写covered/not_applicable/pending_confirmation；空格视为缺口。",
    "items": []
}

FEEDBACK_PATTERN_TEMPLATE = {
    "schema_version": 1,
    "input_xlsx_sha256": "<由 feedback_pattern_gate.py 校验当前最终Excel哈希>",
    "patterns": []
}

EXECUTION_QUALITY_REVIEW_TEMPLATE = {
    "schema_version": 1,
    "input_xlsx_sha256": "<当前最终Excel SHA-256>",
    "status": "PENDING",
    "reviewer": "<复核人>",
    "dimensions": {
        "wording": {"status": "PENDING", "reviewed_case_count": 0, "evidence": "", "findings": []},
        "classification": {"status": "PENDING", "reviewed_case_count": 0, "evidence": "", "findings": []},
        "order": {"status": "PENDING", "reviewed_feature_point_count": 0, "evidence": "", "findings": []},
        "feature_boundary": {"status": "PENDING", "reviewed_case_count": 0, "evidence": "", "findings": []},
    },
    "accepted_automatic_findings": [],
    "note": "四项全表复核完成并与当前最终Excel哈希绑定后才能改为PASS。",
}

MULTI_ROUND_REVIEW_TEMPLATE = {
    "schema_version": 2,
    "input_xlsx_sha256": "<当前最终Excel SHA-256>",
    "prd_sha256": "<当前PRD SHA-256>",
    "case_ids_sha256": "<当前Excel用例编号有序摘要>",
    "case_count": 0,
    "generator_agent_ids": ["<生成Agent ID>"],
    "reviser_agent_ids": ["<修订Agent ID>"],
    "review_control": {
        "execution_mode": "manual",
        "scope_lock": {
            "status": "pending",
            "prd_scope": "",
            "blueprint": "",
            "input_xlsx_sha256": "<当前最终Excel SHA-256>",
            "evidence": ""
        },
        "revision_batch_count": 0
    },
    "required_review_types": [
        "coverage_design", "execution_detail", "adversarial", "regression"
    ],
    "rounds": [],
    "consecutive_clean_rounds": 0,
    "remaining_findings": [],
    "visual_inspection": {
        "status": "pending",
        "input_xlsx_sha256": "<当前最终Excel SHA-256>",
        "checked_items": [],
        "evidence": ""
    },
    "final_status": "PENDING",
    "note": "按测试用例多轮评审规范填写；最终adversarial与regression各由两个隔离上下文的独立Agent完成，原始报告写入工作底稿/agent_reviews。"
}

CHANGED_CASE_IDS_TEMPLATE = {
    "schema_version": 1,
    "source_build_id": "<本轮源变更构建ID>",
    "case_ids": []
}

DECISION_LEDGER_TEMPLATE = {
    "schema_version": 1,
    "note": "每个req_id只能有一条当前决策；历史决策必须用superseded_by指向同req_id的当前decision_id。",
    "items": []
}


def main() -> None:
    ap = argparse.ArgumentParser(description="新建端到端项目工作区骨架")
    ap.add_argument("--name", required=True, help="项目名")
    ap.add_argument("--prd", help="PRD 路径（写入 config 模板，相对项目目录）")
    ap.add_argument("--cases", help="用例 xlsx 路径（写入 config 模板，相对项目目录）")
    ap.add_argument(
        "--workspace-root",
        help="项目工作区根目录；省略时兼容写入 workflow-v2/projects",
    )
    ap.add_argument(
        "--execution-mode", choices=("auto", "core", "strict"), default="strict",
        help="执行档位；省略时保持旧 strict 脚手架兼容，新减负入口显式传 auto",
    )
    ap.add_argument(
        "--work-unit", action="append", default=[],
        help="独立功能工作单，可重复传入；两个及以上时启用并行工作单合同",
    )
    ap.add_argument("--risk", action="append", default=[], help="风险标记，可重复传入")
    ap.add_argument(
        "--capability-pack", action="append", default=[],
        help="显式启用能力包，可重复传入",
    )
    ap.add_argument("--platform", action="append", default=[], help="适用平台，可重复传入")
    ap.add_argument("--force", action="store_true", help="覆盖已存在的 config/运行记录")
    args = ap.parse_args()

    proj = resolve_project(args.name, workspace_root=args.workspace_root)
    config_was_present = (proj / "trace.config.json").exists()
    if config_was_present and not args.force and not (proj / "执行画像.json").exists():
        raise SystemExit(
            "检测到缺少执行画像的历史项目；为保持严格兼容，本命令不会自动补写 core 画像。"
            "如需迁移，请显式使用 --force --execution-mode strict 并先备份。"
        )
    work_units = [validate_component(unit, label="work-unit") for unit in args.work_unit] \
        if args.work_unit else [validate_component(args.name, label="project")]
    profile = build_profile(
        requested_mode=args.execution_mode,
        work_units=work_units,
        risk_flags=args.risk,
        capability_packs=args.capability_pack,
        platform_scope=args.platform,
    )
    subdirs = ["工作底稿", "工作底稿/agent_reviews", "结果", "补充用例", "workunits"]
    subdirs.extend(f"workunits/{unit}" for unit in profile["work_units"])
    for sub in subdirs:
        (proj / sub).mkdir(parents=True, exist_ok=True)

    # config 模板
    cfg = apply_profile_to_config(CONFIG_TEMPLATE, profile)
    cfg["project"] = args.name
    if args.prd:
        cfg["prd_path"] = args.prd
    if args.cases:
        cfg["cases_xlsx"] = args.cases
    cfg["release_acceptance"]["delivery_artifact"]["path"] = cfg["cases_xlsx"]
    cfg["workspace"] = {
        "project_dir": ".",
        "workunits_dir": "workunits",
        "work_units": list(profile["work_units"]),
        "work_unit_contract_file": CONTRACT_FILENAME,
        "work_unit_contracts_required": profile["parallel_generation"],
        "external": args.workspace_root is not None,
    }
    cfg_path = proj / "trace.config.json"
    if cfg_path.exists() and not args.force:
        print(f"  已存在,跳过(用 --force 覆盖): {cfg_path}")
    else:
        cfg_path.write_text(json.dumps(cfg, ensure_ascii=False, indent=2), encoding="utf-8")
        print(f"  写入 {cfg_path}")

    profile_path = proj / "执行画像.json"
    if profile_path.exists() and not args.force:
        print(f"  已存在,跳过(用 --force 覆盖): {profile_path}")
    else:
        write_profile(proj, profile)
        print(f"  写入 {profile_path}")

    blueprint = copy.deepcopy(BLUEPRINT_TEMPLATE)
    if profile["base_path"] == "core":
        allowed_blueprint_keys = set(required_blueprint_keys(profile)) | {
            "continuous_block_exceptions", "generation_state",
        }
        blueprint = {
            key: value for key, value in blueprint.items() if key in allowed_blueprint_keys
        }
        blueprint["platform_scope"] = list(profile.get("platform_scope", []))

    artifacts = {
        "用例设计蓝图.json": blueprint,
        "冲突矩阵索引.json": CONFLICT_INDEX_TEMPLATE,
        "场景覆盖矩阵.json": SCENARIO_MATRIX_TEMPLATE,
        "工作底稿/人员执行质量复核.json": EXECUTION_QUALITY_REVIEW_TEMPLATE,
        "工作底稿/反馈模式账本.json": FEEDBACK_PATTERN_TEMPLATE,
        "工作底稿/最近变更用例ID.json": CHANGED_CASE_IDS_TEMPLATE,
    }
    if cfg["release_acceptance"]["pilot_required"]:
        artifacts["生成验收合同.json"] = GENERATION_CONTRACT_TEMPLATE
    if profile["base_path"] == "strict":
        artifacts["工作底稿/多轮测试用例评审.json"] = MULTI_ROUND_REVIEW_TEMPLATE
        artifacts["工作底稿/需求决策账本.json"] = DECISION_LEDGER_TEMPLATE
    elif has_pack(profile, "peer_review"):
        artifacts["工作底稿/同行评审.json"] = {
            "schema_version": 1,
            "input_xlsx_sha256": "<当前最终Excel SHA-256>",
            "review_assignments": [],
            "findings": [],
            "status": "PENDING",
        }
    for unit in profile["work_units"]:
        artifacts[f"workunits/{unit}/{CONTRACT_FILENAME}"] = build_contract(args.name, unit)

    for filename, payload in artifacts.items():
        path = proj / filename
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists() and not args.force:
            print(f"  已存在,跳过(用 --force 覆盖): {path}")
        else:
            path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
            print(f"  写入 {path}")

    # 运行记录
    log_path = proj / "运行记录.md"
    if log_path.exists() and not args.force:
        print(f"  已存在,跳过(用 --force 覆盖): {log_path}")
    else:
        log_path.write_text(RUNLOG_TEMPLATE.format(name=args.name), encoding="utf-8")
        print(f"  写入 {log_path}")

    print(f"\n项目工作区就绪: {proj}")
    print(f"执行画像: {profile['base_path']} | 能力包={profile['capability_packs']}")
    print("下一步: 检查执行画像.json，再按已启用能力包填写蓝图和 trace.config.json。")


if __name__ == "__main__":
    main()
