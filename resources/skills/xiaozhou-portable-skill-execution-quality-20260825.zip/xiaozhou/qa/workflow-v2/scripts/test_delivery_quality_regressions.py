# -*- coding: utf-8 -*-
"""Regression coverage for complexity-driven scope and compact Excel delivery."""
from __future__ import annotations

import copy
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side


SCRIPTS = Path(__file__).resolve().parent
if str(SCRIPTS) not in sys.path:
    sys.path.insert(0, str(SCRIPTS))

import delivery_quality  # noqa: E402


HEADERS = [
    "用例编号", "功能点", "测试项", "测试点", "前置条件",
    "操作步骤", "预期结果", "实际结果", "优先级", "备注",
]


def rows() -> list[list[str]]:
    return [
        ["FW_001", "音乐首页", "页面展示", "验证音乐首页显示入口", "1.当前未播放歌曲", "1.进入音乐首页", "1.页面显示播放入口", "", "P0", ""],
        ["FW_002", "音乐首页", "入口跳转", "验证点击本地歌曲进入列表", "1.手表内已有本地歌曲", "1.点击本地歌曲", "1.页面进入本地歌曲列表", "", "P0", ""],
        ["JT_001", "交叉场景", "来电", "验证播放中来电结束后恢复播放", "1.本地歌曲正在播放", "1.向手表发起来电", "1.来电结束后本地歌曲恢复播放", "", "P0", ""],
        ["JT_002", "交叉场景", "消息", "验证播放中消息不影响音乐", "1.本地歌曲正在播放", "1.向手表发送消息", "1.本地歌曲持续播放", "", "P1", ""],
    ]


def write_workbook(path: Path, data: list[list[str]] | None = None, sheet_name: str = "全功能测试用例") -> None:
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = sheet_name
    sheet.append(HEADERS)
    for item in data or rows():
        sheet.append(item)
    side = Side(style="thin", color="000000")
    border = Border(left=side, right=side, top=side, bottom=side)
    for physical_row in sheet.iter_rows():
        for cell in physical_row:
            cell.font = Font(name="等线", size=10, bold=cell.row == 1, color="FFFFFF" if cell.row == 1 else "000000")
            cell.border = border
            cell.alignment = Alignment(vertical="center", wrap_text=True)
            if cell.row == 1:
                cell.fill = PatternFill("solid", fgColor="1F4E78")
    sheet.merge_cells("B2:B3")
    sheet.merge_cells("B4:B5")
    workbook.save(path)


def blueprint() -> dict:
    profile = {
        "rationale": "按主流程、模式状态、规则边界、异常恢复、交叉对象、数据链路和兼容范围逐项展开，条数为覆盖结果。",
        "main_flows": ["入口到列表", "播放与返回"],
        "states_and_modes": ["未播放", "播放中"],
        "rules_and_boundaries": ["入口显示规则", "播放恢复规则"],
        "exceptions_and_recovery": ["来电结束恢复"],
        "cross_scenarios": ["来电", "消息"],
        "data_and_sync": {"status": "not_applicable", "reason": "本次样例不含数据传输"},
        "compatibility": ["当前目标固件"],
    }
    return {
        "complexity_profile": {"本地音乐": profile},
        "hierarchy_map": {
            "本地音乐": {
                "音乐首页": {
                    "页面展示": {"intent_keywords": ["显示", "入口"]},
                    "入口跳转": {"intent_keywords": ["进入", "列表"]},
                    "异常测试": {"intent_keywords": ["空态"]},
                },
                "交叉场景": {
                    "来电": {"intent_keywords": ["来电", "恢复播放"]},
                    "消息": {"intent_keywords": ["消息", "持续播放"]},
                },
            }
        },
    }


def quality() -> dict:
    return {
        "delivery_workbook": {
            "single_sheet": True,
            "sheet_name": "全功能测试用例",
            "headers": HEADERS,
            "implicit_module": "本地音乐",
            "font_name": "等线",
            "font_size": 10,
            "require_black_borders": True,
            "merge_hierarchy": ["功能点", "测试项"],
            "expected_version": "v1.6",
            "version_scan_fields": ["前置条件", "备注"],
            "require_empty_actual_result": True,
        },
        "test_item_taxonomy": {"forbidden_generic_items": ["边界测试", "规则确认"]},
        "case_granularity": {"forbid_grouped_scenarios": True, "detect_exact_duplicates": True},
        "cross_scene_block": {"feature_points": ["交叉场景"], "scope": "global", "require_tail": True},
        "case_scale": {"required": True, "file": "用例设计蓝图.json"},
        "hierarchy_mapping": {"required": True, "file": "用例设计蓝图.json"},
        "manual_case_style": {
            "enabled": True,
            "manual_only": True,
            "precondition_action_prefixes": ["点击", "输入", "扫描", "切换", "进入", "重启", "断电", "确认"],
            "observation_step_prefixes": ["查看", "核对", "观察", "询问测试人员"],
            "regression_item_keywords": ["回归"],
            "forbidden_step_phrases": ["基线终点", "观察至批准的有限终点", "对照基线查看结果"],
            "forbidden_expected_phrases": ["结果与基线一致", "与权限基线一致", "与并发基线一致"],
            "baseline_source_keywords": ["上一正式版", "人工执行说明", "产品批准"],
            "baseline_locator_keywords": ["版本号", "构建号", "记录编号", "记录位置", "人工执行说明"],
            "comparison_object_keywords": ["页面", "提示", "按钮", "绑定状态", "设备状态", "数据"],
            "require_explicit_comparison": True,
            "allow_case_ids": [],
        },
    }


def run_gate(config: Path) -> tuple[int, str]:
    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    process = subprocess.run(
        [sys.executable, str(SCRIPTS / "check_structure.py"), "--config", str(config)],
        cwd=SCRIPTS.parent,
        env=env,
        text=True,
        capture_output=True,
        encoding="utf-8",
        errors="replace",
    )
    return process.returncode, (process.stdout + process.stderr).strip()


def main() -> None:
    errors: list[str] = []
    results: list[dict] = []

    def check(name: str, passed: bool, details: object = None) -> None:
        results.append({"name": name, "passed": passed, "details": details})
        if not passed:
            errors.append(f"{name}: {details}")

    with tempfile.TemporaryDirectory(prefix="qa-delivery-quality-") as temp_dir:
        temp = Path(temp_dir)
        good = temp / "本地音乐_v1.6_全功能测试用例.xlsx"
        write_workbook(good)
        (temp / "用例设计蓝图.json").write_text(json.dumps(blueprint(), ensure_ascii=False, indent=2), encoding="utf-8")
        config = {
            "project": "本地音乐",
            "prd_path": "unused.md",
            "cases_xlsx": good.name,
            "modules": [{"name": "本地音乐", "prefix": "FW", "prd_sections": []}],
            "quality_gates": quality(),
        }
        config_path = temp / "trace.config.json"
        config_path.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")

        loaded = delivery_quality.read_case_rows(good, quality()["delivery_workbook"], "本地音乐")
        check("compact_rows_map_test_point_and_implicit_module", loaded[0]["测试点/检查项"].startswith("验证") and loaded[0]["功能模块"] == "本地音乐", loaded[0])

        good_violations = delivery_quality.check_quality(loaded, quality(), good)
        check("complexity_driven_compact_delivery_passes", not good_violations, good_violations)
        code, output = run_gate(config_path)
        check("check_structure_integrates_compact_delivery", code == 0, output)

        custom_sheet_path = temp / "本地音乐_v1.6_自定义总表.xlsx"
        write_workbook(custom_sheet_path, sheet_name="本地音乐用例")
        custom_config = copy.deepcopy(config)
        custom_config["cases_xlsx"] = custom_sheet_path.name
        custom_config["quality_gates"]["delivery_workbook"]["sheet_name"] = "本地音乐用例"
        custom_config_path = temp / "custom.config.json"
        custom_config_path.write_text(json.dumps(custom_config, ensure_ascii=False, indent=2), encoding="utf-8")
        code, output = run_gate(custom_config_path)
        check("custom_single_master_sheet_is_supported", code == 0, output)

        auxiliary_path = temp / "本地音乐_v1.6_含辅助表.xlsx"
        write_workbook(auxiliary_path)
        workbook = load_workbook(auxiliary_path)
        workbook.create_sheet("执行基线与说明")["A1"] = "执行前填写"
        workbook.save(auxiliary_path)
        auxiliary_config = copy.deepcopy(config)
        auxiliary_config["cases_xlsx"] = auxiliary_path.name
        auxiliary_config["quality_gates"]["delivery_workbook"]["allowed_auxiliary_sheets"] = ["执行基线与说明"]
        auxiliary_config["quality_gates"]["delivery_workbook"]["required_auxiliary_sheets"] = ["执行基线与说明"]
        auxiliary_config_path = temp / "auxiliary.config.json"
        auxiliary_config_path.write_text(json.dumps(auxiliary_config, ensure_ascii=False, indent=2), encoding="utf-8")
        code, output = run_gate(auxiliary_config_path)
        check("declared_auxiliary_sheet_is_supported", code == 0, output)

        unlisted_auxiliary_config = copy.deepcopy(auxiliary_config)
        unlisted_auxiliary_config["quality_gates"]["delivery_workbook"]["allowed_auxiliary_sheets"] = []
        unlisted_auxiliary_config["quality_gates"]["delivery_workbook"]["required_auxiliary_sheets"] = []
        unlisted_auxiliary_path = temp / "unlisted-auxiliary.config.json"
        unlisted_auxiliary_path.write_text(json.dumps(unlisted_auxiliary_config, ensure_ascii=False, indent=2), encoding="utf-8")
        code, output = run_gate(unlisted_auxiliary_path)
        check("unlisted_auxiliary_sheet_is_rejected", code != 0 and "未授权" in output, output)

        missing_auxiliary_config = copy.deepcopy(config)
        missing_auxiliary_config["quality_gates"]["delivery_workbook"]["required_auxiliary_sheets"] = ["执行基线与说明"]
        missing_auxiliary_path = temp / "missing-auxiliary.config.json"
        missing_auxiliary_path.write_text(json.dumps(missing_auxiliary_config, ensure_ascii=False, indent=2), encoding="utf-8")
        code, output = run_gate(missing_auxiliary_path)
        check("required_auxiliary_sheet_must_exist", code != 0 and "缺少" in output, output)

        generic = copy.deepcopy(loaded)
        generic[0]["测试项"] = "边界测试"
        violations = delivery_quality.check_test_item_taxonomy(generic, quality()["test_item_taxonomy"])
        check("generic_boundary_item_is_rejected", any("S23" in value for value in violations), violations)
        generic[0]["测试项"] = "规则确认"
        violations = delivery_quality.check_test_item_taxonomy(generic, quality()["test_item_taxonomy"])
        check("generic_rule_confirmation_is_rejected", any("S23" in value for value in violations), violations)
        generic[0]["测试项"] = "异常测试"
        violations = delivery_quality.check_test_item_taxonomy(generic, quality()["test_item_taxonomy"])
        check("exception_test_item_remains_valid", not violations, violations)

        wrong_hierarchy = copy.deepcopy(loaded)
        wrong_hierarchy[0]["测试项"] = "界面操作"
        violations = delivery_quality.check_hierarchy_mapping(wrong_hierarchy, quality()["hierarchy_mapping"], good)
        check("test_item_must_belong_to_feature_point", any("测试项归属错误" in value for value in violations), violations)
        wrong_hierarchy = copy.deepcopy(loaded)
        wrong_hierarchy[0]["测试点/检查项"] = "验证歌曲切换"
        wrong_hierarchy[0]["预期结果"] = "1.播放下一首歌曲"
        violations = delivery_quality.check_hierarchy_mapping(wrong_hierarchy, quality()["hierarchy_mapping"], good)
        check("test_point_must_match_test_item_intent", any("测试点意图错位" in value for value in violations), violations)
        valid_exception = copy.deepcopy(loaded)
        valid_exception[0]["测试项"] = "异常测试"
        valid_exception[0]["测试点/检查项"] = "验证无歌曲时显示空态"
        valid_exception[0]["预期结果"] = "1.页面显示空态"
        violations = delivery_quality.check_hierarchy_mapping(valid_exception, quality()["hierarchy_mapping"], good)
        check("mapped_exception_test_item_is_allowed", not violations, violations)

        grouped = copy.deepcopy(loaded)
        grouped[0]["前置条件"] = "按以下数据组分别执行：\nA.无歌曲\nB.有歌曲"
        violations = delivery_quality.check_case_granularity(grouped, quality()["case_granularity"])
        check("independent_scenarios_cannot_be_grouped", any("过度合并" in value for value in violations), violations)
        grouped[0]["前置条件"] = "1.分别准备播放中、暂停及无记录三种状态"
        grouped[0]["测试点/检查项"] = "验证各播放状态下的恢复"
        violations = delivery_quality.check_case_granularity(grouped, quality()["case_granularity"])
        check("state_variants_cannot_be_hidden_in_one_case", any("过度合并" in value for value in violations), violations)
        grouped[0]["前置条件"] = "1.使用设备A执行播放"
        grouped[0]["测试点/检查项"] = loaded[0]["测试点/检查项"]
        violations = delivery_quality.check_case_granularity(grouped, quality()["case_granularity"])
        check("single_device_a_label_is_not_a_group", not any("过度合并" in value for value in violations), violations)

        duplicate = copy.deepcopy(loaded)
        repeated = copy.deepcopy(duplicate[0])
        repeated["用例编号"] = "FW_099"
        duplicate.append(repeated)
        violations = delivery_quality.check_case_granularity(duplicate, quality()["case_granularity"])
        check("equivalent_intent_cannot_be_split_for_count", any("重复拆分" in value for value in violations), violations)
        duplicate[-1]["前置条件"] = "1.手表内没有本地歌曲"
        duplicate[-1]["预期结果"] = "1.页面显示空态"
        violations = delivery_quality.check_case_granularity(duplicate, quality()["case_granularity"])
        check("same_title_with_different_state_and_result_is_allowed", not any("重复拆分" in value for value in violations), violations)

        normal_manual = copy.deepcopy(loaded[:1])
        violations = delivery_quality.check_manual_case_style(normal_manual, quality()["manual_case_style"])
        check("normal_manual_case_is_not_forced_to_have_more_steps", not violations, violations)

        regression = copy.deepcopy(loaded[:1])
        regression[0].update({
            "用例编号": "REG_001",
            "测试项": "版本回归",
            "测试点/检查项": "验证过期二维码处理与上一正式版一致",
            "前置条件": "1.人工执行说明已记录上一正式版版本号及扫描同一过期二维码后的页面、提示和绑定状态",
            "操作步骤": "1.扫描过期二维码",
            "预期结果": "1.APP页面、提示、绑定状态和设备状态与上一正式版记录一致",
        })
        violations = delivery_quality.check_manual_case_style(regression, quality()["manual_case_style"])
        check("explicit_manual_regression_comparison_passes", not violations, violations)

        vague_step = copy.deepcopy(regression)
        vague_step[0]["操作步骤"] = "1.扫描过期二维码至基线终点"
        violations = delivery_quality.check_manual_case_style(vague_step, quality()["manual_case_style"])
        check("vague_regression_step_endpoint_is_rejected", any("S35 回归步骤终点模糊" in value for value in violations), violations)

        vague_expected = copy.deepcopy(regression)
        vague_expected[0]["预期结果"] = "1.结果与基线一致"
        violations = delivery_quality.check_manual_case_style(vague_expected, quality()["manual_case_style"])
        check("vague_regression_expected_is_rejected", any("S35 回归预期不可判定" in value for value in violations), violations)

        missing_source = copy.deepcopy(regression)
        missing_source[0]["前置条件"] = "1.设备处于可绑定状态"
        missing_source[0]["预期结果"] = "1.APP页面显示二维码过期提示，设备保持未绑定状态"
        violations = delivery_quality.check_manual_case_style(missing_source, quality()["manual_case_style"])
        check("regression_comparison_source_is_required", any("S35 回归比较来源缺失" in value for value in violations), violations)

        shared_source = copy.deepcopy(regression)
        shared_source[0]["前置条件"] = "1.已记录上一正式版扫描同一过期二维码后的页面、提示和绑定状态"
        shared_cfg = copy.deepcopy(quality()["manual_case_style"])
        shared_cfg["shared_baseline_reference"] = "人工执行说明：上一正式版本 App版本/构建号、基线场景人工记录"
        violations = delivery_quality.check_manual_case_style(shared_source, shared_cfg)
        check("declared_shared_baseline_reference_keeps_cases_concise", not violations, violations)

        missing_object = copy.deepcopy(regression)
        missing_object[0]["预期结果"] = "1.行为与上一正式版记录一致"
        violations = delivery_quality.check_manual_case_style(missing_object, quality()["manual_case_style"])
        check("regression_comparison_object_is_required", any("S35 回归比较对象缺失" in value for value in violations), violations)

        redundant_observation = copy.deepcopy(normal_manual)
        redundant_observation[0]["操作步骤"] = "1.点击本地歌曲\n2.查看结果"
        violations = delivery_quality.check_manual_case_style(redundant_observation, quality()["manual_case_style"])
        check("observation_is_not_invented_as_a_second_action", any("S35 冗余观察步骤" in value for value in violations), violations)

        action_in_precondition = copy.deepcopy(normal_manual)
        action_in_precondition[0]["前置条件"] = "1.点击设置项并确认弹窗显示"
        violations = delivery_quality.check_manual_case_style(action_in_precondition, quality()["manual_case_style"])
        check("precondition_cannot_contain_execution_action", any("S35 前置混入操作" in value for value in violations), violations)

        appended_page_observation = copy.deepcopy(normal_manual)
        appended_page_observation[0]["操作步骤"] = "1.点击本地歌曲\n2.查看页面"
        violations = delivery_quality.check_manual_case_style(appended_page_observation, quality()["manual_case_style"])
        check("page_observation_after_trigger_is_rejected", any("S35 冗余观察步骤" in value for value in violations), violations)

        single_vague_observation = copy.deepcopy(normal_manual)
        single_vague_observation[0]["测试项"] = "播放操作"
        single_vague_observation[0]["操作步骤"] = "1.查看结果"
        violations = delivery_quality.check_manual_case_style(single_vague_observation, quality()["manual_case_style"])
        check("single_vague_observation_is_rejected", any("S35 冗余观察步骤" in value for value in violations), violations)

        display_only = copy.deepcopy(normal_manual)
        display_only[0]["测试项"] = "页面展示"
        display_only[0]["操作步骤"] = "1.查看音乐首页"
        violations = delivery_quality.check_manual_case_style(display_only, quality()["manual_case_style"])
        check("single_display_only_view_is_allowed", not violations, violations)

        generic_regression_result = copy.deepcopy(regression)
        generic_regression_result[0]["前置条件"] = "1.已记录上一正式版的扫描表现"
        generic_regression_result[0]["预期结果"] = "1.结果与上一正式版记录一致"
        violations = delivery_quality.check_manual_case_style(generic_regression_result, quality()["manual_case_style"])
        check(
            "generic_previous_version_result_is_rejected",
            any("S35 回归比较来源缺失" in value for value in violations)
            and any("S35 回归比较对象缺失" in value for value in violations),
            violations,
        )

        split_cross = copy.deepcopy(loaded)
        split_cross.insert(3, copy.deepcopy(split_cross[0]))
        split_cross[3]["用例编号"] = "FW_003"
        violations = delivery_quality.check_cross_block(split_cross, quality()["cross_scene_block"])
        check("cross_scenarios_must_be_one_contiguous_block", any("区块分散" in value for value in violations), violations)
        cross_not_tail = copy.deepcopy(loaded)
        cross_not_tail.append(cross_not_tail.pop(0))
        violations = delivery_quality.check_cross_block(cross_not_tail, quality()["cross_scene_block"])
        check("cross_scenario_block_must_follow_main_flow", any("位置错误" in value for value in violations), violations)
        missing_cross = copy.deepcopy(loaded[:2])
        cross_cfg = {**quality()["cross_scene_block"], "require_present": True}
        violations = delivery_quality.check_cross_block(missing_cross, cross_cfg)
        check("declared_cross_scenario_block_must_exist", any("区块缺失" in value for value in violations), violations)

        quota_payload = blueprint()
        quota_payload["complexity_profile"]["本地音乐"]["target_count"] = "200-250条"
        (temp / "用例设计蓝图.json").write_text(json.dumps(quota_payload, ensure_ascii=False, indent=2), encoding="utf-8")
        violations = delivery_quality.check_case_scale(loaded, quality()["case_scale"], good)
        check("numeric_case_quota_is_rejected", any("固定条数配额" in value for value in violations), violations)
        quota_payload = blueprint()
        quota_payload["compression_policy"] = {"rationale": "建议约200-250条作为可读性目标"}
        (temp / "用例设计蓝图.json").write_text(json.dumps(quota_payload, ensure_ascii=False, indent=2), encoding="utf-8")
        violations = delivery_quality.check_case_scale(loaded, quality()["case_scale"], good)
        check("quota_hidden_in_rationale_is_rejected", any("固定条数配额" in value for value in violations), violations)
        boundary_payload = blueprint()
        boundary_payload["complexity_profile"]["本地音乐"]["rules_and_boundaries"] = ["列表最多显示99条歌曲"]
        (temp / "用例设计蓝图.json").write_text(json.dumps(boundary_payload, ensure_ascii=False, indent=2), encoding="utf-8")
        violations = delivery_quality.check_case_scale(loaded, quality()["case_scale"], good)
        check("business_boundary_is_not_mistaken_for_case_quota", not any("固定条数配额" in value for value in violations), violations)
        incomplete_payload = blueprint()
        del incomplete_payload["complexity_profile"]["本地音乐"]["cross_scenarios"]
        incomplete_payload["complexity_profile"]["本地音乐"]["data_and_sync"] = {"status": "not_applicable", "reason": ""}
        (temp / "用例设计蓝图.json").write_text(json.dumps(incomplete_payload, ensure_ascii=False, indent=2), encoding="utf-8")
        violations = delivery_quality.check_case_scale(loaded, quality()["case_scale"], good)
        check("missing_complexity_evidence_and_empty_na_reason_are_rejected", any("复杂度维度无证据" in value for value in violations), violations)
        (temp / "用例设计蓝图.json").write_text(json.dumps(blueprint(), ensure_ascii=False, indent=2), encoding="utf-8")

        actual_result = copy.deepcopy(rows())
        actual_result[0][7] = "PASS"
        actual_path = temp / "本地音乐_v1.6_实际结果非空.xlsx"
        write_workbook(actual_path, actual_result)
        violations = delivery_quality.check_delivery_workbook(actual_path, quality()["delivery_workbook"])
        check("new_execution_workbook_requires_empty_actual_result", any("实际结果非空" in value for value in violations), violations)

        old_version = copy.deepcopy(rows())
        old_version[0][-1] = "沿用v1.5活动用例"
        old_path = temp / "本地音乐_v1.6_旧版本残留.xlsx"
        write_workbook(old_path, old_version)
        violations = delivery_quality.check_delivery_workbook(old_path, quality()["delivery_workbook"])
        check("legacy_active_version_is_rejected", any("旧版本残留" in value for value in violations), violations)
        mixed_name = temp / "本地音乐_v1.5_v1.6_版本混杂.xlsx"
        write_workbook(mixed_name)
        violations = delivery_quality.check_delivery_workbook(mixed_name, quality()["delivery_workbook"])
        check("delivery_filename_cannot_mix_versions", any("文件名旧版本残留" in value for value in violations), violations)

        bad_style = temp / "本地音乐_v1.6_版式错误.xlsx"
        write_workbook(bad_style)
        workbook = load_workbook(bad_style)
        sheet = workbook["全功能测试用例"]
        sheet["J2"].border = Border()
        sheet.unmerge_cells("B2:B3")
        sheet["B3"] = "音乐首页"
        workbook.save(bad_style)
        violations = delivery_quality.check_delivery_workbook(bad_style, quality()["delivery_workbook"])
        check(
            "missing_black_border_and_hierarchy_merge_are_rejected",
            any("黑色边框缺失" in value for value in violations) and any("相同层级文本未合并" in value for value in violations),
            violations,
        )

    print(json.dumps({"success": not errors, "results": results, "errors": errors}, ensure_ascii=False, indent=2))
    raise SystemExit(0 if not errors else 1)


if __name__ == "__main__":
    main()
