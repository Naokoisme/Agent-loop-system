# -*- coding: utf-8 -*-
"""Production semantic gates shared by workflow-v2.

These gates cover quality failures that a structural workbook check cannot
infer reliably from row counts or PRD traceability alone:

- functional testcases remain a manual-execution artifact, separate from
  automation-operation testcases;
- S29 concrete testcase language;
- S30 concrete, human-establishable preconditions;
- S31 realistic manual execution;
- S32 dependency-module and affected-business ownership boundaries;
- S33 explicit conflict-matrix disposition and ownership;
- S34 the non-PRD scenario-completeness axis.
"""
from __future__ import annotations

import json
import re
from collections import Counter
from pathlib import Path
from typing import Any


CROSS_FEATURE_POINTS = {"交叉场景", "冲突场景", "多任务冲突", "异常场景"}
DEFAULT_SCENARIO_DIMENSIONS = [
    "入口与初始化",
    "主流程与业务规则",
    "边界与限制",
    "异常与负向",
    "中断与恢复",
    "交叉与冲突",
    "数据保存与一致性",
    "稳定性",
    "兼容性",
    "人工体验",
]

VAGUE_TEST_POINT_RULES = (
    ("使用‘处理’代替具体结果", re.compile(r"(?:后的处理|后处理|处理(?:明确|正确|正常|结果|状态)|(?:结果|状态)处理)")),
    ("使用笼统状态结论", re.compile(r"状态(?:一致|正确|可判定|正常|明确)")),
    ("使用笼统结果结论", re.compile(r"结果(?:一致|正确|可判定|正常|明确)")),
    ("使用笼统响应结论", re.compile(r"(?:响应|表现|行为|逻辑|情况|效果)(?:一致|正确|可判定|正常|明确)")),
    ("使用按规则类占位结论", re.compile(r"(?:按|依照)[^，。；\n]{0,12}规则")),
    ("使用符合预期类占位结论", re.compile(r"符合\s*(?:预期|PRD|需求)")),
    ("使用目标动作占位结论", re.compile(r"按目标动作")),
)

DEFAULT_PARAMETER_ACTIONS = (
    "设置", "设为", "选择", "选中", "调整", "调至", "输入", "配置", "切换", "修改",
)
DEFAULT_PARAMETER_NAMES = (
    "参数", "数值", "取值", "档位", "时长", "亮度", "音量", "频率", "阈值", "比例",
    "温度", "速度", "距离", "次数", "数量", "长度", "间隔", "强度", "时间", "语言", "模式",
)
DIRECT_PARAMETER_ABSTRACTION_RE = re.compile(
    r"(?:最低档(?:位)?|中间档(?:位)?|中档(?:位)?|最高档(?:位)?|低中高档(?:位)?|阈值(?:前|点|后))"
)
ABSTRACT_PARAMETER_TERM_PATTERN = r"(?:随便|任意|任选|任一|随机(?!播放)|某个|某一)"
ABSTRACT_PARAMETER_VALUE_RE = re.compile(
    r"(?:随便|任意|任选|任一|随机(?!播放)|某个|某一)(?:值|取值|档位?)?"
    r"|(?:最低|最小|中间|最高|最大|默认)(?:值|档位?)"
)
PARAMETER_NOUN_CONTEXT_RE = re.compile(r"设置(?:页面|界面|入口|项|列表|菜单|中)")
PENDING_PARAMETER_RE = re.compile(r"待(?:产品)?确认")
NUMERIC_PARAMETER_VALUE_RE = re.compile(
    r"^(-?\d+(?:\.\d+)?\s*(?:%|‰|ms|s|min|h|毫秒|秒|分钟|小时|档|级|Hz|kHz|℃|°C|次|个|米|厘米|毫米|公里|KB|MB|GB)?)",
    re.IGNORECASE,
)
QUOTED_PARAMETER_VALUE_RE = re.compile(r'^[“\"\']([^”\"\']+)[”\"\']')

STEP_EXPECTED_PLACEHOLDER_RULES = (
    ("目标业务", re.compile(r"目标业务")),
    ("入口状态", re.compile(r"入口状态")),
    ("按目标动作结束", re.compile(r"按目标动作结束")),
    ("按目标动作", re.compile(r"按目标动作")),
    ("状态可判定", re.compile(r"状态可判定")),
    ("明确结果", re.compile(r"明确结果")),
    ("查看执行状态", re.compile(r"查看[^\n。；]{0,30}执行状态")),
    ("原业务状态", re.compile(r"原[^\n。；]{0,20}业务状态")),
    ("记录表现", re.compile(r"记录[^\n。；]{0,20}表现")),
    ("所设测试状态已建立", re.compile(r"所设测试状态已建立")),
    ("观察设备当前状态", re.compile(r"观察设备当前状态")),
    ("目标状态可被观察", re.compile(r"目标状态可被观察")),
    ("查看本步骤执行结果", re.compile(r"查看本步骤执行结果")),
    ("检查对象给出明确结果", re.compile(r"检查对象给出明确结果")),
    ("本步骤执行完成", re.compile(r"本步骤执行完成")),
    ("测试工具确认已完成动作", re.compile(r"测试工具确认已完成动作")),
    ("执行测试点对应操作", re.compile(r"执行测试点对应操作")),
    ("完成对应检查", re.compile(r"完成对应检查")),
    ("继续观察当前页面", re.compile(r"继续观察当前页面")),
)

DEFAULT_PRECONDITION_PLACEHOLDERS = [
    "具备测试条件",
    "满足测试条件",
    "前置条件满足",
    "测试环境正常",
    "环境正常",
    "环境已准备",
    "准备完成",
    "设备正常",
    "无特殊前置",
    "无需前置",
    "所设测试状态已建立",
    "目标状态已建立",
    "N/A",
    "NA",
    "无",
    "-",
]

NUMBERED_LINE_RE = re.compile(r"^\s*\d+[\.\)）、．]\s*")
NUMBERED_LINE_CAPTURE_RE = re.compile(r"^\s*(\d+)[\.\)）、．]\s*(.+?)\s*$")
NUMBERING_TOKEN_RE = re.compile(
    r"(?:^|(?<=[\s；;。]))(\d+)[\.\)）、．](?!\d)\s*(?=\S)"
)
FIXTURE_REF_RE = re.compile(r"(?:引用公共前置|公共前置|fixture)\s*[:：]?\s*([A-Za-z0-9_-]+)", re.I)
MANUAL_AUTO_VALUE = "否"
MANUAL_WAY_VALUE = "人工执行"
FUNCTIONAL_CASE_CONTENT_FIELDS = (
    "功能模块", "功能点", "测试项", "测试点/检查项", "前置条件", "操作步骤", "预期结果",
    "优先级", "兼容性", "是否自动化", "固件版本", "硬件型号", "测试方式", "备注",
)
AUTOMATION_IMPLEMENTATION_RULES = (
    ("内部评审或执行合同代号", re.compile(
        r"(?<![A-Za-z0-9])(?:APP|DEVICE|QR|SEARCH|SCAN|COMM|NETWORK|SERVER|BASELINE|CANDIDATE|"
        r"TEXT|ANDROID|IOS|POST|BOUND|NAME|ACCOUNT|INTERRUPT|IME|VERIFY|UI|TOAST)_[A-Za-z0-9_]+(?![A-Za-z0-9])|"
        r"(?<![A-Za-z0-9])T_[A-Za-z0-9_]+(?![A-Za-z0-9])|(?<![A-Za-z0-9])(?:NEW|OLD)_FW(?![A-Za-z0-9])|"
        r"(?:状态|页面|结果|设备端|App|APP)?锚点|(?:前置|参数|方法|时点|流程|版本|证据)已登记|"
        r"执行基线|平台登记|登记的(?:动作|方法|时点|结果|状态)|延迟观察区间|判定时点"
    )),
    ("内部只读查询或检查器", re.compile(
        r"TEXT_INSPECTOR|(?:按|通过|使用)[^\n。；]{0,24}(?:内部|本地)?(?:记录|数据)(?:查询|读取)|"
        r"查询\s*App\s*(?:内|端)[^\n。；]{0,24}(?:记录|数据)|文本检查器|"
        r"(?:码点|不可见字符)[^\n。；]{0,20}检查器",
        re.I,
    )),
    ("录像逐帧或证据链", re.compile(
        r"逐帧|连续录像|录像[^\n。；]{0,20}(?:起点|终点|时点|区间|无缺帧)|"
        r"证据编号|不可变证据|SHA-?256",
        re.I,
    )),
    ("通信或网络内部记录", re.compile(
        r"(?:清空|采集|导出|检查|比对|查看)[^\n。；]{0,16}(?:通信|通讯|网络)(?:记录|证据)|"
        r"(?:通信|通讯|网络)(?:记录|证据)[^\n。；]{0,16}(?:清空|采集|导出|检查|比对|查看)"
    )),
    ("内部环境或fixture标识", re.compile(
        r"BASE_ENV|引用公共前置|公共前置\s*[:：]|"
        r"(?<![A-Za-z0-9])fixture(?:[_-][A-Za-z0-9_-]+)?(?![A-Za-z0-9])",
        re.I,
    )),
    ("自动化脚本或框架", re.compile(
        r"自动化(?:脚本|消息脚本|事件注入|框架|环境|账号)|测试脚本|数据分析脚本|"
        r"Python(?:脚本|代码)?运行环境|脚本运行环境|代码运行环境|"
        r"\b(?:Appium|Selenium|Playwright|pytest|WebDriver|UiAutomator|Airtest|Poco|Robot Framework)\b",
        re.I,
    )),
    ("定位器或自动化命令", re.compile(
        r"\b(?:xpath|css selector|locator|resource-id|accessibility id|adb(?:\s+shell)?)\b",
        re.I,
    )),
    ("Mock或Stub", re.compile(r"\b(?:mock|stub)\b|协议Mock", re.I)),
    ("注入式执行", re.compile(r"注入(?:工具|器|数据|事件|消息|协议|接口|代码|距离|热量|轨迹|字段|报文|帧)?|(?:协议|接口|代码|事件|消息|数据|故障)注入")),
    ("日志或抓包判定", re.compile(
        r"(?:运行|调试|协议|接口|系统|固件|设备|串口|通信|通讯|脚本|自动化|测试|采集|崩溃|错误|报错|APP)日志|"
        r"日志(?:采集|抓取|解析|分析|比对|校验|检查)|抓包",
        re.I,
    )),
    ("专用自动执行设备", re.compile(
        r"协议注入工具|协议工具|时间模拟工具|弱网工具|自动化工具|专用工具|治具|机械臂|继电器|"
        r"程控(?:电源)?|功耗仪|波形采集|高速采集|数据采集脚本|产测工具|量产工具|测试服务|隐私扫描"
    )),
    ("服务端或数据库实现", re.compile(r"服务端|服务器|数据库")),
    ("固件内部能力标志", re.compile(r"固件标志位|能力标志(?:位)?")),
    ("设备内部缓存或存储", re.compile(r"设备本地|设备内存|本地缓存|缓存数据")),
    ("App内部本地记录", re.compile(
        r"(?:App\s*)?本地[^\n。；]{0,32}(?:记录|缓存|存储项|数据项)"
    )),
    ("生成器内部数据行", re.compile(
        r"\b(?:DECISION_ROW|ORTHOGONAL_ROW)\b|数据行定义|数据集\s*ID|"
        r"(?:判定表|正交(?:试验|实验)?)(?:数据行|数据集)\s*[:：]\s*[A-Za-z0-9_-]+",
        re.I,
    )),
    ("非人工测试数据准备", re.compile(
        r"(?:构造|导入|模拟)[^\n。；]{0,16}(?:测试)?数据|注入",
        re.I,
    )),
    ("自动化层术语", re.compile(r"自动化(?:操作|执行|用例|准备|前置|条件|转换|实现|校验|验证)", re.I)),
    ("底层协议或接口判定", re.compile(
        r"协议字段|协议指令|报文|寄存器|下发指令|"
        r"(?:收到|接收|发送|下发)[^\n。；]{0,12}(?:协议)?指令|"
        r"(?:协议)?指令[^\n。；]{0,12}(?:收到|接收|发送|下发)|"
        r"(?:读取|检查|校验|下发|返回|比对|解析)[^\n。；]{0,16}(?:协议|接口)|"
        r"(?:协议|接口)[^\n。；]{0,16}(?:字段|值|正确|一致|已发送|已接收|已写入|已上报|已下发)",
        re.I,
    )),
)
HIDDEN_EXPECTED_RESULT_RULES = (
    ("服务端或数据库内部状态", re.compile(
        r"(?:"
        r"(?:服务端|服务器|数据库)[^\n。；]{0,24}(?:写入|落库|保存|删除|收到|接收|上传|同步)|"
        r"(?:写入|落库|保存|删除|上传|同步)[^\n。；]{0,12}(?:到|至|进|入)?(?:服务端|服务器|数据库)"
        r")(?:成功|完成|正确|一致|失败|异常|无)?"
    )),
    ("设备内部存储状态", re.compile(
        r"(?:"
        r"(?:设备本地|设备内存|本地缓存)[^\n。；]{0,24}(?:新增|覆盖|保存|清除|删除|写入|更新)|"
        r"(?:新增|覆盖|保存|清除|删除|写入|更新)[^\n。；]{0,12}(?:到|至|进|入)?(?:设备本地|设备内存|本地缓存)"
        r")(?:成功|完成|正确|一致|失败|异常|无)?"
    )),
    ("密钥或令牌内部状态", re.compile(
        r"(?:密钥|令牌|token)[^\n。；]{0,16}(?:清除|删除|更新|写入|正确|一致)", re.I
    )),
    ("抽象状态机结论", re.compile(r"状态机(?:正常|正确|一致|完成|符合)")),
    ("协议内部结论", re.compile(
        r"(?:协议|报文|寄存器|指令)[^\n。；]{0,20}(?:正确|一致|已发送|已接收|已下发|已上报|完成)|"
        r"(?:收到|接收|发送|下发)[^\n。；]{0,12}(?:协议)?指令",
        re.I,
    )),
)
TIME_REPEAT_PATTERNS = (
    re.compile(
        r"(?P<time>\d+(?:\.\d+)?)\s*(?P<unit>毫秒|ms|秒|s)(?:内|以内)?"
        r"[^。；\n]{0,30}?(?P<count>\d+)\s*次",
        re.I,
    ),
    re.compile(
        r"(?P<count>\d+)\s*次[^。；\n]{0,30}?(?:在)?"
        r"(?P<time>\d+(?:\.\d+)?)\s*(?P<unit>毫秒|ms|秒|s)(?:内|以内)?(?:完成)?",
        re.I,
    ),
)
INTERVAL_REPEAT_RE = re.compile(
    r"(?P<count>\d+)\s*次[^。；\n]{0,40}?(?:间隔|周期|每隔)\s*"
    r"(?P<time>\d+(?:\.\d+)?)\s*(?P<unit>毫秒|ms|秒|s)",
    re.I,
)
LEADING_INTERVAL_REPEAT_RE = re.compile(
    r"(?:以)?\s*(?P<time>\d+(?:\.\d+)?)\s*(?P<unit>毫秒|ms|秒|s)\s*(?:的)?(?:间隔|周期)"
    r"[^。；\n]{0,40}?(?P<count>\d+)\s*次",
    re.I,
)
RATE_REPEAT_PATTERNS = (
    re.compile(r"(?P<rate>\d+(?:\.\d+)?)\s*次\s*(?:/|每)\s*(?P<unit>秒|分钟)", re.I),
    re.compile(r"每\s*(?P<unit>秒|分钟)\s*(?P<rate>\d+(?:\.\d+)?)\s*次", re.I),
)
HEAVY_PHYSICAL_ACTION_RE = re.compile(r"插拔|取放|开合|拔插")
STRICT_CONCURRENCY_RE = re.compile(r"严格同时|同一毫秒|毫秒级同步|误差(?:不超过|小于|≤)\s*\d+\s*(?:ms|毫秒)", re.I)
TOOL_KEYWORDS = ["治具", "机械臂", "继电器", "自动化脚本", "测试脚本", "程控", "专用工具", "高速采集"]

DEFAULT_DEPENDENCY_MODULE_RULES = [
    {
        "module_regex": r"(?:蓝牙.*(?:绑定|连接)|(?:绑定|配对).*蓝牙)",
        "forbid_feature_points": ["交叉场景", "冲突场景", "多任务冲突"],
        "business_state_keywords": [
            "录音中", "录像中", "音乐播放中", "本地音乐", "OTA传输中", "OTA升级中",
            "文件传输中", "通话中", "来电中", "AI对话中", "AI翻译中",
        ],
        "dependency_action_keywords": ["解绑", "断连", "关闭蓝牙", "忽略设备"],
        "max_cross_cases": 0,
    }
]


def _as_list(value: Any) -> list:
    if value is None:
        return []
    return value if isinstance(value, list) else [value]


def _production_cfg(quality_gates: dict) -> dict | None:
    value = (quality_gates or {}).get("production_semantics")
    if not value:
        return None
    return value if isinstance(value, dict) else {}


def _row_text(row: dict, fields: tuple[str, ...] | None = None) -> str:
    fields = fields or (
        "功能模块", "功能点", "测试项", "测试点/检查项", "前置条件", "操作步骤", "预期结果", "备注",
    )
    return " ".join(str(row.get(field, "") or "") for field in fields)


def is_manual_case(row: dict) -> bool:
    """Return whether a row declares a human-executed testcase."""
    way = str(row.get("测试方式", "") or "").strip().lower()
    auto = str(row.get("是否自动化", "") or "").strip().lower()
    # Legacy rows still need S30/S31 manual-feasibility checks even though the
    # functional-artifact contract below accepts only the canonical values.
    return auto in {"否", "no", "false", "n", "0"} or any(
        keyword in way for keyword in ("手工", "人工", "manual", "实机", "目视")
    )


def check_functional_manual_contract(rows: list[dict]) -> list[str]:
    """Hard contract for functional testcase artifacts.

    Functional cases describe normal human execution only. Automation-specific
    setup belongs to a separate conversion artifact and cannot be embedded in
    the functional workbook, even when a project configuration omits a gate.
    """
    violations: list[str] = []
    for row in rows:
        cid = str(row.get("用例编号", "") or "<无编号>")
        auto = str(row.get("是否自动化", "") or "").strip()
        way = str(row.get("测试方式", "") or "").strip()
        if auto != MANUAL_AUTO_VALUE:
            violations.append(
                f"[FMC1 功能用例非人工执行] {cid} 是否自动化必须精确为‘{MANUAL_AUTO_VALUE}’，"
                "自动化操作用例须另行转换和交付"
            )
        if way != MANUAL_WAY_VALUE:
            violations.append(
                f"[FMC1 功能用例执行方式不纯] {cid} 测试方式必须精确为‘{MANUAL_WAY_VALUE}’，"
                f"不得混入脚本、日志、Mock、注入或工具链: {way or '<空>'}"
            )
        text = _row_text(row, FUNCTIONAL_CASE_CONTENT_FIELDS)
        leak = find_automation_implementation_leak(text)
        if leak:
            label, matched = leak
            violations.append(
                f"[FMC2 功能用例混入自动化实现细节] {cid} 命中{label}: {matched}"
            )
        expected = str(row.get("预期结果", "") or "")
        for label, pattern in HIDDEN_EXPECTED_RESULT_RULES:
            match = pattern.search(expected)
            if match:
                violations.append(
                    f"[FMC3 人工预期不可观察] {cid} 命中{label}: {match.group(0)}；"
                    "需改写为APP页面、设备灯光/振动、照片、开关机或另一实机可复核结果"
                )
                break
    return violations


def find_automation_implementation_leak(text: object) -> tuple[str, str] | None:
    """Return the first automation-only implementation detail in arbitrary text."""
    value = str(text or "")
    for label, pattern in AUTOMATION_IMPLEMENTATION_RULES:
        match = pattern.search(value)
        if match:
            return label, match.group(0)
    return None


def _numbered_contract(text: str) -> tuple[list[int], list[str]]:
    numbers: list[int] = []
    unnumbered: list[str] = []
    normalized = str(text or "").replace("\r\n", "\n").replace("\r", "\n")
    for raw in normalized.split("\n"):
        line = raw.strip()
        if not line:
            continue
        match = NUMBERED_LINE_CAPTURE_RE.match(line)
        if not match or not match.group(2).strip():
            unnumbered.append(line)
            continue
        # One physical line is one numbered action/result. Embedded "2...."
        # must not masquerade as a newline-separated second item.
        if NUMBERING_TOKEN_RE.search(match.group(2)):
            unnumbered.append(line)
            continue
        numbers.append(int(match.group(1)))
    return numbers, unnumbered


def check_step_expected_contract(rows: list[dict]) -> list[str]:
    """Hard 1:1 contract: every numbered manual action owns one same-number result."""
    violations: list[str] = []
    for row in rows:
        cid = str(row.get("用例编号", "") or "<无编号>")
        steps = str(row.get("操作步骤", "") or "")
        expected = str(row.get("预期结果", "") or "")
        step_numbers, step_unnumbered = _numbered_contract(steps)
        expected_numbers, expected_unnumbered = _numbered_contract(expected)
        if not step_numbers or step_unnumbered:
            violations.append(f"[S8 步骤未逐项编号] {cid} 每个人工操作步骤必须单独编号")
            continue
        if not expected_numbers or expected_unnumbered:
            violations.append(f"[S8 预期未逐项编号] {cid} 每个操作步骤必须有同编号预期结果")
            continue
        sequential = list(range(1, len(step_numbers) + 1))
        if step_numbers != sequential:
            violations.append(f"[S8 步骤编号不连续] {cid} 步骤编号{step_numbers}，必须从1连续编号")
        if expected_numbers != step_numbers:
            violations.append(
                f"[S8 步骤预期非一一对应] {cid} 步骤编号{step_numbers} / 预期编号{expected_numbers}"
            )
    return violations


def _time_to_seconds(value: str, unit: str) -> float:
    number = float(value)
    return number / 1000.0 if unit.lower() in {"ms", "毫秒"} else number


def _parameter_value_cfg(production_cfg: dict) -> dict | None:
    value = production_cfg.get("parameter_values")
    if value is None or value is False:
        return None
    cfg = value if isinstance(value, dict) else {}
    return cfg if cfg.get("enabled", True) else None


def _parameter_terms(parameter_cfg: dict, key: str, defaults: tuple[str, ...]) -> list[str]:
    raw = parameter_cfg.get(key, defaults)
    items = list(raw) if isinstance(raw, (list, tuple, set)) else _as_list(raw)
    values = [str(item).strip() for item in items if str(item).strip()]
    return sorted(set(values), key=len, reverse=True)


def _parameter_operation_context(test_point: str, parameter_cfg: dict) -> tuple[bool, str, str]:
    actions = _parameter_terms(parameter_cfg, "actions", DEFAULT_PARAMETER_ACTIONS)
    names = _parameter_terms(parameter_cfg, "parameter_names", DEFAULT_PARAMETER_NAMES)
    if not actions or not names:
        return False, "", ""
    action_pattern = "|".join(re.escape(value) for value in actions)
    name_pattern = "|".join(re.escape(value) for value in names)
    text = PARAMETER_NOUN_CONTEXT_RE.sub("", test_point)
    pattern = re.compile(
        rf"(?:(?:{action_pattern}).{{0,18}}(?:{name_pattern})|"
        rf"(?:{name_pattern}).{{0,18}}(?:{action_pattern}))"
    )
    return bool(pattern.search(text)), action_pattern, name_pattern


def _configured_parameter_value(test_point: str, parameter_cfg: dict) -> str | None:
    labels = sorted(
        {str(item).strip() for item in _as_list(parameter_cfg.get("actual_value_labels")) if str(item).strip()},
        key=len,
        reverse=True,
    )
    for label in labels:
        if re.search(rf"(?:为|至|到|成|:|：)\s*{re.escape(label)}(?:$|[，。；、\s])", test_point):
            return label
    return None


def _abstract_parameter_description(
    test_point: str, parameter_cfg: dict, action_pattern: str, name_pattern: str
) -> str | None:
    configured_value = _configured_parameter_value(test_point, parameter_cfg)
    configured_labels = {
        str(item).strip() for item in _as_list(parameter_cfg.get("actual_value_labels")) if str(item).strip()
    }
    for match in DIRECT_PARAMETER_ABSTRACTION_RE.finditer(test_point):
        if match.group(0) not in configured_labels:
            return match.group(0)
    if not action_pattern or not name_pattern:
        return None

    text = PARAMETER_NOUN_CONTEXT_RE.sub("", test_point)
    contextual_rules = (
        re.compile(rf"{ABSTRACT_PARAMETER_TERM_PATTERN}(?:地)?\s*(?:{action_pattern})"),
        re.compile(
            rf"(?:{action_pattern}).{{0,10}}{ABSTRACT_PARAMETER_TERM_PATTERN}.{{0,10}}(?:{name_pattern})"
        ),
        re.compile(
            rf"(?:{action_pattern}).{{0,18}}(?:{name_pattern}).{{0,8}}(?:为|至|到|成|:|：)\s*"
            rf"({ABSTRACT_PARAMETER_VALUE_RE.pattern})"
        ),
        re.compile(
            rf"(?:{name_pattern}).{{0,12}}(?:{action_pattern}).{{0,8}}(?:为|至|到|成|:|：)\s*"
            rf"({ABSTRACT_PARAMETER_VALUE_RE.pattern})"
        ),
    )
    for pattern in contextual_rules:
        match = pattern.search(text)
        if not match:
            continue
        matched_value = match.group(1) if match.lastindex else match.group(0)
        if configured_value and configured_value in match.group(0):
            continue
        return matched_value
    return None


def _extract_parameter_value(test_point: str, parameter_cfg: dict) -> str | None:
    configured_value = _configured_parameter_value(test_point, parameter_cfg)
    if configured_value:
        return configured_value
    marker = re.search(r"(?:为|至|到|成|:|：)\s*(.+)$", test_point)
    if not marker:
        return None
    tail = marker.group(1).strip().rstrip("。；;，,")
    numeric = NUMERIC_PARAMETER_VALUE_RE.match(tail)
    if numeric:
        return re.sub(r"\s+", "", numeric.group(1))
    quoted = QUOTED_PARAMETER_VALUE_RE.match(tail)
    if quoted:
        return quoted.group(1).strip()
    if re.fullmatch(r"[A-Za-z][A-Za-z0-9_-]{0,30}", tail):
        return tail
    if re.fullmatch(r"[\u4e00-\u9fff]{1,12}", tail):
        return tail
    return None


def _field_contains_parameter_value(text: str, value: str) -> bool:
    normalized_text = re.sub(r"\s+", "", text).casefold()
    normalized_value = re.sub(r"\s+", "", value).casefold()
    if not normalized_value:
        return False
    if re.match(r"^-?\d", normalized_value):
        return bool(re.search(rf"(?<![\d.]){re.escape(normalized_value)}(?![\d.])", normalized_text))
    return normalized_value in normalized_text


def check_parameter_value_semantics(row: dict, production_cfg: dict) -> list[str]:
    """S29: parameter cases use concrete PRD values consistently in all executable fields."""
    parameter_cfg = _parameter_value_cfg(production_cfg)
    if parameter_cfg is None:
        return []
    cid = str(row.get("用例编号", "") or "<无编号>")
    excluded = {str(item) for item in _as_list(parameter_cfg.get("exclude_case_ids"))}
    if cid in excluded:
        return []
    test_point = str(row.get("测试点/检查项", "") or "").strip()
    if not test_point or PENDING_PARAMETER_RE.search(test_point):
        return []
    has_context, action_pattern, name_pattern = _parameter_operation_context(test_point, parameter_cfg)
    abstract = _abstract_parameter_description(test_point, parameter_cfg, action_pattern, name_pattern)
    if abstract:
        return [
            f"[S29 参数值描述抽象] {cid} 测试点命中‘{abstract}’，必须改为PRD/真实产品的具体值"
        ]
    if not has_context:
        return []
    value = _extract_parameter_value(test_point, parameter_cfg)
    if parameter_cfg.get("require_explicit_value", True) and not value:
        return [
            f"[S29 参数实际值缺失] {cid} 必须使用‘验证设置<参数名>为<具体值>’，不得用档位类别代替"
        ]
    if not value or not parameter_cfg.get("require_value_in_steps_and_expected", True):
        return []
    violations: list[str] = []
    for field in ("操作步骤", "预期结果"):
        text = str(row.get(field, "") or "")
        if not _field_contains_parameter_value(text, value):
            violations.append(
                f"[S29 参数值未贯穿] {cid} 测试点具体值‘{value}’未写入{field}"
            )
    return violations


def check_row_semantics(rows: list[dict], quality_gates: dict) -> list[str]:
    """S29: reject vague testcase intent and generator filler in final rows."""
    cfg = _production_cfg(quality_gates)
    if cfg is None:
        return []
    violations: list[str] = []
    tp_exclude = {str(x) for x in _as_list(cfg.get("test_point_exclude_ids"))}
    detail_exclude = {str(x) for x in _as_list(cfg.get("step_expected_exclude_ids"))}
    require_core = bool(cfg.get("require_nonempty_core_fields", True))

    for row in rows:
        cid = str(row.get("用例编号", ""))
        tp = str(row.get("测试点/检查项", "") or "").strip()
        if require_core and not tp:
            violations.append(f"[S29 测试点为空] {cid} 测试点/检查项必须写明可判定验证意图")
        elif cid not in tp_exclude:
            for label, pattern in VAGUE_TEST_POINT_RULES:
                if pattern.search(tp):
                    violations.append(f"[S29 测试点描述模糊] {cid} {label}: {tp}")
                    break
            violations.extend(check_parameter_value_semantics(row, cfg))

        if cid in detail_exclude:
            continue
        for field in ("操作步骤", "预期结果"):
            text = str(row.get(field, "") or "").strip()
            if require_core and not text:
                violations.append(f"[S29 {field}为空] {cid} {field}必须可执行且可观察")
                continue
            for label, pattern in STEP_EXPECTED_PLACEHOLDER_RULES:
                if pattern.search(text):
                    violations.append(f"[S29 {field}模板占位] {cid} 命中‘{label}’")
                    break
    return violations


def check_precondition_semantics(rows: list[dict], quality_gates: dict) -> list[str]:
    """S30: every executable row needs a concrete, human-establishable state."""
    cfg = _production_cfg(quality_gates)
    if cfg is None:
        return []
    pcfg = cfg.get("preconditions", {})
    if pcfg is False:
        return []
    pcfg = pcfg if isinstance(pcfg, dict) else {}
    if not pcfg.get("require_nonempty", True):
        return []
    placeholders = [str(x).strip().lower() for x in _as_list(
        pcfg.get("placeholder_phrases", DEFAULT_PRECONDITION_PLACEHOLDERS)
    ) if str(x).strip()]
    fixture_ids = {str(x) for x in _as_list(pcfg.get("fixture_ids")) if str(x)}
    fixture_ids.update(
        str(x) for x in _as_list(((quality_gates or {}).get("common_fixtures", {}) or {}).get("fixture_ids")) if str(x)
    )
    excluded = {str(x) for x in _as_list(pcfg.get("exclude_case_ids"))}
    extra_placeholders = [
        re.compile(str(x)) for x in _as_list(pcfg.get("placeholder_patterns", [
            r"目标(?:业务)?状态", r"当前状态可用", r"对应状态已建立", r"测试对象已准备",
        ])) if str(x)
    ]
    contradiction_groups = [
        [str(x) for x in _as_list(group) if str(x)]
        for group in _as_list(pcfg.get("contradiction_groups"))
        if isinstance(group, list)
    ]
    inversion_rules = [
        rule for rule in _as_list(pcfg.get("inversion_rules", [
            {"label": "开始录音前置已在录音", "action_keywords": ["开始录音", "发起录音"], "forbidden_precondition_keywords": ["正在录音", "录音中"]},
            {"label": "开始录像前置已在录像", "action_keywords": ["开始录像", "发起录像"], "forbidden_precondition_keywords": ["正在录像", "录像中"]},
            {"label": "发起OTA前置已在升级", "action_keywords": ["发起OTA", "开始OTA", "发起升级"], "forbidden_precondition_keywords": ["OTA中", "升级中"]},
            {"label": "连接热点前置已连接", "action_keywords": ["连接热点"], "forbidden_precondition_keywords": ["已连接热点"]},
            {"label": "插入充电线前置已在充电", "action_keywords": ["插入充电", "接入充电"], "forbidden_precondition_keywords": ["充电中", "正在充电"]},
            {"label": "执行恢复出厂前置已恢复", "action_keywords": ["恢复出厂"], "forbidden_precondition_keywords": ["已恢复出厂"]},
        ])) if isinstance(rule, dict)
    ]
    violations: list[str] = []

    for row in rows:
        cid = str(row.get("用例编号", ""))
        if cid in excluded:
            continue
        pre = str(row.get("前置条件", "") or "").strip()
        if not pre:
            violations.append(f"[S30 前置条件为空] {cid} 需写可由测试人员建立的具体业务状态")
            continue

        refs = FIXTURE_REF_RE.findall(pre)
        manual = is_manual_case(row)
        if manual and refs:
            violations.append(
                f"[S30 人工用例内部fixture泄漏] {cid} 人工功能用例不得引用fixture {refs}，"
                "需改为可人工准备的具体业务状态"
            )
        undefined = [ref for ref in refs if ref not in fixture_ids]
        if undefined:
            violations.append(f"[S30 公共fixture未声明] {cid} 引用了未在配置声明的fixture {undefined}")
            continue
        steps = str(row.get("操作步骤", "") or "")
        for rule in inversion_rules:
            actions = [str(x) for x in _as_list(rule.get("action_keywords")) if str(x)]
            forbidden = [str(x) for x in _as_list(rule.get("forbidden_precondition_keywords")) if str(x)]
            if any(action in steps for action in actions) and any(state in pre for state in forbidden):
                violations.append(
                    f"[S30 前置条件状态倒置] {cid} {rule.get('label','动作前置已是完成态')}: "
                    f"步骤命中{[x for x in actions if x in steps]}，前置命中{[x for x in forbidden if x in pre]}"
                )
                break
        for group in contradiction_groups:
            hit = [token for token in group if token in pre]
            if len(hit) >= 2:
                violations.append(f"[S30 前置条件互斥] {cid} 同时命中互斥状态 {hit}")
                break

        contents = []
        for line in pre.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
            content = NUMBERED_LINE_RE.sub("", line).strip()
            if content:
                contents.append(content)
        concrete = False
        for content in contents:
            low = content.lower().strip("。；; ")
            if FIXTURE_REF_RE.search(content):
                if not manual:
                    concrete = True
                continue
            if any(pattern.search(content) for pattern in extra_placeholders):
                continue
            if low in placeholders or any(low == phrase for phrase in placeholders):
                continue
            if len(content) >= 4:
                concrete = True
        if not concrete:
            violations.append(f"[S30 前置条件占位] {cid} 前置未说明可执行状态: {pre[:60]}")
    return violations


def check_manual_feasibility(rows: list[dict], quality_gates: dict) -> list[str]:
    """S31: manual cases cannot require unaided sub-second repetition/concurrency."""
    cfg = _production_cfg(quality_gates)
    if cfg is None or not cfg.get("check_manual_feasibility", True):
        return []
    violations: list[str] = []
    max_rate = float(cfg.get("manual_max_actions_per_second", 4.0))
    physical_max_rate = float(cfg.get("manual_physical_max_actions_per_second", 2.0))

    for row in rows:
        way = str(row.get("测试方式", "") or "").lower()
        auto = str(row.get("是否自动化", "") or "").lower()
        manual = is_manual_case(row)
        if not manual:
            continue
        text = _row_text(row, ("测试点/检查项", "前置条件", "操作步骤", "测试方式", "备注"))
        if any(keyword in text for keyword in TOOL_KEYWORDS):
            continue
        cid = str(row.get("用例编号", ""))

        hit = False
        for pattern in TIME_REPEAT_PATTERNS:
            match = pattern.search(text)
            if not match:
                continue
            segment = match.group(0)
            if "每次" in segment or any(word in segment for word in ("间隔", "每隔", "周期")):
                continue
            seconds = _time_to_seconds(match.group("time"), match.group("unit"))
            count = int(match.group("count"))
            if seconds > 0 and (count / seconds > max_rate or (seconds <= 1 and count >= 5)):
                violations.append(
                    f"[S31 手工步骤不可执行] {cid} 要求{seconds:g}秒内完成{count}次操作且未声明治具/自动化"
                )
                hit = True
                break
        if hit:
            continue

        interval = INTERVAL_REPEAT_RE.search(text) or LEADING_INTERVAL_REPEAT_RE.search(text)
        if interval:
            seconds = _time_to_seconds(interval.group("time"), interval.group("unit"))
            count = int(interval.group("count"))
            if seconds > 0 and count >= 5 and 1 / seconds > max_rate:
                violations.append(
                    f"[S31 手工步骤不可执行] {cid} 要求连续{count}次且间隔{seconds:g}秒，需改为治具/自动化或取消严格节拍"
                )
                continue
        for pattern in RATE_REPEAT_PATTERNS:
            rate_match = pattern.search(text)
            if not rate_match:
                continue
            rate = float(rate_match.group("rate"))
            if rate_match.group("unit") == "分钟":
                rate /= 60.0
            limit = physical_max_rate if HEAVY_PHYSICAL_ACTION_RE.search(text) else max_rate
            if rate > limit:
                violations.append(
                    f"[S31 手工频率不可执行] {cid} 要求每秒{rate:g}次操作，人工阈值为每秒{limit:g}次且未声明治具/自动化"
                )
                hit = True
                break
        if hit:
            continue
        if STRICT_CONCURRENCY_RE.search(text):
            violations.append(f"[S31 手工并发不可执行] {cid} 要求毫秒级严格并发但未声明治具/自动化")
    return violations


def check_dependency_module_boundaries(rows: list[dict], quality_gates: dict) -> list[str]:
    """S32: dependency modules cannot own the affected business' interruption cases."""
    cfg = _production_cfg(quality_gates)
    if cfg is None or not cfg.get("check_dependency_module_boundaries", True):
        return []
    raw_rules = cfg.get("dependency_module_rules", DEFAULT_DEPENDENCY_MODULE_RULES)
    rules = [rule for rule in _as_list(raw_rules) if isinstance(rule, dict)]
    violations: list[str] = []

    for rule in rules:
        module_re = re.compile(str(rule.get("module_regex", r"$^")))
        forbidden_fps = {str(x) for x in _as_list(rule.get("forbid_feature_points"))}
        state_keywords = [str(x) for x in _as_list(rule.get("business_state_keywords")) if str(x)]
        action_keywords = [str(x) for x in _as_list(rule.get("dependency_action_keywords")) if str(x)]
        allow_ids = {str(x) for x in _as_list(rule.get("allow_case_ids"))}
        maximum = int(rule.get("max_cross_cases", 0))
        matched = [row for row in rows if module_re.search(str(row.get("功能模块", "") or ""))]
        cross_rows = [row for row in matched if str(row.get("功能点", "") or "") in forbidden_fps]
        if len(cross_rows) > maximum:
            ids = [str(row.get("用例编号", "")) for row in cross_rows]
            violations.append(
                f"[S32 依赖模块伪交叉] 依赖模块交叉用例允许{maximum}条，实际{len(cross_rows)}条: {ids[:20]}"
            )
        for row in matched:
            cid = str(row.get("用例编号", ""))
            if cid in allow_ids:
                continue
            text = _row_text(row)
            states = [kw for kw in state_keywords if kw in text]
            actions = [kw for kw in action_keywords if kw in text]
            if states and actions:
                violations.append(
                    f"[S32 业务中断归属错误] {cid} 在依赖模块中组合{states[:2]}与{actions[:2]}，应归正在受影响的业务模块"
                )
    return violations


def check_production_semantics(rows: list[dict], quality_gates: dict) -> list[str]:
    violations: list[str] = []
    violations.extend(check_row_semantics(rows, quality_gates))
    violations.extend(check_precondition_semantics(rows, quality_gates))
    violations.extend(check_manual_feasibility(rows, quality_gates))
    violations.extend(check_dependency_module_boundaries(rows, quality_gates))
    return violations


def check_conflict_matrix(rows: list[dict], quality_gates: dict, xlsx: Path) -> list[str]:
    """S33: validate explicit matrix disposition, affected owner, reuse and pending policy."""
    cfg = (quality_gates or {}).get("conflict_matrix_policy")
    if not cfg:
        return []
    cfg = cfg if isinstance(cfg, dict) else {}
    legacy_allow_expected_owner = bool(cfg.get("legacy_allow_expected_owner_as_affected", False))
    cross_rows = [row for row in rows if str(row.get("功能点", "") or "") in CROSS_FEATURE_POINTS]
    required = bool(cfg.get("required", False)) or (bool(cfg.get("required_when_cross_cases", True)) and bool(cross_rows))
    path = Path(xlsx).parent / str(cfg.get("index_file", "冲突矩阵索引.json"))
    if not path.exists():
        return [f"[S33 冲突矩阵索引缺失] 存在交叉/冲突执行用例但未找到 {path.name}"] if required else []
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        return [f"[S33 冲突矩阵索引无法解析] {path.name}: {exc}"]
    items = payload.get("items") if isinstance(payload, dict) else None
    if not isinstance(items, list) or not items:
        return [f"[S33 冲突矩阵索引为空] {path.name} 需提供非空 items"]

    allowed_statuses = set(cfg.get("allowed_statuses", [
        "covered", "pending", "pending_confirmation", "rule_only", "not_applicable",
    ]))
    covered_kinds = set(cfg.get("covered_kinds", ["generated", "reused", "existing_case"]))
    reason_statuses = set(cfg.get("require_reason_for", [
        "pending", "pending_confirmation", "rule_only", "not_applicable",
    ]))
    no_case_statuses = set(cfg.get("forbid_case_id_for", [
        "pending", "pending_confirmation", "rule_only", "not_applicable",
    ]))
    owner_statuses = set(cfg.get("require_affected_module_for", ["covered", "pending", "pending_confirmation"]))
    target_statuses = set(cfg.get("require_target_case_id_for", ["covered"]))
    rows_by_id = {str(row.get("用例编号", "")): row for row in rows}
    modules = {str(row.get("功能模块", "")) for row in rows}
    violations: list[str] = []
    keys: list[str] = []
    actions: list[str] = []
    states: list[str] = []
    covered_by_case: dict[str, list[dict]] = {}

    for item in items:
        action = str(item.get("action", "") or "")
        state = str(item.get("state", "") or "")
        key = str(item.get("matrix_key", "") or "")
        keys.append(key)
        actions.append(action)
        states.append(state)
        if not action or not state or key != f"{action}|{state}":
            violations.append(f"[S33 冲突矩阵键异常] {key!r}, action={action!r}, state={state!r}")
    duplicates = sorted(key for key, count in Counter(keys).items() if count > 1)
    if duplicates:
        violations.append(f"[S33 冲突矩阵键重复] {duplicates[:20]}")

    require_cartesian = bool(cfg.get("require_cartesian", False) or payload.get("matrix_shape"))
    if require_cartesian:
        action_order = list(dict.fromkeys(actions))
        state_order = list(dict.fromkeys(states))
        expected = {f"{action}|{state}" for action in action_order for state in state_order}
        missing = sorted(expected - set(keys))
        if missing or len(items) != len(expected):
            violations.append(
                f"[S33 冲突矩阵不完整] actions={len(action_order)} states={len(state_order)} items={len(items)} missing={missing[:10]}"
            )

    for item in items:
        key = str(item.get("matrix_key", "") or "")
        status = str(item.get("status", "") or "")
        kind = str(item.get("coverage_kind", "") or "")
        case_id = str(item.get("case_id", "") or "")
        target_case_id = str(item.get("target_case_id", "") or "")
        affected = str(item.get("affected_module", "") or "")
        expected_owner = str(item.get("expected_owner", "") or "")
        if not affected and legacy_allow_expected_owner:
            affected = expected_owner
        reason = str(item.get("reason", "") or "").strip()
        if status not in allowed_statuses:
            violations.append(f"[S33 冲突矩阵状态非法] {key}->{status}")
            continue
        if not kind:
            violations.append(f"[S33 冲突矩阵缺coverage_kind] {key}")
        elif status == "covered" and kind not in covered_kinds:
            violations.append(f"[S33 已覆盖矩阵格类型非法] {key}->{kind}")
        elif status != "covered" and kind != status:
            violations.append(f"[S33 非执行矩阵格状态不一致] {key} status={status} kind={kind}")
        if status in reason_statuses and not reason:
            violations.append(f"[S33 非执行矩阵格缺原因] {key} status={status}")
        if status in no_case_statuses and (case_id or target_case_id):
            violations.append(f"[S33 非执行矩阵格错误引用用例] {key}")
        if status in owner_statuses:
            if not affected:
                violations.append(f"[S33 冲突矩阵缺受影响模块] {key} status={status}")
            elif affected not in modules:
                violations.append(f"[S33 受影响模块不存在] {key}->{affected}")
            if not expected_owner:
                violations.append(f"[S33 冲突矩阵缺expected_owner] {key} status={status}")
            elif affected and expected_owner != affected:
                violations.append(f"[S33 owner不是受影响业务] {key} expected_owner={expected_owner}, affected_module={affected}")
        if status in target_statuses and not target_case_id:
            violations.append(f"[S33 已覆盖矩阵格缺target_case_id] {key}")
        if status == "covered":
            covered_by_case.setdefault(case_id, []).append(item)
            row = rows_by_id.get(case_id)
            if not case_id or row is None:
                violations.append(f"[S33 已覆盖矩阵格无有效case_id] {key}->{case_id}")
                continue
            actual_owner = str(row.get("功能模块", "") or "")
            if affected and actual_owner != affected:
                violations.append(
                    f"[S33 冲突用例归属错误] {key}->{case_id}, 实际={actual_owner}, 受影响业务={affected}"
                )
            stable_matrix_key = str(row.get("_matrix_key", row.get("matrix_key", "")) or "")
            if kind == "generated" and cfg.get("require_case_matrix_key", False) and stable_matrix_key != key:
                violations.append(
                    f"[S33 生成矩阵格缺稳定映射] {key}->{case_id}, 用例matrix_key={stable_matrix_key!r}"
                )
            if kind in {"reused", "existing_case"} and target_case_id != case_id:
                violations.append(f"[S33 复用矩阵引用不一致] {key} target_case_id必须等于case_id")
            if target_case_id and target_case_id != case_id:
                violations.append(f"[S33 矩阵目标与最终引用不一致] {key} {target_case_id}!={case_id}")
    if cfg.get("forbid_unjustified_multi_cell_reuse", True):
        for case_id, refs in covered_by_case.items():
            if not case_id or len(refs) <= 1:
                continue
            keys_for_case = [str(item.get("matrix_key", "")) for item in refs]
            explicit = all(
                str(item.get("coverage_kind", "")) in {"reused", "existing_case"}
                and str(item.get("reason", "") or "").strip()
                for item in refs
            )
            if not explicit:
                violations.append(
                    f"[S33 单用例重复刷矩阵] {case_id} 被{len(refs)}个矩阵格引用{keys_for_case[:10]}，"
                    "多格复用必须标reused/existing_case并逐格写明等价依据"
                )
    return violations


def check_scenario_coverage(
    rows: list[dict], quality_gates: dict, xlsx: Path, config_modules: list[dict] | None = None
) -> list[str]:
    """S34: require a second, non-PRD completeness axis for full-function delivery."""
    cfg = (quality_gates or {}).get("scenario_coverage")
    if not cfg:
        return []
    cfg = cfg if isinstance(cfg, dict) else {}
    required = bool(cfg.get("required", True))
    path = Path(xlsx).parent / str(cfg.get("file", "场景覆盖矩阵.json"))
    if not path.exists():
        return [f"[S34 场景覆盖矩阵缺失] 未找到 {path.name}，PRD追溯率不能替代全功能场景完整度"] if required else []
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception as exc:  # noqa: BLE001
        return [f"[S34 场景覆盖矩阵无法解析] {path.name}: {exc}"]
    items = payload.get("items", payload.get("dimensions")) if isinstance(payload, dict) else None
    if not isinstance(items, list) or not items:
        return [f"[S34 场景覆盖矩阵为空] {path.name} 需逐模块列出适用维度"]

    row_modules = list(dict.fromkeys(str(row.get("功能模块", "") or "") for row in rows if str(row.get("功能模块", "") or "")))
    configured = [str(m.get("name", "")) for m in (config_modules or []) if str(m.get("name", ""))]
    modules = [m for m in configured if m in set(row_modules)] or row_modules
    dimensions = [str(x) for x in _as_list(cfg.get("expected_dimensions", DEFAULT_SCENARIO_DIMENSIONS)) if str(x)]
    allow_pending = bool(cfg.get("allow_pending", False))
    accepted_pending = {str(x) for x in _as_list(cfg.get("accepted_pending_keys"))}
    rows_by_id = {str(row.get("用例编号", "")): row for row in rows}
    allowed_statuses = {"covered", "not_applicable", "pending_confirmation", "missing", "uncovered"}
    seen: Counter[tuple[str, str]] = Counter()
    violations: list[str] = []

    for item in items:
        module = str(item.get("module", "") or "")
        dimension = str(item.get("dimension", "") or "")
        status = str(item.get("status", "") or "")
        key = f"{module}|{dimension}"
        seen[(module, dimension)] += 1
        if module not in modules:
            violations.append(f"[S34 场景矩阵模块异常] {key} 不在执行模块中")
        if dimension not in dimensions:
            violations.append(f"[S34 场景矩阵维度异常] {key} 不在预期维度中")
        if status not in allowed_statuses:
            violations.append(f"[S34 场景矩阵状态非法] {key}->{status}")
            continue
        case_ids = [str(x) for x in _as_list(item.get("case_ids", item.get("case_id"))) if str(x)]
        reason = str(item.get("reason", "") or "").strip()
        if status == "covered":
            if not case_ids:
                violations.append(f"[S34 场景维度无用例证据] {key} status=covered但未引用case_id")
            missing_ids = [case_id for case_id in case_ids if case_id not in rows_by_id]
            if missing_ids:
                violations.append(f"[S34 场景维度引用失效] {key} 缺少用例{missing_ids}")
            wrong_module = [
                case_id for case_id in case_ids
                if case_id in rows_by_id and str(rows_by_id[case_id].get("功能模块", "")) != module
            ]
            if wrong_module:
                violations.append(f"[S34 场景维度跨模块借证据] {key} 引用了其他模块用例{wrong_module}")
        elif status == "not_applicable":
            if not reason:
                violations.append(f"[S34 不适用维度缺原因] {key}")
        elif status == "pending_confirmation":
            if not reason:
                violations.append(f"[S34 待确认维度缺原因] {key}")
            if not allow_pending and key not in accepted_pending:
                violations.append(f"[S34 场景维度待确认未接受] {key}: {reason or '未说明'}")
        else:
            violations.append(f"[S34 场景维度存在缺口] {key} status={status}")

    for module in modules:
        for dimension in dimensions:
            count = seen[(module, dimension)]
            if count == 0:
                violations.append(f"[S34 场景矩阵缺格] {module}|{dimension}")
            elif count > 1:
                violations.append(f"[S34 场景矩阵重复格] {module}|{dimension} 出现{count}次")
    return violations
