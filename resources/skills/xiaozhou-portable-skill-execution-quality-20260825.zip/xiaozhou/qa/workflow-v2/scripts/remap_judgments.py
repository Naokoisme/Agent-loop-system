# -*- coding: utf-8 -*-
"""Remap judgment case IDs by stable identity, never by testcase title text.

Before reordering, snapshot ``工作底稿`` as ``工作底稿_old``. Both snapshots
must expose one of ``stable_id / _stable_id / matrix_key / _matrix_key`` for each
case. Title edits are therefore harmless; missing or duplicate stable keys fail.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

from project_paths import resolve_project


ROOT = Path(__file__).resolve().parents[1]
STABLE_KEYS = ("stable_id", "_stable_id", "matrix_key", "_matrix_key", "case_uid", "_case_uid")


def stable_key(case: dict) -> str:
    for key in STABLE_KEYS:
        value = str(case.get(key, "") or "").strip()
        if value:
            return f"{key.lstrip('_')}::{value}"
    return ""


def load_cases(folder: Path) -> list[dict]:
    rows: list[dict] = []
    for path in sorted(folder.glob("*.json")):
        rows.extend(json.loads(path.read_text(encoding="utf-8")).get("cases", []))
    return rows


def load_stable_sidecar(project_dir: Path) -> list[dict]:
    path = project_dir / "用例稳定索引.json"
    if not path.exists():
        return []
    payload = json.loads(path.read_text(encoding="utf-8"))
    return [
        {"id": item.get("case_id", ""), "stable_id": item.get("stable_id", ""), "matrix_key": item.get("matrix_key", "")}
        for item in payload.get("items", [])
    ]


def unique_map(cases: list[dict], key_field: str, value_field: str) -> dict[str, str]:
    mapping: dict[str, str] = {}
    duplicates: set[str] = set()
    missing: list[str] = []
    for case in cases:
        key = stable_key(case) if key_field == "stable" else str(case.get(key_field, "") or "")
        value = stable_key(case) if value_field == "stable" else str(case.get(value_field, "") or "")
        if not key:
            missing.append(value or "<无编号>")
            continue
        if key in mapping:
            duplicates.add(key)
        mapping[key] = value
    if missing:
        raise SystemExit(f"存在缺稳定ID用例，禁止按标题猜测迁移: {missing[:20]}")
    if duplicates:
        raise SystemExit(f"稳定ID重复，无法唯一迁移: {sorted(duplicates)[:20]}")
    return mapping


def main() -> None:
    ap = argparse.ArgumentParser(description="按稳定ID/matrix_key重映射判定用例编号")
    ap.add_argument("--project", required=True)
    ap.add_argument("--workspace-root", help="项目工作区根目录；--project 为名称时生效")
    args = ap.parse_args()
    pdir = resolve_project(args.project, workspace_root=args.workspace_root)
    old, new, judgments = pdir / "工作底稿_old", pdir / "工作底稿", pdir / "judgments"
    if not old.exists():
        raise SystemExit(f"缺快照 {old}")
    old_cases = load_cases(old)
    new_cases = load_cases(new)
    if not old_cases:
        old_cases = load_stable_sidecar(pdir / "工作底稿_old")
    if not new_cases:
        new_cases = load_stable_sidecar(pdir)
    old_id_to_stable = unique_map(old_cases, "id", "stable")
    stable_to_new_id = unique_map(new_cases, "stable", "id")

    missing: list[tuple[str, str, str]] = []
    changed = 0
    for path in sorted(judgments.glob("*.json")):
        payload = json.loads(path.read_text(encoding="utf-8"))
        for req_id, verdict in payload.get("verdicts", {}).items():
            remapped: list[str] = []
            for old_id in verdict[1]:
                stable = old_id_to_stable.get(str(old_id), "")
                new_id = stable_to_new_id.get(stable, "") if stable else ""
                if not new_id:
                    missing.append((path.stem, str(req_id), str(old_id)))
                    remapped.append(str(old_id))
                    continue
                changed += new_id != old_id
                remapped.append(new_id)
            verdict[1] = remapped
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    if missing:
        raise SystemExit(f"稳定ID迁移缺失，未写入猜测结果: {missing[:20]}")
    print(f"稳定ID重映射完成: 变更 {changed} 个编号引用")


if __name__ == "__main__":
    main()
