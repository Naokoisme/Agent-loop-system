# -*- coding: utf-8 -*-
"""Build a deterministic, risk-stratified acceptance sample from final Excel."""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any

_SCRIPTS = Path(__file__).resolve().parent
if str(_SCRIPTS) not in sys.path:
    sys.path.insert(0, str(_SCRIPTS))

import tc_excel  # noqa: E402


CANONICAL_STRATA = (
    "changed_case_ids",
    "pending_confirmation",
    "conflict_cases",
    "high_risk",
    "feature_points",
)
STRATUM_ALIASES = {
    "changed": "changed_case_ids",
    "changes": "changed_case_ids",
    "recent_changes": "changed_case_ids",
    "changed_case_ids": "changed_case_ids",
    "最近变更": "changed_case_ids",
    "pending": "pending_confirmation",
    "pending_confirmation": "pending_confirmation",
    "pending_confirmations": "pending_confirmation",
    "待确认": "pending_confirmation",
    "conflict": "conflict_cases",
    "conflicts": "conflict_cases",
    "conflict_cases": "conflict_cases",
    "冲突": "conflict_cases",
    "high_risk": "high_risk",
    "p0_high_risk": "high_risk",
    "risk": "high_risk",
    "P0/高风险": "high_risk",
    "高风险": "high_risk",
    "feature_point": "feature_points",
    "feature_points": "feature_points",
    "per_feature_point": "feature_points",
    "每功能点": "feature_points",
}
PENDING_MARKERS = ("待确认", "待产品确认", "待研发确认", "待硬件确认")
DEFAULT_HIGH_RISK_MARKERS = ("高风险", "HIGH_RISK", "HIGH RISK")


def _resolve(base: Path, value: str | Path) -> Path:
    path = Path(value)
    return path if path.is_absolute() else base / path


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _issue(code: str, message: str) -> dict[str, str]:
    return {"severity": "blocking", "code": code, "message": message}


def _concrete_reason(value: Any) -> bool:
    """A not-applicable waiver must carry a real, reviewable reason."""
    if isinstance(value, str):
        text = value.strip()
        return bool(text) and text not in {"N/A", "NA", "not_applicable", "不适用"}
    if isinstance(value, dict):
        reason = value.get("reason")
        return _concrete_reason(reason)
    return False


def _normalize_not_applicable(value: Any, required: list[str], issues: list[dict[str, str]]) -> dict[str, str]:
    """Normalize explicit empty-stratum waivers and reject ambiguous entries."""
    if value is None:
        return {}
    if not isinstance(value, dict):
        issues.append(_issue(
            "STRATA_NOT_APPLICABLE_INVALID",
            "release_acceptance.strata_not_applicable 必须是分层到具体原因的对象",
        ))
        return {}
    result: dict[str, str] = {}
    for raw_key, raw_reason in value.items():
        key = str(raw_key or "").strip()
        canonical = STRATUM_ALIASES.get(key)
        if not canonical:
            issues.append(_issue("STRATA_NOT_APPLICABLE_UNKNOWN", f"strata_not_applicable 含未知分层: {key}"))
            continue
        if canonical not in required:
            issues.append(_issue(
                "STRATA_NOT_APPLICABLE_NOT_REQUIRED",
                f"strata_not_applicable 只能声明 required_strata 中的分层: {canonical}",
            ))
            continue
        if not _concrete_reason(raw_reason):
            issues.append(_issue(
                "STRATA_NOT_APPLICABLE_REASON_MISSING",
                f"strata_not_applicable.{canonical} 必须填写具体 N/A 原因",
            ))
            continue
        reason = raw_reason.get("reason") if isinstance(raw_reason, dict) else raw_reason
        result[canonical] = str(reason).strip()
    return result


def _extract_id_list(payload: Any) -> list[str] | None:
    if isinstance(payload, list):
        result: list[str] = []
        for item in payload:
            if isinstance(item, str):
                value = item.strip()
            elif isinstance(item, dict):
                value = str(item.get("case_id", item.get("id", item.get("用例编号", ""))) or "").strip()
            else:
                return None
            if not value:
                return None
            result.append(value)
        return result
    if isinstance(payload, dict):
        for key in ("changed_case_ids", "case_ids", "ids", "items"):
            if key in payload:
                return _extract_id_list(payload[key])
    return None


def _conflict_ids(payload: Any) -> list[str] | None:
    if isinstance(payload, dict):
        items = payload.get("items")
    else:
        items = payload
    if not isinstance(items, list):
        return None
    result: list[str] = []
    for item in items:
        if not isinstance(item, dict):
            return None
        for key in ("case_id", "target_case_id"):
            raw = item.get(key)
            values = raw if isinstance(raw, list) else [raw]
            for value in values:
                text = str(value or "").strip()
                if text:
                    result.append(text)
    return result


def _row_text(row: dict) -> str:
    return "|".join(str(value or "") for value in row.values())


def _deterministic_pick(rows: list[dict], seed: str, group_key: str) -> dict:
    def score(row: dict) -> tuple[str, str]:
        case_id = str(row.get("用例编号", "") or "").strip()
        raw = f"{seed}\0{group_key}\0{case_id}".encode("utf-8")
        return hashlib.sha256(raw).hexdigest(), case_id

    return min(rows, key=score)


def build_sample(config_path: str | Path) -> dict[str, Any]:
    config_path = Path(config_path).resolve()
    config = json.loads(config_path.read_text(encoding="utf-8"))
    base = config_path.parent
    release = config.get("release_acceptance", {}) or {}
    issues: list[dict[str, str]] = []

    raw_required = release.get("required_strata")
    normalized_required: list[str] = []
    if not isinstance(raw_required, list) or not raw_required:
        issues.append(_issue("REQUIRED_STRATA_MISSING", "release_acceptance.required_strata 必须配置全部验收分层"))
    else:
        unknown: list[str] = []
        for value in raw_required:
            text = str(value or "").strip()
            canonical = STRATUM_ALIASES.get(text)
            if not canonical:
                unknown.append(text)
            elif canonical not in normalized_required:
                normalized_required.append(canonical)
        if unknown:
            issues.append(_issue("REQUIRED_STRATA_UNKNOWN", f"required_strata 含未知分层: {unknown}"))
        missing = [name for name in CANONICAL_STRATA if name not in normalized_required]
        if missing:
            issues.append(_issue("REQUIRED_STRATA_INCOMPLETE", f"required_strata 缺少: {missing}"))
    not_applicable = _normalize_not_applicable(
        release.get("strata_not_applicable"), normalized_required, issues
    )

    cases_value = config.get("cases_xlsx")
    if not cases_value:
        cases_path = base / "<missing-cases.xlsx>"
        rows: list[dict] = []
        issues.append(_issue("CASES_XLSX_CONFIG_MISSING", "config.cases_xlsx 未配置"))
        xlsx_hash = ""
    else:
        cases_path = _resolve(base, str(cases_value))
        if not cases_path.exists():
            rows = []
            issues.append(_issue("CASES_XLSX_MISSING", f"最终Excel不存在: {cases_path}"))
            xlsx_hash = ""
        else:
            rows = tc_excel.read_master_rows(cases_path)
            xlsx_hash = _sha256(cases_path)

    rows_by_id: dict[str, dict] = {}
    duplicate_ids: set[str] = set()
    for row in rows:
        case_id = str(row.get("用例编号", "") or "").strip()
        if not case_id:
            issues.append(_issue("CASE_ID_MISSING", "最终Excel存在空用例编号"))
            continue
        if case_id in rows_by_id:
            duplicate_ids.add(case_id)
        rows_by_id[case_id] = row
    if duplicate_ids:
        issues.append(_issue("CASE_ID_DUPLICATE", f"最终Excel用例编号重复: {sorted(duplicate_ids)}"))

    candidate_ids: dict[str, set[str]] = {name: set() for name in CANONICAL_STRATA[:-1]}
    changed_value = release.get("changed_case_ids_file")
    changed_path: Path | None = None
    if not changed_value:
        issues.append(_issue("CHANGED_CASE_IDS_FILE_CONFIG_MISSING", "release_acceptance.changed_case_ids_file 未配置"))
    else:
        changed_path = _resolve(base, str(changed_value))
        if not changed_path.exists():
            issues.append(_issue("CHANGED_CASE_IDS_FILE_MISSING", f"最近变更ID文件不存在: {changed_path}"))
        else:
            try:
                changed_ids = _extract_id_list(json.loads(changed_path.read_text(encoding="utf-8")))
            except (OSError, json.JSONDecodeError) as exc:
                changed_ids = None
                issues.append(_issue("CHANGED_CASE_IDS_FILE_INVALID_JSON", f"最近变更ID文件无法读取: {exc}"))
            if changed_ids is None:
                issues.append(_issue("CHANGED_CASE_IDS_SCHEMA_INVALID", "最近变更ID文件必须包含字符串case ID数组"))
            else:
                candidate_ids["changed_case_ids"].update(changed_ids)

    for case_id, row in rows_by_id.items():
        text = _row_text(row)
        if any(marker in text for marker in PENDING_MARKERS):
            candidate_ids["pending_confirmation"].add(case_id)

    conflict_value = release.get("conflict_index_file", "冲突矩阵索引.json")
    conflict_path = _resolve(base, str(conflict_value))
    if not conflict_path.exists():
        issues.append(_issue("CONFLICT_INDEX_FILE_MISSING", f"冲突索引不存在: {conflict_path}"))
    else:
        try:
            conflict_ids = _conflict_ids(json.loads(conflict_path.read_text(encoding="utf-8")))
        except (OSError, json.JSONDecodeError) as exc:
            conflict_ids = None
            issues.append(_issue("CONFLICT_INDEX_FILE_INVALID_JSON", f"冲突索引无法读取: {exc}"))
        if conflict_ids is None:
            issues.append(_issue("CONFLICT_INDEX_SCHEMA_INVALID", "冲突索引必须包含items数组及case_id/target_case_id"))
        else:
            candidate_ids["conflict_cases"].update(conflict_ids)

    risk_markers = [
        str(value) for value in release.get("high_risk_markers", DEFAULT_HIGH_RISK_MARKERS)
        if str(value)
    ]
    for case_id, row in rows_by_id.items():
        priority = str(row.get("优先级", "") or "").strip().upper()
        text_upper = _row_text(row).upper()
        if priority == "P0" or any(marker.upper() in text_upper for marker in risk_markers):
            candidate_ids["high_risk"].add(case_id)

    referenced_ids = set().union(*candidate_ids.values()) if candidate_ids else set()
    missing_references = sorted(referenced_ids - set(rows_by_id))
    if missing_references:
        issues.append(_issue("REFERENCED_CASE_ID_MISSING", f"分层文件引用不存在用例: {missing_references}"))

    reasons: defaultdict[str, set[str]] = defaultdict(set)
    for stratum, ids in candidate_ids.items():
        for case_id in sorted(ids & set(rows_by_id)):
            reasons[case_id].add(stratum)

    seed = str(release.get("sample_seed", release.get("seed", "0")))
    feature_groups: defaultdict[tuple[str, str], list[dict]] = defaultdict(list)
    for row in rows:
        module = str(row.get("功能模块", "") or "").strip()
        feature_point = str(row.get("功能点", "") or "").strip()
        case_id = str(row.get("用例编号", "") or "").strip()
        if module and feature_point and case_id:
            feature_groups[(module, feature_point)].append(row)
    feature_selected: set[str] = set()
    for (module, feature_point), group_rows in sorted(feature_groups.items()):
        selected = _deterministic_pick(group_rows, seed, f"{module}\0{feature_point}")
        case_id = str(selected.get("用例编号", "") or "").strip()
        feature_selected.add(case_id)
        reasons[case_id].add("feature_points")

    sample: list[dict[str, Any]] = []
    for row_index, row in enumerate(rows, 1):
        case_id = str(row.get("用例编号", "") or "").strip()
        if case_id not in reasons:
            continue
        sample.append({
            "case_id": case_id,
            "excel_row_index": row_index,
            "module": str(row.get("功能模块", "") or ""),
            "feature_point": str(row.get("功能点", "") or ""),
            "test_item": str(row.get("测试项", "") or ""),
            "test_point": str(row.get("测试点/检查项", "") or ""),
            "priority": str(row.get("优先级", "") or ""),
            "strata": [name for name in CANONICAL_STRATA if name in reasons[case_id]],
        })

    selected_ids = {item["case_id"] for item in sample}
    coverage_counts: dict[str, dict[str, int]] = {}
    for stratum, ids in candidate_ids.items():
        coverage_counts[stratum] = {
            "candidate_count": len(ids),
            "selected_count": len(ids & selected_ids),
        }
    covered_feature_groups = sum(
        1 for group_rows in feature_groups.values()
        if any(str(row.get("用例编号", "") or "").strip() in selected_ids for row in group_rows)
    )
    coverage_counts["feature_points"] = {
        "candidate_count": len(feature_groups),
        "selected_count": covered_feature_groups,
    }

    for stratum in normalized_required:
        candidate_count = coverage_counts.get(stratum, {}).get("candidate_count", 0)
        reason = not_applicable.get(stratum)
        if candidate_count == 0 and not reason:
            issues.append(_issue(
                "REQUIRED_STRATUM_EMPTY",
                f"必需验收分层 {stratum} 候选数为0；若项目确实不适用，须在 "
                "release_acceptance.strata_not_applicable 填写具体原因",
            ))
        elif candidate_count > 0 and reason:
            issues.append(_issue(
                "STRATUM_NOT_APPLICABLE_CONTRADICTS_CANDIDATES",
                f"分层 {stratum} 已有{candidate_count}条候选，不得声明 not_applicable",
            ))

    status = "PASS" if not issues else "FAIL"
    return {
        "schema_version": 1,
        "tool": "stratified_acceptance_sample",
        "status": status,
        "blocking_count": len(issues),
        "risk_count": 0,
        "warning_count": 0,
        "issues": issues,
        "metrics": {
            "total_case_count": len(rows),
            "sample_count": len(sample),
            "required_strata": normalized_required,
            "strata_not_applicable": not_applicable,
            "coverage_counts": coverage_counts,
            "sample_seed": seed,
        },
        "sample": sample,
        "artifacts": {
            "config": str(config_path),
            "cases_xlsx": str(cases_path),
            "input_xlsx_sha256": xlsx_hash,
            "changed_case_ids_file": str(changed_path) if changed_path else "",
            "conflict_index_file": str(conflict_path),
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="生成交付前分层验收抽样清单")
    parser.add_argument("--config", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    out = Path(args.out).resolve()
    try:
        report = build_sample(args.config)
    except Exception as exc:  # noqa: BLE001 - preserve a machine-readable failure artifact
        report = {
            "schema_version": 1,
            "tool": "stratified_acceptance_sample",
            "status": "FAIL",
            "blocking_count": 1,
            "risk_count": 0,
            "warning_count": 0,
            "issues": [_issue("SAMPLER_EXECUTION_ERROR", str(exc))],
            "metrics": {},
            "sample": [],
            "artifacts": {"config": str(Path(args.config).resolve())},
        }
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    raise SystemExit(0 if report["status"] == "PASS" else 1)


if __name__ == "__main__":
    main()
