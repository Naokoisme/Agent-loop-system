# -*- coding: utf-8 -*-
"""Execution-profile routing for the lightweight and strict QA paths."""
from __future__ import annotations

import copy
import json
from pathlib import Path
from typing import Any, Iterable


PROFILE_FILENAME = "执行画像.json"
PROFILE_SCHEMA_VERSION = 1
MODES = {"auto", "core", "strict"}
CAPABILITY_PACKS = {
    "peer_review",
    "platform_coverage",
    "full_traceability",
    "pilot",
    "ui_matrix",
    "cross_end_conflict",
    "stable_id_migration",
    "strict_review",
    "formal_release",
}
STRICT_PACKS = {
    "full_traceability",
    "pilot",
    "strict_review",
    "formal_release",
}
CORE_BLUEPRINT_KEYS = [
    "module_boundary",
    "feature_order",
    "execution_order",
    "hierarchy_map",
    "unsupported_features",
    "platform_scope",
    "main_risks",
]
LEGACY_CORE_GATE_NAMES = [
    "field_and_source_data",
    "hierarchy_ownership",
    "hierarchy_contiguous_block",
    "duplicate_intent",
    "step_expected",
    "applicability_scope",
    "pending_confirmation",
    "excel_artifact",
    "current_hash",
    "manual_semantics",
]
CORE_GATE_NAMES = [*LEGACY_CORE_GATE_NAMES, "execution_quality"]


def _unique(values: Iterable[str]) -> list[str]:
    result: list[str] = []
    for value in values:
        text = str(value or "").strip()
        if text and text not in result:
            result.append(text)
    return result


def _concrete_reason(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def build_profile(
    *,
    requested_mode: str = "auto",
    work_units: Iterable[str] = (),
    risk_flags: Iterable[str] = (),
    capability_packs: Iterable[str] = (),
    platform_scope: Iterable[str] = (),
) -> dict[str, Any]:
    """Build a visible, deterministic routing decision for a new task."""
    requested = str(requested_mode or "auto").strip().lower()
    if requested not in MODES:
        raise ValueError(f"execution mode 必须是 {sorted(MODES)}，实际为 {requested!r}")

    units = _unique(work_units)
    risks = _unique(risk_flags)
    platforms = _unique(platform_scope)
    explicit_packs = _unique(capability_packs)
    unknown = sorted(set(explicit_packs) - CAPABILITY_PACKS)
    if unknown:
        raise ValueError(f"未知 capability pack: {unknown}")

    selected = list(explicit_packs)
    if len(units) > 1:
        risks = _unique([*risks, "multi_function"])
        selected = _unique([*selected, "peer_review"])
    if len(platforms) > 1 or any(value.lower() in {"android", "ios"} for value in platforms):
        risks = _unique([*risks, "app_platform"])
        selected = _unique([*selected, "platform_coverage"])

    strict_risks = {
        "formal_release", "security", "privacy", "payment", "account_permission",
        "irreversible_data", "ota", "firmware_upgrade", "medical", "health_conclusion",
        "escaped_major_defect", "complex_cross_end",
    }
    high_risk = bool(set(risks) & strict_risks)
    if requested == "strict" or high_risk or bool(set(selected) & STRICT_PACKS):
        base_path = "strict"
        selected = _unique([
            *selected, "full_traceability", "pilot", "strict_review", "formal_release",
        ])
    else:
        base_path = "core"

    reasons = {
        "full_traceability": "未要求正式覆盖证明或完整需求追溯",
        "pilot": "未识别到新产品形态、生成器变更或高扩散风险组合方法",
        "ui_matrix": "未声明有屏多输入页面矩阵",
        "cross_end_conflict": "未声明双端同步、断连恢复或状态冲突",
        "stable_id_migration": "未声明既有编号重排、拆合或迁移",
        "strict_review": "常规团队评审交付，未要求隔离对抗评审",
        "formal_release": "未要求正式 GO/NO_GO、客户发布或审计留档",
        "platform_coverage": "未声明 Android/iOS 等多平台范围",
        "peer_review": "单一工作单无需跨功能同行轮换",
    }
    not_enabled = {
        name: reason for name, reason in reasons.items() if name not in selected
    }
    return {
        "schema_version": PROFILE_SCHEMA_VERSION,
        "task_kind": "prd_to_workbook",
        "requested_mode": requested,
        "base_path": base_path,
        "legacy_fallback": False,
        "work_units": units,
        "parallel_generation": len(units) > 1,
        "risk_flags": risks,
        "platform_scope": platforms,
        "capability_packs": selected,
        "not_enabled": not_enabled,
        "core_gates": list(CORE_GATE_NAMES),
        "delivery_target": "STRICT_GO" if base_path == "strict" else "READY_FOR_REVIEW",
    }


def validate_profile(profile: Any) -> list[str]:
    errors: list[str] = []
    if not isinstance(profile, dict):
        return ["执行画像根节点必须是对象"]
    if profile.get("schema_version") != PROFILE_SCHEMA_VERSION:
        errors.append(f"执行画像 schema_version 必须为 {PROFILE_SCHEMA_VERSION}")
    if profile.get("base_path") not in {"core", "strict"}:
        errors.append("执行画像 base_path 必须为 core/strict")
    requested = profile.get("requested_mode")
    if requested not in MODES and requested != "legacy":
        errors.append("执行画像 requested_mode 必须为 auto/core/strict/legacy")
    packs = profile.get("capability_packs")
    if not isinstance(packs, list):
        errors.append("执行画像 capability_packs 必须是数组")
        packs = []
    unknown = sorted(set(str(value) for value in packs) - CAPABILITY_PACKS)
    if unknown:
        errors.append(f"执行画像包含未知 capability pack: {unknown}")
    units = profile.get("work_units")
    if not isinstance(units, list):
        errors.append("执行画像 work_units 必须是数组")
    if profile.get("parallel_generation") is True and (not isinstance(units, list) or len(units) < 2):
        errors.append("parallel_generation=true 时至少需要两个 work_units")
    if isinstance(units, list) and profile.get("parallel_generation") is not (len(units) > 1):
        errors.append("执行画像 parallel_generation 必须由 work_units 数量派生")
    if isinstance(units, list) and len(units) > 1 and "peer_review" not in packs:
        errors.append("多个 work_units 必须启用 peer_review")
    platforms = profile.get("platform_scope")
    if not isinstance(platforms, list):
        errors.append("执行画像 platform_scope 必须是数组")
        platforms = []
    if (
        (len(platforms) > 1 or any(str(value).lower() in {"android", "ios"} for value in platforms))
        and "platform_coverage" not in packs
    ):
        errors.append("Android/iOS 或多平台任务必须启用 platform_coverage")
    legacy_fallback = profile.get("legacy_fallback")
    if legacy_fallback not in {True, False}:
        errors.append("执行画像 legacy_fallback 必须是布尔值")
    elif legacy_fallback is True and requested != "legacy":
        errors.append("只有 legacy 兼容画像可设置 legacy_fallback=true")
    elif requested == "legacy" and legacy_fallback is not True:
        errors.append("requested_mode=legacy 必须设置 legacy_fallback=true")
    if profile.get("base_path") == "strict":
        missing = sorted(STRICT_PACKS - set(str(value) for value in packs))
        if missing:
            errors.append(f"strict 画像缺能力包: {missing}")
    not_enabled = profile.get("not_enabled")
    if not isinstance(not_enabled, dict):
        errors.append("执行画像 not_enabled 必须是对象")
    elif any(not _concrete_reason(value) for value in not_enabled.values()):
        errors.append("执行画像 not_enabled 每项必须写具体原因")
    expected_target = "STRICT_GO" if profile.get("base_path") == "strict" else "READY_FOR_REVIEW"
    if profile.get("delivery_target") != expected_target:
        errors.append(f"执行画像 delivery_target 必须与 base_path 一致: {expected_target}")
    if profile.get("core_gates") not in (CORE_GATE_NAMES, LEGACY_CORE_GATE_NAMES):
        errors.append("执行画像 core_gates 不得删减、增补或重排")
    if "release_target" in profile:
        errors.append("执行画像禁止使用可影响 release_decision 的 release_target 字段")
    return errors


def write_profile(project_dir: Path, profile: dict[str, Any]) -> Path:
    errors = validate_profile(profile)
    if errors:
        raise ValueError("执行画像无效:\n- " + "\n- ".join(errors))
    path = project_dir / PROFILE_FILENAME
    path.write_text(json.dumps(profile, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def load_profile(project_dir: Path, *, legacy_strict: bool = True) -> dict[str, Any]:
    """Load a project profile; missing legacy profiles stay on the strict path."""
    path = project_dir / PROFILE_FILENAME
    if not path.exists():
        if not legacy_strict:
            raise FileNotFoundError(path)
        profile = build_profile(requested_mode="strict")
        profile.update({
            "requested_mode": "legacy",
            "legacy_fallback": True,
            "not_enabled": {},
        })
        return profile
    profile = json.loads(path.read_text(encoding="utf-8"))
    errors = validate_profile(profile)
    if errors:
        raise ValueError("执行画像无效:\n- " + "\n- ".join(errors))
    return profile


def has_pack(profile: dict[str, Any], name: str) -> bool:
    return name in set(str(value) for value in profile.get("capability_packs", []))


def required_blueprint_keys(profile: dict[str, Any]) -> list[str]:
    if profile.get("legacy_fallback"):
        return [
            "module_boundary", "feature_order", "page_state_anchors", "input_matrix",
            "exception_matrix", "cross_matrix", "common_fixtures", "case_precondition_rules",
            "unsupported_features",
        ]
    if profile.get("base_path") == "strict" or has_pack(profile, "pilot"):
        return [
            "module_boundary", "feature_order", "execution_order", "page_state_anchors", "input_matrix",
            "exception_matrix", "cross_matrix", "common_fixtures", "case_precondition_rules",
            "unsupported_features", "complexity_profile", "hierarchy_map",
        ]
    return list(CORE_BLUEPRINT_KEYS)


def apply_profile_to_config(config: dict[str, Any], profile: dict[str, Any]) -> dict[str, Any]:
    """Apply routing to one shared config without weakening immutable core gates."""
    result = copy.deepcopy(config)
    result["execution_profile"] = {"file": PROFILE_FILENAME}
    result.setdefault("quality_gates", {})["hierarchy_contiguous_block"] = {
        "required": True,
        "group_fields": ["功能模块", "功能点", "测试项"],
        "exceptions_file": "用例设计蓝图.json",
        "exceptions_key": "continuous_block_exceptions",
    }
    release = result.setdefault("release_acceptance", {})
    release["execution_quality_required"] = True
    strict = profile.get("base_path") == "strict"
    release["delivery_target"] = "STRICT_GO" if strict else "READY_FOR_REVIEW"
    release["full_traceability_required"] = strict or has_pack(profile, "full_traceability")
    release["pilot_required"] = strict or has_pack(profile, "pilot")
    strict_review = strict or has_pack(profile, "strict_review")
    release["multi_round_review_required"] = strict_review
    release["multi_agent_review_required"] = strict_review
    release["formal_release_required"] = strict or has_pack(profile, "formal_release")
    if not release["formal_release_required"]:
        release["required_reports"] = []
        release.pop("required_strata", None)
        release.pop("decision_ledger_file", None)
        release.pop("decision_ledger_files", None)
    if not strict_review:
        release.pop("multi_round_review_required", None)
        release.pop("multi_agent_review_required", None)
        release.pop("multi_round_review_file", None)
    result["generation_contract"]["required"] = release["pilot_required"]

    gates = result.setdefault("quality_gates", {})
    if not strict:
        core_names = {
            "manual_case_style", "excel_format", "delivery_workbook",
            "test_item_taxonomy", "case_granularity", "hierarchy_mapping",
            "common_fixtures", "functional_manual_contract", "blueprint",
            "production_semantics", "scenario_coverage", "test_item_exception_objects",
            "cross_scene", "navigation_expectations", "cross_scene_block",
            "hierarchy_contiguous_block", "execution_quality",
        }
        gates = {
            key: copy.deepcopy(value)
            for key, value in gates.items()
            if key in core_names
        }
        gates["blueprint"]["required_keys"] = required_blueprint_keys(profile)
        if has_pack(profile, "ui_matrix"):
            source = config.get("quality_gates", {})
            for key in ("page_input_matrix", "ui_operation_order"):
                gates[key] = copy.deepcopy(source.get(key, {}))
        if has_pack(profile, "cross_end_conflict"):
            source = config.get("quality_gates", {})
            for key in ("module_dependencies", "conflict_matrix_policy"):
                gates[key] = copy.deepcopy(source.get(key, {}))
        if has_pack(profile, "pilot"):
            gates["case_scale"] = copy.deepcopy(config["quality_gates"].get("case_scale", {}))
        if has_pack(profile, "stable_id_migration"):
            gates["excel_format"]["check_migration"] = True
        if has_pack(profile, "platform_coverage"):
            gates["platform_coverage"] = {
                "required": True,
                "platforms": list(profile.get("platform_scope", [])),
                "main_flow_feature_points": ["<填写需覆盖的平台主流程功能点>"],
                "fields": [
                    "兼容性", "测试点/检查项", "前置条件", "操作步骤", "预期结果", "备注",
                ],
            }
        cross_block = gates.get("cross_scene_block")
        if isinstance(cross_block, dict) and cross_block.get("require_present") is True:
            cross_block["require_present"] = False
            cross_block["not_applicable_reason"] = (
                "核心路径按当前 PRD 裁剪；无真实交叉对象时不强制构造交叉场景"
            )
        result["quality_gates"] = gates
    return result
