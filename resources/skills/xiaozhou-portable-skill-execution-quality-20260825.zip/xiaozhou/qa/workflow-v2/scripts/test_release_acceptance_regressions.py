# -*- coding: utf-8 -*-
"""Regression tests for the single versioned release gate."""
from __future__ import annotations

import importlib.util
import copy
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

SCRIPTS = Path(__file__).resolve().parent
sys.path.insert(0, str(SCRIPTS))

import tc_excel  # noqa: E402
import execution_profile  # noqa: E402
import lineage  # noqa: E402
import new_project  # noqa: E402

spec = importlib.util.spec_from_file_location("release_acceptance_regression", SCRIPTS / "release_acceptance.py")
release = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(release)


def row() -> dict:
    return {
        "用例编号": "QA_001", "功能模块": "录音", "功能点": "入口", "测试项": "入口路径",
        "测试点/检查项": "验证进入录音页面", "前置条件": "1.设备处于主界面",
        "操作步骤": "1.点击录音入口", "预期结果": "1.页面显示录音入口",
        "优先级": "P0", "兼容性": "N/A", "是否自动化": "否", "固件版本": "v1.0",
        "硬件型号": "待测", "测试方式": "人工执行", "备注": "",
    }


def case_ids_sha256(case_ids: list[str]) -> str:
    canonical = json.dumps(case_ids, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()


def write_agent_review_report(
    root: Path,
    *,
    round_id: str,
    review_type: str,
    role: str,
    workbook_hash: str,
    prd_hash: str,
    verified_finding_ids: list[str] | None = None,
) -> dict:
    case_ids = ["QA_001"]
    ordered_hash = case_ids_sha256(case_ids)
    context_mode = "raw_artifacts_and_closed_findings" \
        if role == "regression-targeted" else "raw_artifacts_only"
    agent_id = f"release-agent-{role}"
    agent_run_id = f"release-{round_id}-{role}"
    report = {
        "schema_version": 1,
        "agent_id": agent_id,
        "agent_run_id": agent_run_id,
        "review_type": review_type,
        "reviewer_role": role,
        "fork_turns": "none",
        "peer_reports_visible": False,
        "context_mode": context_mode,
        "scope": "all_project",
        "input_xlsx_sha256": workbook_hash,
        "prd_sha256": prd_hash,
        "reviewed_case_count": 1,
        "reviewed_case_ids": case_ids,
        "reviewed_case_ids_sha256": ordered_hash,
        "findings": [],
        "verified_finding_ids": list(verified_finding_ids or []),
        "evidence": f"{role}独立检查当前单用例回归夹具",
        "status": "completed",
    }
    relative = Path("工作底稿") / "agent_reviews" / f"{round_id}-{role}.json"
    path = root / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return {
        "agent_id": agent_id,
        "agent_run_id": agent_run_id,
        "reviewer_role": role,
        "fork_turns": "none",
        "peer_reports_visible": False,
        "context_mode": context_mode,
        "scope": "all_project",
        "input_xlsx_sha256": workbook_hash,
        "prd_sha256": prd_hash,
        "reviewed_case_count": 1,
        "reviewed_case_ids_sha256": ordered_hash,
        "report_path": relative.as_posix(),
        "report_sha256": release.sha256(path),
        "finding_ids": [],
        "verified_finding_ids": list(verified_finding_ids or []),
        "evidence": report["evidence"],
        "status": "completed",
    }


def valid_delivery_gates() -> dict:
    return {
        "delivery_workbook": {
            "single_sheet": False,
            "sheet_name": "全功能测试用例",
            "headers": ["序号", *tc_excel.COLUMNS],
            "font_name": "等线",
            "font_size": 10,
            "require_black_borders": True,
            "merge_hierarchy": ["功能模块", "功能点", "测试项"],
            "forbid_merges_outside_hierarchy": True,
            "expected_version": "v1.0",
            "filename_must_contain_version": True,
            "forbid_other_versions": True,
            "version_scan_fields": ["固件版本", "备注"],
            "require_expected_version_mention": True,
        },
        "test_item_taxonomy": {
            "forbidden_generic_items": [
                "功能测试", "边界测试", "边界场景", "规则确认", "规则测试", "规则校验",
            ]
        },
        "case_granularity": {
            "forbid_grouped_scenarios": True,
            "detect_exact_duplicates": True,
        },
        "cross_scene_block": {
            "feature_points": ["交叉场景"],
            "scope": "global",
            "require_present": False,
            "not_applicable_reason": "当前单用例发布回归夹具没有交叉场景",
            "require_tail": True,
            "cross_items": ["来电", "消息", "闹钟", "低电", "固件OTA"],
        },
        "case_scale": {
            "required": True,
            "file": "用例设计蓝图.json",
            "profile_key": "complexity_profile",
        },
        "hierarchy_mapping": {
            "required": True,
            "file": "用例设计蓝图.json",
            "map_key": "hierarchy_map",
        },
    }


def write_required_report(
    root: Path, config_path: Path, report_hash_mode: str = "", *, stale_report: bool = False,
    report_status: str = "PASS", risk_count: int = 0, warning_count: int = 0,
) -> None:
    config = json.loads(config_path.read_text(encoding="utf-8"))
    files = release.input_files(config_path, config)
    hashes = {
        release._input_key(root, path): release.sha256(path)  # noqa: SLF001 - regression verifies exact contract
        for path in files
    }
    required_keys = release.default_required_report_input_keys(config_path, config, hashes)
    payload: dict = {
        "status": report_status,
        "risk_count": risk_count,
        "warning_count": warning_count,
    }
    if report_hash_mode == "missing":
        pass
    elif report_hash_mode == "empty":
        payload["input_hashes"] = {}
    elif report_hash_mode in {"configured_partial", "default_partial"}:
        payload["input_hashes"] = {"trace.config.json": hashes["trace.config.json"]}
    else:
        payload["input_hashes"] = {key: hashes[key] for key in required_keys}
    if stale_report and payload.get("input_hashes"):
        first_key = next(iter(payload["input_hashes"]))
        payload["input_hashes"][first_key] = "0" * 64
    (root / "report.json").write_text(json.dumps(payload), encoding="utf-8")


def build(
    root: Path,
    *,
    partial: bool = False,
    ghost: bool = False,
    stale_report: bool = False,
    new_project_without_reports: bool = False,
    legacy_contract_required: bool = False,
    pilot_evidence: bool = False,
    decision_ledger: str = "",
    production_without_ledger: bool = False,
    report_hash_mode: str = "",
    required_report_status: str = "PASS",
    required_report_risk_count: int = 0,
    required_report_warning_count: int = 0,
    mutate_spec_after_build: bool = False,
    result_binding_mode: str = "correct",
    touch_result_after_build: bool = False,
    mutate_prd_after_build: bool = False,
    mutate_result_after_finalize: bool = False,
    scaffold_default_paths: bool = False,
    defer_result_finalize: bool = False,
    reexport_after_finalize: bool = False,
    extra_result_file: bool = False,
    judgment_mode: str = "",
    external_prd: bool = False,
    strata_config_mode: str = "complete",
    feedback_required_mode: str = "true",
    feedback_ledger_mode: str = "pattern",
    multi_review_required_mode: str = "true",
    multi_agent_review_required_mode: str = "true",
    multi_review_ledger_mode: str = "valid",
    quality_profile_mode: str = "complete",
    delivery_artifact_mode: str = "valid",
) -> Path:
    (root / "cases").mkdir()
    (root / "结果").mkdir()
    (root / "工作底稿" / "追溯").mkdir(parents=True)
    canonical_rows = [row()]
    if delivery_artifact_mode == "reordered":
        second = copy.deepcopy(row())
        second.update({
            "用例编号": "QA_002",
            "测试点/检查项": "验证录音入口标题显示",
            "预期结果": "1.页面显示录音标题",
        })
        canonical_rows.append(second)
    cases = [
        {**item, "_stable_id": f"CASE::{item['用例编号']}"} for item in canonical_rows
    ]
    stable_items = [
        {"case_id": item["用例编号"], "stable_id": f"CASE::{item['用例编号']}"}
        for item in canonical_rows
    ]
    (root / "cases" / "录音.json").write_text(
        json.dumps({"module": "录音", "cases": cases}, ensure_ascii=False), encoding="utf-8"
    )
    (root / "用例稳定索引.json").write_text(
        json.dumps({"items": stable_items}, ensure_ascii=False), encoding="utf-8"
    )
    tc_excel.write_workbook(canonical_rows, root / "cases.xlsx", ["录音"])
    delivery_rows = list(canonical_rows)
    if delivery_artifact_mode == "missing_case":
        delivery_rows = []
    elif delivery_artifact_mode == "extra_case":
        extra = copy.deepcopy(row())
        extra.update({
            "用例编号": "QA_999",
            "测试点/检查项": "验证额外交付用例",
            "预期结果": "1.页面显示额外交付结果",
        })
        delivery_rows.append(extra)
    elif delivery_artifact_mode == "reordered":
        delivery_rows = list(reversed(delivery_rows))
    elif delivery_artifact_mode == "content_drift":
        changed = copy.deepcopy(delivery_rows[0])
        changed["预期结果"] = "1.页面显示被改写的结果"
        delivery_rows[0] = changed
    tc_excel.write_workbook(delivery_rows, root / "delivery_v1.0.xlsx", ["录音"])
    (root / "prd.md").write_text("# PRD\n", encoding="utf-8")
    contract: dict = {"schema_version": 1}
    if pilot_evidence:
        contract = {
            "schema_version": 3,
            "pilot_risk_types": ["settings", "sensor", "state_flow", "conflict"],
            "pilot_modules": ["录音", "连接", "设置"],
            "pilot_risk_evidence": [
                {"risk_type": "settings", "module": "设置", "evidence_path": "evidence/settings.json"},
                {"risk_type": "sensor", "module": "录音", "evidence_path": "evidence/sensor.json"},
                {"risk_type": "state_flow", "module": "连接", "evidence_path": "evidence/state.json"},
                {"risk_type": "conflict", "module": "录音", "evidence_path": "evidence/conflict.json"},
            ],
        }
        (root / "evidence").mkdir()
        for name in ("settings", "sensor", "state", "conflict"):
            (root / "evidence" / f"{name}.json").write_text(
                json.dumps({"status": "PASS", "evidence": name}), encoding="utf-8"
            )
    (root / "生成验收合同.json").write_text(json.dumps(contract), encoding="utf-8")
    draft = {"module": "录音", "requirements": [{"req_id": "REQ-1", "text": "录音入口", "source": "PRD"}], "cases": [{"id": "QA_001", "risk": {"state": "confirmed"}}]}
    (root / "工作底稿" / "追溯" / "录音.json").write_text(json.dumps(draft, ensure_ascii=False), encoding="utf-8")
    status = "部分覆盖" if partial else "已覆盖"
    matched = ["GHOST_999" if ghost else "QA_001"]
    result = {"module": "录音", "items": [{"req_id": "REQ-1", "testable": True, "status": status, "matched_ids": matched, "note": "待补" if partial else ""}]}
    (root / "结果" / "录音.json").write_text(json.dumps(result, ensure_ascii=False), encoding="utf-8")
    config = {
        "project": "regression", "prd_path": "prd.md", "cases_xlsx": "cases.xlsx",
        "coverage_threshold": 0.95,
        "coverage_policy": {"require_zero_partial": True, "accepted_partial_req_ids": [], "pending_evidence_mode": "report_only"},
        "generation_contract": {
            "required": new_project_without_reports or legacy_contract_required,
            "file": "生成验收合同.json",
        },
        "out_dirs": {"draft": "工作底稿/追溯", "result": "结果", "gaps": "补充用例"},
        "modules": [{"name": "录音", "prefix": "QA", "prd_sections": []}],
        "quality_gates": {},
        "release_acceptance": {
            "required_reports": [] if new_project_without_reports else [
                {
                    "path": "report.json",
                    "accepted_statuses": ["PASS", "PASS_WITH_RISKS"]
                    if required_report_status == "PASS_WITH_RISKS" else ["PASS"],
                }
            ],
        },
    }
    if scaffold_default_paths:
        config["out_dirs"] = copy.deepcopy(new_project.CONFIG_TEMPLATE["out_dirs"])
    if pilot_evidence:
        config["quality_gates"] = {
            "functional_manual_contract": {
                "required": True,
                "execution_mode": "manual",
                "forbid_automation_details": True,
                "step_expected_one_to_one": True,
                "automation_conversion_artifact": "工作底稿/自动化转换候选.json",
            },
            "excel_format": {
                "merge_hierarchy_cells": True,
                "require_precondition_numbering": True,
                "require_test_point_verify_prefix": True,
                "test_point_max_length": 35,
                "check_migration": False,
            },
            "blueprint": {
                "required": True,
                "files": ["用例设计蓝图.json"],
                "required_keys": [
                    "module_boundary", "feature_order", "page_state_anchors", "input_matrix",
                    "exception_matrix", "cross_matrix", "common_fixtures", "case_precondition_rules",
                    "unsupported_features", "complexity_profile", "hierarchy_map",
                ],
            },
            "ui_operation_order": {
                "enabled": True,
                "strict_coverage": True,
                "pages": [{
                    "module": "录音", "page": "录音入口页", "feature_point": "入口",
                    "anchor_keywords": ["进入录音页面"], "ui_keywords": ["点击按钮"],
                }],
            },
            "production_semantics": {
                "require_nonempty_core_fields": True,
                "check_manual_feasibility": True,
                "check_dependency_module_boundaries": True,
                "preconditions": {"require_nonempty": True, "placeholder_phrases": []},
            },
            "conflict_matrix_policy": {
                "required": False,
                "required_when_cross_cases": True,
                "index_file": "冲突矩阵索引.json",
                "allowed_statuses": ["covered", "pending_confirmation", "rule_only", "not_applicable"],
            },
            "scenario_coverage": {
                "required": True,
                "file": "场景覆盖矩阵.json",
                "expected_dimensions": [
                    "入口与初始化", "主流程与业务规则", "边界与限制", "异常与负向",
                    "中断与恢复", "交叉与冲突", "数据保存与一致性", "稳定性", "兼容性", "人工体验",
                ],
                "allow_pending": False,
                "accepted_pending_keys": [],
            },
        }
        config["release_acceptance"]["quality_gate_not_applicable"] = {
            "feature_order": "单用例回归夹具不验证模块内功能顺序",
            "module_dependencies": "当前回归模块没有外部能力依赖",
            "unsupported_features": "当前回归需求未声明不支持能力",
            "page_input_matrix": "当前回归夹具没有独立页面输入矩阵",
            "new_modules": "当前回归夹具没有新增模块",
            "test_item_exception_objects": "当前回归夹具没有对象型测试项例外",
            "cross_scene": "当前回归夹具没有跨模块场景",
            "common_fixtures": "当前回归夹具仅一个用例，不存在公共前置复用",
            "navigation_expectations": "当前回归夹具没有跨功能导航返回路径",
            "test_item_taxonomy": "当前回归专注发布准出，不重复验证测试项分类",
            "case_granularity": "当前回归仅有一条原子用例，不需要粒度扫描",
            "cross_scene_block": "当前回归没有交叉场景区块",
            "case_scale": "当前回归夹具固定为一条输入，不验证需求复杂度推导",
            "hierarchy_mapping": "当前回归仅验证发布链路，不重复验证层级映射",
            "delivery_workbook": "当前回归复用既有标准源表，不单独验证交付样式",
        }
    if external_prd:
        external = root.parent / f"{root.name}-external-prd.md"
        external.write_text("# external PRD\n", encoding="utf-8")
        config["prd_path"] = str(external)
    if report_hash_mode in {"configured_partial", "configured_full"}:
        config["release_acceptance"]["required_reports"][0]["required_input_keys"] = [
            "trace.config.json", "prd.md",
        ]
    if pilot_evidence and not production_without_ledger and not decision_ledger:
        decision_ledger = "valid"
    if pilot_evidence:
        if strata_config_mode != "missing":
            required_strata = [
                "changed_case_ids", "pending_confirmation", "conflict_cases",
                "high_risk", "feature_points",
            ]
            if strata_config_mode == "empty":
                required_strata = []
            elif strata_config_mode == "missing_one":
                required_strata.remove("feature_points")
            config["release_acceptance"]["required_strata"] = required_strata
        if feedback_required_mode != "missing":
            config["release_acceptance"]["feedback_patterns_required"] = feedback_required_mode == "true"
        if multi_review_required_mode != "missing":
            config["release_acceptance"]["multi_round_review_required"] = multi_review_required_mode == "true"
        if multi_agent_review_required_mode != "missing":
            config["release_acceptance"]["multi_agent_review_required"] = \
                multi_agent_review_required_mode == "true"
        config["release_acceptance"].update({
            "feedback_patterns_file": "工作底稿/反馈模式账本.json",
            "multi_round_review_file": "工作底稿/多轮测试用例评审.json",
            "review_control": {
                "execution_mode": "manual",
                "scope_lock_required": True,
                "max_revision_batches": 2,
            },
            "changed_case_ids_file": "changed_case_ids.json",
            "conflict_index_file": "冲突矩阵索引.json",
            "strata_not_applicable": {
                "pending_confirmation": "当前已确认需求和用例中不存在待确认项",
                "conflict_cases": "当前回归夹具没有交叉或冲突用例",
            },
        })
        (root / "changed_case_ids.json").write_text(
            json.dumps({"changed_case_ids": ["QA_001"]}), encoding="utf-8"
        )
        (root / "冲突矩阵索引.json").write_text(
            json.dumps({
                "schema_version": 1,
                "items": [{
                    "matrix_key": "无交叉动作|标准状态",
                    "action": "无交叉动作",
                    "state": "标准状态",
                    "status": "not_applicable",
                    "coverage_kind": "not_applicable",
                    "reason": "当前回归夹具没有交叉或冲突场景",
                }],
            }, ensure_ascii=False), encoding="utf-8"
        )
        scenario_dimensions = config["quality_gates"]["scenario_coverage"]["expected_dimensions"]
        (root / "场景覆盖矩阵.json").write_text(
            json.dumps({
                "schema_version": 1,
                "items": [
                    {
                        "module": "录音",
                        "dimension": dimension,
                        "status": "covered" if dimension == "主流程与业务规则" else "not_applicable",
                        "case_ids": ["QA_001"] if dimension == "主流程与业务规则" else [],
                        "reason": "录音入口主流程已由 QA_001 覆盖" if dimension == "主流程与业务规则"
                        else "当前单用例回归夹具不验证该扩展场景维度",
                    }
                    for dimension in scenario_dimensions
                ],
            }, ensure_ascii=False), encoding="utf-8"
        )
        if quality_profile_mode == "empty":
            config["quality_gates"] = {}
        elif quality_profile_mode == "missing_manual_contract":
            config["quality_gates"].pop("functional_manual_contract", None)
        elif quality_profile_mode == "missing_one":
            config["release_acceptance"]["quality_gate_not_applicable"].pop("navigation_expectations", None)
        elif quality_profile_mode == "waived_one":
            pass
        elif quality_profile_mode == "blank_waiver":
            config["release_acceptance"]["quality_gate_not_applicable"]["navigation_expectations"] = ""
        config["release_acceptance"]["delivery_artifact"] = {
            "path": "delivery_v1.0.xlsx",
            "module": "录音",
            "expected_version": "v1.0",
            "quality_gates": valid_delivery_gates(),
            "projection": {
                "mode": "exact",
                "fields": list(release.REQUIRED_DELIVERY_PROJECTION_FIELDS),
            },
        }
        if delivery_artifact_mode == "missing_config":
            config["release_acceptance"].pop("delivery_artifact", None)
        elif delivery_artifact_mode == "waived":
            config["release_acceptance"].pop("delivery_artifact", None)
            config["release_acceptance"]["quality_gate_not_applicable"]["delivery_artifact"] = \
                "当前回归试图豁免最终用户交付表"
        elif delivery_artifact_mode == "failing_quality":
            config["release_acceptance"]["delivery_artifact"]["quality_gates"] \
                ["test_item_taxonomy"]["forbidden_generic_items"].append("入口路径")
        elif delivery_artifact_mode == "disabled_workbook":
            config["release_acceptance"]["delivery_artifact"]["quality_gates"] \
                ["delivery_workbook"]["require_black_borders"] = False
        elif delivery_artifact_mode == "disabled_taxonomy":
            config["release_acceptance"]["delivery_artifact"]["quality_gates"] \
                ["test_item_taxonomy"]["forbidden_generic_items"] = []
        elif delivery_artifact_mode == "disabled_granularity":
            config["release_acceptance"]["delivery_artifact"]["quality_gates"] \
                ["case_granularity"]["forbid_grouped_scenarios"] = False
        elif delivery_artifact_mode == "disabled_cross":
            config["release_acceptance"]["delivery_artifact"]["quality_gates"] \
                ["cross_scene_block"]["cross_items"] = []
        elif delivery_artifact_mode == "disabled_scale":
            config["release_acceptance"]["delivery_artifact"]["quality_gates"] \
                ["case_scale"]["required"] = False
        elif delivery_artifact_mode == "disabled_hierarchy":
            config["release_acceptance"]["delivery_artifact"]["quality_gates"] \
                ["hierarchy_mapping"]["required"] = False
        elif delivery_artifact_mode == "empty_projection_fields":
            config["release_acceptance"]["delivery_artifact"]["projection"]["fields"] = []
        if feedback_ledger_mode != "missing":
            if feedback_ledger_mode == "empty_declared":
                feedback_ledger = {
                    "patterns": [],
                    "no_feedback_recorded": True,
                    "note": "当前项目尚未收到用户反馈，保留空账本并执行门禁",
                    "input_xlsx_sha256": release.sha256(root / "cases.xlsx"),
                }
            elif feedback_ledger_mode == "empty_undeclared":
                feedback_ledger = {"patterns": []}
            else:
                feedback_ledger = {"patterns": [{
                    "pattern_id": "FB-001",
                    "reported_case_ids": ["QA_001"],
                    "scope": "all_project",
                    "scan_status": "passed",
                    "scanned_case_count": len(canonical_rows),
                    "matched_case_ids": ["QA_001"],
                    "resolved_case_ids": ["QA_001"],
                    "evidence": "已按本次反馈模式扫描当前全部用例并完成修复",
                    "input_xlsx_sha256": release.sha256(root / "cases.xlsx"),
                }]}
            (root / "工作底稿" / "反馈模式账本.json").write_text(
                json.dumps(feedback_ledger, ensure_ascii=False), encoding="utf-8"
            )
        if multi_review_ledger_mode != "missing":
            current_hash = release.sha256(root / "cases.xlsx")
            ledger_hash = "0" * 64 if multi_review_ledger_mode == "stale" else current_hash
            review_rounds = [
                {
                    "round_id": "R1",
                    "review_type": "coverage_design",
                    "review_perspective": "需求覆盖与测试设计",
                    "scope": "all_project",
                    "input_xlsx_sha256": current_hash,
                    "reviewed_case_count": len(canonical_rows),
                    "finding_counts": {"blocker": 0, "major": 0, "minor": 0},
                    "findings": [],
                    "evidence": "已对照需求和场景矩阵完成全量设计评审",
                    "status": "completed",
                },
                {
                    "round_id": "R2",
                    "review_type": "execution_detail",
                    "review_perspective": "首次执行人员",
                    "scope": "all_project",
                    "input_xlsx_sha256": current_hash,
                    "reviewed_case_count": len(canonical_rows),
                    "finding_counts": {"blocker": 0, "major": 0, "minor": 0},
                    "findings": [],
                    "evidence": "已逐条检查前置、动作、数据和可观察预期",
                    "status": "completed",
                },
                {
                    "round_id": "R3",
                    "review_type": "adversarial",
                    "review_perspective": "反向挑错",
                    "scope": "all_project",
                    "input_xlsx_sha256": current_hash,
                    "reviewed_case_count": len(canonical_rows),
                    "finding_counts": {"blocker": 0, "major": 0, "minor": 0},
                    "findings": [],
                    "evidence": "已从误操作和故障状态反向验证全部用例",
                    "status": "completed",
                },
                {
                    "round_id": "R4",
                    "review_type": "regression",
                    "review_perspective": "修订回归",
                    "scope": "all_project",
                    "input_xlsx_sha256": current_hash,
                    "reviewed_case_count": len(canonical_rows),
                    "finding_counts": {"blocker": 0, "major": 0, "minor": 0},
                    "findings": [],
                    "evidence": "已重新打开当前Excel并全量回归检查",
                    "status": "completed",
                },
            ]
            prd_hash = release.sha256(root / "prd.md")
            review_rounds[-2]["agent_reviews"] = [
                write_agent_review_report(
                    root, round_id="R3", review_type="adversarial",
                    role="adversarial-risk", workbook_hash=current_hash, prd_hash=prd_hash,
                ),
                write_agent_review_report(
                    root, round_id="R3", review_type="adversarial",
                    role="adversarial-execution", workbook_hash=current_hash, prd_hash=prd_hash,
                ),
            ]
            review_rounds[-1]["agent_reviews"] = [
                write_agent_review_report(
                    root, round_id="R4", review_type="regression",
                    role="regression-blind", workbook_hash=current_hash, prd_hash=prd_hash,
                ),
                write_agent_review_report(
                    root, round_id="R4", review_type="regression",
                    role="regression-targeted", workbook_hash=current_hash, prd_hash=prd_hash,
                ),
            ]
            if multi_review_ledger_mode == "one_clean_round":
                review_rounds[-2]["finding_counts"]["major"] = 1
                review_rounds[-2]["findings"] = [{
                    "finding_id": "MR-001",
                    "severity": "major",
                    "category": "执行确定性",
                    "case_ids": ["QA_001"],
                    "description": "步骤缺少确定测试数据",
                    "status": "resolved",
                    "resolution": "补充确定测试数据",
                }]
            multi_review_ledger = {
                "schema_version": 2,
                "input_xlsx_sha256": ledger_hash,
                "prd_sha256": prd_hash,
                "case_ids_sha256": case_ids_sha256(["QA_001"]),
                "case_count": len(canonical_rows),
                "generator_agent_ids": ["release-agent-generator"],
                "reviser_agent_ids": ["release-agent-reviser"],
                "review_control": {
                    "execution_mode": "manual",
                    "scope_lock": {
                        "status": "locked",
                        "prd_scope": "当前回归夹具只覆盖录音入口需求",
                        "blueprint": "用例设计蓝图.json 中的录音入口层级",
                        "input_xlsx_sha256": current_hash,
                        "evidence": "已在评审前锁定PRD范围、蓝图和当前Excel哈希",
                    },
                    "revision_batch_count": 0,
                },
                "required_review_types": [
                    "coverage_design", "execution_detail", "adversarial", "regression",
                ],
                "rounds": review_rounds,
                "consecutive_clean_rounds": 1 if multi_review_ledger_mode == "one_clean_round" else 4,
                "remaining_findings": [],
                "visual_inspection": {
                    "status": "passed",
                    "input_xlsx_sha256": current_hash,
                    "checked_items": ["文字完整显示", "层级合并", "边框与字体", "冻结与筛选"],
                    "evidence": "已重新打开最终Excel并检查数据区域和显示效果",
                },
                "final_status": "PASS",
            }
            if multi_review_ledger_mode == "legacy_v1":
                multi_review_ledger["schema_version"] = 1
                for key in ("prd_sha256", "case_ids_sha256", "generator_agent_ids", "reviser_agent_ids"):
                    multi_review_ledger.pop(key, None)
                for round_row in multi_review_ledger["rounds"]:
                    round_row.pop("agent_reviews", None)
            (root / "工作底稿" / "多轮测试用例评审.json").write_text(
                json.dumps(multi_review_ledger, ensure_ascii=False), encoding="utf-8"
            )
    if decision_ledger:
        config["release_acceptance"]["decision_ledger_file"] = "工作底稿/需求决策账本.json"
        if decision_ledger == "conflict":
            ledger = {
                "schema_version": 1,
                "items": [
                    {"decision_id": "D1", "req_id": "REQ-1", "action": "direct_covered", "status": "current"},
                    {"decision_id": "D2", "req_id": "REQ-1", "action": "keep_partial", "status": "current"},
                ],
            }
        elif decision_ledger == "broken_supersession":
            ledger = {
                "schema_version": 1,
                "items": [
                    {"decision_id": "D1", "req_id": "REQ-1", "action": "keep_partial", "status": "superseded"},
                    {"decision_id": "D2", "req_id": "REQ-1", "action": "direct_covered", "status": "current"},
                ],
            }
        elif decision_ledger == "missing_current":
            ledger = {
                "schema_version": 1,
                "items": [
                    {"decision_id": "D1", "req_id": "REQ-FAKE", "action": "direct_covered", "status": "current"},
                ],
            }
        elif decision_ledger == "unknown_req":
            ledger = {
                "schema_version": 1,
                "items": [
                    {"decision_id": "D1", "req_id": "REQ-1", "action": "direct_covered", "status": "current"},
                    {"decision_id": "D2", "req_id": "REQ-FAKE", "action": "direct_covered", "status": "current"},
                ],
            }
        else:
            ledger = {
                "schema_version": 1,
                "items": [
                    {"decision_id": "D1", "req_id": "REQ-1", "action": "keep_partial", "status": "superseded", "superseded_by": "D2"},
                    {"decision_id": "D2", "req_id": "REQ-1", "action": "direct_covered", "status": "current"},
                ],
            }
        (root / "工作底稿" / "需求决策账本.json").write_text(
            json.dumps(ledger, ensure_ascii=False), encoding="utf-8"
        )
    path = root / "trace.config.json"
    path.write_text(json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8")
    if pilot_evidence:
        (root / "specs").mkdir()
        spec_path = root / "specs" / "录音.json"
        spec_path.write_text(json.dumps({"module": "录音", "cases": []}, ensure_ascii=False), encoding="utf-8")
        (root / "用例设计蓝图.json").write_text(json.dumps({
            "module_boundary": {"录音": "录音入口与页面主流程"},
            "feature_order": {"录音": ["入口"]},
            "page_state_anchors": {},
            "input_matrix": {},
            "exception_matrix": [],
            "cross_matrix": [],
            "common_fixtures": {},
            "case_precondition_rules": ["每条用例写明独有可执行状态"],
            "unsupported_features": [],
            "complexity_profile": {
                "录音": {
                    "rationale": "单用例回归夹具只验证录音入口发布链路",
                    "main_flows": ["进入录音页面"],
                    "states_and_modes": {"status": "not_applicable", "reason": "没有状态或模式分支"},
                    "rules_and_boundaries": {"status": "not_applicable", "reason": "没有规则或边界"},
                    "exceptions_and_recovery": {"status": "not_applicable", "reason": "没有异常恢复"},
                    "cross_scenarios": {"status": "not_applicable", "reason": "没有交叉场景"},
                    "data_and_sync": {"status": "not_applicable", "reason": "没有数据同步"},
                    "compatibility": {"status": "not_applicable", "reason": "没有兼容范围"},
                }
            },
            "hierarchy_map": {"录音": {"入口": {"入口路径": {"intent_keywords": ["录音", "页面"]}}}},
        }, ensure_ascii=False), encoding="utf-8")
        lineage.record_casegen(root)
        lineage.record_export(root, root / "cases.xlsx", root / "用例稳定索引.json")
        lineage.record_trace(root, root / "cases.xlsx", root / "工作底稿" / "追溯")
        result_path = root / "结果" / "录音.json"
        result_payload = json.loads(result_path.read_text(encoding="utf-8"))
        if result_binding_mode != "missing":
            binding = lineage.result_binding(root, root / "工作底稿" / "追溯" / "录音.json")
            if result_binding_mode == "wrong_draft":
                binding["draft_sha256"] = "0" * 64
            result_payload["_lineage"] = binding
        result_path.write_text(json.dumps(result_payload, ensure_ascii=False), encoding="utf-8")
        if not defer_result_finalize:
            lineage.record_results(root, [result_path])
        if touch_result_after_build:
            import os
            future = time.time() + 60
            os.utime(result_path, (future, future))
        if mutate_prd_after_build:
            (root / "prd.md").write_text("# PRD changed\n", encoding="utf-8")
        if mutate_result_after_finalize:
            changed_result = json.loads(result_path.read_text(encoding="utf-8"))
            changed_result["items"][0]["note"] = "tampered after finalize"
            result_path.write_text(json.dumps(changed_result, ensure_ascii=False), encoding="utf-8")
        if reexport_after_finalize:
            lineage.record_export(root, root / "cases.xlsx", root / "用例稳定索引.json")
        if extra_result_file:
            (root / "结果" / "旧模块.json").write_text(json.dumps({"module": "旧模块", "items": []}), encoding="utf-8")
        if judgment_mode:
            draft_path = root / "工作底稿" / "追溯" / "录音.json"
            old_binding = lineage.result_binding(root, draft_path)
            if judgment_mode == "old":
                changed_draft = json.loads(draft_path.read_text(encoding="utf-8"))
                changed_draft["requirements"][0]["text"] = "录音入口新规则"
                draft_path.write_text(json.dumps(changed_draft, ensure_ascii=False), encoding="utf-8")
                lineage.record_trace(root, root / "cases.xlsx", draft_path.parent, [draft_path])
            else:
                lineage.record_trace(root, root / "cases.xlsx", draft_path.parent, [draft_path])
            (root / "结果" / "录音.json").unlink(missing_ok=True)
            judgment = {
                "module": "录音",
                "verdicts": {"REQ-1": ["已覆盖", ["QA_001"], ""]},
            }
            if judgment_mode == "current":
                judgment["_lineage"] = lineage.result_binding(root, draft_path)
            elif judgment_mode == "old":
                judgment["_lineage"] = old_binding
            (root / "judgments").mkdir()
            (root / "judgments" / "录音.json").write_text(
                json.dumps(judgment, ensure_ascii=False, indent=2), encoding="utf-8"
            )
        if mutate_spec_after_build:
            spec_path.write_text(json.dumps({"module": "录音", "cases": [], "changed": True}, ensure_ascii=False), encoding="utf-8")
    write_required_report(
        root, path, report_hash_mode, stale_report=stale_report,
        report_status=required_report_status,
        risk_count=required_report_risk_count,
        warning_count=required_report_warning_count,
    )
    return path


def main() -> None:
    results = []
    errors = []
    with tempfile.TemporaryDirectory(prefix="release-acceptance-") as tmp:
        base = Path(tmp)
        for name, kwargs, expected in (
            ("pass", {}, "PASS"),
            ("gate_b_partial_fails", {"partial": True}, "FAIL"),
            ("missing_result_reference_fails", {"ghost": True}, "FAIL"),
            ("stale_required_report_fails", {"stale_report": True}, "FAIL"),
            ("new_project_empty_required_reports_fails", {"new_project_without_reports": True, "pilot_evidence": True}, "FAIL"),
            ("schema_v1_required_contract_remains_legacy_compatible", {"legacy_contract_required": True}, "PASS"),
            ("pilot_evidence_is_hashed", {"pilot_evidence": True}, "PASS"),
            ("schema_v3_lineage_complete_passes", {"pilot_evidence": True}, "PASS"),
            ("schema_v3_spec_change_without_rebuild_fails", {"pilot_evidence": True, "mutate_spec_after_build": True}, "FAIL"),
            ("schema_v3_result_missing_binding_fails", {"pilot_evidence": True, "result_binding_mode": "missing"}, "FAIL"),
            ("schema_v3_result_wrong_draft_binding_fails", {"pilot_evidence": True, "result_binding_mode": "wrong_draft"}, "FAIL"),
            ("schema_v3_old_result_touch_without_binding_fails", {"pilot_evidence": True, "result_binding_mode": "missing", "touch_result_after_build": True}, "FAIL"),
            ("schema_v3_prd_change_without_trace_rebuild_fails", {"pilot_evidence": True, "mutate_prd_after_build": True}, "FAIL"),
            ("schema_v3_result_tamper_after_finalize_fails", {"pilot_evidence": True, "mutate_result_after_finalize": True}, "FAIL"),
            ("schema_v3_scaffold_default_draft_path_passes", {"pilot_evidence": True, "scaffold_default_paths": True}, "PASS"),
            ("schema_v3_explicit_finalize_existing_passes", {"pilot_evidence": True, "defer_result_finalize": True}, "PASS"),
            ("schema_v3_reexport_invalidates_downstream_fails", {"pilot_evidence": True, "reexport_after_finalize": True}, "FAIL"),
            ("schema_v3_extra_result_module_fails", {"pilot_evidence": True, "extra_result_file": True}, "FAIL"),
            ("schema_v3_current_judgment_binding_passes", {"pilot_evidence": True, "judgment_mode": "current"}, "PASS"),
            ("schema_v3_missing_judgment_binding_fails", {"pilot_evidence": True, "judgment_mode": "missing"}, "FAIL"),
            ("schema_v3_old_judgment_binding_fails", {"pilot_evidence": True, "judgment_mode": "old"}, "FAIL"),
            ("schema_v3_external_prd_path_fails_clearly", {"pilot_evidence": True, "external_prd": True}, "FAIL"),
            ("schema_v3_without_configured_ledger_fails", {"pilot_evidence": True, "production_without_ledger": True}, "FAIL"),
            ("schema_v3_required_strata_missing_fails", {"pilot_evidence": True, "strata_config_mode": "missing"}, "FAIL"),
            ("schema_v3_required_strata_empty_fails", {"pilot_evidence": True, "strata_config_mode": "empty"}, "FAIL"),
            ("schema_v3_required_strata_incomplete_fails", {"pilot_evidence": True, "strata_config_mode": "missing_one"}, "FAIL"),
            ("schema_v3_feedback_required_missing_fails", {"pilot_evidence": True, "feedback_required_mode": "missing"}, "FAIL"),
            ("schema_v3_feedback_required_false_fails", {"pilot_evidence": True, "feedback_required_mode": "false"}, "FAIL"),
            ("schema_v3_without_multi_agent_config_must_migrate", {"pilot_evidence": True, "multi_review_required_mode": "missing", "multi_agent_review_required_mode": "missing", "multi_review_ledger_mode": "missing"}, "FAIL"),
            ("schema_v3_multi_review_required_false_fails", {"pilot_evidence": True, "multi_review_required_mode": "false"}, "FAIL"),
            ("schema_v3_multi_agent_review_required_false_fails", {"pilot_evidence": True, "multi_agent_review_required_mode": "false"}, "FAIL"),
            ("schema_v3_multi_agent_review_v1_ledger_fails", {"pilot_evidence": True, "multi_agent_review_required_mode": "true", "multi_review_ledger_mode": "legacy_v1"}, "FAIL"),
            ("schema_v3_multi_review_ledger_missing_fails", {"pilot_evidence": True, "multi_review_ledger_mode": "missing"}, "FAIL"),
            ("schema_v3_multi_review_ledger_stale_fails", {"pilot_evidence": True, "multi_review_ledger_mode": "stale"}, "FAIL"),
            ("schema_v3_multi_review_not_converged_fails", {"pilot_evidence": True, "multi_review_ledger_mode": "one_clean_round"}, "FAIL"),
            ("schema_v3_declared_empty_feedback_ledger_passes", {"pilot_evidence": True, "feedback_ledger_mode": "empty_declared"}, "PASS"),
            ("schema_v3_undeclared_empty_feedback_ledger_fails", {"pilot_evidence": True, "feedback_ledger_mode": "empty_undeclared"}, "FAIL"),
            ("schema_v3_quality_gates_empty_fails", {"pilot_evidence": True, "quality_profile_mode": "empty"}, "FAIL"),
            ("schema_v3_functional_manual_contract_missing_fails", {"pilot_evidence": True, "quality_profile_mode": "missing_manual_contract"}, "FAIL"),
            ("schema_v3_quality_gate_missing_fails", {"pilot_evidence": True, "quality_profile_mode": "missing_one"}, "FAIL"),
            ("schema_v3_quality_gate_concrete_na_passes", {"pilot_evidence": True, "quality_profile_mode": "waived_one"}, "PASS"),
            ("schema_v3_quality_gate_blank_na_fails", {"pilot_evidence": True, "quality_profile_mode": "blank_waiver"}, "FAIL"),
            ("schema_v3_delivery_artifact_config_missing_fails", {"pilot_evidence": True, "delivery_artifact_mode": "missing_config"}, "FAIL"),
            ("schema_v3_delivery_artifact_waiver_is_forbidden", {"pilot_evidence": True, "delivery_artifact_mode": "waived"}, "FAIL"),
            ("schema_v3_delivery_artifact_quality_failure_blocks_release", {"pilot_evidence": True, "delivery_artifact_mode": "failing_quality"}, "FAIL"),
            ("schema_v3_delivery_workbook_checks_cannot_be_disabled", {"pilot_evidence": True, "delivery_artifact_mode": "disabled_workbook"}, "FAIL"),
            ("schema_v3_delivery_taxonomy_cannot_be_emptied", {"pilot_evidence": True, "delivery_artifact_mode": "disabled_taxonomy"}, "FAIL"),
            ("schema_v3_delivery_granularity_cannot_be_disabled", {"pilot_evidence": True, "delivery_artifact_mode": "disabled_granularity"}, "FAIL"),
            ("schema_v3_delivery_cross_items_cannot_be_empty", {"pilot_evidence": True, "delivery_artifact_mode": "disabled_cross"}, "FAIL"),
            ("schema_v3_delivery_scale_cannot_be_disabled", {"pilot_evidence": True, "delivery_artifact_mode": "disabled_scale"}, "FAIL"),
            ("schema_v3_delivery_hierarchy_cannot_be_disabled", {"pilot_evidence": True, "delivery_artifact_mode": "disabled_hierarchy"}, "FAIL"),
            ("schema_v3_delivery_projection_fields_cannot_be_empty", {"pilot_evidence": True, "delivery_artifact_mode": "empty_projection_fields"}, "FAIL"),
            ("schema_v3_delivery_missing_case_fails", {"pilot_evidence": True, "delivery_artifact_mode": "missing_case"}, "FAIL"),
            ("schema_v3_delivery_extra_case_fails", {"pilot_evidence": True, "delivery_artifact_mode": "extra_case"}, "FAIL"),
            ("schema_v3_delivery_reordered_cases_fail", {"pilot_evidence": True, "delivery_artifact_mode": "reordered"}, "FAIL"),
            ("schema_v3_delivery_content_drift_fails", {"pilot_evidence": True, "delivery_artifact_mode": "content_drift"}, "FAIL"),
            ("schema_v3_delivery_artifact_valid_and_hashed", {"pilot_evidence": True}, "PASS"),
            ("schema_v3_complete_strata_feedback_and_valid_na_passes", {"pilot_evidence": True}, "PASS"),
            ("decision_current_conflict_fails", {"decision_ledger": "conflict"}, "FAIL"),
            ("broken_supersession_fails", {"decision_ledger": "broken_supersession"}, "FAIL"),
            ("valid_supersession_passes", {"decision_ledger": "valid"}, "PASS"),
            ("decision_missing_current_requirement_fails", {"decision_ledger": "missing_current"}, "FAIL"),
            ("decision_unknown_requirement_fails", {"decision_ledger": "unknown_req"}, "FAIL"),
            ("missing_report_input_hashes_fail", {"report_hash_mode": "missing"}, "FAIL"),
            ("empty_report_input_hashes_fail", {"report_hash_mode": "empty"}, "FAIL"),
            ("configured_report_hash_coverage_missing_fails", {"report_hash_mode": "configured_partial"}, "FAIL"),
            ("default_report_hash_coverage_missing_fails", {"report_hash_mode": "default_partial"}, "FAIL"),
            ("configured_report_hash_coverage_passes", {"report_hash_mode": "configured_full"}, "PASS"),
            (
                "accepted_required_report_findings_are_preserved",
                {
                    "required_report_status": "PASS_WITH_RISKS",
                    "required_report_risk_count": 1,
                    "required_report_warning_count": 1,
                },
                "PASS_WITH_RISKS",
            ),
        ):
            root = base / name
            root.mkdir()
            try:
                config = build(root, **kwargs)
            except lineage.LineageError as exc:
                if name == "schema_v3_external_prd_path_fails_clearly":
                    passed = "必须位于项目目录内" in str(exc)
                    results.append({"name": name, "passed": passed, "status": "FAIL", "issues": [{"code": "BUILD_LINEAGE_INVALID", "message": str(exc)}]})
                    if not passed:
                        errors.append(name)
                    continue
                raise
            finalize_proc = None
            judgment_proc = None
            if name == "schema_v3_explicit_finalize_existing_passes":
                finalize_proc = subprocess.run(
                    [sys.executable, str(SCRIPTS / "judge_build.py"), "--project", str(root), "--finalize-existing"],
                    cwd=SCRIPTS.parent, text=True, capture_output=True, encoding="utf-8", errors="replace",
                )
                if finalize_proc.returncode == 0:
                    write_required_report(root, config, kwargs.get("report_hash_mode", ""))
            if name.startswith("schema_v3_") and "judgment_binding" in name:
                judgment_proc = subprocess.run(
                    [sys.executable, str(SCRIPTS / "judge_build.py"), "--project", str(root)],
                    cwd=SCRIPTS.parent, text=True, capture_output=True, encoding="utf-8", errors="replace",
                )
                if judgment_proc.returncode == 0:
                    write_required_report(root, config, kwargs.get("report_hash_mode", ""))
            report, first_path = release.evaluate(config)
            passed = report["status"] == expected
            accepted = expected in {"PASS", "PASS_WITH_RISKS"}
            passed = passed and report.get("release_decision") == ("GO" if accepted else "NO_GO")
            passed = passed and report.get("readiness_level") == (
                "READY_WITH_RISKS" if expected == "PASS_WITH_RISKS" else (
                    "STRICT_GO" if expected == "PASS" else "DRAFT"
                )
            )
            passed = passed and report.get("delivery_status") == (
                "READY_WITH_RISKS" if expected == "PASS_WITH_RISKS" else (
                    "STRICT_GO" if expected == "PASS" else "NO_GO"
                )
            )
            if name == "accepted_required_report_findings_are_preserved":
                passed = passed and report.get("risk_count") == 1 \
                    and report.get("warning_count") == 1 \
                    and report.get("blocking_count") == 0 \
                    and {row.get("severity") for row in report.get("issues", [])} == {"risk", "warning"} \
                    and all(
                        row.get("details", {}).get("source_report", "").endswith("report.json")
                        for row in report.get("issues", [])
                    )
            if finalize_proc is not None:
                passed = passed and finalize_proc.returncode == 0
            if name == "schema_v3_current_judgment_binding_passes":
                passed = passed and judgment_proc is not None and judgment_proc.returncode == 0
            if name in {"schema_v3_missing_judgment_binding_fails", "schema_v3_old_judgment_binding_fails"}:
                passed = passed and judgment_proc is not None and judgment_proc.returncode != 0 and \
                    "judgment 未密码学绑定当前 draft" in judgment_proc.stdout + judgment_proc.stderr
            if name == "pass":
                second, second_path = release.evaluate(config)
                passed = passed and second["status"] == "PASS" and first_path != second_path and first_path.exists() and second_path.exists()
            if name == "pilot_evidence_is_hashed":
                evidence_keys = {key for key in report["input_hashes"] if key.startswith("evidence/")}
                passed = passed and len(evidence_keys) == 4 and report["metrics"]["pilot_risk_evidence_files"] == 4
            if name == "schema_v3_lineage_complete_passes":
                agent_report_keys = {
                    key for key in report["input_hashes"]
                    if key.startswith("工作底稿/agent_reviews/")
                }
                passed = passed and report["metrics"].get("lineage_valid") is True \
                    and len(agent_report_keys) == 4
            if name == "schema_v3_delivery_artifact_valid_and_hashed":
                delivery_hashes = {
                    key: value for key, value in report["input_hashes"].items()
                    if key.endswith("delivery_v1.0.xlsx")
                }
                passed = passed and len(delivery_hashes) == 1 \
                    and report["metrics"].get("delivery_sha256") in set(delivery_hashes.values()) \
                    and report["metrics"].get("delivery_projection_difference_count") == 0
            expected_codes = {
                "schema_v3_without_configured_ledger_fails": "DECISION_LEDGER_REQUIRED",
                "schema_v3_required_strata_missing_fails": "REQUIRED_STRATA_CONFIG_MISSING",
                "schema_v3_required_strata_empty_fails": "REQUIRED_STRATA_CONFIG_EMPTY",
                "schema_v3_required_strata_incomplete_fails": "REQUIRED_STRATA_CONFIG_INCOMPLETE",
                "schema_v3_feedback_required_missing_fails": "FEEDBACK_PATTERNS_REQUIRED_CONFIG_MISSING",
                "schema_v3_feedback_required_false_fails": "FEEDBACK_PATTERNS_REQUIRED_CONFIG_FALSE",
                "schema_v3_without_multi_agent_config_must_migrate": "MULTI_ROUND_REVIEW_REQUIRED_CONFIG_MISSING",
                "schema_v3_multi_review_required_false_fails": "MULTI_ROUND_REVIEW_REQUIRED_CONFIG_FALSE",
                "schema_v3_multi_agent_review_required_false_fails": "MULTI_AGENT_REVIEW_REQUIRED_CONFIG_FALSE",
                "schema_v3_multi_agent_review_v1_ledger_fails": "GATE_FAILED",
                "schema_v3_multi_review_ledger_missing_fails": "GATE_FAILED",
                "schema_v3_multi_review_ledger_stale_fails": "GATE_FAILED",
                "schema_v3_multi_review_not_converged_fails": "GATE_FAILED",
                "schema_v3_undeclared_empty_feedback_ledger_fails": "GATE_FAILED",
                "schema_v3_quality_gates_empty_fails": "QUALITY_GATES_PROFILE_REQUIRED",
                "schema_v3_functional_manual_contract_missing_fails": "QUALITY_GATE_FUNCTIONAL_MANUAL_CONTRACT_INVALID",
                "schema_v3_quality_gate_missing_fails": "QUALITY_GATE_CONFIG_MISSING",
                "schema_v3_quality_gate_blank_na_fails": "QUALITY_GATE_CONFIG_MISSING",
                "schema_v3_delivery_artifact_config_missing_fails": "DELIVERY_ARTIFACT_CONFIG_MISSING",
                "schema_v3_delivery_artifact_waiver_is_forbidden": "DELIVERY_ARTIFACT_WAIVER_FORBIDDEN",
                "schema_v3_delivery_artifact_quality_failure_blocks_release": "DELIVERY_QUALITY_FAILED",
                "schema_v3_delivery_workbook_checks_cannot_be_disabled": "DELIVERY_WORKBOOK_PROFILE_DISABLED",
                "schema_v3_delivery_taxonomy_cannot_be_emptied": "DELIVERY_TAXONOMY_PROFILE_DISABLED",
                "schema_v3_delivery_granularity_cannot_be_disabled": "DELIVERY_GRANULARITY_PROFILE_DISABLED",
                "schema_v3_delivery_cross_items_cannot_be_empty": "DELIVERY_CROSS_BLOCK_PROFILE_DISABLED",
                "schema_v3_delivery_scale_cannot_be_disabled": "DELIVERY_SCALE_PROFILE_DISABLED",
                "schema_v3_delivery_hierarchy_cannot_be_disabled": "DELIVERY_HIERARCHY_PROFILE_DISABLED",
                "schema_v3_delivery_projection_fields_cannot_be_empty": "DELIVERY_PROJECTION_FIELDS_INCOMPLETE",
                "schema_v3_delivery_missing_case_fails": "DELIVERY_CASE_SEQUENCE_MISMATCH",
                "schema_v3_delivery_extra_case_fails": "DELIVERY_CASE_SEQUENCE_MISMATCH",
                "schema_v3_delivery_reordered_cases_fail": "DELIVERY_CASE_SEQUENCE_MISMATCH",
                "schema_v3_delivery_content_drift_fails": "DELIVERY_CASE_CONTENT_MISMATCH",
                "stale_required_report_fails": "REQUIRED_REPORT_STALE_HASH",
                "decision_missing_current_requirement_fails": "DECISION_CURRENT_MISSING",
                "decision_unknown_requirement_fails": "DECISION_REQ_UNKNOWN",
                "missing_report_input_hashes_fail": "REQUIRED_REPORT_HASHES_MISSING",
                "empty_report_input_hashes_fail": "REQUIRED_REPORT_HASHES_EMPTY",
                "configured_report_hash_coverage_missing_fails": "REQUIRED_REPORT_HASH_COVERAGE_MISSING",
                "default_report_hash_coverage_missing_fails": "REQUIRED_REPORT_HASH_COVERAGE_MISSING",
                "schema_v3_spec_change_without_rebuild_fails": "BUILD_LINEAGE_INVALID",
                "schema_v3_result_missing_binding_fails": "BUILD_LINEAGE_INVALID",
                "schema_v3_result_wrong_draft_binding_fails": "BUILD_LINEAGE_INVALID",
                "schema_v3_old_result_touch_without_binding_fails": "BUILD_LINEAGE_INVALID",
                "schema_v3_prd_change_without_trace_rebuild_fails": "BUILD_LINEAGE_INVALID",
                "schema_v3_result_tamper_after_finalize_fails": "BUILD_LINEAGE_INVALID",
                "schema_v3_reexport_invalidates_downstream_fails": "BUILD_LINEAGE_INVALID",
                "schema_v3_extra_result_module_fails": "BUILD_LINEAGE_INVALID",
            }
            if name in expected_codes:
                passed = passed and expected_codes[name] in {item.get("code") for item in report["issues"]}
            results.append({"name": name, "passed": passed, "status": report["status"], "issues": report["issues"]})
            if not passed:
                errors.append(name)

        for mode, expected_readiness, expected_commands in (
            ("core", "READY_FOR_REVIEW", {"gate_c", "execution_quality", "feedback_patterns"}),
            (
                "strict",
                "STRICT_GO",
                {
                    "gate_c", "gate_b", "execution_quality", "feedback_patterns",
                    "multi_round_review", "stratified_sample",
                },
            ),
        ):
            name = f"new_profile_{mode}_shadow_release_passes"
            root = base / name
            root.mkdir()
            config_path = build(root, pilot_evidence=True)
            config = json.loads(config_path.read_text(encoding="utf-8"))
            profile = execution_profile.build_profile(
                requested_mode=mode,
                work_units=["录音"],
            )
            if mode == "core":
                config["quality_gates"].update(copy.deepcopy(
                    config["release_acceptance"]["delivery_artifact"]["quality_gates"]
                ))
                blueprint_path = root / "用例设计蓝图.json"
                blueprint = json.loads(blueprint_path.read_text(encoding="utf-8"))
                blueprint["platform_scope"] = []
                blueprint["main_risks"] = []
                blueprint_path.write_text(
                    json.dumps(blueprint, ensure_ascii=False, indent=2), encoding="utf-8"
                )
                versioned_xlsx = root / "cases_v1.0.xlsx"
                shutil.copyfile(root / "cases.xlsx", versioned_xlsx)
                config["cases_xlsx"] = versioned_xlsx.name
            config = execution_profile.apply_profile_to_config(config, profile)
            execution_gate = copy.deepcopy(
                new_project.CONFIG_TEMPLATE["quality_gates"]["execution_quality"]
            )
            config["quality_gates"]["execution_quality"] = execution_gate
            config["release_acceptance"]["delivery_artifact"]["quality_gates"] \
                ["execution_quality"] = copy.deepcopy(execution_gate)
            blueprint_path = root / "用例设计蓝图.json"
            blueprint = json.loads(blueprint_path.read_text(encoding="utf-8"))
            blueprint["module_boundary"] = {
                "录音": {
                    "scope": "验证录音入口和录音页面主流程",
                    "owned_outcome_keywords": ["录音", "页面"],
                    "foreign_feature_keywords": ["AI翻译", "音乐播放"],
                },
            }
            blueprint["execution_order"] = {"录音": {"入口": ["入口路径"]}}
            blueprint_path.write_text(
                json.dumps(blueprint, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            blueprint_gate = config["quality_gates"].get("blueprint")
            if isinstance(blueprint_gate, dict):
                required_keys = blueprint_gate.setdefault("required_keys", [])
                if "execution_order" not in required_keys:
                    required_keys.append("execution_order")
            active_xlsx = root / config["cases_xlsx"]
            (root / "工作底稿" / "人员执行质量复核.json").write_text(
                json.dumps({
                    "schema_version": 1,
                    "input_xlsx_sha256": release.sha256(active_xlsx),
                    "status": "PASS",
                    "reviewer": "发布回归复核员",
                    "dimensions": {
                        "wording": {
                            "status": "PASS", "reviewed_case_count": 1,
                            "evidence": "已逐条确认措辞可执行且结果可观察", "findings": [],
                        },
                        "classification": {
                            "status": "PASS", "reviewed_case_count": 1,
                            "evidence": "已逐条确认层级和业务归属正确", "findings": [],
                        },
                        "order": {
                            "status": "PASS", "reviewed_feature_point_count": 1,
                            "evidence": "已按录音入口执行路径核对顺序", "findings": [],
                        },
                        "feature_boundary": {
                            "status": "PASS", "reviewed_case_count": 1,
                            "evidence": "已逐条确认预期结果归属录音模块", "findings": [],
                        },
                    },
                    "accepted_automatic_findings": [],
                }, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            config_path.write_text(
                json.dumps(config, ensure_ascii=False, indent=2), encoding="utf-8"
            )
            execution_profile.write_profile(root, profile)
            if mode == "core":
                (root / "生成验收合同.json").unlink()
            else:
                lineage.record_casegen(root)
                lineage.record_export(root, root / "cases.xlsx", root / "用例稳定索引.json")
                draft_path = root / "工作底稿" / "追溯" / "录音.json"
                lineage.record_trace(root, root / "cases.xlsx", draft_path.parent, [draft_path])
                result_path = root / "结果" / "录音.json"
                result_payload = json.loads(result_path.read_text(encoding="utf-8"))
                result_payload["_lineage"] = lineage.result_binding(root, draft_path)
                result_path.write_text(
                    json.dumps(result_payload, ensure_ascii=False), encoding="utf-8"
                )
                lineage.record_results(root, [result_path])
            write_required_report(root, config_path)
            report, _ = release.evaluate(config_path)
            command_names = {row["name"] for row in report["commands"]}
            passed = (
                report["status"] == "PASS"
                and report["release_decision"] == "GO"
                and report["readiness_level"] == expected_readiness
                and report["delivery_status"] == expected_readiness
                and report["metrics"].get("legacy_strict") is False
                and report["metrics"].get("execution_profile") == mode
                and command_names == expected_commands
            )
            results.append({
                "name": name,
                "passed": passed,
                "status": report["status"],
                "readiness_level": report.get("readiness_level"),
                "commands": sorted(command_names),
                "issues": report["issues"],
            })
            if not passed:
                errors.append(name)
    print(json.dumps({"success": not errors, "results": results, "errors": errors}, ensure_ascii=False, indent=2))
    if errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
