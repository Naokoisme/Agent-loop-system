# -*- coding: utf-8 -*-
"""生成前验收合同与紧凑用例规格校验。

新项目由 ``new_project.py`` 在 ``trace.config.json`` 中显式声明合同必需；
未声明该策略的遗留项目继续允许无合同运行。无论是否启用合同，结构化用例字段
和判定表/正交法数据行都会在任何稳定 ID 或 cases 文件写入前完成校验。
"""
from __future__ import annotations

import argparse
import glob
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from quality_semantics import check_functional_manual_contract, check_step_expected_contract
from project_paths import resolve_project


CONTRACT_FILENAME = "生成验收合同.json"
CONFIG_FILENAME = "trace.config.json"
PRODUCT_FORMS = {"app", "embedded", "iot", "watch", "app-iot", "嵌入式", "手表"}
COMBINATION_METHOD_ALIASES = {
    "判定表": "判定表法",
    "判定表法": "判定表法",
    "正交": "正交试验法",
    "正交法": "正交试验法",
    "正交试验": "正交试验法",
    "正交试验法": "正交试验法",
}
SUMMARY_PHRASES = (
    "遍历组合", "遍历所有组合", "执行正交组合", "执行判定表组合",
    "覆盖所有组合", "全部组合", "所有组合", "逐一组合", "按正交组合",
)
PLACEHOLDER_MARKERS = ("待填写", "待补充", "占位", "TODO", "TBD")
PLACEHOLDER_PATTERN = re.compile(r"<[^<>\r\n]{1,120}>")
NUMBERED_PREFIX = re.compile(r"^\s*\d+\s*[\.．、\)]\s*")
DATASET_ID_PATTERN = re.compile(r"^[A-Z0-9][A-Z0-9_-]{2,63}$")
EVIDENCE_EFFECTIVE_CHAR_RE = re.compile(r"[A-Za-z0-9\u4e00-\u9fff]")
FACTOR_SEPARATOR_RE = re.compile(r"[=＝:：]")
FACTOR_EVIDENCE_FIELDS = {
    "pre": "precondition_text",
    "step": "step_text",
    "exp": "expected_text",
}
FACTOR_EVIDENCE_KEYS = {"factor", "field", "fragments"}
ORDER_FACTOR_NAME_RE = re.compile(r"(?:顺序|先后|时序|order|sequence)", re.IGNORECASE)
ORDER_FACTOR_VALUE_RE = re.compile(
    r"(?:A\s*(?:后|→|->)\s*B|B\s*(?:后|→|->)\s*A|先.+再.+|.+(?:后|→|->).+)",
    re.IGNORECASE,
)
UNORDERED_LEVEL_RE = re.compile(r"^(?:无先后|同时|同步|并发|同一时刻|同一时间)$", re.IGNORECASE)
ORDER_ACTION_RE = re.compile(
    r"(?:打开|关闭|开启|启动|停止|开始|结束|点击|按下|松开|滑动|拖动|进入|返回|"
    r"选择|切换|输入|修改|设置|新增|添加|删除|保存|提交|连接|断开|绑定|解绑|"
    r"插入|拔出|晃动|等待|发送|拨打|接听|挂断|触发|到点|到达|发起|执行|查看|观察)"
)
POSITIVE_LEVELS = {"是", "有", "yes", "true"}
NEGATIVE_LEVELS = {"否", "no", "false"}
POSITIVE_MARKERS = ("已", "正在", "允许", "在线", "可用", "存在", "启用", "完成", "成功", "enabled", "connected", "available", "passed")
NEGATIVE_MARKERS = ("未", "无", "关闭", "禁止", "失败", "断开", "离线", "不可用", "不足", "尚未", "不", "disabled", "disconnected", "unavailable", "failed")
SHORT_OPPOSITES = {
    "强": ("弱",), "弱": ("强",),
    "短": ("长",), "长": ("短",),
    "前台": ("后台",), "后台": ("前台",),
    "日": ("周", "月", "年"), "周": ("日", "月", "年"),
    "月": ("日", "周", "年"), "年": ("日", "周", "月"),
    "空": ("非空", "有数据"),
}
CONTROLLED_FACTOR_BINDINGS: dict[tuple[str, str], tuple[tuple[str, ...], ...]] = {
    ("记录过程", "跨零点"): (("跨越零点",),),
    ("应用", "系统通知"): (("系统日历", "通知"),),
    ("断连", "开始前"): (("当前未连接",), ("开始前", "断连"), ("开始前", "未连接")),
    ("断连", "运动中"): (("运动开始后", "关闭", "蓝牙"), ("运动中", "断连")),
    ("定位", "不可用"): (("定位服务", "关闭"),),
    ("心率自检", "通过"): (("心率传感器", "正常工作"),),
    ("g-sensor自检", "通过"): (("加速度传感器", "正常工作"),),
    ("缺失", "无"): (("数据完整",), ("无缺失",)),
    ("列表修改", "是"): (("修改运动列表",), ("列表已修改",)),
}


GENERATION_CONTRACT_TEMPLATE: dict[str, Any] = {
    "schema_version": 3,
    "contract_state": "draft",
    "product_form": {"value": "<app/embedded/iot/watch/app-iot>", "locked": False},
    "modules": [
        {
            "name": "<功能模块名>",
            "prefix": "<唯一英文编号前缀>",
            "prefix_locked": False,
            "in_scope": True,
            "applicable_test_methods": ["<适用测试方法>"],
        }
    ],
    "module_order": {"items": ["<功能模块名>"], "locked": False},
    "test_item_taxonomy": {
        "locked": False,
        "allowed_generic_items": ["界面操作", "异常测试", "中断测试", "恢复测试", "限制测试", "交叉对象", "稳定性测试", "兼容性测试"],
        "forbidden_specific_patterns": ["<具体数值/平台/语言/异常对象不得进入测试项>"],
    },
    "design_contract": {
        "locked": False,
        "required_blueprint_fields": [
            "module_boundary", "feature_order", "page_state_anchors", "input_matrix",
            "exception_matrix", "cross_matrix", "common_fixtures",
            "case_precondition_rules", "unsupported_features", "complexity_profile", "hierarchy_map"
        ],
        "stable_id_policy": "persisted_uuid",
        "ordering_policy": "stable_id_preserving",
    },
    "coverage_policy": {
        "locked": False,
        "coverage_threshold": 0.95,
        "require_zero_partial": True,
        "pending_evidence_mode": "require_acceptance",
        "accepted_partial_req_ids": [],
        "accepted_pending_req_ids": [],
    },
    "pilot_risk_types": [
        "settings_or_configuration", "health_or_sensor", "complex_state_flow",
        "cross_app_device", "high_conflict", "ambiguous_requirement"
    ],
    "pilot_risk_evidence": [
        {
            "risk_type": "<pilot_risk_types 中的一项>",
            "module": "<pilot_modules 中的模块>",
            "evidence_path": "<相对项目目录的先导审查报告.json>",
            "note": "<该模块为何证明此风险类型已审查>",
        }
    ],
    "combination_dataset_plan": [
        {
            "module": "<功能模块名>",
            "method": "<判定表法/正交试验法>",
            "minimum_rows": 1,
            "locked": False,
        }
    ],
    "special_test_applicability": [
        {
            "name": "<性能/稳定性/兼容性/安全/功耗等专项>",
            "status": "pending",
            "modules": ["<适用模块；不适用时留空数组>"],
            "reason": "<适用或不适用的项目依据>",
        }
    ],
    "delivery_boundaries": {
        "FW": {"scope": "<固件功能边界>", "out_of_scope": "<明确排除项>", "locked": False},
        "TC": {"scope": "<测试用例边界>", "out_of_scope": "<明确排除项>", "locked": False},
        "JT": {"scope": "<联调边界>", "out_of_scope": "<明确排除项>", "locked": False},
    },
    "risk_exit_policy": {
        "locked": False,
        "blocking_issue_policy": "block",
        "pending_confirmation_policy": "block",
        "accepted_risks": [],
    },
    "pilot_modules": ["<高风险先导模块1>", "<高风险先导模块2>", "<高风险先导模块3>"],
    "pilot_acceptance": {"status": "pending", "evidence": "<先导模块审查证据>", "locked": False},
}


class GenerationContractError(ValueError):
    """生成前输入不满足验收合同。"""

    def __init__(self, errors: list[str] | str):
        self.errors = [errors] if isinstance(errors, str) else errors
        super().__init__("生成前验收失败:\n- " + "\n- ".join(self.errors))


@dataclass
class PreparedCase:
    source: dict[str, Any]
    precondition_text: str
    step_text: str
    expected_text: str
    method: str
    dataset_id: str
    factors: list[str]


@dataclass
class PreparedSpec:
    path: Path
    data: dict[str, Any]
    module: str
    prefix: str
    cases: list[PreparedCase]


def _is_concrete(value: Any) -> bool:
    text = str(value or "").strip()
    if not text:
        return False
    upper = text.upper()
    return not PLACEHOLDER_PATTERN.search(text) and not any(
        marker.upper() in upper for marker in PLACEHOLDER_MARKERS
    )


def _read_json(path: Path, label: str, errors: list[str]) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        errors.append(f"{label}无法读取或不是合法JSON: {path} ({exc})")
        return None


def _render_items(value: Any, field: str, location: str, errors: list[str]) -> str:
    if not isinstance(value, list) or not value:
        errors.append(f"{location} {field} 必须是非空字符串数组")
        return ""
    clean: list[str] = []
    for index, item in enumerate(value, 1):
        if not isinstance(item, str) or not item.strip():
            errors.append(f"{location} {field}[{index}] 必须是非空字符串")
            continue
        text = item.strip()
        if "\n" in text or "\r" in text:
            errors.append(f"{location} {field}[{index}] 禁止内嵌换行；每个数组元素只表达一项")
        if NUMBERED_PREFIX.match(text):
            errors.append(f"{location} {field}[{index}] 不得自带编号，由生成器确定性编号")
        clean.append(text)
    return "\n".join(f"{index}.{item}" for index, item in enumerate(clean, 1))


def _contains_summary_phrase(case: dict[str, Any]) -> str:
    text_parts: list[str] = []
    for key in ("tp", "pre", "step", "exp", "note"):
        text_parts.append(str(case.get(key, "") or ""))
    for key in ("preconditions", "steps", "expected", "factors"):
        value = case.get(key)
        if isinstance(value, list):
            text_parts.extend(str(item) for item in value)
    joined = "\n".join(text_parts)
    return next((phrase for phrase in SUMMARY_PHRASES if phrase in joined), "")


def _normalize_method(value: Any) -> str:
    text = str(value or "").strip()
    return COMBINATION_METHOD_ALIASES.get(text, text)


def _parse_factor_expression(value: Any) -> tuple[str, str] | None:
    if not isinstance(value, str):
        return None
    text = value.strip()
    match = FACTOR_SEPARATOR_RE.search(text)
    if match is None:
        return None
    name = text[:match.start()].strip()
    level = text[match.end():].strip()
    if not name or not level:
        return None
    return name, level


def _normalize_factor_expression(value: Any) -> str:
    parsed = _parse_factor_expression(value)
    return f"{parsed[0]}={parsed[1]}" if parsed else ""


def _factor_name_anchors(name: str) -> set[str]:
    lowered = name.casefold()
    anchors = {lowered} if len(EVIDENCE_EFFECTIVE_CHAR_RE.findall(lowered)) >= 2 else set()
    for token in (
        "登录", "绑定", "连接", "充电", "电量", "定位", "gps", "正文", "通知",
        "自检", "心率", "g-sensor", "加速度传感器", "数据", "缺失", "列表", "修改",
        "ble", "app", "平台", "单位", "类型", "应用", "记录", "过程",
    ):
        if token in lowered:
            anchors.add(token)
    return anchors


def _contains_any(text: str, values: tuple[str, ...]) -> bool:
    lowered = text.casefold()
    return any(value.casefold() in lowered for value in values)


def _without_factor_name_anchors(text: str, anchors: set[str]) -> str:
    """Exclude factor-name text from value and polarity checks."""
    masked = text
    for anchor in sorted(anchors, key=len, reverse=True):
        masked = masked.replace(anchor, " ")
    return masked


def _factor_evidence_semantically_binds(
    name: str,
    level: str,
    fragments: list[str],
) -> bool:
    text = " ".join(fragments).casefold()
    name_key = name.casefold()
    level_key = level.casefold()
    controlled = CONTROLLED_FACTOR_BINDINGS.get((name_key, level_key), ())
    if any(all(token.casefold() in text for token in token_group) for token_group in controlled):
        return True

    anchors = _factor_name_anchors(name)
    has_name_anchor = any(anchor in text for anchor in anchors)
    evidence_text = _without_factor_name_anchors(text, anchors)
    if level_key in POSITIVE_LEVELS:
        return (
            has_name_anchor
            and _contains_any(evidence_text, POSITIVE_MARKERS)
            and not _contains_any(evidence_text, NEGATIVE_MARKERS)
        )
    if level_key in NEGATIVE_LEVELS:
        return (
            has_name_anchor
            and _contains_any(evidence_text, NEGATIVE_MARKERS)
            and not _contains_any(evidence_text, POSITIVE_MARKERS)
        )
    if level_key == "无":
        return has_name_anchor and _contains_any(evidence_text, ("无", "未", "没有", "完整"))
    if level_key in {"强", "弱", "短", "长", "前台", "后台"}:
        opposites = SHORT_OPPOSITES.get(level_key, ())
        return has_name_anchor and level_key in evidence_text and not _contains_any(evidence_text, opposites)
    if len(EVIDENCE_EFFECTIVE_CHAR_RE.findall(level)) == 1:
        opposites = SHORT_OPPOSITES.get(level_key, ())
        return has_name_anchor and level_key in evidence_text and not _contains_any(evidence_text, opposites)

    # Unambiguous multi-character/numeric levels must be explicit, unless a
    # project-independent controlled binding above defines the natural synonym.
    return len(EVIDENCE_EFFECTIVE_CHAR_RE.findall(level)) >= 2 and level_key in text


def _is_order_factor(name: str, level: str) -> bool:
    return bool(ORDER_FACTOR_NAME_RE.search(name) or ORDER_FACTOR_VALUE_RE.fullmatch(level.strip()))


def _prepare_case(case: Any, location: str, errors: list[str]) -> PreparedCase | None:
    if not isinstance(case, dict):
        errors.append(f"{location} 必须是对象")
        return None

    legacy_keys = ("pre", "step", "exp")
    structured_keys = ("preconditions", "steps", "expected")
    has_legacy = any(key in case for key in legacy_keys)
    has_structured = any(key in case for key in structured_keys)
    if has_legacy and has_structured:
        errors.append(
            f"{location} 禁止混用 pre/step/exp 与 preconditions/steps/expected；"
            "请选择一种格式"
        )
        return None

    if "risk" in case and "_risk" in case and case["risk"] != case["_risk"]:
        errors.append(f"{location} risk/_risk 内容冲突，禁止静默选择风险口径")
    risk_value = case.get("risk") if "risk" in case else case.get("_risk")
    if risk_value not in (None, "", {}, []) and not isinstance(risk_value, (bool, str, dict)):
        errors.append(f"{location} risk 必须是布尔值、字符串或对象")

    if has_structured:
        missing = [key for key in structured_keys if key not in case]
        if missing:
            errors.append(f"{location} 结构化字段不完整，缺少: {missing}")
            return None
        pre_text = _render_items(case.get("preconditions"), "preconditions", location, errors)
        step_text = _render_items(case.get("steps"), "steps", location, errors)
        expected_text = _render_items(case.get("expected"), "expected", location, errors)
        steps = case.get("steps")
        expected = case.get("expected")
        if isinstance(steps, list) and isinstance(expected, list) and len(steps) != len(expected):
            errors.append(
                f"{location} steps/expected 数量不一致: {len(steps)} != {len(expected)}"
            )
    else:
        # 遗留字符串原样透传，不改写、不猜测连接词语义。
        pre_text = str(case.get("pre", "") or "")
        step_text = str(case.get("step", "") or "")
        expected_text = str(case.get("exp", "") or "")

    method_present = "method" in case
    dataset_present = "dataset_id" in case
    factors_present = "factors" in case
    method = _normalize_method(case.get("method", ""))
    dataset_id = str(case.get("dataset_id", "") or "").strip()
    raw_factors = case.get("factors", [])
    factors: list[str] = []

    if method_present and not _is_concrete(method):
        errors.append(f"{location} method 不能为空或占位")
    is_combination = method in set(COMBINATION_METHOD_ALIASES.values())
    if dataset_present or factors_present:
        if not method:
            errors.append(f"{location} 提供 dataset_id/factors 时必须同时提供 method")
        elif not is_combination:
            errors.append(f"{location} dataset_id/factors 仅用于判定表法或正交试验法数据行")

    if is_combination:
        if not dataset_id:
            errors.append(f"{location} {method}数据行缺 dataset_id")
        elif not DATASET_ID_PATTERN.fullmatch(dataset_id):
            errors.append(
                f"{location} dataset_id={dataset_id!r} 格式错误；"
                "须为3-64位大写字母、数字、下划线或连字符"
            )
        if not isinstance(raw_factors, list) or len(raw_factors) < 2:
            errors.append(f"{location} {method}数据行 factors 至少包含2个具体因子值")
        else:
            factor_names: set[str] = set()
            for factor_index, factor in enumerate(raw_factors, 1):
                if not isinstance(factor, str) or not _is_concrete(factor):
                    errors.append(f"{location} factors[{factor_index}] 必须是具体非空字符串")
                    continue
                text = factor.strip()
                parsed_factor = _parse_factor_expression(text)
                if parsed_factor is None:
                    errors.append(
                        f"{location} factors[{factor_index}]={text!r} 缺少因子=取值表达"
                    )
                    continue
                name, level = parsed_factor
                if name in factor_names:
                    errors.append(f"{location} factors 因子名重复: {name}")
                factor_names.add(name)
                factors.append(f"{name}={level}")
        summary = _contains_summary_phrase(case)
        if summary:
            errors.append(
                f"{location} 使用概括式组合描述 {summary!r}；"
                "判定表/正交法必须一条用例对应一行具体因子数据"
            )
    elif isinstance(raw_factors, list):
        factors = [str(item).strip() for item in raw_factors if str(item).strip()]

    return PreparedCase(
        source=case,
        precondition_text=pre_text,
        step_text=step_text,
        expected_text=expected_text,
        method=method,
        dataset_id=dataset_id,
        factors=factors,
    )


def _validate_factor_evidence_case(
    item: PreparedCase,
    location: str,
    errors: list[str],
    *,
    required: bool,
    default_pre: str,
) -> None:
    """Bind every combination factor to exact, ordered human-body evidence."""
    if _normalize_method(item.method) not in set(COMBINATION_METHOD_ALIASES.values()):
        if "factor_evidence" in item.source:
            errors.append(f"{location} factor_evidence 仅允许用于判定表法/正交试验法数据行")
        return

    if "factor_evidence" not in item.source:
        if required:
            errors.append(f"{location} 组合数据行缺 factor_evidence")
        return
    raw_evidence = item.source.get("factor_evidence")
    if not isinstance(raw_evidence, list):
        errors.append(f"{location} 组合数据行 factor_evidence 必须是数组")
        return
    if not raw_evidence:
        errors.append(f"{location} 组合数据行 factor_evidence 不能为空")
        return

    expected_factors = set(item.factors)
    seen: dict[str, int] = {}
    fragment_owners: dict[str, str] = {}
    for evidence_index, evidence in enumerate(raw_evidence, 1):
        evidence_location = f"{location} factor_evidence[{evidence_index}]"
        if not isinstance(evidence, dict):
            errors.append(f"{evidence_location} 必须是对象")
            continue
        unknown_keys = sorted(set(evidence) - FACTOR_EVIDENCE_KEYS)
        missing_keys = sorted(FACTOR_EVIDENCE_KEYS - set(evidence))
        if missing_keys:
            errors.append(f"{evidence_location} 缺少字段: {missing_keys}")
        if unknown_keys:
            errors.append(f"{evidence_location} 含非法字段: {unknown_keys}")

        factor = _normalize_factor_expression(evidence.get("factor"))
        if not factor:
            errors.append(
                f"{evidence_location}.factor 必须是有效的 因子=取值 字符串，支持 =/＝/:/："
            )
            continue
        factor_name, factor_level = factor.split("=", 1)
        seen[factor] = seen.get(factor, 0) + 1
        if seen[factor] > 1:
            errors.append(f"{location} factor_evidence 因子重复: {factor}")

        field = evidence.get("field")
        if field not in FACTOR_EVIDENCE_FIELDS:
            errors.append(
                f"{evidence_location}.field={field!r} 非法；仅允许 pre/step/exp"
            )
            continue
        fragments = evidence.get("fragments")
        if not isinstance(fragments, list) or not fragments:
            errors.append(f"{evidence_location}.fragments 必须是非空字符串数组")
            continue
        order_factor = _is_order_factor(factor_name, factor_level)
        unordered_factor = order_factor and bool(UNORDERED_LEVEL_RE.fullmatch(factor_level.strip()))
        if order_factor and field != "step":
            errors.append(f"{evidence_location} 顺序/时序因子必须引用 step 人工动作正文")
        if order_factor and not unordered_factor and len(fragments) < 2:
            errors.append(f"{evidence_location} 顺序因子 {factor} 至少需要2个有序正文片段")

        if field == "pre" and not ("pre" in item.source or "preconditions" in item.source):
            body = str(default_pre or "")
        else:
            body = str(getattr(item, FACTOR_EVIDENCE_FIELDS[field], "") or "")
        search_from = 0
        clean_fragments: list[str] = []
        order_fragment_keys: set[str] = set()
        for fragment_index, fragment in enumerate(fragments, 1):
            fragment_location = f"{evidence_location}.fragments[{fragment_index}]"
            if not isinstance(fragment, str) or not fragment.strip():
                errors.append(f"{fragment_location} 必须是非空字符串")
                continue
            fragment = fragment.strip()
            clean_fragments.append(fragment)
            effective_length = len(EVIDENCE_EFFECTIVE_CHAR_RE.findall(fragment))
            if effective_length < 2:
                errors.append(
                    f"{fragment_location} 有效字符少于2个，禁止用‘是/否/无/强/弱’等短值碰运气: {fragment!r}"
                )
                continue
            fragment_key = re.sub(r"\s+", " ", fragment.casefold()).strip()
            previous_owner = fragment_owners.get(fragment_key)
            if previous_owner is not None and previous_owner != factor:
                errors.append(
                    f"{fragment_location} 与其他factor复用同一证据片段: {fragment!r} "
                    f"({previous_owner} / {factor})"
                )
            else:
                fragment_owners[fragment_key] = factor
            if order_factor and not unordered_factor:
                if fragment_key in order_fragment_keys:
                    errors.append(f"{fragment_location} 顺序证据片段必须互异: {fragment!r}")
                order_fragment_keys.add(fragment_key)
                if ORDER_ACTION_RE.search(fragment) is None:
                    errors.append(
                        f"{fragment_location} 未锚定人工动作，不能证明顺序: {fragment!r}"
                    )
            position = body.find(fragment, search_from)
            if position < 0:
                if fragment in body:
                    errors.append(
                        f"{fragment_location} 在 {field} 正文中的顺序错误: {fragment!r}"
                    )
                else:
                    errors.append(
                        f"{fragment_location} 不存在于 {field} 人工正文: {fragment!r}"
                    )
                continue
            search_from = position + len(fragment)

        if clean_fragments:
            if order_factor:
                if unordered_factor:
                    evidence_text = " ".join(clean_fragments)
                    if not _contains_any(
                        evidence_text,
                        ("无先后", "同时", "同步", "同一时刻", "同一时间", "并发"),
                    ):
                        errors.append(
                            f"{evidence_location} 未绑定无先后/同时语义: {clean_fragments}"
                        )
            elif not _factor_evidence_semantically_binds(
                factor_name,
                factor_level,
                clean_fragments,
            ):
                errors.append(
                    f"{evidence_location} 证据未受控绑定 factor 的名称与取值: "
                    f"{factor} -> {clean_fragments}"
                )

    actual_factors = set(seen)
    missing = sorted(expected_factors - actual_factors)
    extra = sorted(actual_factors - expected_factors)
    if missing:
        errors.append(f"{location} factor_evidence 缺少 factors 证据: {missing}")
    if extra:
        errors.append(f"{location} factor_evidence 包含额外因子: {extra}")


def _validate_factor_evidence(
    prepared_specs: list[PreparedSpec],
    errors: list[str],
    *,
    required: bool,
) -> None:
    for spec in prepared_specs:
        default_pre = str(spec.data.get("default_pre", "") or "")
        for case_index, item in enumerate(spec.cases, 1):
            _validate_factor_evidence_case(
                item,
                f"{spec.path.name} 第{case_index}条用例",
                errors,
                required=required,
                default_pre=default_pre,
            )


def _load_prepared_specs(project_dir: Path, errors: list[str]) -> list[PreparedSpec]:
    prepared: list[PreparedSpec] = []
    files = sorted(Path(path) for path in glob.glob(str(project_dir / "specs" / "*.json")))
    if not files:
        errors.append(f"未找到紧凑用例规格: {project_dir / 'specs' / '*.json'}")
        return prepared

    seen_modules: set[str] = set()
    seen_prefixes: dict[str, str] = {}
    seen_datasets: dict[str, str] = {}
    for path in files:
        data = _read_json(path, "用例spec", errors)
        if not isinstance(data, dict):
            continue
        module = str(data.get("module", "") or "").strip()
        prefix = str(data.get("prefix", "") or "").strip()
        cases = data.get("cases")
        if not _is_concrete(module):
            errors.append(f"{path.name} module 为空或占位")
        elif module in seen_modules:
            errors.append(f"spec 功能模块重复: {module}")
        seen_modules.add(module)
        if not _is_concrete(prefix):
            errors.append(f"{path.name} prefix 为空或占位")
        elif prefix in seen_prefixes:
            errors.append(f"spec prefix 全项目重复: {prefix} ({seen_prefixes[prefix]} / {path.name})")
        else:
            seen_prefixes[prefix] = path.name
        if not isinstance(cases, list) or not cases:
            errors.append(f"{path.name} cases 必须是非空数组")
            continue
        normalized: list[PreparedCase] = []
        for index, case in enumerate(cases, 1):
            location = f"{path.name} 第{index}条用例"
            item = _prepare_case(case, location, errors)
            if item is None:
                continue
            normalized.append(item)
            if item.dataset_id:
                if item.dataset_id in seen_datasets:
                    errors.append(
                        f"dataset_id 全项目重复: {item.dataset_id} "
                        f"({seen_datasets[item.dataset_id]} / {location})"
                    )
                else:
                    seen_datasets[item.dataset_id] = location

        combination_bodies: dict[tuple[str, ...], tuple[int, PreparedCase]] = {}
        default_pre = str(data.get("default_pre", "") or "")
        for case_index, item in enumerate(normalized, 1):
            if _normalize_method(item.method) not in set(COMBINATION_METHOD_ALIASES.values()):
                continue
            source = item.source
            effective_pre = item.precondition_text if (
                "pre" in source or "preconditions" in source
            ) else default_pre

            def normalized_text(value: Any) -> str:
                return "\n".join(
                    line.strip() for line in str(value or "").replace("\r\n", "\n").replace("\r", "\n").split("\n")
                    if line.strip()
                )

            signature = (
                normalized_text(effective_pre),
                normalized_text(item.step_text),
                normalized_text(item.expected_text),
            )
            previous = combination_bodies.get(signature)
            if previous is not None:
                previous_index, previous_item = previous
                errors.append(
                    f"{path.name} 组合方法数据行人工正文重复: 第{previous_index}条 "
                    f"({previous_item.dataset_id}, factors={previous_item.factors}) / 第{case_index}条 "
                    f"({item.dataset_id}, factors={item.factors})；因素取值必须实例化到 "
                    "前置/步骤/预期，fp/ti/tp 也应反映具体场景；禁止只更换 dataset_id/factors 标签"
                )
            else:
                combination_bodies[signature] = (case_index, item)
        prepared.append(PreparedSpec(path=path, data=data, module=module, prefix=prefix, cases=normalized))

    contract_rows: list[dict[str, Any]] = []
    for prepared_spec in prepared:
        default_pre = prepared_spec.data.get("default_pre", "")
        default_compat = prepared_spec.data.get("default_compat", "Android/iOS")
        for index, prepared_case in enumerate(prepared_spec.cases, 1):
            source = prepared_case.source
            contract_rows.append({
                "用例编号": f"{prepared_spec.prefix}_{index:03d}",
                "功能模块": prepared_spec.module,
                "功能点": source.get("fp", ""),
                "测试项": source.get("ti", ""),
                "测试点/检查项": source.get("tp", ""),
                "前置条件": prepared_case.precondition_text if (
                    "pre" in source or "preconditions" in source
                ) else default_pre,
                "操作步骤": prepared_case.step_text,
                "预期结果": prepared_case.expected_text,
                "优先级": source.get("pri", "P2"),
                "兼容性": source.get("compat", default_compat),
                "是否自动化": source.get("auto", "否"),
                "固件版本": source.get("fw", ""),
                "硬件型号": source.get("hw", ""),
                "测试方式": source.get("way", "人工执行"),
                "备注": source.get("note", ""),
            })
    errors.extend(check_functional_manual_contract(contract_rows))
    errors.extend(check_step_expected_contract(contract_rows))
    return prepared


def _contract_policy(
    project_dir: Path,
    errors: list[str],
) -> tuple[bool, str, dict[str, Any] | None]:
    config_path = project_dir / CONFIG_FILENAME
    if not config_path.exists():
        return False, CONTRACT_FILENAME, None
    config = _read_json(config_path, "追溯配置", errors)
    if not isinstance(config, dict):
        return False, CONTRACT_FILENAME, None
    policy = config.get("generation_contract")
    if policy is None:
        return False, CONTRACT_FILENAME, config
    if not isinstance(policy, dict):
        errors.append("trace.config.json generation_contract 必须是对象")
        return False, CONTRACT_FILENAME, config
    filename = str(policy.get("file", CONTRACT_FILENAME) or CONTRACT_FILENAME).strip()
    return bool(policy.get("required", False)), filename, config


def _config_requires_manual_factor_evidence(config: dict[str, Any] | None) -> bool:
    if not isinstance(config, dict):
        return False
    quality_gates = config.get("quality_gates")
    if not isinstance(quality_gates, dict):
        return False
    manual_contract = quality_gates.get("functional_manual_contract")
    return isinstance(manual_contract, dict) and manual_contract.get("required") is True


def _validate_contract(
    contract: Any,
    prepared_specs: list[PreparedSpec],
    errors: list[str],
    *,
    pilot_only: bool = False,
) -> set[str]:
    if not isinstance(contract, dict):
        errors.append("生成验收合同根节点必须是对象")
        return set()
    schema_version = contract.get("schema_version")
    schema_level = schema_version if isinstance(schema_version, int) and not isinstance(schema_version, bool) else 0
    if schema_level not in {1, 2, 3}:
        errors.append("生成验收合同 schema_version 必须为1、2或3")
    if contract.get("contract_state") != "locked":
        errors.append("生成验收合同未锁定: contract_state 必须为 locked")

    product_form = contract.get("product_form")
    if not isinstance(product_form, dict):
        errors.append("生成验收合同缺 product_form 对象")
    else:
        value = str(product_form.get("value", "") or "").strip()
        if value not in PRODUCT_FORMS:
            errors.append(f"product_form.value 无效或占位: {value!r}")
        if product_form.get("locked") is not True:
            errors.append("product_form 未锁定")

    module_rows = contract.get("modules")
    module_map: dict[str, dict[str, Any]] = {}
    contract_prefixes: dict[str, str] = {}
    if not isinstance(module_rows, list) or not module_rows:
        errors.append("生成验收合同 modules 必须是非空数组")
    else:
        for index, row in enumerate(module_rows, 1):
            if not isinstance(row, dict):
                errors.append(f"modules[{index}] 必须是对象")
                continue
            name = str(row.get("name", "") or "").strip()
            if not _is_concrete(name):
                errors.append(f"modules[{index}].name 为空或占位")
                continue
            if name in module_map:
                errors.append(f"合同模块重复: {name}")
            module_map[name] = row
            prefix = str(row.get("prefix", "") or "").strip()
            if not _is_concrete(prefix):
                errors.append(f"合同模块 {name} prefix 为空或占位")
            elif prefix in contract_prefixes:
                errors.append(
                    f"合同模块 prefix 重复: {prefix} "
                    f"({contract_prefixes[prefix]} / {name})"
                )
            else:
                contract_prefixes[prefix] = name
            if row.get("prefix_locked") is not True:
                errors.append(f"合同模块 {name} prefix 未锁定")
            if not isinstance(row.get("in_scope"), bool):
                errors.append(f"合同模块 {name} 的 in_scope 必须是布尔值")
            methods = row.get("applicable_test_methods")
            if row.get("in_scope") is True:
                if not isinstance(methods, list) or not methods or any(not _is_concrete(x) for x in methods):
                    errors.append(f"合同模块 {name} 缺具体 applicable_test_methods")
                elif len({_normalize_method(x) for x in methods}) != len(methods):
                    errors.append(f"合同模块 {name} applicable_test_methods 重复")

    spec_modules = {item.module for item in prepared_specs if item.module}
    specs_by_module = {item.module: item for item in prepared_specs if item.module}
    in_scope_modules = {name for name, row in module_map.items() if row.get("in_scope") is True}
    pilot_modules = contract.get("pilot_modules")
    pilot_module_set = {
        str(value).strip() for value in pilot_modules
        if isinstance(pilot_modules, list) and _is_concrete(value)
    }
    required_specs = pilot_module_set if pilot_only else in_scope_modules
    missing_specs = sorted(required_specs - spec_modules)
    undeclared_specs = sorted(spec_modules - in_scope_modules)
    if missing_specs:
        label = "合同先导模块" if pilot_only else "合同范围内模块"
        errors.append(f"{label}缺spec: {missing_specs}")
    if undeclared_specs:
        errors.append(f"spec模块未纳入合同范围或被标为范围外: {undeclared_specs}")
    for module in sorted(spec_modules & set(module_map)):
        contract_prefix = str(module_map[module].get("prefix", "") or "").strip()
        spec_prefix = specs_by_module[module].prefix
        if contract_prefix and spec_prefix and contract_prefix != spec_prefix:
            errors.append(
                f"模块 {module} prefix 与合同不一致: contract={contract_prefix} spec={spec_prefix}"
            )

    if schema_level >= 2:
        module_order = contract.get("module_order")
        if not isinstance(module_order, dict):
            errors.append("生成验收合同缺 module_order")
        else:
            items = module_order.get("items")
            if module_order.get("locked") is not True:
                errors.append("module_order 未锁定")
            if not isinstance(items, list) or any(not _is_concrete(x) for x in items):
                errors.append("module_order.items 必须是具体模块数组")
            elif items != [name for name, row in module_map.items() if row.get("in_scope") is True]:
                errors.append("module_order.items 必须与合同范围内模块顺序完全一致")

        taxonomy = contract.get("test_item_taxonomy")
        if not isinstance(taxonomy, dict):
            errors.append("生成验收合同缺 test_item_taxonomy")
        else:
            if taxonomy.get("locked") is not True:
                errors.append("test_item_taxonomy 未锁定")
            allowed = taxonomy.get("allowed_generic_items")
            forbidden = taxonomy.get("forbidden_specific_patterns")
            if not isinstance(allowed, list) or not allowed or any(not _is_concrete(x) for x in allowed):
                errors.append("test_item_taxonomy.allowed_generic_items 必须是具体非空数组")
            if not isinstance(forbidden, list) or not forbidden or any(not _is_concrete(x) for x in forbidden):
                errors.append("test_item_taxonomy.forbidden_specific_patterns 必须是具体非空数组")

        design = contract.get("design_contract")
        if not isinstance(design, dict):
            errors.append("生成验收合同缺 design_contract")
        else:
            if design.get("locked") is not True:
                errors.append("design_contract 未锁定")
            fields = design.get("required_blueprint_fields")
            if not isinstance(fields, list) or any(not _is_concrete(x) for x in fields):
                errors.append("design_contract.required_blueprint_fields 必须是具体数组")
            if design.get("stable_id_policy") != "persisted_uuid":
                errors.append("stable_id_policy 必须为 persisted_uuid")
            if design.get("ordering_policy") != "stable_id_preserving":
                errors.append("ordering_policy 必须为 stable_id_preserving")

        coverage = contract.get("coverage_policy")
        if not isinstance(coverage, dict):
            errors.append("生成验收合同缺 coverage_policy")
        else:
            if coverage.get("locked") is not True:
                errors.append("coverage_policy 未锁定")
            threshold = coverage.get("coverage_threshold")
            if not isinstance(threshold, (int, float)) or not 0 < float(threshold) <= 1:
                errors.append("coverage_policy.coverage_threshold 必须在0到1之间")
            if coverage.get("require_zero_partial") is not True:
                errors.append("coverage_policy.require_zero_partial 必须为 true")
            if coverage.get("pending_evidence_mode") not in {"require_acceptance", "block"}:
                errors.append("coverage_policy.pending_evidence_mode 必须为 require_acceptance/block")
            for key in ("accepted_partial_req_ids", "accepted_pending_req_ids"):
                if not isinstance(coverage.get(key), list):
                    errors.append(f"coverage_policy.{key} 必须是数组")

        risk_types = contract.get("pilot_risk_types")
        if not isinstance(risk_types, list) or len(set(str(x) for x in risk_types if _is_concrete(x))) < 4:
            errors.append("pilot_risk_types 至少锁定4种具体风险类型")

        if schema_level >= 3:
            declared_risks = {
                str(value).strip() for value in risk_types
                if isinstance(risk_types, list) and _is_concrete(value)
            }
            evidence_rows = contract.get("pilot_risk_evidence")
            covered_risks: set[str] = set()
            covered_pilots: set[str] = set()
            seen_bindings: set[tuple[str, str]] = set()
            if not isinstance(evidence_rows, list) or not evidence_rows:
                errors.append("schema v3 合同 pilot_risk_evidence 必须逐项绑定风险类型、先导模块和证据文件")
            else:
                for index, row in enumerate(evidence_rows, 1):
                    if not isinstance(row, dict):
                        errors.append(f"pilot_risk_evidence[{index}] 必须是对象")
                        continue
                    risk_type = str(row.get("risk_type", "") or "").strip()
                    module = str(row.get("module", "") or "").strip()
                    evidence_value = str(row.get("evidence_path", "") or "").strip()
                    note = row.get("note")
                    if risk_type not in declared_risks:
                        errors.append(f"pilot_risk_evidence[{index}].risk_type 未列入 pilot_risk_types: {risk_type!r}")
                    if module not in pilot_module_set:
                        errors.append(f"pilot_risk_evidence[{index}].module 未列入 pilot_modules: {module!r}")
                    if not _is_concrete(evidence_value):
                        errors.append(f"pilot_risk_evidence[{index}].evidence_path 为空或占位")
                    else:
                        evidence_path = Path(evidence_value)
                        if not evidence_path.is_absolute():
                            evidence_path = prepared_specs[0].path.parent.parent / evidence_path \
                                if prepared_specs else Path(evidence_value)
                        if not evidence_path.is_file():
                            errors.append(f"pilot_risk_evidence[{index}] 证据文件不存在: {evidence_path}")
                    if not _is_concrete(note):
                        errors.append(f"pilot_risk_evidence[{index}].note 缺具体审查说明")
                    binding = (risk_type, module)
                    if binding in seen_bindings:
                        errors.append(f"先导风险证据重复绑定: {risk_type}/{module}")
                    seen_bindings.add(binding)
                    if risk_type in declared_risks:
                        covered_risks.add(risk_type)
                    if module in pilot_module_set:
                        covered_pilots.add(module)
                missing_risks = sorted(declared_risks - covered_risks)
                missing_pilots = sorted(pilot_module_set - covered_pilots)
                if missing_risks:
                    errors.append(f"pilot_risk_types 缺逐模块证据绑定: {missing_risks}")
                if missing_pilots:
                    errors.append(f"pilot_modules 缺风险证据绑定: {missing_pilots}")

    special_rows = contract.get("special_test_applicability")
    if not isinstance(special_rows, list) or not special_rows:
        errors.append("special_test_applicability 必须逐项声明专项测试适用性")
    else:
        seen_special: set[str] = set()
        for index, row in enumerate(special_rows, 1):
            if not isinstance(row, dict):
                errors.append(f"special_test_applicability[{index}] 必须是对象")
                continue
            name = str(row.get("name", "") or "").strip()
            status = str(row.get("status", "") or "").strip()
            reason = row.get("reason")
            modules = row.get("modules")
            if not _is_concrete(name):
                errors.append(f"special_test_applicability[{index}].name 为空或占位")
            elif name in seen_special:
                errors.append(f"专项测试声明重复: {name}")
            seen_special.add(name)
            if status not in {"applicable", "not_applicable"}:
                errors.append(f"专项测试 {name or index} status 必须为 applicable/not_applicable")
            if not _is_concrete(reason):
                errors.append(f"专项测试 {name or index} 缺具体适用性依据")
            if not isinstance(modules, list):
                errors.append(f"专项测试 {name or index} modules 必须是数组")
            else:
                invalid = sorted({str(x) for x in modules} - in_scope_modules)
                if invalid:
                    errors.append(f"专项测试 {name or index} 引用非范围内模块: {invalid}")
                if status == "applicable" and not modules:
                    errors.append(f"专项测试 {name or index} 标为适用但未指定模块")

    boundaries = contract.get("delivery_boundaries")
    if not isinstance(boundaries, dict):
        errors.append("生成验收合同缺 delivery_boundaries")
    else:
        for owner in ("FW", "TC", "JT"):
            boundary = boundaries.get(owner)
            if not isinstance(boundary, dict):
                errors.append(f"delivery_boundaries 缺 {owner} 边界")
                continue
            if not _is_concrete(boundary.get("scope")):
                errors.append(f"{owner}.scope 为空或占位")
            if not _is_concrete(boundary.get("out_of_scope")):
                errors.append(f"{owner}.out_of_scope 为空或占位")
            if boundary.get("locked") is not True:
                errors.append(f"{owner} 边界未锁定")

    policy = contract.get("risk_exit_policy")
    if not isinstance(policy, dict):
        errors.append("生成验收合同缺 risk_exit_policy")
    else:
        if policy.get("locked") is not True:
            errors.append("risk_exit_policy 未锁定")
        if policy.get("blocking_issue_policy") != "block":
            errors.append("blocking_issue_policy 必须为 block")
        if policy.get("pending_confirmation_policy") not in {"block", "accepted_risk"}:
            errors.append("pending_confirmation_policy 必须为 block/accepted_risk")
        if not isinstance(policy.get("accepted_risks"), list):
            errors.append("accepted_risks 必须是数组")

    if not isinstance(pilot_modules, list) or not 3 <= len(pilot_modules) <= 5:
        errors.append("pilot_modules 必须选择3-5个高风险先导模块")
    else:
        if len(set(str(x) for x in pilot_modules)) != len(pilot_modules):
            errors.append("pilot_modules 存在重复模块")
        invalid = sorted({str(x) for x in pilot_modules} - in_scope_modules)
        if invalid:
            errors.append(f"pilot_modules 引用非范围内模块: {invalid}")
        if any(not _is_concrete(x) for x in pilot_modules):
            errors.append("pilot_modules 包含占位值")
    pilot_acceptance = contract.get("pilot_acceptance")
    if not isinstance(pilot_acceptance, dict):
        errors.append("生成验收合同缺 pilot_acceptance")
    else:
        if pilot_only:
            if pilot_acceptance.get("status") not in {"pending", "passed"}:
                errors.append("先导模式 pilot_acceptance.status 必须为 pending/passed")
        else:
            if pilot_acceptance.get("locked") is not True:
                errors.append("pilot_acceptance 未锁定")
            if pilot_acceptance.get("status") != "passed":
                errors.append("先导模块未验收通过: pilot_acceptance.status 必须为 passed")
            if not _is_concrete(pilot_acceptance.get("evidence")):
                errors.append("pilot_acceptance.evidence 缺具体审查证据")

    actual_rows: dict[tuple[str, str], int] = {}
    for spec in prepared_specs:
        for case in spec.cases:
            normalized = _normalize_method(case.method)
            if normalized in set(COMBINATION_METHOD_ALIASES.values()):
                key = (spec.module, normalized)
                actual_rows[key] = actual_rows.get(key, 0) + 1

    plan_rows = contract.get("combination_dataset_plan")
    if not isinstance(plan_rows, list):
        errors.append("combination_dataset_plan 必须是数组")
        plan_rows = []
    planned: dict[tuple[str, str], int] = {}
    for index, row in enumerate(plan_rows, 1):
        if not isinstance(row, dict):
            errors.append(f"combination_dataset_plan[{index}] 必须是对象")
            continue
        module = str(row.get("module", "") or "").strip()
        method = _normalize_method(row.get("method", ""))
        minimum = row.get("minimum_rows")
        key = (module, method)
        if module not in in_scope_modules:
            errors.append(f"组合数据计划引用非范围内模块: {module!r}")
        if method not in set(COMBINATION_METHOD_ALIASES.values()):
            errors.append(f"组合数据计划 method 无效或占位: {row.get('method')!r}")
        if key in planned:
            errors.append(f"组合数据计划重复: {module}/{method}")
        if not isinstance(minimum, int) or isinstance(minimum, bool) or minimum < 1:
            errors.append(f"组合数据计划 {module}/{method} minimum_rows 必须为正整数")
            minimum = 1
        planned[key] = minimum
        if row.get("locked") is not True:
            errors.append(f"组合数据计划 {module}/{method} 未锁定")
        methods = module_map.get(module, {}).get("applicable_test_methods", [])
        normalized_methods = {_normalize_method(value) for value in methods} if isinstance(methods, list) else set()
        if method and method not in normalized_methods:
            errors.append(f"组合数据计划 {module}/{method} 未列入模块 applicable_test_methods")

    for module, row in module_map.items():
        if row.get("in_scope") is not True:
            continue
        if pilot_only and module not in pilot_module_set:
            continue
        methods = row.get("applicable_test_methods", [])
        for raw_method in methods if isinstance(methods, list) else []:
            method = _normalize_method(raw_method)
            if method in set(COMBINATION_METHOD_ALIASES.values()) and (module, method) not in planned:
                errors.append(f"合同声明 {module}/{method} 适用，但缺组合数据计划")

    applicable_plans = {
        key: minimum for key, minimum in planned.items()
        if not pilot_only or key[0] in pilot_module_set
    }
    for key, minimum in applicable_plans.items():
        count = actual_rows.get(key, 0)
        if count < minimum:
            errors.append(
                f"合同声明 {key[0]}/{key[1]} 至少{minimum}行，spec仅有{count}行具体数据"
            )
    for key in sorted(set(actual_rows) - set(planned)):
        errors.append(f"spec存在未纳入合同计划的组合数据行: {key[0]}/{key[1]}")
    return pilot_module_set


def load_and_validate_generation_inputs(
    project_dir: Path,
    *,
    pilot_only: bool = False,
) -> list[PreparedSpec]:
    """只读加载并校验全部生成输入；失败时不修改任何项目文件。"""
    errors: list[str] = []
    prepared_specs = _load_prepared_specs(project_dir, errors)
    required, filename, config = _contract_policy(project_dir, errors)
    contract_path = project_dir / filename
    if required and not contract_path.exists():
        errors.append(f"项目配置要求生成验收合同，但文件缺失: {contract_path}")
    pilot_modules: set[str] = set()
    contract_schema_level = 0
    if contract_path.exists():
        contract = _read_json(contract_path, "生成验收合同", errors)
        if (
            isinstance(contract, dict)
            and isinstance(contract.get("schema_version"), int)
            and not isinstance(contract.get("schema_version"), bool)
        ):
            contract_schema_level = contract["schema_version"]
        pilot_modules = _validate_contract(contract, prepared_specs, errors, pilot_only=pilot_only)
        if (
            isinstance(contract, dict)
            and isinstance(contract.get("schema_version"), int)
            and not isinstance(contract.get("schema_version"), bool)
            and contract.get("schema_version") >= 2
        ):
            if not isinstance(config, dict):
                errors.append("schema v2 生成验收合同要求存在 trace.config.json")
            else:
                contract_order = (contract.get("module_order") or {}).get("items", [])
                config_order = [row.get("name") for row in config.get("modules", []) if isinstance(row, dict)]
                if contract_order != config_order:
                    errors.append("trace.config.json 模块顺序与生成验收合同 module_order 不一致")
                contract_coverage = contract.get("coverage_policy") or {}
                config_coverage = config.get("coverage_policy") or {}
                scalar_pairs = (
                    ("coverage_threshold", config.get("coverage_threshold")),
                    ("require_zero_partial", config_coverage.get("require_zero_partial")),
                    ("pending_evidence_mode", config_coverage.get("pending_evidence_mode")),
                )
                for key, actual in scalar_pairs:
                    if contract_coverage.get(key) != actual:
                        errors.append(f"trace.config.json {key} 与生成验收合同 coverage_policy 不一致")
                for key in ("accepted_partial_req_ids", "accepted_pending_req_ids"):
                    if contract_coverage.get(key, []) != config_coverage.get(key, []):
                        errors.append(f"trace.config.json {key} 与生成验收合同 coverage_policy 不一致")
    elif pilot_only:
        errors.append("--pilot 必须提供生成验收合同，无法从遗留项目推断先导模块")
    factor_evidence_required = (
        contract_schema_level >= 3 or _config_requires_manual_factor_evidence(config)
    )
    evidence_specs = prepared_specs
    if pilot_only:
        evidence_specs = [spec for spec in prepared_specs if spec.module in pilot_modules]
    _validate_factor_evidence(
        evidence_specs,
        errors,
        required=factor_evidence_required,
    )
    if errors:
        raise GenerationContractError(errors)
    if pilot_only:
        return [spec for spec in prepared_specs if spec.module in pilot_modules]
    return prepared_specs


def main() -> None:
    parser = argparse.ArgumentParser(description="校验生成前验收合同与紧凑用例规格")
    parser.add_argument("--project", required=True, help="项目目录或项目绝对路径")
    parser.add_argument("--workspace-root", help="项目工作区根目录；--project 为名称时生效")
    parser.add_argument("--pilot", action="store_true", help="只校验合同中的3-5个先导模块")
    args = parser.parse_args()
    project_dir = resolve_project(args.project, workspace_root=args.workspace_root)
    try:
        specs = load_and_validate_generation_inputs(project_dir, pilot_only=args.pilot)
    except GenerationContractError as exc:
        print(json.dumps({"success": False, "errors": exc.errors}, ensure_ascii=False, indent=2))
        raise SystemExit(1) from exc
    case_count = sum(len(spec.cases) for spec in specs)
    print(json.dumps({
        "success": True,
        "project": project_dir.name,
        "mode": "pilot" if args.pilot else "full",
        "modules": len(specs),
        "cases": case_count,
        "errors": [],
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
