---
name: test-workflow-orchestrator
description: 端到端测试工作流主控。当用户要求从 PRD、蓝湖、需求或已有 Excel 生成、修订、审查并交付测试用例时使用。先生成可见执行画像，普通任务走轻量核心路径，复杂或正式任务按风险加载完整追溯、先导、UI矩阵、跨端冲突、稳定ID迁移、严格多Agent评审和正式准出能力包；支持独立功能工作单并行、核心 S1-S36 与按平台启用 S37、Excel 实物验收和兼容 GO/NO_GO 外层状态。
---

# 测试工作流 v2

本文件只负责路由、编排和准出。用例固定层级与内容合同由 [`../test-planning/SKILL.md`](../test-planning/SKILL.md) 定义；PRD 审查与覆盖判定细则分别见 [`references/需求文档审查清单.md`](references/需求文档审查清单.md) 和 [`references/覆盖追溯判定规范.md`](references/覆盖追溯判定规范.md)。

## 任务路由

1. 直接生成、修订、评审或交付测试用例：使用本主控。
2. 只有测试计划、测试方案、测试策略或测试点分析：转到 `../test-planning/SKILL.md`，无需初始化完整工作流项目。
3. 蓝湖或 Axure 输入：先按 `../lanhu-prd-parser/SKILL.md` 生成 PRD，再回到本主控。
4. 已有 Excel 定向修订：保留原文件作证据，扫描全表同类模式，只重建受影响源数据、Excel、哈希和核心回归；不重跑输入未变化的阶段。
5. 多个相互独立的功能或 PRD：按功能拆 `workunits/` 并行生成，禁止按正常/异常/交叉测试类型拆分同一功能。

新项目先生成 `执行画像.json`；路由结论必须可查看、可覆盖：

```powershell
python scripts/new_project.py --name "<项目>" --workspace-root "<外部工作区根目录>" --execution-mode auto --work-unit "<功能1>" --work-unit "<功能2>" --platform Android --platform iOS
```

- `auto`：默认选择 core；命中高风险或严格能力包时只能升级。
- `core`：常规团队生产和过审，保持全部核心质量门禁。
- `strict`：完整追溯、先导、严格评审和正式准出。
- 用户明确要求“完整流程、完整追溯、对抗评审、正式 GO/NO_GO、客户发布或审计留档”时，强制 `strict`。
- 缺少 `执行画像.json` 的历史项目继续走严格兼容路径，不自动降级。

## 能力包

所有任务共用一套生成与核心门禁；能力包只追加检查和证据，不复制流程。

| 能力包 | 触发条件 | 追加内容 |
| --- | --- | --- |
| `peer_review` | 多个独立工作单 | 工作单轮换同行评审 |
| `platform_coverage` | Android/iOS 等多平台 | 每个平台完整主流程，门禁 S37 |
| `full_traceability` | 要求覆盖证明、需求冲突、正式签核 | Gate B、决策账本、完整追溯 |
| `pilot` | 新形态、新生成器、复杂组合或高扩散风险 | 完整生成合同、3 至 5 个高风险先导 |
| `ui_matrix` | 有屏且存在多输入或页面状态 | 页面锚点、输入矩阵和顺序检查 |
| `cross_end_conflict` | App/设备同步、BLE、恢复、并发或冲突 | 依赖边界、冲突矩阵和一致性检查 |
| `stable_id_migration` | 既有用例重排、插入、拆合或迁移 | 稳定 ID 迁移证据 |
| `strict_review` | 明确对抗评审或高影响链路 | 隔离的双对抗和双回归 Reviewer |
| `formal_release` | 正式 GO/NO_GO、客户发布、审计 | 不可变 acceptance run、完整报告和 manifest |

风险特征只能升级，不能降级。不适用能力必须在 `执行画像.json -> not_enabled` 写具体原因，不为简单项目构造空证据。

## 核心流程

1. **锁定输入与范围**：记录 PRD、版本、补充说明、平台、交付字段和真实 Blocker；只有结论会改变实现时才停下确认。
2. **建立归类蓝图**：core 至少填写 `module_boundary / feature_order / execution_order / hierarchy_map / unsupported_features / platform_scope / main_risks`；`module_boundary` 必须含范围、所属结果和外部功能关键词，能力包按需追加页面、异常、冲突和组合数据。
3. **检索并设计**：读取 `../test-planning/SKILL.md`，执行多轮知识路由，再按固定层级和 PRD 裁剪生成；常规任务不默认加载完整先导合同。
4. **生成工作单**：各工作单只写自己的目录，交回路径、用例数、哈希、待确认和自检结果。
5. **同行评审与集中修订**：启用 `peer_review` 的多功能任务轮换评审一次，主代理汇总共性和单功能问题后集中修订；仅 `strict_review` 启动四 Reviewer。
6. **统一验收**：重新打开最终 Excel，全表检查措辞、归类、执行顺序、功能边界与连续区块，按功能点检查执行语义，核对数量、版本和 SHA-256；人员执行质量复核账本与所有报告必须绑定同一候选文件哈希。自动结果、已启用的评审证据和人工验收同时通过，才满足双轴准出。
7. **单一准出**：运行 `release_acceptance.py`；任何后续文件变化都使旧结论失效。

质量第一,数量其次。核心路径必须拦截字段/源数据、层级归属、重复意图、步骤预期、适用范围、待确认样式、Excel 实物、当前哈希和人工语义问题；`功能模块 + 功能点 + 测试项` 默认只能形成一个连续区块。措辞、归类、顺序和功能边界是不可关闭的 P0 人员执行质量门禁：`scripts/execution_quality_gate.py` 负责确定性扫描、候选闭环、全表人工复核和 Excel 哈希绑定，任一维度未通过即 `NO_GO + DRAFT`。Gate C 的权威实现是 `scripts/check_structure.py`：S1-S36 为固定核心检查，S36 检查三级分组连续；命中 `platform_coverage` 时追加 S37 检查平台主流程覆盖。不要在入口复制各编号细则，失败时按编号检索规则并修源数据。

## 并行工作单

冻结共享 PRD 基线、字段合同、命名、蓝图和准出标准后再分发：

```text
workunits/<功能>/
```

- 脚手架为每个目录生成 `工作单合同.json`；填写真实 PRD 和蓝图后运行 `python scripts/work_unit_contract.py --project "<项目>" --workspace-root "<项目根>" --freeze`，再分发工作单。
- 一个工作单负责一个完整功能的生成、自检和修订，只能写本目录。
- 第一波并行生成；第二波轮换检查其他功能的归类、重复、遗漏、步骤预期和平台范围。
- 一个工作单失败只修该工作单；共性规则问题才回归所有受影响工作单；输入与哈希未变化时不重复评审。
- 子代理不得改共享规则、其他工作单或最终合并目录，也不得宣布项目整体通过。
- 主代理独占统一问题清单、合并目录、最终实物验收和准出决定。
- 工作单交回后运行 `python scripts/work_unit_contract.py --project "<项目>" --workspace-root "<项目根>" --validate --require-complete --json`；输入哈希、用例数、交回文件、自检、同行评审和主验收任一不一致均不得合并。

严格多 Agent 的角色、隔离、收敛和证据要求只在 [`../test-planning/references/规则/测试用例多轮评审.md`](../test-planning/references/规则/测试用例多轮评审.md) 定义；只有 `strict_review` 命中时读取。

## 准出状态

内部进度状态与外层发布枚举分开：

| 内部状态 | 含义 |
| --- | --- |
| `DRAFT` | 尚未完成核心验收 |
| `READY_FOR_REVIEW` | core 通过，可交团队评审或执行 |
| `READY_WITH_RISKS` | 核心门禁通过，但存在已列明的待确认或可接受风险 |
| `STRICT_GO` | strict 与正式证据全部通过 |

为兼容现有消费者，外层 `release_decision` 只使用 `GO` / `NO_GO`；上述等级写入独立 `readiness_level`。无风险的 core 映射为 `GO + READY_FOR_REVIEW`，无风险的 strict 映射为 `GO + STRICT_GO`；任一模式存在已接受风险时映射为 `GO + READY_WITH_RISKS`，失败映射为 `NO_GO + DRAFT`。`delivery_status` 仅保留为旧消费者兼容别名。普通“发给同事过审一遍”不冒充正式过审。

固定流程在“产物就绪”结束。外部发送授权与回读只按 [`../../references/qa-testcase-delivery.md`](../../references/qa-testcase-delivery.md) 执行。

## 命令入口

以下命令默认当前目录为 `workflow-v2/`，项目可用名称加 `--workspace-root`，也可直接传项目绝对路径：

```powershell
python scripts/new_project.py --name "<项目>" --workspace-root "<项目根>" --execution-mode auto --work-unit "<功能>"
python ..\test-planning\scripts\route_knowledge_retrieval.py --product "<形态>" --modules "<模块>" --prd-keywords "<关键词>" --output "<项目目录>"
python scripts/generation_contract.py --project "<项目>" --workspace-root "<项目根>"
python scripts/casegen.py --project "<项目>" --workspace-root "<项目根>"
python scripts/export_cases.py --project "<项目>" --workspace-root "<项目根>" --single-sheet
python scripts/check_structure.py --config "<项目目录>\trace.config.json"
python scripts/execution_quality_gate.py --config "<项目目录>\trace.config.json" --init-review
python scripts/release_acceptance.py --config "<项目目录>\trace.config.json"
```

启用 `pilot` 时先给 `generation_contract.py` 和 `casegen.py` 加 `--pilot`，验收通过后再生成正式 `cases/`。重排和迁移只使用 `export_cases.py --renumber --migration-file <文件>`，禁止基于 Excel 展示行号维护身份。

按需读取参考，普通任务总计只加载 1 至 3 份：

- 用例层级、检索和内容合同：`../test-planning/SKILL.md`。
- PRD Blocker 与可测性：`references/需求文档审查清单.md`。
- 完整追溯：`references/覆盖追溯判定规范.md`。
- Excel 字段和物理格式：`../test-planning/references/规范/Excel与XMind输出规范.md`。
- strict 多 Agent：`../test-planning/references/规则/测试用例多轮评审.md`。

便携校验兼容短语：`S1-S35` 仍属于当前 S1-S36 核心范围；正式参数示例保持 `验证设置<参数名>为<PRD实际值>`。
