# TDD Real Verification 吸收参考

## 定位

本文件用于吸收 Beachburg `test-driven-development` 的真实验证原则，约束小周内置 QA 能力中涉及代码修复、脚本调整、自动化工具修改和回归验证的工作。

它不是要求所有测试用例设计都走代码 TDD；它要求凡是改代码、改脚本、改门禁、改导出工具，都必须用真实命令和真实输出证明改动有效。

## 适用范围

- 修复 `workflow-v2/scripts/` 中的脚本。
- 修复 `test-planning/scripts/` 中的检索、校验、发布脚本。
- 修改 Excel 读写、覆盖追溯、补强插入、编号迁移、结构检查。
- 为某个缺陷补自动化回归验证。
- 验收其他模型或同事完成的脚本修复。

## 核心原则

- 不编造测试结果。
- 不只写“已验证”。
- 必须报告真实命令和真实输出摘要。
- 能写失败用例的，先让它失败，再修复，再让它通过。
- 不能自动化验证的，必须说明原因、手工验证步骤和剩余风险。

## 推荐流程

### 1. 复现或构造失败

优先选择最小可复现方式：

- 运行现有失败命令。
- 构造最小 Excel / JSON / trace.config 样例。
- 写一个针对函数或脚本行为的失败测试。
- 如果是门禁缺口，构造 fail / pass 两组样本。

记录：

```text
RED command:
RED output summary:
Expected failure reason:
```

### 2. 最小修复

只改与失败原因相关的代码，不顺手重构无关逻辑。

禁止：

- 为了让测试过而删除门禁。
- 放宽现有 S1-S35 规则。
- 跳过 Excel 15 列或覆盖追溯。
- 改动 `knowledge/` 或项目产物来掩盖脚本问题。

### 3. 重新验证

修复后重新运行同一命令或测试，再运行相关回归。

记录：

```text
GREEN command:
GREEN output summary:
Regression command:
Regression output summary:
```

### 4. 说明剩余风险

如果某项验证没跑，必须写：

```text
Not run:
Reason:
Residual risk:
```

## 证据格式

最终回复或验收记录中至少包含：

```text
Commands run:
- <command>

Results:
- <actual summary>

Files checked:
- <path>

Not run:
- <reason, if any>
```

## 与当前门禁的关系

- 修改结构检查：至少要证明相关 S 编号的 fail / pass 行为。
- 修改覆盖追溯：至少要证明 extract / assemble / gate 的关键路径。
- 修改 Excel 读写：至少要证明标准 15 列、合并读取回填、待确认标红或相关样式未破坏。
- 修改知识检索：至少要证明目标关键词命中预期条目。
- 修改补强插入：至少要证明 `_anchor_id` 插入、编号、字段齐全和覆盖回指。

## 不能自动化时

允许手工验证，但必须明确：

- 为什么无法自动化。
- 手工验证环境。
- 手工步骤。
- 观察到的真实结果。
- 哪些边界仍未覆盖。

手工验证不能写成泛化的“看起来正常”，必须写可观察证据。
