from __future__ import annotations

import argparse
import importlib.util
import json
import subprocess
import sys
from pathlib import Path


QA_ROOT = Path(__file__).resolve().parents[1]
REQUIREMENTS = QA_ROOT / "requirements.txt"
MODULES = {
    "openpyxl": "Excel generation and quality gates",
    "numpy": "image OCR array conversion",
    "PIL": "image loading for OCR",
    "rapidocr_onnxruntime": "offline screenshot OCR",
}


def status() -> dict[str, object]:
    available = {name: importlib.util.find_spec(name) is not None for name in MODULES}
    return {
        "python": sys.version.split()[0],
        "requirements": str(REQUIREMENTS),
        "available": available,
        "missing": [name for name, ok in available.items() if not ok],
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Check or install Xiaozhou portable QA dependencies.")
    parser.add_argument("--install", action="store_true", help="Install missing dependencies from requirements.txt.")
    parser.add_argument("--json", action="store_true", help="Print machine-readable JSON.")
    args = parser.parse_args()

    result = status()
    if result["missing"] and args.install:
        command = [sys.executable, "-m", "pip", "install", "-r", str(REQUIREMENTS)]
        completed = subprocess.run(command, cwd=QA_ROOT)
        if completed.returncode != 0:
            raise SystemExit(completed.returncode)
        result = status()

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"Python: {result['python']}")
        for name, ok in result["available"].items():
            print(f"{'PASS' if ok else 'MISSING'}: {name} - {MODULES[name]}")
        if result["missing"]:
            print(f"Install: {sys.executable} -m pip install -r {REQUIREMENTS}")

    if result["missing"]:
        raise SystemExit(2)


if __name__ == "__main__":
    main()
