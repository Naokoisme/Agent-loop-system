from __future__ import annotations

import argparse
import importlib.util
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path


sys.dont_write_bytecode = True


QA_ROOT = Path(__file__).resolve().parents[1]
WORKFLOW = QA_ROOT / "workflow-v2"
TEST_PLANNING = QA_ROOT / "test-planning"


def run(command: list[str], cwd: Path) -> dict[str, object]:
    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    completed = subprocess.run(
        command,
        cwd=cwd,
        env=env,
        text=True,
        capture_output=True,
        encoding="utf-8",
        errors="replace",
    )
    return {
        "command": command,
        "cwd": str(cwd),
        "returncode": completed.returncode,
        "stdout": completed.stdout.strip(),
        "stderr": completed.stderr.strip(),
    }


def load_tc_excel():
    path = WORKFLOW / "scripts" / "tc_excel.py"
    spec = importlib.util.spec_from_file_location("qatest_skill_tc_excel", path)
    if not spec or not spec.loader:
        raise RuntimeError(f"Cannot load Excel helper: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def load_lineage():
    path = WORKFLOW / "scripts" / "lineage.py"
    spec = importlib.util.spec_from_file_location("qatest_skill_lineage", path)
    if not spec or not spec.loader:
        raise RuntimeError(f"Cannot load build-lineage helper: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def load_judge_build():
    scripts = WORKFLOW / "scripts"
    if str(scripts) not in sys.path:
        sys.path.insert(0, str(scripts))
    path = scripts / "judge_build.py"
    spec = importlib.util.spec_from_file_location("qatest_skill_judge_build", path)
    if not spec or not spec.loader:
        raise RuntimeError(f"Cannot load result-lineage entry point: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> None:
    parser = argparse.ArgumentParser(description="Run a non-customer portable QA smoke test.")
    parser.add_argument("--json", action="store_true", help="Print machine-readable JSON.")
    args = parser.parse_args()

    checks: list[dict[str, object]] = []
    errors: list[str] = []
    with tempfile.TemporaryDirectory(prefix="qatest-skill-smoke-") as temp_dir:
        temp = Path(temp_dir)
        xlsx = temp / "portable-testcases.xlsx"
        rows = [
            {
                "用例编号": "SMK_001",
                "功能模块": "Portable QA",
                "功能点": "Device connection",
                "测试项": "Core flow",
                "测试点/检查项": "Verify the device page shows the connected device",
                "前置条件": "1. The test device is paired with the demo app",
                "操作步骤": "1. Open the device page in the demo app",
                "预期结果": "1. The page shows the paired device as connected",
                "优先级": "P0",
                "兼容性": "Android/iOS",
                "是否自动化": "否",
                "固件版本": "N/A",
                "硬件型号": "N/A",
                "测试方式": "人工执行",
                "备注": "Portable workbook sample",
            },
            {
                "用例编号": "SMK_002",
                "功能模块": "Portable QA",
                "功能点": "Recovery",
                "测试项": "Connection recovery",
                "测试点/检查项": "Verify the device reconnects after Bluetooth is restored",
                "前置条件": "1. The paired device is shown as disconnected in the demo app",
                "操作步骤": "1. Enable Bluetooth on the phone",
                "预期结果": "1. The demo app shows the paired device as connected",
                "优先级": "P1",
                "兼容性": "Android/iOS",
                "是否自动化": "否",
                "固件版本": "N/A",
                "硬件型号": "N/A",
                "测试方式": "人工执行",
                "备注": "Portable workbook sample",
            },
        ]
        tc_excel = load_tc_excel()
        tc_excel.write_workbook(rows, xlsx, ["Portable QA"])
        if not xlsx.is_file() or xlsx.stat().st_size == 0:
            errors.append("Excel writer did not create a non-empty workbook")

        try:
            lineage = load_lineage()
            lineage_api_ok = all(
                callable(getattr(lineage, name, None))
                for name in (
                    "record_casegen", "verify_before_export", "record_export",
                    "verify_before_trace", "record_trace", "validate_release",
                )
            ) and lineage.required(temp) is False
            checks.append({
                "name": "build_lineage_import_and_api",
                "returncode": 0 if lineage_api_ok else 1,
                "stdout": "lineage API available" if lineage_api_ok else "lineage API incomplete",
                "stderr": "",
            })
            if not lineage_api_ok:
                errors.append("Build-lineage helper API is incomplete")
        except Exception as exc:
            checks.append({
                "name": "build_lineage_import_and_api",
                "returncode": 1,
                "stdout": "",
                "stderr": str(exc),
            })
            errors.append(f"Build-lineage helper could not be imported: {exc}")

        try:
            judge_build = load_judge_build()
            judge_api_ok = all(
                callable(getattr(judge_build, name, None)) for name in ("build", "main")
            ) and callable(getattr(judge_build, "record_results", None)) \
                and callable(getattr(judge_build, "result_binding", None))
            checks.append({
                "name": "result_lineage_entrypoint_import_and_api",
                "returncode": 0 if judge_api_ok else 1,
                "stdout": "judge_build API available" if judge_api_ok else "judge_build API incomplete",
                "stderr": "",
            })
            if not judge_api_ok:
                errors.append("Result-lineage entry point API is incomplete")
        except Exception as exc:
            checks.append({
                "name": "result_lineage_entrypoint_import_and_api",
                "returncode": 1,
                "stdout": "",
                "stderr": str(exc),
            })
            errors.append(f"Result-lineage entry point could not be imported: {exc}")

        gate = run([sys.executable, str(WORKFLOW / "scripts" / "check_structure.py"), "--xlsx", str(xlsx)], WORKFLOW)
        checks.append(gate)
        if gate["returncode"] != 0:
            errors.append("Generated workbook failed Gate C smoke validation")

        delivery_quality = run(
            [sys.executable, str(WORKFLOW / "scripts" / "test_delivery_quality_regressions.py")],
            WORKFLOW,
        )
        checks.append(delivery_quality)
        if delivery_quality["returncode"] != 0:
            errors.append("Final workbook design and delivery quality regression suite failed")

        execution_quality = run(
            [sys.executable, str(WORKFLOW / "scripts" / "test_execution_quality_regressions.py")],
            WORKFLOW,
        )
        checks.append(execution_quality)
        if execution_quality["returncode"] != 0:
            errors.append("Personnel execution quality regression suite failed")

        trace_extract_profiles = run(
            [sys.executable, str(WORKFLOW / "scripts" / "test_trace_extract_regressions.py")],
            WORKFLOW,
        )
        checks.append(trace_extract_profiles)
        if trace_extract_profiles["returncode"] != 0:
            errors.append("Compact and standard trace extraction regression suite failed")

        regressions = run(
            [sys.executable, str(WORKFLOW / "scripts" / "test_quality_regressions.py")],
            WORKFLOW,
        )
        checks.append(regressions)
        if regressions["returncode"] != 0:
            errors.append("QA failure-mode regression suite failed")

        generation_contract = run(
            [sys.executable, str(WORKFLOW / "scripts" / "test_generation_contract_regressions.py")],
            WORKFLOW,
        )
        checks.append(generation_contract)
        if generation_contract["returncode"] != 0:
            errors.append("Generation acceptance contract regression suite failed")

        feedback_sampling = run(
            [sys.executable, str(WORKFLOW / "scripts" / "test_feedback_sampling_regressions.py")],
            WORKFLOW,
        )
        checks.append(feedback_sampling)
        if feedback_sampling["returncode"] != 0:
            errors.append("Feedback full-scan and stratified acceptance regression suite failed")

        multi_round_review = run(
            [sys.executable, str(WORKFLOW / "scripts" / "test_multi_round_review_regressions.py")],
            WORKFLOW,
        )
        checks.append(multi_round_review)
        if multi_round_review["returncode"] != 0:
            errors.append("Multi-round testcase review convergence regression suite failed")

        release_acceptance = run(
            [sys.executable, str(WORKFLOW / "scripts" / "test_release_acceptance_regressions.py")],
            WORKFLOW,
        )
        checks.append(release_acceptance)
        if release_acceptance["returncode"] != 0:
            errors.append("Versioned single release gate regression suite failed")

        lightweight_routing = run(
            [sys.executable, str(WORKFLOW / "scripts" / "test_lightweight_routing_regressions.py")],
            WORKFLOW,
        )
        checks.append(lightweight_routing)
        if lightweight_routing["returncode"] != 0:
            errors.append("Lightweight routing and work-unit contract regression suite failed")

        stable_ids = run(
            [sys.executable, str(WORKFLOW / "scripts" / "test_stable_ids.py")],
            WORKFLOW,
        )
        checks.append(stable_ids)
        if stable_ids["returncode"] != 0:
            errors.append("Stable testcase identity pipeline regression failed")

        ocr_tiling = run(
            [sys.executable, str(QA_ROOT / "lanhu-prd-parser" / "scripts" / "test_large_image_tiling.py")],
            QA_ROOT,
        )
        checks.append(ocr_tiling)
        if ocr_tiling["returncode"] != 0:
            errors.append("Lanhu large-image OCR tiling regression failed")

        search = run(
            [
                sys.executable,
                str(TEST_PLANNING / "scripts" / "search_semantic_knowledge.py"),
                "--关键词",
                "带屏耳机仓 OTA 中断恢复 测试用例",
                "--分类",
                "功能模块",
                "--数量",
                "1",
                "--format",
                "json",
            ],
            TEST_PLANNING,
        )
        checks.append(search)
        if search["returncode"] != 0 or "OTA" not in str(search["stdout"]):
            errors.append("Bundled semantic retrieval did not return the expected OTA capability")

        knowledge_root = temp / "knowledge"
        publish = run(
            [
                sys.executable,
                str(TEST_PLANNING / "scripts" / "publish_knowledge.py"),
                "--category",
                "rule",
                "--title",
                "Portable smoke knowledge",
                "--summary",
                "Portable local knowledge writeback verification",
                "--content",
                "Bundled QA knowledge can be written and validated without Git.",
                "--tags",
                "app",
                "--knowledge-root",
                str(knowledge_root),
            ],
            TEST_PLANNING,
        )
        checks.append(publish)
        written = knowledge_root / "规则" / "Portable-smoke-knowledge.json"
        if publish["returncode"] != 0 or not written.is_file():
            errors.append("Portable local knowledge writeback or validation failed")

        result = {
            "success": not errors,
            "qa_root": str(QA_ROOT),
            "workbook_bytes": xlsx.stat().st_size if xlsx.exists() else 0,
            "checks": checks,
            "errors": errors,
        }

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("PASS" if result["success"] else "FAIL")
        print(f"Workbook bytes: {result['workbook_bytes']}")
        for error in errors:
            print(f"- {error}")

    if errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
