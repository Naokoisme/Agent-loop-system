# -*- coding: utf-8 -*-
"""Run the focused, non-customer QA capability regression line.

This entry point intentionally excludes portable-package verification.  Static
package verification remains a separate command so neither command can invoke
itself indirectly and packaging can choose the appropriate validation depth.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Any


sys.dont_write_bytecode = True

QA_ROOT = Path(__file__).resolve().parents[1]
WORKFLOW = QA_ROOT / "workflow-v2"
WORKFLOW_SCRIPTS = WORKFLOW / "scripts"
TEST_PLANNING = QA_ROOT / "test-planning"


def load_audit_contract():
    path = WORKFLOW_SCRIPTS / "audit_contract.py"
    spec = importlib.util.spec_from_file_location("qatest_skill_audit_contract", path)
    if not spec or not spec.loader:
        raise RuntimeError(f"cannot load audit contract: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


AUDIT = load_audit_contract()

REQUIRED_FILES = [
    WORKFLOW_SCRIPTS / "generation_contract.py",
    WORKFLOW_SCRIPTS / "test_generation_contract_regressions.py",
    WORKFLOW_SCRIPTS / "delivery_quality.py",
    WORKFLOW_SCRIPTS / "test_delivery_quality_regressions.py",
    WORKFLOW_SCRIPTS / "execution_quality_gate.py",
    WORKFLOW_SCRIPTS / "test_execution_quality_regressions.py",
    WORKFLOW_SCRIPTS / "test_trace_extract_regressions.py",
    WORKFLOW_SCRIPTS / "feedback_pattern_gate.py",
    WORKFLOW_SCRIPTS / "multi_round_review_gate.py",
    WORKFLOW_SCRIPTS / "test_multi_round_review_regressions.py",
    WORKFLOW_SCRIPTS / "stratified_acceptance_sample.py",
    WORKFLOW_SCRIPTS / "test_feedback_sampling_regressions.py",
    WORKFLOW_SCRIPTS / "release_acceptance.py",
    WORKFLOW_SCRIPTS / "test_release_acceptance_regressions.py",
    WORKFLOW_SCRIPTS / "work_unit_contract.py",
    WORKFLOW_SCRIPTS / "test_lightweight_routing_regressions.py",
    WORKFLOW_SCRIPTS / "lineage.py",
    WORKFLOW_SCRIPTS / "judge_build.py",
    WORKFLOW_SCRIPTS / "audit_contract.py",
    WORKFLOW_SCRIPTS / "test_audit_contract_regressions.py",
    Path(__file__).resolve(),
]


CHECKS = [
    {
        "name": "lightweight_routing",
        "script": WORKFLOW_SCRIPTS / "test_lightweight_routing_regressions.py",
        "cwd": WORKFLOW,
    },
    {
        "name": "delivery_quality",
        "script": WORKFLOW_SCRIPTS / "test_delivery_quality_regressions.py",
        "cwd": WORKFLOW,
    },
    {
        "name": "execution_quality",
        "script": WORKFLOW_SCRIPTS / "test_execution_quality_regressions.py",
        "cwd": WORKFLOW,
    },
    {
        "name": "trace_extract_profiles",
        "script": WORKFLOW_SCRIPTS / "test_trace_extract_regressions.py",
        "cwd": WORKFLOW,
    },
    {
        "name": "generation_contract",
        "script": WORKFLOW_SCRIPTS / "test_generation_contract_regressions.py",
        "cwd": WORKFLOW,
    },
    {
        "name": "audit_contract",
        "script": WORKFLOW_SCRIPTS / "test_audit_contract_regressions.py",
        "cwd": WORKFLOW,
    },
    {
        "name": "quality_gates",
        "script": WORKFLOW_SCRIPTS / "test_quality_regressions.py",
        "cwd": WORKFLOW,
    },
    {
        "name": "feedback_sampling",
        "script": WORKFLOW_SCRIPTS / "test_feedback_sampling_regressions.py",
        "cwd": WORKFLOW,
    },
    {
        "name": "multi_round_review",
        "script": WORKFLOW_SCRIPTS / "test_multi_round_review_regressions.py",
        "cwd": WORKFLOW,
    },
    {
        "name": "release_acceptance",
        "script": WORKFLOW_SCRIPTS / "test_release_acceptance_regressions.py",
        "cwd": WORKFLOW,
    },
    {
        "name": "stable_ids",
        "script": WORKFLOW_SCRIPTS / "test_stable_ids.py",
        "cwd": WORKFLOW,
    },
    {
        "name": "knowledge_validation",
        "script": TEST_PLANNING / "scripts" / "validate_knowledge.py",
        "cwd": TEST_PLANNING,
    },
    {
        "name": "portable_boundary",
        "script": QA_ROOT / "scripts" / "test_portable_package_regressions.py",
        "cwd": QA_ROOT,
    },
    {
        "name": "quick_validate_aggregation",
        "script": QA_ROOT / "scripts" / "test_quick_validate_regressions.py",
        "cwd": QA_ROOT,
    },
]


def parse_json_output(stdout: str) -> Any | None:
    text = str(stdout or "").strip()
    if not text:
        return None
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        return None


def is_audit_payload(payload: Any) -> bool:
    return isinstance(payload, dict) and set(AUDIT.REQUIRED_FIELDS).issubset(payload)


def output_tail(text: str, limit: int = 2400) -> str:
    text = str(text or "").strip()
    return text if len(text) <= limit else text[-limit:]


def child_status(returncode: int, payload: Any | None) -> str:
    if is_audit_payload(payload):
        if not AUDIT.validate_report(payload):
            return str(payload["status"])
        return "BLOCKED"
    if returncode == 0:
        return "PASS"
    if returncode == 1:
        return "FAIL"
    return "BLOCKED"


def run_check(entry: dict[str, Any]) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    name = str(entry["name"])
    script = Path(entry["script"])
    cwd = Path(entry["cwd"])
    command = [sys.executable, str(script)]
    started = time.perf_counter()
    issues: list[dict[str, Any]] = []

    if script.resolve() == Path(__file__).resolve():
        issues.append(
            AUDIT.make_issue(
                "blocking",
                "quick_validate refused a recursive self invocation",
                code="QUICK_VALIDATE_RECURSION",
                kind="blocked",
            )
        )
        return {
            "name": name,
            "status": "BLOCKED",
            "returncode": 2,
            "duration_seconds": 0.0,
            "command": command,
            "cwd": str(cwd),
            "stdout": "",
            "stderr": "recursive command rejected",
        }, issues

    if not script.is_file():
        issues.append(
            AUDIT.make_issue(
                "blocking",
                f"required quick-validation script is missing: {script.relative_to(QA_ROOT)}",
                code=f"{name.upper()}_MISSING",
                kind="blocked",
            )
        )
        return {
            "name": name,
            "status": "BLOCKED",
            "returncode": 2,
            "duration_seconds": 0.0,
            "command": command,
            "cwd": str(cwd),
            "stdout": "",
            "stderr": "required script missing",
        }, issues

    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    try:
        completed = subprocess.run(
            command,
            cwd=cwd,
            env=env,
            text=True,
            capture_output=True,
            encoding="utf-8",
            errors="replace",
        )
    except OSError as exc:
        duration = round(time.perf_counter() - started, 3)
        issues.append(
            AUDIT.make_issue(
                "blocking",
                f"{name} could not be executed: {exc}",
                code=f"{name.upper()}_EXEC_BLOCKED",
                kind="blocked",
            )
        )
        return {
            "name": name,
            "status": "BLOCKED",
            "returncode": 2,
            "duration_seconds": duration,
            "command": command,
            "cwd": str(cwd),
            "stdout": "",
            "stderr": str(exc),
        }, issues

    duration = round(time.perf_counter() - started, 3)
    payload = parse_json_output(completed.stdout)
    status = child_status(completed.returncode, payload)
    details: dict[str, Any] = {
        "returncode": completed.returncode,
        "stdout_tail": output_tail(completed.stdout),
        "stderr_tail": output_tail(completed.stderr),
    }
    if is_audit_payload(payload):
        schema_errors = AUDIT.validate_report(payload)
        if schema_errors:
            status = "BLOCKED"
            issues.append(
                AUDIT.make_issue(
                    "blocking",
                    f"{name} emitted a malformed canonical audit report",
                    code=f"{name.upper()}_AUDIT_SCHEMA",
                    kind="blocked",
                    details={"errors": schema_errors},
                )
            )
        elif status == "PASS_WITH_RISKS":
            issues.append(
                AUDIT.make_issue(
                    "risk",
                    f"{name} passed with risks",
                    code=f"{name.upper()}_RISKS",
                    details={
                        "risk_count": payload.get("risk_count", 0),
                        "warning_count": payload.get("warning_count", 0),
                        "issues": payload.get("issues", []),
                    },
                )
            )
    if status == "FAIL":
        issues.append(
            AUDIT.make_issue(
                "blocking",
                f"{name} regression failed",
                code=f"{name.upper()}_FAIL",
                kind="failure",
                details=details,
            )
        )
    elif status == "BLOCKED" and not issues:
        issues.append(
            AUDIT.make_issue(
                "blocking",
                f"{name} validation was blocked",
                code=f"{name.upper()}_BLOCKED",
                kind="blocked",
                details=details,
            )
        )

    return {
        "name": name,
        "status": status,
        "returncode": completed.returncode,
        "duration_seconds": duration,
        "command": command,
        "cwd": str(cwd),
        "stdout": output_tail(completed.stdout),
        "stderr": output_tail(completed.stderr),
    }, issues


def main() -> None:
    parser = argparse.ArgumentParser(description="Run focused qatest_-skill regressions and knowledge validation.")
    parser.add_argument("--json", action="store_true", help="Compatibility flag; canonical JSON is always printed.")
    args = parser.parse_args()
    del args

    started = time.perf_counter()
    checks: list[dict[str, Any]] = []
    issues: list[dict[str, Any]] = []
    for path in REQUIRED_FILES:
        if not path.is_file():
            issues.append(
                AUDIT.make_issue(
                    "blocking",
                    f"required QA validation file is missing: {path.relative_to(QA_ROOT)}",
                    code="QUICK_VALIDATE_REQUIRED_FILE_MISSING",
                    kind="blocked",
                )
            )
    for entry in CHECKS:
        check, check_issues = run_check(entry)
        checks.append(check)
        issues.extend(check_issues)

    status_counts = {status: sum(1 for check in checks if check["status"] == status) for status in AUDIT.STATUSES}
    report = AUDIT.build_report(
        "quick_validate",
        issues=issues,
        metrics={
            "checks": len(checks),
            "passed": status_counts["PASS"],
            "passed_with_risks": status_counts["PASS_WITH_RISKS"],
            "failed": status_counts["FAIL"],
            "blocked": status_counts["BLOCKED"],
            "duration_seconds": round(time.perf_counter() - started, 3),
        },
        artifacts=[],
        extensions={"success": not any(check["status"] in {"FAIL", "BLOCKED"} for check in checks), "checks": checks},
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    raise SystemExit(AUDIT.exit_code(report))


if __name__ == "__main__":
    main()
