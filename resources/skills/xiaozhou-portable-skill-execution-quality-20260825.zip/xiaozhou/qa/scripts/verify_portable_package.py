from __future__ import annotations

import argparse
import importlib.util
import json
import re
import sys
import tokenize
from pathlib import Path


QA_ROOT = Path(__file__).resolve().parents[1]
EXCLUDED_DIR_NAMES = {".git", ".venv", "venv", "__pycache__"}
EXCLUDED_SUFFIXES = {".pyc", ".pyo"}
REQUIRED = [
    QA_ROOT / "CAPABILITY_MANIFEST.json",
    QA_ROOT / "AGENTS.md",
    QA_ROOT / "portable-ai-usage.md",
    QA_ROOT / "requirements.txt",
    QA_ROOT / "lanhu-prd-parser" / "SKILL.md",
    QA_ROOT / "lanhu-prd-parser" / "scripts" / "extract_prd_from_axure.py",
    QA_ROOT / "lanhu-prd-parser" / "scripts" / "test_large_image_tiling.py",
    QA_ROOT / "test-planning" / "SKILL.md",
    QA_ROOT / "test-planning" / "scripts" / "route_knowledge_retrieval.py",
    QA_ROOT / "test-planning" / "scripts" / "search_semantic_knowledge.py",
    QA_ROOT / "test-planning" / "references" / "检索" / "多轮检索路由配置.json",
    QA_ROOT / "test-planning" / "references" / "规则" / "测试用例多轮评审.md",
    QA_ROOT / "test-planning" / "references" / "规则" / "纯人工功能用例简洁与回归表达.md",
    QA_ROOT / "test-planning" / "references" / "规范" / "人员执行质量判定规范.md",
    QA_ROOT / "workflow-v2" / "SKILL.md",
    QA_ROOT / "workflow-v2" / "用例自审清单.md",
    QA_ROOT / "workflow-v2" / "scripts" / "check_structure.py",
    QA_ROOT / "workflow-v2" / "scripts" / "casegen.py",
    QA_ROOT / "workflow-v2" / "scripts" / "new_project.py",
    QA_ROOT / "workflow-v2" / "scripts" / "execution_profile.py",
    QA_ROOT / "workflow-v2" / "scripts" / "project_paths.py",
    QA_ROOT / "workflow-v2" / "scripts" / "work_unit_contract.py",
    QA_ROOT / "workflow-v2" / "scripts" / "test_lightweight_routing_regressions.py",
    QA_ROOT / "workflow-v2" / "scripts" / "quality_semantics.py",
    QA_ROOT / "workflow-v2" / "scripts" / "audit_contract.py",
    QA_ROOT / "workflow-v2" / "scripts" / "test_audit_contract_regressions.py",
    QA_ROOT / "workflow-v2" / "scripts" / "generation_contract.py",
    QA_ROOT / "workflow-v2" / "scripts" / "test_generation_contract_regressions.py",
    QA_ROOT / "workflow-v2" / "scripts" / "delivery_quality.py",
    QA_ROOT / "workflow-v2" / "scripts" / "test_delivery_quality_regressions.py",
    QA_ROOT / "workflow-v2" / "scripts" / "execution_quality_gate.py",
    QA_ROOT / "workflow-v2" / "scripts" / "test_execution_quality_regressions.py",
    QA_ROOT / "workflow-v2" / "scripts" / "test_trace_extract_regressions.py",
    QA_ROOT / "workflow-v2" / "scripts" / "feedback_pattern_gate.py",
    QA_ROOT / "workflow-v2" / "scripts" / "stratified_acceptance_sample.py",
    QA_ROOT / "workflow-v2" / "scripts" / "test_feedback_sampling_regressions.py",
    QA_ROOT / "workflow-v2" / "scripts" / "multi_round_review_gate.py",
    QA_ROOT / "workflow-v2" / "scripts" / "test_multi_round_review_regressions.py",
    QA_ROOT / "workflow-v2" / "scripts" / "release_acceptance.py",
    QA_ROOT / "workflow-v2" / "scripts" / "test_release_acceptance_regressions.py",
    QA_ROOT / "workflow-v2" / "scripts" / "lineage.py",
    QA_ROOT / "workflow-v2" / "scripts" / "judge_build.py",
    QA_ROOT / "workflow-v2" / "scripts" / "test_quality_regressions.py",
    QA_ROOT / "workflow-v2" / "scripts" / "test_stable_ids.py",
    QA_ROOT / "workflow-v2" / "scripts" / "stable_ids.py",
    QA_ROOT / "workflow-v2" / "scripts" / "export_cases.py",
    QA_ROOT / "workflow-v2" / "scripts" / "traceability" / "trace_extract.py",
    QA_ROOT / "workflow-v2" / "scripts" / "traceability" / "trace_gate.py",
    QA_ROOT / "scripts" / "quick_validate.py",
    QA_ROOT / "scripts" / "test_quick_validate_regressions.py",
    QA_ROOT / "scripts" / "test_portable_package_regressions.py",
    QA_ROOT.parent / "references" / "qa-testcase-delivery.md",
]
CRITICAL_TEXT = [
    QA_ROOT / "AGENTS.md",
    QA_ROOT / "portable-ai-usage.md",
    QA_ROOT / "lanhu-prd-parser" / "SKILL.md",
    QA_ROOT / "test-planning" / "SKILL.md",
    QA_ROOT / "workflow-v2" / "SKILL.md",
]


def load_audit_contract():
    path = QA_ROOT / "workflow-v2" / "scripts" / "audit_contract.py"
    spec = importlib.util.spec_from_file_location("qatest_skill_audit_contract", path)
    if not spec or not spec.loader:
        raise RuntimeError(f"Cannot load audit contract: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def is_runtime_source(path: Path) -> bool:
    """Match the portable package boundary rather than transient source-tree state."""
    try:
        relative = path.relative_to(QA_ROOT)
    except ValueError:
        return False
    if any(part in EXCLUDED_DIR_NAMES for part in relative.parts):
        return False
    if relative.parts and relative.parts[0] == "workflow-v2" and len(relative.parts) > 1:
        if relative.parts[1] in {"projects", "prd"}:
            return False
    return path.suffix.lower() not in EXCLUDED_SUFFIXES


def main() -> None:
    parser = argparse.ArgumentParser(description="Verify the qatest_-skill repository is complete and portable.")
    parser.add_argument("--json", action="store_true", help="Print machine-readable JSON.")
    args = parser.parse_args()

    errors: list[str] = []
    audit = None
    audit_path = QA_ROOT / "workflow-v2" / "scripts" / "audit_contract.py"
    if audit_path.is_file():
        try:
            audit = load_audit_contract()
            probe = audit.build_report(
                "verify_portable_package.contract_probe",
                issues=[audit.make_issue("risk", "portable contract probe", code="PORTABLE_PROBE")],
            )
            probe_errors = audit.validate_report(probe)
            if probe_errors or probe.get("status") != "PASS_WITH_RISKS" or audit.exit_code(probe) != 0:
                errors.append(f"audit contract self-check failed: {probe_errors or probe}")
        except Exception as exc:
            errors.append(f"audit contract import/self-check failed: {exc}")
    missing = [str(path) for path in REQUIRED if not path.is_file()]
    if missing:
        errors.extend(f"missing required file: {path}" for path in missing)

    python_files = sorted(path for path in QA_ROOT.rglob("*.py") if is_runtime_source(path))
    json_files = sorted(path for path in QA_ROOT.rglob("*.json") if is_runtime_source(path))
    knowledge_json = sorted((QA_ROOT / "test-planning" / "knowledge").rglob("*.json"))
    knowledge_json += sorted((QA_ROOT / "workflow-v2" / "knowledge").rglob("*.json"))

    if len(python_files) < 25:
        errors.append(f"too few Python capability scripts: {len(python_files)}")
    if len(knowledge_json) < 200:
        errors.append(f"too few repository knowledge records: {len(knowledge_json)}")

    for path in python_files:
        try:
            with tokenize.open(path) as handle:
                source = handle.read()
            compile(source, str(path), "exec")
        except Exception as exc:
            errors.append(f"Python compile failed: {path}: {exc}")

    for path in json_files:
        try:
            json.loads(path.read_text(encoding="utf-8"))
        except Exception as exc:
            errors.append(f"JSON parse failed: {path}: {exc}")

    route_config = QA_ROOT / "test-planning" / "references" / "检索" / "多轮检索路由配置.json"
    if route_config.exists():
        route_payload = json.loads(route_config.read_text(encoding="utf-8"))
        gate_routes = route_payload.get("gate_failure_routes", {}) if isinstance(route_payload, dict) else {}
        missing_routes = [f"S{number}" for number in range(1, 38) if f"S{number}" not in gate_routes]
        if missing_routes:
            errors.append(f"missing gate failure retrieval routes: {missing_routes}")

    absolute_pattern = re.compile(r"[A-Za-z]:\\")
    runtime_text = list(python_files) + [path for path in CRITICAL_TEXT if path.exists()]
    for path in runtime_text:
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        if absolute_pattern.search(text):
            errors.append(f"machine-specific absolute path in runtime file: {path}")

    workflow_text = (QA_ROOT / "workflow-v2" / "SKILL.md").read_text(encoding="utf-8")
    agents_text = (QA_ROOT / "AGENTS.md").read_text(encoding="utf-8")
    external_contract_text = (QA_ROOT.parent / "references" / "qa-testcase-delivery.md").read_text(
        encoding="utf-8"
    )
    required_contract_phrases = {
        "workflow-v2/SKILL.md": [
            "产物就绪", "S1-S35", "双轴准出",
            "质量第一,数量其次", "验证设置<参数名>为<PRD实际值>",
        ],
        "AGENTS.md": [
            "用例质量优先,数量其次", "验证设置<参数名>为<具体值>",
        ],
        "references/qa-testcase-delivery.md": [
            "外部发送不是 QA 固定流程", "明确指定渠道和收件人",
        ],
    }
    for label, phrases in required_contract_phrases.items():
        if label.startswith("workflow"):
            text = workflow_text
        elif label == "AGENTS.md":
            text = agents_text
        else:
            text = external_contract_text
        for phrase in phrases:
            if phrase not in text:
                errors.append(f"missing QA delivery contract in {label}: {phrase}")

    capability_manifest = json.loads((QA_ROOT / "CAPABILITY_MANIFEST.json").read_text(encoding="utf-8"))
    manifest_paths = {
        "required_entrypoints": QA_ROOT,
        "required_runtime_files": QA_ROOT,
        "regression_entrypoints": QA_ROOT,
        "external_contracts": QA_ROOT,
    }
    for key, base in manifest_paths.items():
        values = capability_manifest.get(key)
        if not isinstance(values, list) or not values:
            errors.append(f"capability manifest missing non-empty {key}")
            continue
        missing_declared = [value for value in values if not (base / str(value)).is_file()]
        if missing_declared:
            errors.append(f"capability manifest {key} points to missing files: {missing_declared}")
    evidence_keys = capability_manifest.get("validation_evidence")
    if not isinstance(evidence_keys, list) or not evidence_keys:
        errors.append("capability manifest missing non-empty validation_evidence")
    else:
        missing_evidence = [key for key in evidence_keys if not capability_manifest.get(str(key))]
        if missing_evidence:
            errors.append(f"capability manifest validation_evidence keys are unresolved: {missing_evidence}")
    expected_capabilities = {
        "project-wide feedback-pattern scanning with current-workbook hash binding",
        "hash-bound multi-agent testcase review with isolated dual-agent adversarial and regression batches, finding-union preservation, and final workbook inspection",
        "deterministic stratified final acceptance sampling across changed, pending, conflict, high-risk, and feature-point strata",
        "immutable single release acceptance gate with input manifests and stale-report rejection",
        "deterministic schema-v3 build lineage across source, cases, Excel, stable index, trace drafts, and final release",
        "final delivery workbook quality and exact canonical projection validation for headers, font, black borders, merges, version, results, order, and business content",
        "quality-first testcase design with concrete PRD-backed parameter values and deduplicated ordinary-low-middle-high representative coverage",
        "manual-first testcase wording with action-only steps and explicit regression comparison contracts",
        "bounded evidence-based multi-agent review convergence with scope lock and revision cap",
    }
    declared_capabilities = set(capability_manifest.get("bundled_capabilities", [])) \
        if isinstance(capability_manifest, dict) else set()
    missing_capabilities = sorted(expected_capabilities - declared_capabilities)
    if missing_capabilities:
        errors.append(f"capability manifest missing hard-rule declarations: {missing_capabilities}")
    if str(capability_manifest.get("snapshot_date", "")) < "2026-08-14":
        errors.append("capability manifest snapshot_date predates hard-rule release")

    fixed_send_patterns = [
        r"(?:固定流程|固定阶段)[^\n]{0,40}(?:包含|含|必须|自动|默认)[^\n]{0,30}(?:钉钉|DingTalk|邮件|云盘)",
        r"(?:钉钉|DingTalk|邮件|云盘)[^\n]{0,30}(?:属于|纳入|作为)[^\n]{0,30}(?:固定流程|固定阶段)",
    ]
    if any(re.search(pattern, workflow_text, re.I) for pattern in fixed_send_patterns):
        errors.append("workflow incorrectly treats external sending as a fixed QA stage")

    legacy_renumber_commands: list[str] = []
    for path in QA_ROOT.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in {".md", ".py", ".txt"}:
            continue
        if "projects" in path.parts or "__pycache__" in path.parts:
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        lines = text.splitlines()
        for line_number, line in enumerate(lines, 1):
            if "--renumber" not in line or "add_argument" in line or "no-renumber" in line:
                continue
            context = " ".join(lines[line_number - 1:min(len(lines), line_number + 2)])
            executable_context = line.lstrip().startswith("python ") or "下一步:" in line
            if executable_context and "--migration-file" not in context:
                legacy_renumber_commands.append(f"{path}:{line_number}")
    if legacy_renumber_commands:
        errors.append(f"renumber command missing migration file: {legacy_renumber_commands[:20]}")

    result = {
        "success": not errors,
        "qa_root": str(QA_ROOT),
        "python_files": len(python_files),
        "json_files": len(json_files),
        "knowledge_records": len(knowledge_json),
        "errors": errors,
    }

    if audit is not None:
        try:
            canonical = audit.build_report(
                "verify_portable_package",
                issues=[
                    audit.make_issue("blocking", error, code="PORTABLE_VERIFY_FAIL", kind="failure")
                    for error in errors
                ],
                metrics={
                    "python_files": len(python_files),
                    "json_files": len(json_files),
                    "knowledge_records": len(knowledge_json),
                },
                artifacts=[],
            )
            result["audit"] = canonical
        except Exception as exc:
            errors.append(f"audit contract report build failed: {exc}")
            result["success"] = False

    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("PASS" if result["success"] else "FAIL")
        print(f"Python scripts: {result['python_files']}")
        print(f"Knowledge records: {result['knowledge_records']}")
        for error in errors:
            print(f"- {error}")

    if errors:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
