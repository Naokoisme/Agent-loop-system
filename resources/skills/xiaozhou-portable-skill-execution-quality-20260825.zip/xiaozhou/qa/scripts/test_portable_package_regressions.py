# -*- coding: utf-8 -*-
"""Focused regression for the portable QA package boundary and required files."""
from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path


SCRIPTS = Path(__file__).resolve().parent
QA_ROOT = SCRIPTS.parent
WORKFLOW_SCRIPTS = QA_ROOT / "workflow-v2" / "scripts"
sys.dont_write_bytecode = True


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if not spec or not spec.loader:
        raise RuntimeError(f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> None:
    verify = load_module("portable_verify_regression", SCRIPTS / "verify_portable_package.py")
    audit = load_module("portable_audit_regression", WORKFLOW_SCRIPTS / "audit_contract.py")
    quick_source = (SCRIPTS / "quick_validate.py").read_text(encoding="utf-8")
    capability_manifest = json.loads((QA_ROOT / "CAPABILITY_MANIFEST.json").read_text(encoding="utf-8"))

    required = {
        WORKFLOW_SCRIPTS / "generation_contract.py",
        WORKFLOW_SCRIPTS / "test_generation_contract_regressions.py",
        WORKFLOW_SCRIPTS / "delivery_quality.py",
        WORKFLOW_SCRIPTS / "test_delivery_quality_regressions.py",
        WORKFLOW_SCRIPTS / "execution_quality_gate.py",
        WORKFLOW_SCRIPTS / "test_execution_quality_regressions.py",
        WORKFLOW_SCRIPTS / "test_trace_extract_regressions.py",
        WORKFLOW_SCRIPTS / "casegen.py",
        WORKFLOW_SCRIPTS / "new_project.py",
        WORKFLOW_SCRIPTS / "feedback_pattern_gate.py",
        WORKFLOW_SCRIPTS / "stratified_acceptance_sample.py",
        WORKFLOW_SCRIPTS / "test_feedback_sampling_regressions.py",
        WORKFLOW_SCRIPTS / "multi_round_review_gate.py",
        WORKFLOW_SCRIPTS / "test_multi_round_review_regressions.py",
        WORKFLOW_SCRIPTS / "release_acceptance.py",
        WORKFLOW_SCRIPTS / "test_release_acceptance_regressions.py",
        WORKFLOW_SCRIPTS / "lineage.py",
        WORKFLOW_SCRIPTS / "judge_build.py",
        WORKFLOW_SCRIPTS / "traceability" / "trace_extract.py",
        WORKFLOW_SCRIPTS / "audit_contract.py",
        WORKFLOW_SCRIPTS / "test_audit_contract_regressions.py",
        SCRIPTS / "quick_validate.py",
    }
    verify_required = set(verify.REQUIRED)
    checks = [
        {
            "name": "portable_required_files_are_declared",
            "passed": required.issubset(verify_required),
            "details": sorted(str(path.relative_to(QA_ROOT)) for path in required - verify_required),
        },
        {
            "name": "project_runtime_data_is_excluded",
            "passed": not verify.is_runtime_source(QA_ROOT / "workflow-v2" / "projects" / "demo" / "case.py"),
        },
        {
            "name": "project_cache_is_excluded",
            "passed": not verify.is_runtime_source(
                QA_ROOT / "workflow-v2" / "projects" / "demo" / "__pycache__" / "case.cpython-312.pyc"
            ),
        },
        {
            "name": "runtime_cache_is_excluded",
            "passed": not verify.is_runtime_source(
                QA_ROOT / "workflow-v2" / "scripts" / "__pycache__" / "casegen.cpython-312.pyc"
            ),
        },
        {
            "name": "runtime_python_is_included",
            "passed": verify.is_runtime_source(WORKFLOW_SCRIPTS / "casegen.py"),
        },
        {
            "name": "quick_validate_does_not_call_portable_verifier",
            "passed": "verify_portable_package.py" not in quick_source,
        },
        {
            "name": "quick_validate_runs_execution_feedback_and_release_regressions",
            "passed": "test_feedback_sampling_regressions.py" in quick_source
            and "test_execution_quality_regressions.py" in quick_source
            and "test_multi_round_review_regressions.py" in quick_source
            and "test_release_acceptance_regressions.py" in quick_source
            and "test_delivery_quality_regressions.py" in quick_source
            and "test_trace_extract_regressions.py" in quick_source
            and "lineage.py" in quick_source
            and "judge_build.py" in quick_source,
        },
        {
            "name": "capability_manifest_declares_hard_rule_release",
            "passed": capability_manifest.get("snapshot_date") == "2026-08-25"
            and all(
                phrase in capability_manifest.get("bundled_capabilities", [])
                for phrase in (
                    "project-wide feedback-pattern scanning with current-workbook hash binding",
                    "hash-bound multi-agent testcase review with isolated dual-agent adversarial and regression batches, finding-union preservation, and final workbook inspection",
                    "deterministic stratified final acceptance sampling across changed, pending, conflict, high-risk, and feature-point strata",
                    "immutable single release acceptance gate with input manifests and stale-report rejection",
                    "deterministic schema-v3 build lineage across source, cases, Excel, stable index, trace drafts, and final release",
                    "final delivery workbook quality and exact canonical projection validation for headers, font, black borders, merges, version, results, order, and business content",
                    "quality-first testcase design with concrete PRD-backed parameter values and deduplicated ordinary-low-middle-high representative coverage",
                    "manual-first testcase wording with action-only steps and explicit regression comparison contracts",
                    "bounded evidence-based multi-agent review convergence with scope lock and revision cap",
                    "hash-bound personnel execution-quality gate for wording, classification, order, feature boundaries, and full-workbook human review",
                )
            ),
        },
        {
            "name": "capability_manifest_declares_slim_runtime_contract",
            "passed": all(
                capability_manifest.get(key)
                for key in (
                    "required_runtime_files", "regression_entrypoints",
                    "external_contracts", "validation_evidence",
                )
            ),
        },
    ]
    failures = [item for item in checks if not item["passed"]]
    report = audit.build_report(
        "test_portable_package_regressions",
        issues=[
            audit.make_issue(
                "blocking",
                item["name"],
                code="PORTABLE_REGRESSION_FAIL",
                kind="failure",
                details=item.get("details"),
            )
            for item in failures
        ],
        metrics={"tests": len(checks), "passed": len(checks) - len(failures)},
        extensions={"results": checks},
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    raise SystemExit(audit.exit_code(report))


if __name__ == "__main__":
    main()
