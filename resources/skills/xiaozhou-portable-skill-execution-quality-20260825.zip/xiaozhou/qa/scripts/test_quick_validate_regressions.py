# -*- coding: utf-8 -*-
"""Regression tests for child audit parsing and aggregation in quick_validate."""
from __future__ import annotations

import importlib.util
import json
import sys
import tempfile
from pathlib import Path


SCRIPTS = Path(__file__).resolve().parent
QA_ROOT = SCRIPTS.parent
WORKFLOW_SCRIPTS = QA_ROOT / "workflow-v2" / "scripts"
sys.dont_write_bytecode = True


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if not spec or not spec.loader:
        raise RuntimeError(f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def write_child(path: Path, payload: dict, returncode: int) -> None:
    path.write_text(
        "import json, sys\n"
        f"print(json.dumps({payload!r}, ensure_ascii=False))\n"
        f"raise SystemExit({returncode})\n",
        encoding="utf-8",
    )


def main() -> None:
    quick = load_module("quick_validate_regression", SCRIPTS / "quick_validate.py")
    audit = load_module("quick_validate_audit", WORKFLOW_SCRIPTS / "audit_contract.py")
    checks: list[dict] = []

    parsed = quick.parse_json_output('{"schema_version": 1, "tool": "x"}')
    checks.append({
        "name": "json_child_output_is_parsed",
        "passed": isinstance(parsed, dict) and parsed.get("tool") == "x",
    })

    with tempfile.TemporaryDirectory(prefix="quick-validate-regression-") as temp_dir:
        temp = Path(temp_dir)
        risk_child = temp / "risk_child.py"
        risk_payload = audit.build_report(
            "risk_child",
            issues=[audit.make_issue("risk", "pending threshold", code="PENDING")],
        )
        write_child(risk_child, risk_payload, 0)
        risk_check, risk_issues = quick.run_check({"name": "risk_child", "script": risk_child, "cwd": temp})
        checks.append({
            "name": "pass_with_risks_child_is_aggregated",
            "passed": risk_check["status"] == "PASS_WITH_RISKS"
            and len(risk_issues) == 1
            and risk_issues[0].get("severity") == "risk",
            "details": {"check": risk_check, "issues": risk_issues},
        })

        malformed_child = temp / "malformed_child.py"
        malformed = dict(audit.build_report("malformed_child"))
        malformed["status"] = "FAIL"
        write_child(malformed_child, malformed, 0)
        malformed_check, malformed_issues = quick.run_check(
            {"name": "malformed_child", "script": malformed_child, "cwd": temp}
        )
        checks.append({
            "name": "malformed_canonical_child_is_blocked",
            "passed": malformed_check["status"] == "BLOCKED"
            and any(issue.get("kind") == "blocked" for issue in malformed_issues),
            "details": {"check": malformed_check, "issues": malformed_issues},
        })

    failures = [item for item in checks if not item["passed"]]
    report = audit.build_report(
        "test_quick_validate_regressions",
        issues=[
            audit.make_issue(
                "blocking",
                item["name"],
                code="QUICK_VALIDATE_REGRESSION_FAIL",
                kind="failure",
                details=item.get("details"),
            )
            for item in failures
        ],
        metrics={"tests": len(checks), "passed": len(checks) - len(failures)},
        extensions={"results": checks},
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    raise SystemExit(audit.exit_code(report))


if __name__ == "__main__":
    main()
