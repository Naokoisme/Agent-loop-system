import argparse
import json
from pathlib import Path


分类别名 = {
    "faq": "问答",
    "问答": "问答",
    "rule": "规则",
    "规则": "规则",
    "case": "案例",
    "案例": "案例",
    "module": "功能模块",
    "功能模块": "功能模块",
    "glossary": "术语",
    "术语": "术语",
}


def 规范分类(分类值: str | None) -> str | None:
    if 分类值 is None:
        return None
    return 分类别名.get(分类值.strip().lower(), 分类别名.get(分类值.strip(), 分类值.strip()))


def 取字段(条目: dict, 中文字段: str, 英文字段: str, 默认值=None):
    if 中文字段 in 条目:
        return 条目.get(中文字段, 默认值)
    if 英文字段 in 条目:
        return 条目.get(英文字段, 默认值)
    return 默认值


def 载入条目(root: Path):
    for path in sorted(root.rglob("*.json")):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            continue
        if not isinstance(data, dict):
            continue
        yield path, data


def 计算得分(条目: dict, 查询词: list[str], 标签: str | None, 分类: str | None) -> int:
    标题 = str(取字段(条目, "标题", "title", ""))
    摘要 = str(取字段(条目, "摘要", "summary", ""))
    内容 = str(取字段(条目, "内容", "content", ""))
    标签列表 = 取字段(条目, "标签", "tags", []) or []
    条目分类 = 规范分类(str(取字段(条目, "分类", "category", "")))

    score = 0
    检索文本 = "\n".join([标题, 摘要, 内容, " ".join(标签列表)]).lower()
    标题小写 = 标题.lower()
    标签小写 = [tag.lower() for tag in 标签列表]

    for term in 查询词:
        if term in 检索文本:
            score += 2
        if term and term in 标题小写:
            score += 3
        if term in 标签小写:
            score += 3

    if 分类 and 条目分类 == 分类:
        score += 2
    if 标签 and 标签.lower() in 标签小写:
        score += 2
    return score


def main():
    parser = argparse.ArgumentParser(description="搜索共享测试知识。")
    parser.add_argument("--query", "--关键词", dest="query", required=True, help="自由文本检索词。")
    parser.add_argument(
        "--category",
        "--分类",
        dest="category",
        choices=sorted(分类别名.keys()),
        help="可选的分类过滤：问答、规则、案例、功能模块、术语。",
    )
    parser.add_argument("--tag", "--标签", dest="tag", help="可选的标签过滤。")
    parser.add_argument("--limit", "--数量", dest="limit", type=int, default=5, help="最多输出多少条结果。")
    parser.add_argument(
        "--format",
        "--格式",
        dest="format",
        choices=["text", "json"],
        default="text",
        help="输出格式。默认 text；json 便于先看摘要再决定读取哪些详情。",
    )
    parser.add_argument(
        "--root",
        "--根目录",
        dest="root",
        default=Path(__file__).resolve().parent.parent / "knowledge",
        type=Path,
        help="知识库根目录。",
    )
    args = parser.parse_args()

    查询词 = [term.strip().lower() for term in args.query.split() if term.strip()]
    if not 查询词:
        raise SystemExit("关键词不能为空。")

    过滤分类 = 规范分类(args.category)
    results = []
    for path, entry in 载入条目(args.root):
        条目分类 = 规范分类(str(取字段(entry, "分类", "category", "")))
        标签列表 = 取字段(entry, "标签", "tags", []) or []

        if 过滤分类 and 条目分类 != 过滤分类:
            continue
        if args.tag and args.tag.lower() not in [tag.lower() for tag in 标签列表]:
            continue

        score = 计算得分(entry, 查询词, args.tag, 过滤分类)
        if score > 0:
            results.append((score, path, entry))

    results.sort(key=lambda item: (-item[0], str(item[1])))

    if not results:
        if args.format == "json":
            print("[]")
            return
        print("没有找到匹配的知识条目。")
        return

    if args.format == "json":
        payload = []
        for score, path, entry in results[: args.limit]:
            payload.append(
                {
                    "score": score,
                    "path": str(path.relative_to(args.root.parent)),
                    "title": 取字段(entry, "标题", "title", "未命名条目"),
                    "category": 规范分类(str(取字段(entry, "分类", "category", "未知"))),
                    "tags": 取字段(entry, "标签", "tags", []),
                    "summary": 取字段(entry, "摘要", "summary", ""),
                    "read_detail": "仅当该条与当前产品形态、功能模块、PRD入口均匹配时读取详情。",
                }
            )
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return

    for index, (score, path, entry) in enumerate(results[: args.limit], start=1):
        rel_path = path.relative_to(args.root.parent)
        print(f"[{index}] {取字段(entry, '标题', 'title', '未命名条目')}（得分={score}）")
        print(f"    路径: {rel_path}")
        print(f"    分类: {规范分类(str(取字段(entry, '分类', 'category', '未知')))}")
        print(f"    标签: {', '.join(取字段(entry, '标签', 'tags', []))}")
        print(f"    摘要: {取字段(entry, '摘要', 'summary', '')}")
        print("")


if __name__ == "__main__":
    main()
