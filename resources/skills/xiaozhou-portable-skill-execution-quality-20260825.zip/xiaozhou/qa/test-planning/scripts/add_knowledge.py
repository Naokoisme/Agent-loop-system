import argparse
import json
import re
from datetime import date
from pathlib import Path


分类别名 = {
    "faq": "问答",
    "问答": "问答",
    "rule": "规则",
    "规则": "规则",
    "case": "案例",
    "案例": "案例",
    "module": "功能模块",
    "功能模块": "功能模块",
    "glossary": "术语",
    "术语": "术语",
}

分类目录 = {
    "问答": "问答",
    "规则": "规则",
    "案例": "案例",
    "功能模块": "功能模块",
    "术语": "术语",
}


def 规范分类(分类值: str) -> str:
    原始值 = 分类值.strip()
    return 分类别名.get(原始值.lower(), 分类别名.get(原始值, 原始值))


def 生成文件名(value: str) -> str:
    text = value.strip()
    text = re.sub(r"\s+", "-", text)
    text = re.sub(r"[^\w\u4e00-\u9fff-]+", "-", text, flags=re.UNICODE)
    text = re.sub(r"-{2,}", "-", text).strip("-_")
    return text or "知识条目"


def main():
    parser = argparse.ArgumentParser(description="新增一条共享测试知识。")
    parser.add_argument("--category", "--分类", dest="category", required=True, choices=sorted(分类别名.keys()))
    parser.add_argument("--title", "--标题", dest="title", required=True)
    parser.add_argument("--author", "--作者", dest="author", required=True)
    parser.add_argument("--summary", "--摘要", dest="summary", required=True)
    parser.add_argument("--content", "--内容", dest="content", required=True)
    parser.add_argument("--tags", "--标签", dest="tags", default="", help="逗号分隔的标签。")
    parser.add_argument("--slug", "--文件名", dest="slug", help="可选，自定义文件名，不带 .json。")
    parser.add_argument(
        "--root",
        "--根目录",
        dest="root",
        default=Path(__file__).resolve().parent.parent / "knowledge",
        type=Path,
        help="知识库根目录。",
    )
    args = parser.parse_args()

    分类 = 规范分类(args.category)
    if 分类 not in 分类目录:
        raise SystemExit(f"不支持的分类：{args.category}")

    标签列表 = [tag.strip() for tag in args.tags.split(",") if tag.strip()]
    今天 = date.today().isoformat()
    文件名 = args.slug or f"{今天}-{生成文件名(args.title)}"
    目标目录 = args.root / 分类目录[分类]
    目标目录.mkdir(parents=True, exist_ok=True)
    目标路径 = 目标目录 / f"{文件名}.json"

    if 目标路径.exists():
        raise SystemExit(f"目标文件已存在：{目标路径}")

    payload = {
        "标题": args.title,
        "分类": 分类,
        "标签": 标签列表,
        "作者": args.author,
        "更新时间": 今天,
        "摘要": args.summary,
        "内容": args.content,
    }

    目标路径.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"已创建：{目标路径}")


if __name__ == "__main__":
    main()
