import argparse
import importlib.util
import json
from pathlib import Path


BASE = Path(__file__).resolve().parent.parent


ARCHITECTURE_CHECKS = [
    {
        "name": "fixed_hierarchy",
        "description": "固定五层架构存在",
        "phrases": ["功能模块 > 功能点 > 测试项 > 测试点/检查项 > 用例详情"],
    },
    {
        "name": "layer_roles",
        "description": "每层职责清晰",
        "phrases": [
            "`功能模块`：", "`功能点`：", "`测试项`：",
            "`测试点/检查项`：", "`用例详情`：",
        ],
    },
    {
        "name": "workflow_boundary",
        "description": "完整生产任务路由到 workflow-v2",
        "phrases": ["PRD 到最终 Excel 的完整生产任务", "../workflow-v2/SKILL.md"],
    },
    {
        "name": "no_duplicate_layers",
        "description": "功能点、测试项、测试点禁止同义重复",
        "phrases": ["功能点、测试项和测试点不能同义重复"],
    },
    {
        "name": "continuous_group",
        "description": "三级分组默认保持单一连续区块",
        "phrases": ["同一 `功能模块 + 功能点 + 测试项` 默认只形成一个连续区块"],
    },
    {
        "name": "main_flow_design",
        "description": "先识别主流程与真实产品范围",
        "phrases": ["先识别真实入口、主流程、状态、数据链路、平台", "再按 PRD 裁剪"],
    },
    {
        "name": "retrieval_before_detail",
        "description": "先检索摘要再读详情",
        "phrases": ["禁止预读整个 `knowledge/`", "按命中只加载 1 至 3 份详情"],
    },
    {
        "name": "applicability_gate",
        "description": "命中知识必须做适用性判断",
        "phrases": ["最新补充说明始终高于知识模板", "知识只能裁剪补强，不能替换输入"],
    },
    {
        "name": "output_gate",
        "description": "输出可执行可判定",
        "phrases": ["可执行、可判定的验证意图", "禁止用 `正常`、`符合预期`、`按规则处理`"],
    },
    {
        "name": "platform_main_flow",
        "description": "适用平台分别覆盖完整主流程",
        "phrases": ["Android/iOS 等适用平台必须各自覆盖完整主流程"],
    },
]


COMBINED_CASES = [
    {
        "name": "默认架构问答",
        "query": "测试用例默认架构是什么",
        "expected_titles": ["测试用例默认框架必须作为skill入口规则优先执行", "全功能测试用例应按主流程分层并保证预期可判定"],
        "phrase_groups": [
            ["功能模块 > 功能点 > 测试项 > 测试点/检查项 > 用例详情", "功能模块 → 功能点 → 测试项"],
            ["层级职责", "功能点是子功能"],
            ["裁剪原则", "不硬套"],
        ],
    },
    {
        "name": "绑定带屏手势",
        "query": "带屏手表绑定二维码页面要不要覆盖上下左右滑",
        "expected_titles": ["绑定流程必须先按无屏带屏形态裁剪", "绑定流程记错本", "带屏设备绑定流程测试架构案例"],
        "phrase_groups": [
            ["带屏设备"],
            ["手势操作"],
            ["左滑"],
            ["右滑"],
            ["上滑"],
            ["下滑"],
        ],
    },
    {
        "name": "有屏页面级界面操作",
        "query": "A033 绑定流程 页面级界面操作 二维码 确认页",
        "expected_titles": ["有屏设备测试用例必须先建立页面节点清单", "带屏设备绑定流程测试架构案例", "绑定流程记错本"],
        "phrase_groups": [
            ["页面节点清单"],
            ["独立设备页面", "确认页", "可操作弹窗"],
            ["功能点=<页面/真实功能点> / 测试项=界面操作"],
            ["上滑、下滑、左滑、右滑、短按、长按、双击"],
        ],
    },
    {
        "name": "绑定不硬套入口",
        "query": "绑定流程没有明确入口是不是不要硬写入口",
        "expected_titles": ["绑定流程必须先按无屏带屏形态裁剪", "绑定流程记错本"],
        "phrase_groups": [
            ["不强行补入口", "绑定流程通常不是单一入口模块"],
            ["真实用户链路", "用户主流程"],
        ],
    },
    {
        "name": "绑定前交叉裁剪",
        "query": "绑定成功前要不要硬套录音秒表和AI翻译交叉",
        "expected_titles": ["绑定流程记错本", "绑定流程必须先按无屏带屏形态裁剪", "状态类交叉场景不得默认推导业务功能限制", "交叉场景记错本"],
        "forbidden_titles": ["复杂AI音频生成类模块不得过度压缩", "AI 音频生成记错本"],
        "phrase_groups": [
            ["通常只保留低电、充电、省电模式", "绑定完成前通常只覆盖低电、充电、省电模式"],
            ["不要补", "不硬套", "不能硬套"],
        ],
    },
    {
        "name": "闹钟双端CRUD归类",
        "query": "设备和APP都能新增闹钟功能点怎么分",
        "expected_titles": ["双端CRUD功能应按业务动作归类", "音乐闹钟天气模块应按对象链路和双端同步拆解"],
        "phrase_groups": [
            ["功能点应按新增", "功能点按新增"],
            ["设备端/App端应下沉到测试项", "端侧差异下沉到测试项"],
        ],
    },
    {
        "name": "通话能力裁剪",
        "query": "没有4G但是支持蓝牙通话还能写拨号盘吗",
        "expected_titles": ["通话功能必须先按4G与BTHFP能力裁剪", "通话功能记错本"],
        "phrase_groups": [
            ["4G/SIM 独立通话", "4G/SIM独立通话"],
            ["BT/HFP 蓝牙通话", "BT/HFP蓝牙通话"],
            ["仅来电提醒"],
        ],
    },
    {
        "name": "AI复杂模块覆盖密度",
        "query": "AI助手AI翻译本地录音测试点不能太少",
        "expected_titles": ["复杂AI音频生成类模块不得过度压缩", "AI 音频生成记错本"],
        "phrase_groups": [
            ["不能只输出少量代表性测试点", "压缩成少量代表性测试点"],
            ["入口、配置、核心流程", "入口"],
            ["音频焦点"],
        ],
    },
    {
        "name": "工厂模式两套架构",
        "query": "工厂模式能不能直接加GPS地磁检测项",
        "expected_titles": ["工厂模式必须按无屏带屏两套架构裁剪", "工厂模式记错本"],
        "phrase_groups": [
            ["无屏产测"],
            ["带屏/B004", "带屏设备"],
            ["GPS", "地磁"],
            ["PRD"],
        ],
    },
    {
        "name": "设置模块闭环",
        "query": "设置屏幕亮度和亮屏时长修改后App设备同步",
        "expected_titles": ["设置模块应按设置组入口配置持久化同步和恢复裁剪"],
        "phrase_groups": [
            ["每个设置组内部按闭环设计", "设置组内部按闭环设计"],
            ["App/设备同步", "设备修改设置同步 App"],
            ["重启保持"],
        ],
    },
    {
        "name": "控制中心能力裁剪",
        "query": "无4G项目控制中心要不要写SIM图标",
        "expected_titles": ["控制中心模块应按入口状态快捷控制和同步闭环设计"],
        "phrase_groups": [
            ["无 4G 不写 SIM", "无4G不写SIM"],
            ["状态图标"],
            ["产品能力"],
        ],
    },
    {
        "name": "健康模块边界来源",
        "query": "睡眠监测时间窗口跨0点怎么测",
        "expected_titles": ["健康模块心率睡眠血氧应按入口测量数据同步和异常裁剪"],
        "phrase_groups": [
            ["睡眠"],
            ["时间窗口"],
            ["PRD", "待确认"],
        ],
    },
    {
        "name": "描述风格阈值占位",
        "query": "阈值前阈值点阈值后这种描述不对",
        "expected_titles": ["描述风格记错本", "按键定义模块应只校验全局按键规则"],
        "phrase_groups": [
            ["阈值前"],
            ["阈值点"],
            ["阈值后"],
            ["具体值", "具体数值"],
        ],
    },
]


def load_semantic_module():
    path = BASE / "scripts" / "search_semantic_knowledge.py"
    spec = importlib.util.spec_from_file_location("semantic_search", path)
    module = importlib.util.module_from_spec(spec)
    assert spec and spec.loader
    spec.loader.exec_module(module)
    return module


def check_phrases(text: str, checks: list[dict]) -> list[dict]:
    rows = []
    for check in checks:
        missing = [phrase for phrase in check["phrases"] if phrase not in text]
        rows.append(
            {
                "name": check["name"],
                "description": check["description"],
                "passed": not missing,
                "missing": missing,
            }
        )
    return rows


def entry_text(semantic, entry: dict) -> str:
    parts = [
        str(semantic.取字段(entry, "标题", "title", "")),
        str(semantic.取字段(entry, "摘要", "summary", "")),
        str(semantic.取字段(entry, "内容", "content", "")),
        " ".join(semantic.取字段(entry, "标签", "tags", []) or []),
    ]
    return "\n".join(parts)


def evaluate_combined_cases(semantic, root: Path, synonyms: Path, top_k: int, reference_roots: list[Path]) -> list[dict]:
    rows = []
    for case in COMBINED_CASES:
        results, _ = semantic.搜索(case["query"], root, synonyms, top_k, None, None, reference_roots)
        titles = [semantic.取字段(entry, "标题", "title", "") for *_rest, entry in results]
        hit = bool(set(case["expected_titles"]).intersection(titles))
        forbidden_titles = set(case.get("forbidden_titles", []))
        forbidden_hits = sorted(forbidden_titles.intersection(titles))
        combined_text = "\n".join(entry_text(semantic, entry) for *_rest, entry in results)
        missing_groups = []
        for group in case["phrase_groups"]:
            if not any(phrase in combined_text for phrase in group):
                missing_groups.append(group)
        rows.append(
            {
                "name": case["name"],
                "query": case["query"],
                "passed": hit and not missing_groups and not forbidden_hits,
                "hit": hit,
                "top_titles": titles,
                "forbidden_hits": forbidden_hits,
                "missing_phrase_groups": missing_groups,
            }
        )
    return rows


def summarize(rows: list[dict]) -> dict:
    passed = sum(1 for row in rows if row["passed"])
    total = len(rows)
    return {"passed": passed, "total": total, "accuracy": round(passed / total, 3) if total else 0}


def main():
    parser = argparse.ArgumentParser(description="联合验证测试用例默认架构与语义检索命中率。")
    parser.add_argument("--format", choices=["text", "json"], default="text")
    parser.add_argument("--top-k", type=int, default=3)
    parser.add_argument("--skill", type=Path, default=BASE / "SKILL.md")
    parser.add_argument("--eval", dest="eval_path", type=Path, default=BASE / "references" / "检索" / "全面对比集.json")
    parser.add_argument("--root", type=Path, default=BASE / "knowledge")
    parser.add_argument("--synonyms", type=Path, default=BASE / "references" / "检索" / "同义词表.json")
    parser.add_argument("--reference-root", type=Path, action="append", default=[BASE / "references" / "记错本"])
    args = parser.parse_args()

    semantic = load_semantic_module()
    skill_text = args.skill.read_text(encoding="utf-8")
    architecture_rows = check_phrases(skill_text, ARCHITECTURE_CHECKS)
    retrieval_top1 = semantic.评估(args.eval_path, args.root, args.synonyms, 1, args.reference_root)
    retrieval_topk = semantic.评估(args.eval_path, args.root, args.synonyms, args.top_k, args.reference_root)
    combined_rows = evaluate_combined_cases(semantic, args.root, args.synonyms, args.top_k, args.reference_root)

    report = {
        "architecture_static": {**summarize(architecture_rows), "cases": architecture_rows},
        "retrieval_top1": {
            "passed": retrieval_top1[0],
            "total": retrieval_top1[1],
            "accuracy": round(retrieval_top1[0] / retrieval_top1[1], 3) if retrieval_top1[1] else 0,
        },
        "retrieval_topk": {
            "top_k": args.top_k,
            "passed": retrieval_topk[0],
            "total": retrieval_topk[1],
            "accuracy": round(retrieval_topk[0] / retrieval_topk[1], 3) if retrieval_topk[1] else 0,
        },
        "combined_architecture_retrieval": {**summarize(combined_rows), "cases": combined_rows},
    }

    gate_failed = (
        any(not row["passed"] for row in architecture_rows)
        or retrieval_topk[0] != retrieval_topk[1]
        or any(not row["passed"] for row in combined_rows)
    )

    if args.format == "json":
        print(json.dumps(report, ensure_ascii=False, indent=2))
        raise SystemExit(1 if gate_failed else 0)

    print("架构静态检查: {passed}/{total} accuracy={accuracy}".format(**report["architecture_static"]))
    print("检索回归 Top1: {passed}/{total} accuracy={accuracy}".format(**report["retrieval_top1"]))
    print(
        "检索回归 Top{top_k}: {passed}/{total} accuracy={accuracy}".format(
            **report["retrieval_topk"]
        )
    )
    print("架构+检索联合场景: {passed}/{total} accuracy={accuracy}".format(**report["combined_architecture_retrieval"]))
    failed = [row for row in architecture_rows + combined_rows if not row["passed"]]
    if failed:
        print("\n失败项:")
        for row in failed:
            print("- " + row.get("name", row.get("description", "unknown")))
    if retrieval_topk[0] != retrieval_topk[1]:
        print(f"- retrieval_top{args.top_k}: {retrieval_topk[0]}/{retrieval_topk[1]}")
    raise SystemExit(1 if gate_failed else 0)


if __name__ == "__main__":
    main()
