import argparse
import json
from datetime import date
from pathlib import Path


分类别名 = {
    "faq": "问答",
    "问答": "问答",
    "rule": "规则",
    "规则": "规则",
    "case": "案例",
    "案例": "案例",
    "module": "功能模块",
    "功能模块": "功能模块",
    "glossary": "术语",
    "术语": "术语",
}

分类目录 = {
    "问答": "问答",
    "规则": "规则",
    "案例": "案例",
    "功能模块": "功能模块",
    "术语": "术语",
}

业务域标签 = {"app", "嵌入式", "iot", "手表", "app-iot"}
模糊测试点词 = ("后的处理", "状态可判定", "处理明确", "状态正确", "结果明确", "符合预期", "按规则处理")


def 取字段(条目: dict, 中文字段: str, 英文字段: str, 默认值=None):
    if 中文字段 in 条目:
        return 条目.get(中文字段, 默认值)
    if 英文字段 in 条目:
        return 条目.get(英文字段, 默认值)
    return 默认值


def 规范分类(分类值: str | None) -> str | None:
    if 分类值 is None:
        return None
    原始值 = 分类值.strip()
    return 分类别名.get(原始值.lower(), 分类别名.get(原始值, 原始值))


def validate_entry(path: Path, root: Path) -> list[str]:
    errors = []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        return [f"{path}: JSON 格式非法（{exc}）"]

    if not isinstance(data, dict):
        return [f"{path}: 条目必须是 JSON 对象"]

    标题 = 取字段(data, "标题", "title")
    分类 = 规范分类(取字段(data, "分类", "category"))
    标签 = 取字段(data, "标签", "tags")
    作者 = 取字段(data, "作者", "author")
    更新时间 = 取字段(data, "更新时间", "updated_at")
    摘要 = 取字段(data, "摘要", "summary")
    内容 = 取字段(data, "内容", "content")

    缺失字段 = []
    if 标题 is None:
        缺失字段.append("标题")
    if 分类 is None:
        缺失字段.append("分类")
    if 标签 is None:
        缺失字段.append("标签")
    if 作者 is None:
        缺失字段.append("作者")
    if 更新时间 is None:
        缺失字段.append("更新时间")
    if 摘要 is None:
        缺失字段.append("摘要")
    if 内容 is None:
        缺失字段.append("内容")
    if 缺失字段:
        errors.append(f"{path}: 缺少必填字段：{', '.join(缺失字段)}")

    if 分类 not in 分类目录:
        errors.append(f"{path}: 不支持的分类：{分类}")
    else:
        期望目录 = 分类目录[分类]
        实际目录 = path.parent.name
        if 实际目录 != 期望目录:
            errors.append(f"{path}: 分类为“{分类}”时应放在目录“{期望目录}”，当前目录为“{实际目录}”")

    if not isinstance(标签, list) or not all(isinstance(tag, str) and tag.strip() for tag in 标签 or []):
        errors.append(f"{path}: 标签必须是非空字符串数组")
    else:
        标准标签 = {tag.strip().lower() if tag.strip().lower() in {'app', 'iot', 'app-iot'} else tag.strip() for tag in 标签}
        if not 标准标签.intersection(业务域标签):
            errors.append(f"{path}: 至少需要一个业务域标签：{', '.join(sorted(业务域标签))}")

    for 字段名, 值 in [("标题", 标题), ("作者", 作者), ("摘要", 摘要), ("内容", 内容)]:
        if not isinstance(值, str) or not 值.strip():
            errors.append(f"{path}: 字段“{字段名}”必须是非空字符串")

    if not isinstance(更新时间, str):
        errors.append(f"{path}: 更新时间必须是 YYYY-MM-DD 格式字符串")
    else:
        try:
            date.fromisoformat(更新时间)
        except ValueError:
            errors.append(f"{path}: 更新时间必须使用 YYYY-MM-DD 格式")

    if root not in path.parents:
        errors.append(f"{path}: 文件不在知识库根目录下")

    if 分类 == "功能模块":
        def 扫描测试点(value, key_path=""):
            if isinstance(value, dict):
                for key, child in value.items():
                    child_path = f"{key_path}.{key}" if key_path else str(key)
                    if key in {"测试点", "测试点/检查项", "test_points", "test_point"}:
                        for point in child if isinstance(child, list) else [child]:
                            if isinstance(point, str):
                                hit = [word for word in 模糊测试点词 if word in point]
                                if hit:
                                    errors.append(f"{path}: {child_path} 含模糊测试点词{hit}: {point}")
                    扫描测试点(child, child_path)
            elif isinstance(value, list):
                for index, child in enumerate(value):
                    扫描测试点(child, f"{key_path}[{index}]")
        扫描测试点(data)

    return errors


def main():
    parser = argparse.ArgumentParser(description="校验小周内置 QA 知识库。")
    parser.add_argument(
        "--root",
        type=Path,
        default=Path(__file__).resolve().parent.parent / "knowledge",
        help="要校验的知识库根目录。",
    )
    args = parser.parse_args()
    root = args.root.resolve()
    files = sorted(root.rglob("*.json"))
    if not files:
        raise SystemExit("没有找到任何知识文件。")

    all_errors = []
    for path in files:
        all_errors.extend(validate_entry(path, root))

    if all_errors:
        print("知识库校验失败：")
        for error in all_errors:
            print(f"- {error}")
        raise SystemExit(1)

    print(f"知识库校验通过，共检查 {len(files)} 个文件。")


if __name__ == "__main__":
    main()
