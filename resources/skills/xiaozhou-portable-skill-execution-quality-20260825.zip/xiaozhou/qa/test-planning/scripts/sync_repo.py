import argparse
import shutil
import subprocess
from pathlib import Path


def run_git(command: list[str], repo_root: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        cwd=repo_root,
        text=True,
        capture_output=True,
        encoding="utf-8",
        errors="replace",
    )


def main():
    parser = argparse.ArgumentParser(description="同步本地测试知识仓库。")
    parser.add_argument(
        "--repo-root",
        default=Path(__file__).resolve().parents[2],
        type=Path,
        help="Git 仓库根目录。",
    )
    parser.add_argument(
        "--rebase",
        action="store_true",
        help="使用 rebase 方式拉取远程更新。",
    )
    args = parser.parse_args()

    repo_root = args.repo_root.resolve()
    if not (repo_root / ".git").exists():
        print("未配置 Git 仓库，继续使用小周内置 QA 知识快照；未执行远程同步。")
        return
    if not shutil.which("git"):
        print("当前环境未安装 Git，继续使用小周内置 QA 知识快照；未执行远程同步。")
        return

    pull_cmd = ["git", "pull"]
    if args.rebase:
        pull_cmd.extend(["--rebase", "--autostash"])

    result = run_git(pull_cmd, repo_root)
    if result.returncode != 0:
        print("仓库同步失败：")
        if result.stdout.strip():
            print(result.stdout.strip())
        if result.stderr.strip():
            print(result.stderr.strip())
        raise SystemExit(result.returncode)

    print("仓库同步成功。")
    if result.stdout.strip():
        print(result.stdout.strip())
    if result.stderr.strip():
        print(result.stderr.strip())


if __name__ == "__main__":
    main()
