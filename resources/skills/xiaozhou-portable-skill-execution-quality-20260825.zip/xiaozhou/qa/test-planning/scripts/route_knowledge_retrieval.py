import argparse
import importlib.util
import json
import re
from datetime import datetime
from pathlib import Path
from typing import Any


BASE = Path(__file__).resolve().parent.parent
REPO_ROOT = BASE.parent
DEFAULT_CONFIG = BASE / "references" / "检索" / "多轮检索路由配置.json"
DEFAULT_EVAL = BASE / "references" / "检索" / "多轮检索路由回归集.json"
DEFAULT_SYNONYMS = BASE / "references" / "检索" / "同义词表.json"
DEFAULT_KNOWLEDGE = BASE / "knowledge"


def load_json(path: Path, default: Any) -> Any:
    if not path.exists():
        return default
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def load_semantic_module():
    path = BASE / "scripts" / "search_semantic_knowledge.py"
    spec = importlib.util.spec_from_file_location("semantic_search", path)
    module = importlib.util.module_from_spec(spec)
    if not spec or not spec.loader:
        raise RuntimeError(f"无法加载语义检索脚本: {path}")
    spec.loader.exec_module(module)
    return module


def resolve_path(path: Path, base: Path = BASE) -> Path:
    if path.is_absolute():
        return path
    candidate = (Path.cwd() / path).resolve()
    if candidate.exists():
        return candidate
    return (base / path).resolve()


def safe_relative(path: Path, base: Path = BASE) -> str:
    try:
        return str(path.resolve().relative_to(base.resolve()))
    except ValueError:
        try:
            return str(path.resolve().relative_to(REPO_ROOT.resolve()))
        except ValueError:
            return str(path)


def split_csv(value: str | None) -> list[str]:
    if not value:
        return []
    return [item.strip() for item in re.split(r"[,，;\n]+", value) if item.strip()]


def compact_text(value: str) -> str:
    return re.sub(r"\s+", " ", value).strip()


def render_template(template: str, context: dict[str, str]) -> str:
    try:
        return compact_text(template.format(**context))
    except KeyError:
        return compact_text(template)


def product_matches(product: str, needles: list[str] | None) -> bool:
    if not needles:
        return True
    return any(item and item in product for item in needles)


def unique_queries(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen = set()
    output = []
    for row in rows:
        key = (row.get("query"), row.get("category"), row.get("module"), row.get("round"))
        if key in seen:
            continue
        seen.add(key)
        output.append(row)
    return output


def project_text(project: Path) -> str:
    if not project.exists():
        return ""
    chunks: list[str] = []
    for pattern in ("*PRD*.md", "*需求*.md", "运行记录.md"):
        for path in sorted(project.glob(pattern)):
            try:
                chunks.append(path.read_text(encoding="utf-8")[:8000])
            except UnicodeDecodeError:
                continue
    return "\n".join(chunks)


def extract_project_modules(project: Path) -> list[str]:
    modules: list[str] = []
    cases_root = project / "cases"
    if not cases_root.exists():
        return modules

    def visit(value: Any) -> None:
        if isinstance(value, dict):
            for key, item in value.items():
                if key in {"功能模块", "module", "module_name", "模块名"} and isinstance(item, str):
                    modules.append(item.strip())
                visit(item)
        elif isinstance(value, list):
            for item in value:
                visit(item)

    for path in sorted(cases_root.rglob("*.json")):
        try:
            visit(load_json(path, {}))
        except json.JSONDecodeError:
            continue
    return list(dict.fromkeys(item for item in modules if item))


def build_queries(config: dict[str, Any], product: str, modules: list[str], prd_keywords: str, gates: list[str]) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    base_context = {"product": product, "prd_keywords": prd_keywords, "module": ""}

    for group in config.get("product_shape_queries", []):
        for template in group.get("queries", []):
            rows.append(
                {
                    "round": "R1 产品形态识别",
                    "name": group.get("name", "产品形态识别"),
                    "module": None,
                    "query": render_template(template, base_context),
                    "category": group.get("category"),
                }
            )

    for group in config.get("baseline_queries", []):
        for template in group.get("queries", []):
            rows.append(
                {
                    "round": "R2 总基线检索",
                    "name": group.get("name", "总基线检索"),
                    "module": None,
                    "query": render_template(template, base_context),
                    "category": group.get("category"),
                }
            )

    aliases = config.get("module_aliases", {})
    for module in modules:
        module_context = {"product": product, "prd_keywords": prd_keywords, "module": module}
        for template in config.get("module_query_templates", []):
            if not product_matches(product, template.get("when_product_contains")):
                continue
            rows.append(
                {
                    "round": "R3 模块模板检索",
                    "name": template.get("name", "模块模板检索"),
                    "module": module,
                    "query": render_template(template.get("query", "{module}"), module_context),
                    "category": "功能模块",
                }
            )
        for alias in aliases.get(module, []):
            alias_context = {"product": product, "prd_keywords": prd_keywords, "module": alias}
            rows.append(
                {
                    "round": "R3 模块模板检索",
                    "name": "模块别名模板检索",
                    "module": module,
                    "query": render_template("{product} {module} 测试用例", alias_context),
                    "category": "功能模块",
                }
            )

        for query in config.get("forced_rule_queries", {}).get(module, []):
            rows.append(
                {
                    "round": "R4 规则检索",
                    "name": "强制规则检索",
                    "module": module,
                    "query": render_template(query, module_context),
                    "category": None,
                }
            )

        mistake_queries = []
        mistake_queries.extend(config.get("forced_mistake_queries", {}).get(module, []))
        mistake_queries.extend(config.get("forced_mistake_queries", {}).get("默认", []))
        for query in mistake_queries:
            rows.append(
                {
                    "round": "R5 记错本检索",
                    "name": "强制记错本检索",
                    "module": module,
                    "query": render_template(query, module_context),
                    "category": None,
                }
            )

        defect_queries = []
        defect_queries.extend(config.get("defect_case_queries", {}).get(module, []))
        defect_queries.extend(config.get("defect_case_queries", {}).get("默认", []))
        for query in defect_queries:
            rows.append(
                {
                    "round": "R6 缺陷案例检索",
                    "name": "缺陷案例检索",
                    "module": module,
                    "query": render_template(query, module_context),
                    "category": None,
                }
            )

    gate_routes = config.get("gate_failure_routes", {})
    for gate in gates:
        route = gate_routes.get(gate.upper())
        if not route:
            continue
        rows.append(
            {
                "round": "G 门禁失败反查",
                "name": gate.upper(),
                "module": None,
                "query": route.get("query", gate),
                "category": None,
                "fix": route.get("fix", ""),
                "target_resources": route.get("target_resources", []),
            }
        )

    return [row for row in unique_queries(rows) if row.get("query")]


def hit_from_result(semantic: Any, root: Path, result: tuple[Any, ...], query_row: dict[str, Any], thresholds: dict[str, float]) -> dict[str, Any]:
    score, semantic_score, phrase_score, filter_boost, intent_boost, path, entry = result
    score_value = round(float(score), 3)
    if score_value >= thresholds["strong"]:
        strength = "strong"
    elif score_value >= thresholds["weak"]:
        strength = "medium"
    else:
        strength = "weak"
    return {
        "round": query_row.get("round"),
        "name": query_row.get("name"),
        "module": query_row.get("module"),
        "query": query_row.get("query"),
        "category_filter": query_row.get("category"),
        "score": score_value,
        "strength": strength,
        "semantic": round(float(semantic_score), 3),
        "phrase": round(float(phrase_score), 3),
        "filter_boost": round(float(filter_boost), 3),
        "intent_boost": round(float(intent_boost), 3),
        "path": safe_relative(path, root.parent),
        "title": semantic.取字段(entry, "标题", "title", "未命名条目"),
        "category": semantic.规范分类(str(semantic.取字段(entry, "分类", "category", "未知"))),
        "tags": semantic.取字段(entry, "标签", "tags", []) or [],
        "summary": semantic.取字段(entry, "摘要", "summary", "") or "",
        "fix": query_row.get("fix", ""),
        "target_resources": query_row.get("target_resources", []),
    }


def target_resource_hits(
    semantic: Any,
    root: Path,
    query_row: dict[str, Any],
    indexed_hits: list[dict[str, Any]],
) -> list[dict[str, Any]]:
    """Place configured gate-repair resources first without fabricating retrieval hits."""
    indexed_by_path = {str(hit.get("path", "")).replace("\\", "/"): hit for hit in indexed_hits}
    ordered: list[dict[str, Any]] = []
    seen: set[str] = set()

    for resource in query_row.get("target_resources", []):
        normalized = str(resource).replace("\\", "/")
        path = (BASE / normalized).resolve()
        hit = indexed_by_path.get(normalized)
        if hit is None and path.is_file():
            try:
                if path.suffix.lower() == ".json":
                    entry = load_json(path, {})
                    title = semantic.取字段(entry, "标题", "title", path.stem)
                    category = semantic.规范分类(str(semantic.取字段(entry, "分类", "category", "参考")))
                    tags = semantic.取字段(entry, "标签", "tags", []) or []
                    summary = semantic.取字段(entry, "摘要", "summary", "") or ""
                else:
                    first_line = next((line.strip() for line in path.read_text(encoding="utf-8").splitlines() if line.strip()), path.stem)
                    title = first_line.lstrip("# ").strip() or path.stem
                    category = "参考"
                    tags = []
                    summary = ""
                hit = {
                    "round": query_row.get("round"),
                    "name": query_row.get("name"),
                    "module": query_row.get("module"),
                    "query": query_row.get("query"),
                    "category_filter": query_row.get("category"),
                    "score": 0.0,
                    "strength": "target",
                    "semantic": 0.0,
                    "phrase": 0.0,
                    "filter_boost": 0.0,
                    "intent_boost": 0.0,
                    "path": safe_relative(path, root.parent),
                    "title": title,
                    "category": category,
                    "tags": tags,
                    "summary": summary,
                    "fix": query_row.get("fix", ""),
                    "target_resources": query_row.get("target_resources", []),
                    "target_resource": True,
                }
            except (OSError, json.JSONDecodeError):
                hit = None
        if hit is not None and normalized not in seen:
            selected = dict(hit)
            selected["target_resource"] = True
            ordered.append(selected)
            seen.add(normalized)

    for hit in indexed_hits:
        normalized = str(hit.get("path", "")).replace("\\", "/")
        if normalized not in seen:
            ordered.append(hit)
            seen.add(normalized)
    return ordered


def run_route(
    product: str,
    modules: list[str],
    prd_keywords: str,
    gates: list[str],
    config: dict[str, Any],
    root: Path,
    synonyms: Path,
    reference_roots: list[Path],
    top_k: int,
) -> dict[str, Any]:
    semantic = load_semantic_module()
    thresholds = {
        "weak": float(config.get("defaults", {}).get("weak_score_threshold", 20)),
        "strong": float(config.get("defaults", {}).get("strong_score_threshold", 60)),
    }
    query_rows = build_queries(config, product, modules, prd_keywords, gates)
    route_results: list[dict[str, Any]] = []

    for query_row in query_rows:
        results, expanded_terms = semantic.搜索(
            query_row["query"],
            root,
            synonyms,
            top_k,
            query_row.get("category"),
            None,
            reference_roots,
        )
        if not results and not query_row.get("target_resources"):
            route_results.append(
                {
                    "round": query_row.get("round"),
                    "name": query_row.get("name"),
                    "module": query_row.get("module"),
                    "query": query_row.get("query"),
                    "category_filter": query_row.get("category"),
                    "hits": [],
                    "expanded_terms": expanded_terms,
                    "fix": query_row.get("fix", ""),
                    "target_resources": query_row.get("target_resources", []),
                }
            )
            continue
        indexed_hits = [hit_from_result(semantic, root, result, query_row, thresholds) for result in results]
        route_results.append(
            {
                "round": query_row.get("round"),
                "name": query_row.get("name"),
                "module": query_row.get("module"),
                "query": query_row.get("query"),
                "category_filter": query_row.get("category"),
                "expanded_terms": expanded_terms,
                "hits": target_resource_hits(semantic, root, query_row, indexed_hits),
                "fix": query_row.get("fix", ""),
                "target_resources": query_row.get("target_resources", []),
            }
        )

    return summarize_route(product, modules, prd_keywords, gates, route_results, config)


def unique_hits(
    route_results: list[dict[str, Any]],
    module: str | None = None,
    round_name: str | None = None,
    category: str | None = None,
) -> list[dict[str, Any]]:
    seen = set()
    hits: list[dict[str, Any]] = []
    for row in route_results:
        if module is not None and row.get("module") != module:
            continue
        if round_name is not None and row.get("round") != round_name:
            continue
        for hit in row.get("hits", []):
            if category is not None and hit.get("category") != category:
                continue
            key = hit.get("title")
            if key in seen:
                continue
            seen.add(key)
            hits.append(hit)
    hits.sort(key=lambda item: (-float(item.get("score", 0)), str(item.get("title", ""))))
    return hits


def module_match_score(hit: dict[str, Any], module: str, aliases: dict[str, list[str]]) -> float:
    terms = [module, *aliases.get(module, [])]
    title = str(hit.get("title", ""))
    tags = " ".join(str(item) for item in hit.get("tags", []) or [])
    summary = str(hit.get("summary", ""))
    query = str(hit.get("query", ""))
    score = 0.0
    for term in terms:
        if not term:
            continue
        if term in title:
            score += 100.0
        if term in tags:
            score += 45.0
        if term in summary:
            score += 20.0
        if term in query:
            score += 8.0
    return score


def sort_for_module(hits: list[dict[str, Any]], module: str, aliases: dict[str, list[str]]) -> list[dict[str, Any]]:
    return sorted(
        hits,
        key=lambda item: (
            -module_match_score(item, module, aliases),
            -float(item.get("score", 0)),
            str(item.get("title", "")),
        ),
    )


def summarize_route(
    product: str,
    modules: list[str],
    prd_keywords: str,
    gates: list[str],
    route_results: list[dict[str, Any]],
    config: dict[str, Any],
) -> dict[str, Any]:
    module_summaries = []
    aliases = config.get("module_aliases", {})
    for module in modules:
        hits = unique_hits(route_results, module)
        templates = unique_hits(route_results, module, "R3 模块模板检索", "功能模块")
        rules = unique_hits(route_results, module, "R4 规则检索", "规则")
        mistakes = unique_hits(route_results, module, "R5 记错本检索", "记错本")
        cases = unique_hits(route_results, module, "R6 缺陷案例检索", "案例")
        if not templates:
            templates = [hit for hit in hits if hit.get("category") == "功能模块"]
        if not rules:
            rules = [hit for hit in hits if hit.get("category") == "规则"]
        if not mistakes:
            mistakes = [hit for hit in hits if hit.get("category") == "记错本"]
        if not cases:
            cases = [hit for hit in hits if hit.get("category") == "案例"]
        templates = sort_for_module(templates, module, aliases)
        rules = sort_for_module(rules, module, aliases)
        mistakes = sort_for_module(mistakes, module, aliases)
        cases = sort_for_module(cases, module, aliases)
        hits = sort_for_module(hits, module, aliases)
        module_summaries.append(
            {
                "module": module,
                "status": "hit" if hits else "miss",
                "selected_templates": [hit["title"] for hit in templates[:5]],
                "required_rules": [hit["title"] for hit in rules[:5]],
                "mistake_book_hits": [hit["title"] for hit in mistakes[:5]],
                "case_hits": [hit["title"] for hit in cases[:5]],
                "top_hits": [
                    {
                        "title": hit["title"],
                        "category": hit["category"],
                        "score": hit["score"],
                        "strength": hit["strength"],
                    }
                    for hit in hits[:8]
                ],
            }
        )

    all_hits = unique_hits(route_results)
    return {
        "schema": "qatest-knowledge-route-v1",
        "generated_at": datetime.now().isoformat(timespec="seconds"),
        "product": product,
        "prd_keywords": prd_keywords,
        "modules": modules,
        "gates": gates,
        "config_version": config.get("version", "unknown"),
        "summary": {
            "query_count": len(route_results),
            "hit_count": sum(len(row.get("hits", [])) for row in route_results),
            "unique_hit_count": len(all_hits),
            "missed_queries": [row["query"] for row in route_results if not row.get("hits")],
            "missed_modules": [row["module"] for row in module_summaries if row["status"] == "miss"],
            "top_titles": [hit["title"] for hit in all_hits[:20]],
        },
        "module_summaries": module_summaries,
        "route_results": route_results,
    }


def markdown_report(report: dict[str, Any]) -> str:
    lines: list[str] = []
    lines.append("# 知识命中报告")
    lines.append("")
    lines.append("## 基本信息")
    lines.append("")
    lines.append(f"- 产品形态: {report.get('product') or '未提供'}")
    lines.append(f"- PRD关键词: {report.get('prd_keywords') or '未提供'}")
    lines.append(f"- 模块清单: {', '.join(report.get('modules') or []) or '未提供'}")
    lines.append(f"- 门禁反查: {', '.join(report.get('gates') or []) or '无'}")
    lines.append(f"- 生成时间: {report.get('generated_at')}")
    lines.append("")
    lines.append("## 汇总")
    lines.append("")
    summary = report.get("summary", {})
    lines.append(f"- 检索轮次: {summary.get('query_count', 0)}")
    lines.append(f"- 命中条目数: {summary.get('hit_count', 0)}")
    lines.append(f"- 去重命中数: {summary.get('unique_hit_count', 0)}")
    lines.append(f"- 未命中模块: {', '.join(summary.get('missed_modules') or []) or '无'}")
    lines.append("")

    lines.append("## 模块命中")
    for module in report.get("module_summaries", []):
        lines.append("")
        lines.append(f"### {module['module']}")
        lines.append("")
        lines.append(f"- 状态: {module['status']}")
        lines.append(f"- 模板: {', '.join(module.get('selected_templates') or []) or '未命中'}")
        lines.append(f"- 规则: {', '.join(module.get('required_rules') or []) or '未命中'}")
        lines.append(f"- 记错本: {', '.join(module.get('mistake_book_hits') or []) or '未命中'}")
        lines.append(f"- 案例/缺陷: {', '.join(module.get('case_hits') or []) or '未命中'}")
        lines.append("")
        lines.append("| 标题 | 分类 | 分数 | 强度 |")
        lines.append("| --- | --- | ---: | --- |")
        for hit in module.get("top_hits", []):
            lines.append(f"| {hit['title']} | {hit['category']} | {hit['score']} | {hit['strength']} |")

    lines.append("")
    lines.append("## 检索轮次明细")
    for row in report.get("route_results", []):
        lines.append("")
        title = row.get("round", "")
        if row.get("module"):
            title += f" / {row['module']}"
        lines.append(f"### {title}")
        lines.append("")
        lines.append(f"- 查询: `{row.get('query')}`")
        if row.get("category_filter"):
            lines.append(f"- 分类过滤: `{row.get('category_filter')}`")
        if row.get("fix"):
            lines.append(f"- 建议修复: {row.get('fix')}")
        if row.get("target_resources"):
            lines.append("- 目标资源: " + ", ".join(f"`{path}`" for path in row.get("target_resources", [])))
        hits = row.get("hits", [])
        if not hits:
            lines.append("- 命中: 无")
            continue
        lines.append("")
        lines.append("| 排名 | 标题 | 分类 | 分数 | 路径 |")
        lines.append("| ---: | --- | --- | ---: | --- |")
        for index, hit in enumerate(hits[:5], start=1):
            score = "目标" if hit.get("target_resource") else hit["score"]
            lines.append(f"| {index} | {hit['title']} | {hit['category']} | {score} | `{hit['path']}` |")
    lines.append("")
    return "\n".join(lines)


def write_outputs(report: dict[str, Any], output: Path | None) -> None:
    if output is None:
        return
    output = output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    write_json(output / "knowledge_hits.json", report)
    (output / "knowledge_hits.md").write_text(markdown_report(report), encoding="utf-8")


def route_eval(cases_path: Path, config: dict[str, Any], root: Path, synonyms: Path, reference_roots: list[Path], top_k: int) -> dict[str, Any]:
    cases = load_json(cases_path, [])
    rows = []
    for case in cases:
        report = run_route(
            product=case.get("product", ""),
            modules=case.get("modules", []),
            prd_keywords=case.get("prd_keywords", ""),
            gates=case.get("gates", []),
            config=config,
            root=root,
            synonyms=synonyms,
            reference_roots=reference_roots,
            top_k=top_k,
        )
        top_titles = set(report.get("summary", {}).get("top_titles", []))
        all_titles = {
            hit.get("title")
            for row in report.get("route_results", [])
            for hit in row.get("hits", [])
        }
        expected = set(case.get("expected_titles", []))
        missing = sorted(title for title in expected if title not in all_titles)

        module_rows = []
        for module, expected_titles in case.get("expected_modules", {}).items():
            module_titles = {
                hit.get("title")
                for row in report.get("route_results", [])
                if row.get("module") == module
                for hit in row.get("hits", [])
            }
            module_rows.append(
                {
                    "module": module,
                    "expected": expected_titles,
                    "missing": sorted(title for title in expected_titles if title not in module_titles),
                }
            )

        module_missing = [row for row in module_rows if row["missing"]]
        rows.append(
            {
                "name": case.get("name", "未命名"),
                "passed": not missing and not module_missing,
                "missing_titles": missing,
                "module_missing": module_missing,
                "top_titles": sorted(top_titles),
            }
        )
    passed = sum(1 for row in rows if row["passed"])
    total = len(rows)
    return {
        "passed": passed,
        "total": total,
        "accuracy": round(passed / total, 3) if total else 0,
        "cases": rows,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="自动多轮检索路由：产品形态、总基线、模块模板、规则、记错本、缺陷案例。")
    parser.add_argument("--product", default="", help="产品形态或产品名称，例如：带屏耳机仓。")
    parser.add_argument("--modules", default="", help="逗号分隔的模块清单，例如：绑定流程,表盘,OTA升级。")
    parser.add_argument("--prd-keywords", default="", help="从 PRD 提取的关键词或简短摘要。")
    parser.add_argument("--project", type=Path, help="workflow-v2 项目目录；未显式提供 modules/output 时可辅助推断。")
    parser.add_argument("--gate", "--gates", dest="gates", default="", help="逗号分隔的门禁失败编号，例如：S23,S24。")
    parser.add_argument("--output", type=Path, help="输出目录，写入 knowledge_hits.json 和 knowledge_hits.md。")
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--root", type=Path, default=DEFAULT_KNOWLEDGE)
    parser.add_argument("--synonyms", type=Path, default=DEFAULT_SYNONYMS)
    parser.add_argument("--reference-root", type=Path, action="append")
    parser.add_argument("--no-references", action="store_true")
    parser.add_argument("--top-k", type=int, default=5)
    parser.add_argument("--format", choices=["text", "json"], default="text")
    parser.add_argument("--eval", dest="eval_path", type=Path, help="运行多轮检索路由回归集。")
    args = parser.parse_args()

    config_path = resolve_path(args.config)
    config = load_json(config_path, {})
    root = resolve_path(args.root)
    synonyms = resolve_path(args.synonyms)

    if args.no_references:
        reference_roots: list[Path] = []
    elif args.reference_root:
        reference_roots = [resolve_path(path) for path in args.reference_root]
    else:
        reference_roots = [resolve_path(Path(item)) for item in config.get("defaults", {}).get("reference_roots", ["references/记错本"])]

    top_k = args.top_k or int(config.get("defaults", {}).get("top_k", 5))

    if args.eval_path:
        report = route_eval(resolve_path(args.eval_path), config, root, synonyms, reference_roots, top_k)
        print(json.dumps(report, ensure_ascii=False, indent=2))
        raise SystemExit(0 if report["passed"] == report["total"] else 1)

    modules = split_csv(args.modules)
    prd_keywords = args.prd_keywords
    project = resolve_path(args.project, REPO_ROOT) if args.project else None
    if project and not modules:
        modules = extract_project_modules(project)
    if project and not prd_keywords:
        prd_keywords = compact_text(project_text(project)[:1000])
    output = args.output
    if output is None and project:
        output = project

    report = run_route(
        product=args.product,
        modules=modules,
        prd_keywords=prd_keywords,
        gates=split_csv(args.gates),
        config=config,
        root=root,
        synonyms=synonyms,
        reference_roots=reference_roots,
        top_k=top_k,
    )
    write_outputs(report, output)

    if args.format == "json":
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return

    summary = report["summary"]
    print(f"多轮检索完成: queries={summary['query_count']} hits={summary['hit_count']} unique={summary['unique_hit_count']}")
    print("未命中模块: " + (", ".join(summary["missed_modules"]) if summary["missed_modules"] else "无"))
    if output:
        print(f"已输出: {output.resolve() / 'knowledge_hits.json'}")
        print(f"已输出: {output.resolve() / 'knowledge_hits.md'}")


if __name__ == "__main__":
    main()
