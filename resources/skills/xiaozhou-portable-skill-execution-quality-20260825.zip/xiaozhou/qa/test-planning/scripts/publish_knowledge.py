import argparse
import json
import re
import subprocess
import sys
from datetime import date
from pathlib import Path


分类别名 = {
    "faq": "问答",
    "问答": "问答",
    "rule": "规则",
    "规则": "规则",
    "case": "案例",
    "案例": "案例",
    "glossary": "术语",
    "术语": "术语",
}

分类目录 = {
    "问答": "问答",
    "规则": "规则",
    "案例": "案例",
    "术语": "术语",
}

业务域标签 = {"app", "嵌入式", "iot", "手表", "app-iot"}


def 规范分类(分类值: str) -> str:
    原始值 = 分类值.strip()
    return 分类别名.get(原始值.lower(), 分类别名.get(原始值, 原始值))


def 生成文件名(value: str) -> str:
    text = value.strip()
    text = re.sub(r"\s+", "-", text)
    text = re.sub(r"[^\w\u4e00-\u9fff-]+", "-", text, flags=re.UNICODE)
    text = re.sub(r"-{2,}", "-", text).strip("-_")
    return text or "知识条目"


def 运行命令(command: list[str], cwd: Path) -> subprocess.CompletedProcess[str]:
    return subprocess.run(
        command,
        cwd=cwd,
        text=True,
        capture_output=True,
        encoding="utf-8",
        errors="replace",
    )


def 执行或退出(command: list[str], cwd: Path, 错误提示: str):
    result = 运行命令(command, cwd)
    if result.returncode != 0:
        print(错误提示)
        if result.stdout.strip():
            print(result.stdout.strip())
        if result.stderr.strip():
            print(result.stderr.strip())
        raise SystemExit(result.returncode)
    return result


def main():
    parser = argparse.ArgumentParser(description="新增或更新小周内置 QA 知识；默认本地保存并校验。")
    parser.add_argument("--category", "--分类", dest="category", required=True, choices=sorted(分类别名.keys()))
    parser.add_argument("--title", "--标题", dest="title", required=True)
    parser.add_argument("--author", "--作者", dest="author", default="codex-auto")
    parser.add_argument("--summary", "--摘要", dest="summary", required=True)
    parser.add_argument("--content", "--内容", dest="content", required=True)
    parser.add_argument("--tags", "--标签", dest="tags", default="", help="逗号分隔标签。")
    parser.add_argument("--slug", "--文件名", dest="slug", help="可选，自定义文件名，不带 .json。")
    parser.add_argument(
        "--repo-root",
        "--仓库根目录",
        dest="repo_root",
        default=Path(__file__).resolve().parents[2],
        type=Path,
        help="Git 仓库根目录。",
    )
    parser.add_argument(
        "--knowledge-root",
        "--知识库根目录",
        dest="knowledge_root",
        default=Path(__file__).resolve().parent.parent / "knowledge",
        type=Path,
        help="知识库根目录。",
    )
    parser.add_argument(
        "--git-sync",
        action="store_true",
        help="显式启用 Git pull/commit/push；默认仅更新内置知识快照。",
    )
    parser.add_argument(
        "--skip-pull",
        action="store_true",
        help="启用 --git-sync 时跳过写入前的 git pull。",
    )
    parser.add_argument(
        "--skip-push",
        action="store_true",
        help="启用 --git-sync 时只提交到本地，不推送远程。",
    )
    parser.add_argument(
        "--replace-existing",
        action="store_true",
        help="如果同名文件已存在，则直接覆盖更新。",
    )
    args = parser.parse_args()

    repo_root = args.repo_root.resolve()
    knowledge_root = args.knowledge_root.resolve()

    if args.git_sync and not (repo_root / ".git").exists():
        raise SystemExit(f"--git-sync 需要已配置的 Git 仓库: {repo_root}")

    if args.git_sync and not args.skip_pull:
        执行或退出(["git", "pull", "--rebase", "--autostash"], repo_root, "写入前同步远程仓库失败。")

    分类 = 规范分类(args.category)
    if 分类 not in 分类目录:
        raise SystemExit(f"不支持的分类：{args.category}")

    标签列表 = [tag.strip() for tag in args.tags.split(",") if tag.strip()]
    if not set(标签列表).intersection(业务域标签):
        raise SystemExit(f"至少需要一个业务域标签：{', '.join(sorted(业务域标签))}")

    文件名 = args.slug or 生成文件名(args.title)
    目标目录 = knowledge_root / 分类目录[分类]
    目标目录.mkdir(parents=True, exist_ok=True)
    目标路径 = 目标目录 / f"{文件名}.json"

    if 目标路径.exists() and not args.replace_existing:
        raise SystemExit(f"目标文件已存在：{目标路径}。如需覆盖，请加 --replace-existing。")

    payload = {
        "标题": args.title,
        "分类": 分类,
        "标签": 标签列表,
        "作者": args.author,
        "更新时间": date.today().isoformat(),
        "摘要": args.summary,
        "内容": args.content,
    }
    目标路径.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    验证脚本 = Path(__file__).resolve().parent / "validate_knowledge.py"
    执行或退出([sys.executable, str(验证脚本), "--root", str(knowledge_root)], repo_root, "知识库校验失败。")

    if not args.git_sync:
        print("内置 QA 知识更新完成并通过校验。")
        print(f"文件路径: {目标路径}")
        print("本次未要求 Git 同步。")
        return

    相对路径 = str(目标路径.relative_to(repo_root))
    执行或退出(["git", "add", 相对路径], repo_root, "暂存知识文件失败。")

    状态结果 = 执行或退出(["git", "status", "--short"], repo_root, "检查 Git 状态失败。")
    if not 状态结果.stdout.strip():
        print("没有检测到可提交的变更。")
        return

    提交说明 = f"docs: 更新知识库 - {args.title}"
    执行或退出(["git", "commit", "-m", 提交说明], repo_root, "提交知识库变更失败。")

    if not args.skip_push:
        执行或退出(["git", "push"], repo_root, "推送知识库变更失败。")

    print("知识库更新完成。")
    print(f"文件路径: {目标路径}")
    print(f"提交说明: {提交说明}")
    if args.skip_push:
        print("本次未推送远程仓库。")


if __name__ == "__main__":
    main()
