# Git 协作说明

1. 使用或编辑前先拉取最新版本
2. 新增知识前先检索是否已有相似条目
3. 在 `knowledge/` 下新增或更新知识条目
4. 执行 `python scripts/validate_knowledge.py`
5. 提交 commit，说明本次新增或更新了什么可复用知识

## 维护建议

- `SKILL.md` 只维护流程，不堆动态知识
- 模板和规范优先放 `references/`
- 高频经验与案例优先放 `knowledge/`
