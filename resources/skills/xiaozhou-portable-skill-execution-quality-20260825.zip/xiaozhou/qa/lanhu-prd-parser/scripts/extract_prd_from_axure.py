#!/usr/bin/env python3
import argparse
import html
import re
import warnings
from datetime import datetime
from pathlib import Path


KEYWORDS = (
    "需求", "功能", "规则", "入口", "页面", "弹窗", "toast", "提示",
    "默认", "支持", "不支持", "新增", "删除", "保存", "返回", "同步",
    "断连", "回连", "蓝牙", "心率", "数据项", "运动", "绑定", "设备",
    "APP", "app", "固件", "标志位", "置灰", "忽略", "本项目"
)


VERSION_HISTORY_NOISE = (
    "版本记录", "版本号", "修改记录", "修改时间", "修改人", "整理拟定",
    "删除通话相关功能", "删除语音助手", "删除游戏功能"
)


def is_version_history_noise(line: str) -> bool:
    if any(k in line for k in VERSION_HISTORY_NOISE):
        return True
    if re.fullmatch(r"V\d+(?:\.\d+){1,3}", line.strip(), flags=re.I):
        return True
    return False


def clean_text(text: str) -> str:
    text = html.unescape(text)
    text = re.sub(r"<script\b[^>]*>.*?</script>", "\n", text, flags=re.I | re.S)
    text = re.sub(r"<style\b[^>]*>.*?</style>", "\n", text, flags=re.I | re.S)
    text = re.sub(r"<[^>]+>", "\n", text)
    text = html.unescape(text)
    text = re.sub(r"\r\n?", "\n", text)
    text = re.sub(r"[ \t\f\v]+", " ", text)
    text = re.sub(r"\n\s*\n+", "\n", text)
    return text.strip()


def extract_strings_from_js(text: str) -> str:
    # Axure data.js often stores visible text as escaped HTML fragments.
    candidates = []
    for match in re.finditer(r'"((?:\\.|[^"\\]){4,})"', text):
        raw = match.group(1)
        try:
            with warnings.catch_warnings():
                warnings.simplefilter("ignore", DeprecationWarning)
                value = bytes(raw, "utf-8").decode("unicode_escape")
        except Exception:
            value = raw
        if any(k in value for k in KEYWORDS) or re.search(r"[\u4e00-\u9fff]{2,}", value):
            candidates.append(value)
    return "\n".join(candidates)


def iter_sources(path: Path):
    if path.is_file():
        yield path
        return
    patterns = ("*.html", "*.htm", "*_data.js", "data.js", "*.js")
    seen = set()
    for pattern in patterns:
        for p in sorted(path.rglob(pattern)):
            if p not in seen:
                seen.add(p)
                yield p


def useful_lines(text: str):
    out = []
    for line in clean_text(text).splitlines():
        line = re.sub(r"\s+", " ", line).strip()
        if not line:
            continue
        if len(line) <= 1:
            continue
        if is_version_history_noise(line):
            continue
        if any(k in line for k in KEYWORDS) or re.search(r"[\u4e00-\u9fff]{2,}", line):
            out.append(line)
    # de-duplicate while preserving order
    result = []
    seen = set()
    for line in out:
        key = line[:200]
        if key not in seen:
            seen.add(key)
            result.append(line)
    return result


def parse_crop(value: str):
    if not value:
        return None
    parts = [p.strip() for p in value.split(",")]
    if len(parts) != 4:
        raise SystemExit("--ocr-crop must be formatted as left,top,right,bottom")
    try:
        return tuple(int(p) if p else None for p in parts)
    except ValueError as exc:
        raise SystemExit("--ocr-crop only accepts integer pixel values") from exc


def iter_ocr_images(path: Path):
    if path.is_file() and path.suffix.lower() in {".png", ".jpg", ".jpeg", ".bmp", ".webp"}:
        if "版本记录" not in path.stem and "修改记录" not in path.stem:
            yield path
        return
    if not path.exists():
        raise SystemExit(f"ocr image path not found: {path}")
    for pattern in ("*.png", "*.jpg", "*.jpeg", "*.bmp", "*.webp"):
        for image in sorted(path.rglob(pattern)):
            if "版本记录" in image.stem or "修改记录" in image.stem:
                continue
            yield image


def iter_ocr_tiles(image, tile_max_pixels=4_000_000, overlap=48):
    """Yield bounded RGB tiles as ``(image, x_offset, y_offset)``.

    Large design screenshots are often extremely tall. Converting the whole
    image to a NumPy array can exhaust memory, so tile before materialization.
    """
    width, height = image.size
    max_pixels = max(250_000, int(tile_max_pixels))
    if width * height <= max_pixels:
        yield image, 0, 0
        return
    tile_height = max(256, max_pixels // max(1, width))
    tile_height = min(tile_height, height)
    step = max(1, tile_height - max(0, int(overlap)))
    top = 0
    while top < height:
        bottom = min(height, top + tile_height)
        yield image.crop((0, top, width, bottom)), 0, top
        if bottom >= height:
            break
        top += step


def _ocr_tile(engine, np, tile, x_offset, y_offset, min_confidence):
    result, _ = engine(np.asarray(tile, dtype=np.uint8))
    rows = []
    for box, text, score in result or []:
        if score < min_confidence:
            continue
        text = re.sub(r"\s+", " ", text).strip()
        if len(text) <= 1:
            continue
        if not (any(k in text for k in KEYWORDS) or re.search(r"[\u4e00-\u9fff]{2,}", text)):
            continue
        xs = [p[0] + x_offset for p in box]
        ys = [p[1] + y_offset for p in box]
        rows.append((sum(ys) / len(ys), min(xs), text))
    return rows


def ocr_image_lines(
    image_path: Path, engine, crop=None, min_confidence=0.75, tile_max_pixels=4_000_000, tile_overlap=48
):
    try:
        from PIL import Image
        import numpy as np
    except ImportError as exc:
        raise SystemExit("OCR requires pillow and numpy. Install from the bundled QA root: python -m pip install -r requirements.txt") from exc

    rows = []
    with Image.open(image_path) as source:
        image = source
        if crop:
            left, top, right, bottom = crop
            width, height = image.size
            box = (
                max(0, left or 0),
                max(0, top or 0),
                min(width, right if right is not None else width),
                min(height, bottom if bottom is not None else height),
            )
            image = image.crop(box)
        for tile, x_offset, y_offset in iter_ocr_tiles(image, tile_max_pixels, tile_overlap):
            rgb = tile.convert("RGB")
            try:
                rows.extend(_ocr_tile(engine, np, rgb, x_offset, y_offset, min_confidence))
            except (MemoryError, OSError) as exc:
                if rgb.size[0] * rgb.size[1] <= 500_000:
                    raise RuntimeError(f"OCR tile failed after memory-safe split: {image_path}: {exc}") from exc
                for retry, retry_x, retry_y in iter_ocr_tiles(rgb, max(250_000, tile_max_pixels // 4), tile_overlap // 2):
                    rows.extend(_ocr_tile(engine, np, retry.convert("RGB"), x_offset + retry_x, y_offset + retry_y, min_confidence))

    rows.sort(key=lambda item: (item[0], item[1]))
    grouped = []
    for y, x, text in rows:
        if not grouped or abs(grouped[-1][0] - y) > 16:
            grouped.append([y, [(x, text)]])
        else:
            grouped[-1][1].append((x, text))

    lines = []
    for _, cells in grouped:
        cells.sort(key=lambda item: item[0])
        line = " ".join(text for _, text in cells)
        line = re.sub(r"\s+", " ", line).strip()
        if line:
            lines.append(line)

    result_lines = []
    seen = set()
    for line in lines:
        key = line[:200]
        if is_version_history_noise(line):
            continue
        if key not in seen:
            seen.add(key)
            result_lines.append(line)
    return result_lines


def classify(lines):
    sections = {
        "页面与入口": [],
        "主流程": [],
        "功能规则": [],
        "数据项与字段": [],
        "异常与边界": [],
        "适用范围与裁剪": [],
        "待确认项": [],
        "原始需求摘录": [],
    }
    for line in lines:
        target = "原始需求摘录"
        if any(k in line for k in ("入口", "页面", "按钮", "弹窗", "toast", "提示")):
            target = "页面与入口"
        if any(k in line for k in ("流程", "发起", "点击", "返回", "保存", "添加", "删除", "开始", "结束", "暂停", "继续")):
            target = "主流程"
        if any(k in line for k in ("规则", "默认", "最多", "至少", "支持", "不支持", "标志位", "倒计时")):
            target = "功能规则"
        if any(k in line for k in ("数据项", "字段", "心率", "步数", "距离", "配速", "速度", "卡路里", "用时", "热量")):
            target = "数据项与字段"
        if any(k in line for k in ("断连", "回连", "失败", "关闭", "异常", "权限", "杀掉", "关机", "重启")):
            target = "异常与边界"
        if any(k in line for k in ("本项目", "忽略", "置灰", "灰", "不适用")):
            target = "适用范围与裁剪"
        if any(k in line for k in ("待确认", "需确认", "建议", "未明确")):
            target = "待确认项"
        sections[target].append(line)
    return sections


def main():
    parser = argparse.ArgumentParser(description="Extract a PRD Markdown draft from Lanhu/Axure HTML/JS files.")
    parser.add_argument("--input", "-i", required=True, help="Lanhu/Axure exported file or folder")
    parser.add_argument("--output", "-o", required=True, help="Output Markdown path")
    parser.add_argument("--title", default="", help="Document title")
    parser.add_argument("--ocr-images", default="", help="Optional screenshot/image file or folder to OCR")
    parser.add_argument("--ocr-crop", default="", help="Optional OCR crop box in pixels: left,top,right,bottom")
    parser.add_argument("--ocr-min-confidence", type=float, default=0.75, help="Minimum OCR confidence")
    parser.add_argument("--ocr-tile-max-pixels", type=int, default=4_000_000, help="Maximum pixels per OCR tile")
    parser.add_argument("--ocr-tile-overlap", type=int, default=48, help="Vertical overlap between OCR tiles")
    args = parser.parse_args()

    src = Path(args.input).resolve()
    out = Path(args.output).resolve()
    if not src.exists():
        raise SystemExit(f"input not found: {src}")

    pages = []
    all_lines = []
    for file in iter_sources(src):
        try:
            raw = file.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            continue
        text = raw
        if file.suffix.lower() == ".js":
            text = extract_strings_from_js(raw)
        lines = useful_lines(text)
        if lines:
            pages.append((file, lines))
            all_lines.extend(lines)

    if args.ocr_images:
        try:
            from rapidocr_onnxruntime import RapidOCR
        except ImportError as exc:
            raise SystemExit(
                "OCR requires rapidocr-onnxruntime. Install from the bundled QA root: python -m pip install -r requirements.txt"
            ) from exc
        engine = RapidOCR()
        crop = parse_crop(args.ocr_crop)
        for image in iter_ocr_images(Path(args.ocr_images).resolve()):
            lines = ocr_image_lines(
                image, engine, crop=crop, min_confidence=args.ocr_min_confidence,
                tile_max_pixels=args.ocr_tile_max_pixels, tile_overlap=args.ocr_tile_overlap,
            )
            if lines:
                pages.append((image, lines))
                all_lines.extend(lines)

    sections = classify(all_lines)
    title = args.title or f"{src.stem} PRD 需求解析"
    md = [
        f"# {title}",
        "",
        "## 1. 需求来源",
        f"- 来源文件：{src}",
        f"- 解析时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
        "- 说明：本文件为自动抽取初稿，需结合蓝湖页面和图片复核。",
        "",
        "## 2. 功能概述",
        "- 待人工根据下方需求摘录归纳。",
        "",
    ]

    order = [
        ("适用范围与裁剪", "## 3. 适用范围与裁剪"),
        ("页面与入口", "## 4. 页面与入口"),
        ("主流程", "## 5. 主流程"),
        ("功能规则", "## 6. 功能规则"),
        ("数据项与字段", "## 7. 数据项与字段"),
        ("异常与边界", "## 8. 异常与边界"),
        ("待确认项", "## 9. 待确认项"),
        ("原始需求摘录", "## 10. 原始需求摘录"),
    ]
    for key, heading in order:
        md.append(heading)
        lines = sections.get(key, [])
        if not lines:
            md.append("- 暂无明确摘录。")
        else:
            for line in lines[:300]:
                md.append(f"- {line}")
            if len(lines) > 300:
                md.append(f"- ……已截断，剩余 {len(lines) - 300} 条请查看源文件。")
        md.append("")

    md.append("## 11. 页面来源索引")
    for file, lines in pages:
        source_type = "OCR" if file.suffix.lower() in {".png", ".jpg", ".jpeg", ".bmp", ".webp"} else "文本"
        md.append(f"- [{source_type}] {file.name}：{len(lines)} 条文本")
    md.append("")

    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text("\n".join(md), encoding="utf-8")
    print(f"wrote {out}")
    print(f"source files: {len(pages)}")
    print(f"lines: {len(all_lines)}")


if __name__ == "__main__":
    main()
