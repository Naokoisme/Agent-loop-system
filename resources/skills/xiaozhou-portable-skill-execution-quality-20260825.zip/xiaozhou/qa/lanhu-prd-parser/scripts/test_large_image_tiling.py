from __future__ import annotations

import importlib.util
from pathlib import Path

from PIL import Image


SCRIPT = Path(__file__).resolve().parent / "extract_prd_from_axure.py"
spec = importlib.util.spec_from_file_location("lanhu_large_image_regression", SCRIPT)
if not spec or not spec.loader:
    raise RuntimeError(f"cannot load {SCRIPT}")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def main() -> None:
    image = Image.new("RGB", (2000, 12000), "white")
    tiles = list(module.iter_ocr_tiles(image, tile_max_pixels=2_000_000, overlap=48))
    assert len(tiles) > 1, "large image was not tiled"
    assert all(tile.size[0] * tile.size[1] <= 2_000_000 for tile, _, _ in tiles), "tile exceeded memory bound"
    assert tiles[0][2] == 0
    assert tiles[-1][2] + tiles[-1][0].size[1] == image.size[1]
    print(f"PASS tiles={len(tiles)} max_pixels={max(tile.size[0] * tile.size[1] for tile, _, _ in tiles)}")


if __name__ == "__main__":
    main()
