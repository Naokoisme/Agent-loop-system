---
name: lanhu-prd-parser
description: 当用户提供蓝湖/Lanhu 链接、Lanhu invite URL、蓝湖截图、Axure/Lanhu 原型导出 HTML/JS，或要求拉取、解析、整理蓝湖设计稿需求为 Markdown PRD 文档时使用。该 skill 只负责先把设计稿解析成 PRD 需求文档，不直接生成测试用例，除非用户明确要求跳过 PRD 解析。
---

# 蓝湖 PRD 解析专家

## 核心规则

用户给蓝湖链接、蓝湖分享信息、Lanhu invite URL、蓝湖截图、Axure/Lanhu 导出文件时，先输出 PRD Markdown 文档，再进入测试设计。不要直接跳到测试用例，除非用户明确说跳过 PRD 解析。

## 工作流程

1. 确认访问条件
   - 链接需要登录时，先让用户完成登录。
   - 用户确认已登录后，继续使用当前浏览器会话或本地下载资源解析。
   - 无法访问页面时，让用户提供导出的 HTML/JS、截图或页面资源。
2. 收集源材料
   - 优先使用 Axure/Lanhu 导出的 HTML 页面、`*_data.js`、mapping 文件和资源图片。
   - 保留页面名称、入口、可见文字、红字/灰字标注、置灰内容、截图名和页面流转关系。
3. 提取原始需求
   - 本地存在 HTML/JS 时，优先运行 `scripts/extract_prd_from_axure.py`。
   - 页面文字在 canvas 或图片中无法提取时，必须结合截图 OCR。大图必须自动分块后逐块识别，禁止先把整张超大图转成 NumPy 数组；遇到内存异常继续缩小图块重试并记录失败图块。
   - OCR 结果不完整时，把不确定内容放入 `待确认项`。
4. 归类整理
   - 功能范围
   - 页面/入口
   - 交互流程
   - 状态与规则
   - 数据项
   - 异常/边界
   - 适用/不适用内容
   - 待确认项
5. 输出 Markdown
   - 输出 `<项目/模块>_PRD需求解析.md`。
   - 先给 PRD 解析文档，不要混入测试用例表。

## Markdown 结构

```markdown
# <项目/模块> PRD 需求解析

## 1. 需求来源
- 来源链接/文件：
- 解析时间：
- 适用项目/设备：

## 2. 功能概述

## 3. 适用范围与裁剪
- 适用：
- 不适用：
- 置灰/忽略内容：

## 4. 页面与入口

## 5. 主流程

## 6. 功能规则

## 7. 数据项与字段

## 8. 异常与边界

## 9. 交叉场景

## 10. 待确认项
```

## 解析规则

- 灰色/置灰内容不要直接丢弃，先放到 `置灰/忽略内容`，除非用户明确说适用或不适用。
- `版本记录`、`修改记录` 只作为来源元数据，不转换成功能规则、测试点、裁剪依据或待确认项，除非功能页重复出现同一要求。
- 必须保留明确数值、toast 文案、选项名、计时、数量、默认值、重置规则。
- UI 注释只有描述产品行为时才转换成需求规则。
- 区分原文和推断；推断内容前加 `推断：`。
- 不补写 PRD 没写的细节；缺失值放到 `待确认项`。
- OCR 内容必须标明来源页面或截图，识别不清的文字不要当成确定规则。

## 输出规则

- PRD 文档要简洁，但必须足够支撑后续测试用例设计。
- 不使用“符合 PRD”“正常”“按规则处理”等模糊描述。
- 输出完成后，在对话里给出简短置信度说明，包括源材料覆盖情况和待确认项。

## 脚本

解析本地 HTML/JS：

```powershell
python scripts/extract_prd_from_axure.py --input "<folder-or-file>" --output "<项目或模块>_PRD需求解析.md"
```

解析截图并结合 OCR：

```powershell
python scripts/extract_prd_from_axure.py --input "<folder-or-file>" --ocr-images "<screenshots-folder>" --ocr-crop "260,50,," --output "<项目或模块>_PRD需求解析.md"
```

超大长图默认按不超过 400 万像素的图块识别，可按机器内存调整：

```powershell
python scripts/extract_prd_from_axure.py --input "<folder-or-file>" --ocr-images "<screenshots-folder>" --ocr-tile-max-pixels 2000000 --ocr-tile-overlap 48 --output "<项目或模块>_PRD需求解析.md"
```

脚本输出只能作为初稿，交付前必须人工对照蓝湖页面、截图、OCR 文本和资源文件复核。
