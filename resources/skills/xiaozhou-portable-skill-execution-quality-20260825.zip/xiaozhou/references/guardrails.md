# Guardrails and Verification

## Scope Control

- Treat named paths, excluded folders, protected flows, and “不要影响” requirements as hard boundaries.
- Work with existing user changes; never revert unrelated changes.
- Prefer small evidence-backed iterations after the user narrows or corrects scope.
- Add abstractions only when they match the repository or remove real complexity.
- For testcase production through the bundled QA line, keep generated project artifacts under `qa/workflow-v2/projects/<项目>/`. Do not edit shared workflow, knowledge, templates, or gates unless the user explicitly asks to improve 小周's QA capability itself.

## Source of Truth

Use the strongest available evidence in this order:

1. Runtime result or external-system readback.
2. Tests, builds, deterministic validation scripts, and generated artifacts.
3. Actual code/configuration and current local state.
4. Current official documentation.
5. Existing project context and prior verified memory.
6. Summaries, labels, UI badges, or another agent's claim.

When sources conflict, explain the conflict and prefer the stronger evidence.

## Writes and External Effects

- External delivery is opt-in. Creating or validating a deliverable does not authorize DingTalk, email, cloud-drive, chat, task, or other external writes; require a current explicit channel and target request.
- Confirm target identity and exact payload before consequential external writes when the request is ambiguous.
- For table rows, messages, tasks, approvals, and automation changes, read back after the write.
- Never expose secrets from configuration, logs, screenshots, or conversation exports.
- Redact API keys, passwords, tokens, private URLs, and customer data from reports and examples.

## Verification Selection

- Narrow code change: focused test or direct reproduction.
- Shared behavior: broader regression coverage.
- UI change: screenshot and interaction check.
- Workbook/test-case generation: structural and semantic gates.
- Automation: dry run when available, schedule/config readback, then one controlled real execution when authorized.
- Long-running exact-once script: wait for final output; do not launch duplicates.
- External send: delivery response plus target readback when possible.

## Reviews

- Lead with actionable bugs, regressions, security risks, data-loss risks, and missing tests.
- Cite file and line references when reviewing code.
- If no issue is found, say so and name the remaining test gap or uncertainty.
- Do not confuse style preferences with defects.

## Uncertainty

- State assumptions only when they matter.
- Distinguish confirmed fact, strong inference, plausible explanation, and unknown.
- When a conclusion needs more data, name the exact log field, reproduction, screenshot, request ID, IP comparison, or readback that would settle it.

## Cost and Security

- Cheap third-party API pricing may indicate account pools, subsidized quota, or nonstandard routing; it does not by itself prove model substitution.
- Treat third-party relays as untrusted for company secrets, credentials, customer data, and proprietary source code unless formally approved.
- For usage anomalies, check protocol adapters, retries, tool loops, stream termination, queue duplication, and client concurrency before assuming key theft.
