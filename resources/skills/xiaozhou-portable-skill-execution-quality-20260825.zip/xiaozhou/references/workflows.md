# Reusable Workflows

## Resume Existing Work

1. Read the newest `.codex/context`, handoff, worklog, spec, plan, and task state when present.
2. Inspect recent artifacts and current runtime state.
3. Continue the unfinished step; do not restart discovery from an older summary.
4. Preserve user edits and unrelated dirty-worktree changes.

## Code, Debugging, and Project Questions

- Inspect actual code paths before asserting capabilities or causes.
- Prefer existing patterns and helpers over introducing a new architecture.
- For diagnosis, show the concrete cause chain: trigger -> failing component -> observed symptom.
- For implementation, keep the patch scoped and verify the affected path plus nearby shared behavior.
- When asked whether a folder can be handed to another team, inspect the real runtime and dependency boundary and name the exact deliverable.

## Testing and Test-Case Work

- For PRD, requirement, Lanhu/prototype, testcase generation, or testcase workbook review, read [qa-testcase-delivery.md](qa-testcase-delivery.md) and route through the authoritative QA production line bundled at `../qa/`.
- Do not replace that production line with a generic checklist, a chat-only table, or newly invented testcase rules.
- Treat requirements, screenshots, existing workbooks, and baseline cases as source material, not decoration.
- Make `测试项` describe verification intent, not merely repeat action steps.
- Cover normal, boundary, abnormal, cross-feature, stability, compatibility, interruption, recovery, and state-persistence behavior when relevant.
- Turn prose quality rules into executable or mechanical gates when possible.
- When one workbook row reveals a semantic issue, inspect sibling rows or the full workbook for the same pattern.
- Separate generated quantity from useful coverage; more rows are not proof of better testing.
- Treat PRD traceability and scenario completeness as separate release axes; both must pass before saying “全功能完整”.
- The fixed QA workflow ends at a validated, ready artifact. DingTalk/email/cloud-drive delivery is optional and needs a current explicit channel and target request.

## Requirements to Automation

Keep the staged boundary clear:

```text
PRD or design -> deliverable human-readable test cases -> automation-executable test cases -> automation execution plan -> tool execution -> evidence
```

Do not claim that an old protocol, command name, or README proves current execution capability. Confirm current adapters, capability files, probes, and runtime behavior.

## Screenshots, UI, and Visual Artifacts

- Use the screenshot as the layout and content source of truth when the user says to match it.
- Inspect the image directly; do not infer critical spacing or labels from filenames.
- Rebuild the runnable artifact when requested, then verify at relevant desktop/mobile sizes.
- Check text fit, overlap, empty canvases, missing assets, and interaction states.
- Return a visible fresh artifact when the user says they cannot see the update.

## Documents and Reports

- Produce ready-to-forward Chinese Markdown, workbook, image, or document artifacts when requested.
- Separate completed, verified, and pending work.
- Include exact evidence and unresolved risk without dumping internal process narration.
- For weekly summaries, preserve the requested row semantics and visible fields exactly.

## DingTalk and Office Automation

- Use the dedicated connector or DWS skill when available.
- Before writes, resolve the target document/table, sheet/view, field schema, person identity, and time range.
- Preview the rows/messages or summarize the exact write set when risk warrants it.
- After writing, read back created or updated records.
- Distinguish webhook delivery, current-user delivery, bot delivery, and merely generating an image.
- For exact-once automations, run once, wait for completion, and use final structured output as truth. Do not retry just because intermediate output is quiet.

## API Billing and Usage Analysis

Always separate these concepts:

1. Official model token price.
2. Platform billing multiplier.
3. Recharge exchange rate or reseller markup.
4. Prompt input, output, cache creation, and cache read tokens.
5. The user's final RMB cost.

- Recalculate sample rows from token fields.
- Compare like-for-like time ranges, models, and workloads.
- Check duplicate request IDs, failed-request charges, retry storms, and cache rebuild patterns.
- Do not infer model authenticity from a provider label alone.
- For abnormal volume, compare client ingress requests with upstream forwards before assigning blame to the user or relay.

## Git and Delivery

- For synchronization, fetch first, compare local and remote state, then explain merge impact before pulling or merging.
- Preserve explicit exclusions and secret hygiene.
- Do not use destructive reset or checkout operations without clear authorization.
- For packaging, inspect imports, runtime files, environment variables, native dependencies, and startup scripts.
