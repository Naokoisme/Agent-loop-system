from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import zipfile
from pathlib import Path


XIAOZHOU_ROOT = Path(__file__).resolve().parents[1]
QA_ROOT = XIAOZHOU_ROOT / "qa"
EXCLUDED_DIR_NAMES = {".git", ".venv", "venv", "__pycache__"}
EXCLUDED_SUFFIXES = {".pyc", ".pyo", ".log", ".tmp", ".temp"}
QA_RUNTIME_SPREADSHEET_SUFFIXES = {".xls", ".xlsx", ".xlsm", ".xlsb"}


def excluded(path: Path) -> bool:
    relative = path.relative_to(XIAOZHOU_ROOT)
    if any(part in EXCLUDED_DIR_NAMES for part in relative.parts):
        return True
    if path.suffix.lower() in EXCLUDED_SUFFIXES:
        return True
    qa_runtime = Path("qa") / "workflow-v2"
    if relative.is_relative_to(qa_runtime / "projects"):
        return True
    if relative.is_relative_to(qa_runtime / "prd"):
        return True
    if relative.is_relative_to(qa_runtime) and path.suffix.lower() in QA_RUNTIME_SPREADSHEET_SUFFIXES:
        return True
    return False


def run_check(script: Path) -> dict[str, object]:
    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    completed = subprocess.run(
        [sys.executable, str(script), "--json"],
        cwd=QA_ROOT,
        env=env,
        text=True,
        capture_output=True,
        encoding="utf-8",
        errors="replace",
    )
    if completed.returncode != 0:
        if completed.stdout:
            print(completed.stdout)
        if completed.stderr:
            print(completed.stderr, file=sys.stderr)
        raise SystemExit(completed.returncode)
    return json.loads(completed.stdout)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description="Validate and package the complete portable Xiaozhou skill.")
    parser.add_argument(
        "--output",
        type=Path,
        default=Path.cwd() / "xiaozhou-portable-skill.zip",
        help="Destination ZIP path.",
    )
    parser.add_argument("--skip-smoke", action="store_true", help="Skip runtime smoke test; package verification still runs.")
    parser.add_argument("--json", action="store_true", help="Print machine-readable JSON.")
    args = parser.parse_args()

    verification = run_check(QA_ROOT / "scripts" / "verify_portable_package.py")
    quick_validation = run_check(QA_ROOT / "scripts" / "quick_validate.py")
    smoke = None if args.skip_smoke else run_check(QA_ROOT / "scripts" / "smoke_test.py")

    output = args.output.expanduser().resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        output.unlink()

    files = [path for path in XIAOZHOU_ROOT.rglob("*") if path.is_file() and not excluded(path)]
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in sorted(files):
            relative = path.relative_to(XIAOZHOU_ROOT)
            archive.write(path, Path("xiaozhou") / relative)

    required_entries = {
        "xiaozhou/qa/workflow-v2/scripts/build_lock.py",
        "xiaozhou/qa/workflow-v2/scripts/casegen.py",
        "xiaozhou/qa/workflow-v2/scripts/check_structure.py",
        "xiaozhou/qa/workflow-v2/scripts/execution_profile.py",
        "xiaozhou/qa/workflow-v2/scripts/execution_quality_gate.py",
        "xiaozhou/qa/workflow-v2/scripts/export_cases.py",
        "xiaozhou/qa/workflow-v2/scripts/feedback_pattern_gate.py",
        "xiaozhou/qa/workflow-v2/scripts/generation_contract.py",
        "xiaozhou/qa/workflow-v2/scripts/stratified_acceptance_sample.py",
        "xiaozhou/qa/workflow-v2/scripts/release_acceptance.py",
        "xiaozhou/qa/workflow-v2/scripts/lineage.py",
        "xiaozhou/qa/workflow-v2/scripts/judge_build.py",
        "xiaozhou/qa/workflow-v2/scripts/quality_semantics.py",
        "xiaozhou/qa/workflow-v2/scripts/project_paths.py",
        "xiaozhou/qa/workflow-v2/scripts/stable_ids.py",
        "xiaozhou/qa/workflow-v2/scripts/tc_excel.py",
        "xiaozhou/qa/workflow-v2/scripts/test_feedback_sampling_regressions.py",
        "xiaozhou/qa/workflow-v2/scripts/test_execution_quality_regressions.py",
        "xiaozhou/qa/workflow-v2/scripts/test_generation_contract_regressions.py",
        "xiaozhou/qa/workflow-v2/scripts/test_lightweight_routing_regressions.py",
        "xiaozhou/qa/workflow-v2/scripts/test_quality_regressions.py",
        "xiaozhou/qa/workflow-v2/scripts/test_release_acceptance_regressions.py",
        "xiaozhou/qa/workflow-v2/scripts/test_stable_ids.py",
        "xiaozhou/qa/workflow-v2/scripts/work_unit_contract.py",
        "xiaozhou/qa/CAPABILITY_MANIFEST.json",
    }
    with zipfile.ZipFile(output, "r") as archive:
        names = {name.replace("\\", "/") for name in archive.namelist()}
        missing_entries = sorted(required_entries - names)
        forbidden_entries = sorted(
            name for name in names
            if any(part in EXCLUDED_DIR_NAMES for part in Path(name).parts)
            or Path(name).suffix.lower() in EXCLUDED_SUFFIXES
            or "/qa/workflow-v2/projects/" in f"/{name}"
            or "/qa/workflow-v2/prd/" in f"/{name}"
            or (
                "/qa/workflow-v2/" in f"/{name}"
                and Path(name).suffix.lower() in QA_RUNTIME_SPREADSHEET_SUFFIXES
            )
        )
    if missing_entries or forbidden_entries:
        output.unlink(missing_ok=True)
        raise SystemExit(
            f"ZIP verification failed: missing={missing_entries}, forbidden={forbidden_entries[:20]}"
        )

    result = {
        "success": True,
        "output": str(output),
        "bytes": output.stat().st_size,
        "sha256": sha256(output),
        "files": len(files),
        "verification": verification,
        "quick_validation": quick_validation,
        "smoke": smoke,
        "zip_verification": {
            "entry_count": len(names),
            "missing_required_entries": missing_entries,
            "forbidden_entries": forbidden_entries,
        },
    }
    if args.json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print(f"Portable skill package: {output}")
        print(f"Files: {result['files']}")
        print(f"SHA-256: {result['sha256']}")


if __name__ == "__main__":
    main()
